import { Component, OnInit } from '@angular/core';
import { IonApp, IonRouterOutlet } from '@ionic/angular/standalone';
import { CommonModule } from '@angular/common';
import { AuthService } from './core/services/auth.service';
import { SessionService } from './core/services/session.service';
import { PatientSyncService } from './core/services/patient-sync.service';
@Component({
  selector: 'app-root',
  standalone: true,
  template: `
    <ion-app>
      <ion-router-outlet></ion-router-outlet>
    </ion-app>
  `,
  imports: [
    CommonModule,
    IonApp,
    IonRouterOutlet,
  ],
})
export class AppComponent implements OnInit {
  constructor(
    private authService: AuthService,
    private sessionService: SessionService,
    private patientSyncService: PatientSyncService
  ) {}

  ngOnInit() {
    this.initializeApp();
  }

  private initializeApp(): void {
    console.log('🚀 Remedi App Initializing...');

    // Initialize authentication system
    // Session service auto-initializes and restores session if available
    console.log('📱 Platform:', this.sessionService.currentSession?.platform || 'Unknown');

    // Initialize background patient sync service
    // This will automatically sync offline patients when device comes online
    console.log(' Patient Sync Service initialized for background sync');


    // Log session status for debugging
    setTimeout(() => {
      const sessionInfo = this.authService.getSessionInfo();
      console.log('🔐 Session Status:', sessionInfo);
    }, 1000);
  }
}
