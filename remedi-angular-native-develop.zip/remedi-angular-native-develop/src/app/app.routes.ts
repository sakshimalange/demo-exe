import { Routes } from '@angular/router';
import { AuthGuard } from './core/auth/auth.guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: 'home',
    loadComponent: () => import('./home/home.page').then(m => m.HomePage),
  },
  {
    path: 'login',
    loadComponent: () => import('./modules/login/login/login.page').then(m => m.LoginPage),
  },
  {
    path: 'forgot-password',
    loadComponent: () => import('./modules/login/forgot-password/forgot-password.page').then(m => m.ForgotPasswordPage),
  },
  {
    path: 'register-patient',
    loadComponent: () => import('./modules/login/patient-registration/patient-registration.page').then(m => m.PatientRegistrationPage)
  },
  {
    path: 'dashboard',
    loadComponent: () => import('./modules/consultation/dashboard/dashboard.page').then(m => m.DashboardPage),
    canActivate: [AuthGuard]
  },
  {
    path: 'doctor-dashboard',
    loadComponent: () => import('./modules/doctor-dashboard/doctor-dashboard.page').then(m => m.DoctorDashboardPage),
    canActivate: [AuthGuard]
  },
  {
    path: 'search-patient-list',
    loadComponent: () => import('./modules/doctor-dashboard/search-patient-list/search-patient-list.page').then(m => m.SearchPatientListPage)
  },
  {
    path: 'patient-details',
    loadComponent: () => import('./modules/doctor-dashboard/patient-details/patient-details.page').then(m => m.PatientDetailsPage)
  },

  // PRMS BLE & USB DEVICE ROUTES
  { path: 'thermometer', loadComponent: () => import('./modules/prms/ble-device/thermometer/thermometer.page').then(m => m.ThermometerPage) },
  { path: 'parameter', loadComponent: () => import('./modules/prms/parameter/parameter.page').then(m => m.ParameterPage) },
  { path: 'spo2-device', loadComponent: () => import('./modules/prms/ble-device/spo2-device/spo2-device.page').then(m => m.Spo2DevicePage) },
  { path: 'common-dialog', loadComponent: () => import('./modules/common/common-dialog/common-dialog.page').then(m => m.CommonDialogPage) },
  { path: 'icare-device', loadComponent: () => import('./modules/prms/ble-device/icare-device/icare-device.page').then(m => m.IcareDevicePage) },
  { path: 'spo2-manual-entry', loadComponent: () => import('./modules/prms/ble-device/spo2-manual-entry/spo2-manual-entry.page').then(m => m.Spo2ManualEntryPage) },
  { path: 'icare-spo2', loadComponent: () => import('./modules/prms/ble-device/icare-spo2/icare-spo2.page').then(m => m.IcareSpo2Page) },
  { path: 'icare-thermometer', loadComponent: () => import('./modules/prms/ble-device/icare-thermometer/icare-thermometer.page').then(m => m.IcareThermometerPage) },
  { path: 'rapid-test', loadComponent: () => import('./modules/prms/usb-device/rapid-test/rapid-test.page').then(m => m.RapidTestPage) },
  { path: 'icare-rapid-test', loadComponent: () => import('./modules/prms/usb-device/icare-rapid-test/icare-rapid-test.page').then(m => m.IcareRapidTestPage) },
  { path: 'hemoglobin', loadComponent: () => import('./modules/prms/usb-device/hemoglobin/hemoglobin.page').then(m => m.HemoglobinPage) },
  { path: 'ecg-jetty-device', loadComponent: () => import('./modules/prms/ble-device/ecg-jetty-device/ecg-jetty-device.page').then(m => m.EcgJettyDevicePage) },
  { path: 'ecg-icare-device', loadComponent: () => import('./modules/prms/ble-device/ecg-icare-device/ecg-icare-device.page').then(m => m.EcgIcareDevicePage) },
  { path: 'stethoscope-device', loadComponent: () => import('./modules/prms/ble-device/stethoscope-device/stethoscope-device.page').then(m => m.StethoscopeDevicePage) },
  { path: 'blood-pressure-icare', loadComponent: () => import('./modules/prms/ble-device/blood-pressure-icare/blood-pressure-icare.page').then(m => m.BloodPressureIcarePage) },
  { path: 'blood-pressure-jetty', loadComponent: () => import('./modules/prms/ble-device/blood-pressure-jetty/blood-pressure-jetty.page').then(m => m.BloodPressureJettyPage) },
  { path: 'glucometer', loadComponent: () => import('./modules/prms/ble-device/glucometer/glucometer.page').then(m => m.GlucometerPage) },
  { path: 'hba1c', loadComponent: () => import('./modules/prms/usb-device/hba1c/hba1c.page').then(m => m.Hba1cPage) },
  { path: 'lipid-icare', loadComponent: () => import('./modules/prms/usb-device/lipid-icare/lipid-icare.page').then(m => m.LipidIcarePage) },
  { path: 'lipid-profile', loadComponent: () => import('./modules/prms/usb-device/lipid-profile/lipid-profile.page').then(m => m.LipidProfilePage) },
  { path: 'hb-a1c-ble-device', loadComponent: () => import('./modules/prms/ble-device/hb-a1c-ble-device/hb-a1c-ble-device.page').then(m => m.HbA1cBleDevicePage) },
  { path: 'hemoglobin-jetty', loadComponent: () => import('./modules/prms/usb-device/hemoglobin-jetty/hemoglobin-jetty.page').then(m => m.HemoglobinJettyPage) },
  { path: 'icare-urine-test', loadComponent: () => import('./modules/prms/usb-device/icare-urine-test/icare-urine-test.page').then(m => m.IcareUrineTestPage) },
  { path: 'urine-test', loadComponent: () => import('./modules/prms/usb-device/urine-test/urine-test.page').then(m => m.UrineTestPage) },
  { path: 'glucose', loadComponent: () => import('./modules/prms/usb-device/glucose/glucose.page').then(m => m.GlucosePage) },
  { path: 'glucose-ble', loadComponent: () => import('./modules/prms/ble-device/glucose-ble/glucose-ble.page').then(m => m.GlucoseBlePage) },
  { path: 'spirometer-icare-device', loadComponent: () => import('./modules/prms/ble-device/spirometer-icare-device/spirometer-icare-device.page').then(m => m.SpirometerIcareDevicePage) },
  { path: 'spirometer-jetty-device', loadComponent: () => import('./modules/prms/ble-device/spirometer-jetty-device/spirometer-jetty-device.page').then(m => m.SpirometerJettyDevicePage) },
  { path: 'ecg-comment-dialog', loadComponent: () => import('./modules/prms/ble-device/ecg-comment-dialog/ecg-comment-dialog.page').then(m => m.EcgCommentDialogPage) },
  { path: 'test-selection-dialog', loadComponent: () => import('./modules/prms/usb-device/test-selection-dialog/test-selection-dialog.page').then(m => m.TestSelectionDialogPage) },

  // LOCAL CONSULTATION ROUTES
  { path: 'patientinfo', loadComponent: () => import('./modules/consultation/local-consultation/patientinfo/patientinfo.page').then(m => m.PatientinfoPage) },
  { path: 'counseling', loadComponent: () => import('./modules/consultation/local-consultation/counseling/counseling.page').then(m => m.CounselingPage) },
  { path: 'diagnosis', loadComponent: () => import('./modules/consultation/local-consultation/diagnosis/diagnosis.page').then(m => m.DiagnosisPage) },
  { path: 'intervention', loadComponent: () => import('./modules/consultation/local-consultation/intervention/intervention.page').then(m => m.InterventionPage) },
  { path: 'investigations', loadComponent: () => import('./modules/consultation/local-consultation/investigations/investigations.page').then(m => m.InvestigationsPage) },
  { path: 'medicines', loadComponent: () => import('./modules/consultation/local-consultation/medicines/medicines.page').then(m => m.MedicinesPage) },
  { path: 'parameters', loadComponent: () => import('./modules/consultation/local-consultation/parameters/parameters.page').then(m => m.ParametersPage) },
  { path: 'pastrecords', loadComponent: () => import('./modules/consultation/local-consultation/pastrecords/pastrecords.page').then(m => m.PastrecordsPage) },
  { path: 'patient-history', loadComponent: () => import('./modules/consultation/local-consultation/patient-history/patient-history.page').then(m => m.PatientHistoryPage) },
  { path: 'referrals', loadComponent: () => import('./modules/consultation/local-consultation/referrals/referrals.page').then(m => m.ReferralsPage) },
  { path: 'tabs', loadComponent: () => import('./modules/consultation/local-consultation/tabs/tabs.page').then(m => m.TabsPage) },
  { path: 'complaints', loadComponent: () => import('./modules/consultation/local-consultation/complaints/complaints.page').then(m => m.ComplaintsPage) },
  { path: 'sidebar', loadComponent: () => import('./modules/consultation/local-consultation/sidebar/sidebar.page').then(m => m.SidebarPage) },
  { path: 'navbar', loadComponent: () => import('./modules/consultation/navbar/navbar.page').then(m => m.NavbarPage) },
  { path: 'upload-documents', loadComponent: () => import('./modules/consultation/local-consultation/upload-documents/upload-documents.page').then(m => m.UploadDocumentsPage) },
  { path: 'consultation-report', loadComponent: () => import('./modules/consultation/local-consultation/viewconsultation/viewconsultation.page').then(m => m.ViewconsultationPage) },
  { path: 'print-patient-id', loadComponent: () => import('./modules/consultation/local-consultation/print-patient-id/print-patient-id.page').then(m => m.PrintPatientIdPage) },
  { path: 'finish-consul-dialog', loadComponent: () => import('./modules/consultation/local-consultation/finish-consul-dialog/finish-consul-dialog.page').then(m => m.FinishConsulDialogPage) },
  { path: 'past-consultation', loadComponent: () => import('./modules/consultation/local-consultation/past-consultation/past-consultation.page').then(m => m.PastConsultationPage) },

  // Nurse & Doctor extras

    {path: 'find-doctor',
    loadComponent: () => import('./modules/doctor-dashboard/find-doctor/find-doctor.page').then( m => m.FindDoctorPage)
  },
  { path: 'u-documents', loadComponent: () => import('./modules/consultation/local-consultation/u-documents/u-documents.page').then(m => m.UDocumentsPage) },
  { path: 'privacy-policy', loadComponent: () => import('./modules/login/privacy-policy/privacy-policy.page').then(m => m.PrivacyPolicyPage) },
    {
    path: 'view-patient-readings',
    loadComponent: () => import('./modules/consultation/local-consultation/view-patient-readings/view-patient-readings.page').then( m => m.ViewPatientReadingsPage)
  },
  
  {
    path: 'viewreport',
    loadComponent: () => import('./modules/consultation/local-consultation/viewreport/viewreport.page').then( m => m.ViewreportPage)
  },
  {
    path: 'past-images-preview',
    loadComponent: () => import('./modules/consultation/local-consultation/past-images-preview/past-images-preview.page').then( m => m.PastImagesPreviewPage)
  },

  // PRMS BLE & USB DEVICE ROUTES
  { path: 'thermometer', loadComponent: () => import('./modules/prms/ble-device/thermometer/thermometer.page').then(m => m.ThermometerPage) },
  { path: 'parameter', loadComponent: () => import('./modules/prms/parameter/parameter.page').then(m => m.ParameterPage) },
  { path: 'spo2-device', loadComponent: () => import('./modules/prms/ble-device/spo2-device/spo2-device.page').then(m => m.Spo2DevicePage) },
  { path: 'common-dialog', loadComponent: () => import('./modules/common/common-dialog/common-dialog.page').then(m => m.CommonDialogPage) },
  { path: 'icare-device', loadComponent: () => import('./modules/prms/ble-device/icare-device/icare-device.page').then(m => m.IcareDevicePage) },
  { path: 'spo2-manual-entry', loadComponent: () => import('./modules/prms/ble-device/spo2-manual-entry/spo2-manual-entry.page').then(m => m.Spo2ManualEntryPage) },
  { path: 'icare-spo2', loadComponent: () => import('./modules/prms/ble-device/icare-spo2/icare-spo2.page').then(m => m.IcareSpo2Page) },
  { path: 'icare-thermometer', loadComponent: () => import('./modules/prms/ble-device/icare-thermometer/icare-thermometer.page').then(m => m.IcareThermometerPage) },
  { path: 'rapid-test', loadComponent: () => import('./modules/prms/usb-device/rapid-test/rapid-test.page').then(m => m.RapidTestPage) },
  { path: 'icare-rapid-test', loadComponent: () => import('./modules/prms/usb-device/icare-rapid-test/icare-rapid-test.page').then(m => m.IcareRapidTestPage) },
  { path: 'hemoglobin', loadComponent: () => import('./modules/prms/usb-device/hemoglobin/hemoglobin.page').then(m => m.HemoglobinPage) },
  { path: 'ecg-jetty-device', loadComponent: () => import('./modules/prms/ble-device/ecg-jetty-device/ecg-jetty-device.page').then(m => m.EcgJettyDevicePage) },
  { path: 'ecg-icare-device', loadComponent: () => import('./modules/prms/ble-device/ecg-icare-device/ecg-icare-device.page').then(m => m.EcgIcareDevicePage) },
  { path: 'stethoscope-device', loadComponent: () => import('./modules/prms/ble-device/stethoscope-device/stethoscope-device.page').then(m => m.StethoscopeDevicePage) },
  { path: 'blood-pressure-icare', loadComponent: () => import('./modules/prms/ble-device/blood-pressure-icare/blood-pressure-icare.page').then(m => m.BloodPressureIcarePage) },
  { path: 'blood-pressure-jetty', loadComponent: () => import('./modules/prms/ble-device/blood-pressure-jetty/blood-pressure-jetty.page').then(m => m.BloodPressureJettyPage) },
  { path: 'glucometer', loadComponent: () => import('./modules/prms/ble-device/glucometer/glucometer.page').then(m => m.GlucometerPage) },
  { path: 'hba1c', loadComponent: () => import('./modules/prms/usb-device/hba1c/hba1c.page').then(m => m.Hba1cPage) },
  { path: 'lipid-icare', loadComponent: () => import('./modules/prms/usb-device/lipid-icare/lipid-icare.page').then(m => m.LipidIcarePage) },
  { path: 'lipid-profile', loadComponent: () => import('./modules/prms/usb-device/lipid-profile/lipid-profile.page').then(m => m.LipidProfilePage) },
  { path: 'hb-a1c-ble-device', loadComponent: () => import('./modules/prms/ble-device/hb-a1c-ble-device/hb-a1c-ble-device.page').then(m => m.HbA1cBleDevicePage) },
  { path: 'hemoglobin-jetty', loadComponent: () => import('./modules/prms/usb-device/hemoglobin-jetty/hemoglobin-jetty.page').then(m => m.HemoglobinJettyPage) },
  { path: 'icare-urine-test', loadComponent: () => import('./modules/prms/usb-device/icare-urine-test/icare-urine-test.page').then(m => m.IcareUrineTestPage) },
  { path: 'urine-test', loadComponent: () => import('./modules/prms/usb-device/urine-test/urine-test.page').then(m => m.UrineTestPage) },
  { path: 'glucose', loadComponent: () => import('./modules/prms/usb-device/glucose/glucose.page').then(m => m.GlucosePage) },
  { path: 'glucose-ble', loadComponent: () => import('./modules/prms/ble-device/glucose-ble/glucose-ble.page').then(m => m.GlucoseBlePage) },
  { path: 'spirometer-icare-device', loadComponent: () => import('./modules/prms/ble-device/spirometer-icare-device/spirometer-icare-device.page').then(m => m.SpirometerIcareDevicePage) },
  { path: 'spirometer-jetty-device', loadComponent: () => import('./modules/prms/ble-device/spirometer-jetty-device/spirometer-jetty-device.page').then(m => m.SpirometerJettyDevicePage) },
  { path: 'ecg-comment-dialog', loadComponent: () => import('./modules/prms/ble-device/ecg-comment-dialog/ecg-comment-dialog.page').then(m => m.EcgCommentDialogPage) },
  { path: 'test-selection-dialog', loadComponent: () => import('./modules/prms/usb-device/test-selection-dialog/test-selection-dialog.page').then(m => m.TestSelectionDialogPage) },

  // LOCAL CONSULTATION ROUTES
  { path: 'patientinfo', loadComponent: () => import('./modules/consultation/local-consultation/patientinfo/patientinfo.page').then(m => m.PatientinfoPage) },
  { path: 'counseling', loadComponent: () => import('./modules/consultation/local-consultation/counseling/counseling.page').then(m => m.CounselingPage) },
  { path: 'diagnosis', loadComponent: () => import('./modules/consultation/local-consultation/diagnosis/diagnosis.page').then(m => m.DiagnosisPage) },
  { path: 'intervention', loadComponent: () => import('./modules/consultation/local-consultation/intervention/intervention.page').then(m => m.InterventionPage) },
  { path: 'investigations', loadComponent: () => import('./modules/consultation/local-consultation/investigations/investigations.page').then(m => m.InvestigationsPage) },
  { path: 'medicines', loadComponent: () => import('./modules/consultation/local-consultation/medicines/medicines.page').then(m => m.MedicinesPage) },
  { path: 'parameters', loadComponent: () => import('./modules/consultation/local-consultation/parameters/parameters.page').then(m => m.ParametersPage) },
  { path: 'pastrecords', loadComponent: () => import('./modules/consultation/local-consultation/pastrecords/pastrecords.page').then(m => m.PastrecordsPage) },
  { path: 'patient-history', loadComponent: () => import('./modules/consultation/local-consultation/patient-history/patient-history.page').then(m => m.PatientHistoryPage) },
  { path: 'referrals', loadComponent: () => import('./modules/consultation/local-consultation/referrals/referrals.page').then(m => m.ReferralsPage) },
  { path: 'tabs', loadComponent: () => import('./modules/consultation/local-consultation/tabs/tabs.page').then(m => m.TabsPage) },
  { path: 'complaints', loadComponent: () => import('./modules/consultation/local-consultation/complaints/complaints.page').then(m => m.ComplaintsPage) },
  { path: 'sidebar', loadComponent: () => import('./modules/consultation/local-consultation/sidebar/sidebar.page').then(m => m.SidebarPage) },
  { path: 'navbar', loadComponent: () => import('./modules/consultation/navbar/navbar.page').then(m => m.NavbarPage) },
  { path: 'upload-documents', loadComponent: () => import('./modules/consultation/local-consultation/upload-documents/upload-documents.page').then(m => m.UploadDocumentsPage) },
  { path: 'consultation-report', loadComponent: () => import('./modules/consultation/local-consultation/viewconsultation/viewconsultation.page').then(m => m.ViewconsultationPage) },
  { path: 'print-patient-id', loadComponent: () => import('./modules/consultation/local-consultation/print-patient-id/print-patient-id.page').then(m => m.PrintPatientIdPage) },
  { path: 'finish-consul-dialog', loadComponent: () => import('./modules/consultation/local-consultation/finish-consul-dialog/finish-consul-dialog.page').then(m => m.FinishConsulDialogPage) },
  { path: 'past-consultation', loadComponent: () => import('./modules/consultation/local-consultation/past-consultation/past-consultation.page').then(m => m.PastConsultationPage) },

  // Nurse & Doctor extras

    {path: 'find-doctor',
    loadComponent: () => import('./modules/doctor-dashboard/find-doctor/find-doctor.page').then( m => m.FindDoctorPage)
  },
  { path: 'u-documents', loadComponent: () => import('./modules/consultation/local-consultation/u-documents/u-documents.page').then(m => m.UDocumentsPage) },
  { path: 'privacy-policy', loadComponent: () => import('./modules/login/privacy-policy/privacy-policy.page').then(m => m.PrivacyPolicyPage) },
    {
    path: 'view-patient-readings',
    loadComponent: () => import('./modules/consultation/local-consultation/view-patient-readings/view-patient-readings.page').then( m => m.ViewPatientReadingsPage)
  },
  
  {
    path: 'viewreport',
    loadComponent: () => import('./modules/consultation/local-consultation/viewreport/viewreport.page').then( m => m.ViewreportPage)
  },
  {
    path: 'otoscope',
    loadComponent: () => import('./modules/prms/usb-device/otoscope/otoscope.page').then( m => m.OtoscopePage)
  },


 
];

