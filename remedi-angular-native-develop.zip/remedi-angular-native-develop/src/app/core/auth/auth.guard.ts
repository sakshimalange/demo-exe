

import { Injectable } from '@angular/core';
import { CanActivate, Router, UrlTree } from '@angular/router';
import { Observable, of } from 'rxjs';
import { map, tap, take, timeout, catchError } from 'rxjs/operators';
import { AuthService } from '../services/auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(private auth: AuthService, private router: Router) {
    // Ensure session init runs early (safe even if called multiple times)
    // this.auth.initialize();
  }

  canActivate(): Observable<boolean | UrlTree> {
    console.log('AuthGuard: Starting route protection check...', this.auth.isLoggedInSync);

    // Fast path: session restored from localStorage
    if (this.auth.isLoggedInSync) {
      console.log('AuthGuard: User authenticated (sync/localStorage)');
      this.auth.updateActivity().subscribe();
      return of(true);
    }

    //  Fallback: wait for async session restoration (PouchDB/Android)
    return this.auth.isLoggedIn.pipe(
      timeout(3000), // max wait time
      take(1),
      tap(isLoggedIn => {
        console.log('AuthGuard check result:', isLoggedIn ? 'Authorized ' : 'Unauthorized ');
      }),
      map(isLoggedIn => {
        if (!isLoggedIn) {
          console.log('AuthGuard: Redirecting to login - no valid session');
          return this.router.createUrlTree(['/login']);
        }

        console.log(' AuthGuard: Access granted, updating activity');
        this.auth.updateActivity().subscribe();
        return true;
      }),
      catchError((error) => {
        console.error('AuthGuard: Session check timeout or error:', error);
        return of(this.router.createUrlTree(['/login']));
      })
    );
  }
}
