export interface EcgDataRecord {
  action: string;
  domain: string;
  consultationId: string;
  patientId: number;
  isNewReading: string;
  isBle: string;
  ecgPulse: string;
  ecgDataChunk: string;
  token?: string;
  type: string; // e.g., 'ecg_record'
  synced?: boolean; // Optional field to track sync status
  timestamp?: string; // Optional field for timestamp
  _id?: string; // Optional field for PouchDB document ID   
   _rev?: string; // Optional field for PouchDB document revision
   source?: string; // Optional field to indicate the source of the data
   forwardto?:string;
}


export interface EcgiDataRecord {
  action: string;
  domain: string;
  consultationId: string;
  patientId: number;
  isNewReading: string;
  isBle: string;
  ecgPulse: string;
  ecgDataChunk: string;
  token?: string;
  type: string; // e.g., 'ecg_record'
  synced?: boolean; // Optional field to track sync status
  timestamp?: string; // Optional field for timestamp
  _id?: string; // Optional field for PouchDB document ID   
   _rev?: string; // Optional field for PouchDB document revision
   source?: string; // Optional field to indicate the source of the data
   forwardto?:string;
   language?:string;
   userName?:string;
}
export interface aftersaveecgapicall {
  action: string
  patientId: string
  domain: string
  consultationId: string
  token: string
  isEcgBle: boolean
  isBleEcgReadingCompleted: number
  synced?: boolean; // Optional field to track sync status
  timestamp?: string; // Optional field for timestamp
  _id?: string;
  type?: string; // e.g., 'ecg_record'
  source?: string; // Optional field to indicate the source of the data
  forwardto?:string;
  requestFrom?:string;
}


//save ecg icare data locally to pouchdb
export interface IcareEcgRecord {
  type: 'icare_ecg_record';
  timestamp: string;
  pulse_rate: string;
  ecg_file_name: string;
  ecg_value?: number[]; // Optional field for raw ECG data
  synced?: boolean; // Optional field to track sync status
  _id?: string; // Optional field for PouchDB document ID
  _rev?: string; // Optional field for PouchDB document revision

}


export interface Printreportpatientinfo {
  type: string;
  consultationId?: string;
  patientId?: string;
  domainwisepid?: string;
  patientName?: string;
  first_name?: string;
  last_name?: string;
  gender?: string;
  age?: string;
  consultationDate?: string;
  consultationTime?: string;
  synced?: boolean;
  _id?: string;
  timestamp: string;
  forwardto?:string;
}

export interface aftersaveecgiapicall {
  action: string
  patientId: string
  domain: string
  consultationId: string
  token: string
  isEcgBle: boolean
  isBleecginterpretationReadingCompleted?: number
  synced?: boolean; // Optional field to track sync status
  timestamp?: string; // Optional field for timestamp
  _id?: string;
  type?: string; // e.g., 'ecg_record'
  source?: string; // Optional field to indicate the source of the data
  forwardto?:string;
  requestFrom?:string;
}


export interface SendEcgInterpretationRecord {
  _id: string;
  type: 'send_ecg_interpretation';
  action: string;
  consultationId: string;
  patientId: string;
  domain: string;
  token: string;
  timestamp: string;
  synced: boolean;
  forwardto: string;
}

export interface SendEcgToTricogRecord {
  _id: string;
  type: 'send_ecg_to_tricog';
  action: string;
  consultationId: string;
  connectedDeviceMAC: string;
  deviceAcquisitionDate: string;
  deviceAcquisitionTime: string;
  domain: string;
  token: string;
  dataArrayEncodedString: string;
  timestamp: string;
  synced: boolean;
  forwardto: string;
}


export interface ECGIGraphDetail {
  p_id: string;
  p_name: string;
  p_age: string;
  p_gender: string;
  c_date: string;
  c_time: string | null;
}


export interface ECGResponse {
  fileName: string;
  data(data: any): unknown;
  status: string;
  message: any;
}

