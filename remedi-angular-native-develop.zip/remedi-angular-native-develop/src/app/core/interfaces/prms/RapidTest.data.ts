
export interface RapidTestApiPayload {
  // PouchDB specific fields (added automatically)
  _id?: string;              // PouchDB document ID
  _rev?: string;             // PouchDB revision ID (required for updates/deletes)
  
  // API Payload fields (exact match to your Postman data)
  action: string;            // "save_Rapid_Test_Data"
  domain: string;            // "21"
  consultationId: string;    // "88579"
  patientId: string;         // "6956"
  testName: string;          // "BLOOD_GROUPING"
  testresult: string;        // "Result is A POSITIVE (A+)" - NOTE: lowercase 'r' in 'testresult'
  imgName: string;           // "BLOOD_GROUPING_12345_67890.png"
  language: string;          // "English"
  requestFrom: string;       // "angular"
  tblname: string;           // "prms_diagnosis"
  img: string;               // Very long encrypted base64 string
  token: string;             // Authentication token (should not be stored locally)
  
  synced?: boolean;          // Has this been synced to server?
  forwardto?: string;


}