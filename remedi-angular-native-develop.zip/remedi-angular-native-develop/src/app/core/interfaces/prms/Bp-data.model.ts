// Blood Pressure
export class SaveBpDataRequest {
  _id?: string = '';
  _rev?: string = '';
  type: string = 'bp_record'; // optional: to identify the type of record
  action: string = '';
  consultationId: number = 0;
  patientId: number = 0;
  domain: number = 0;
  tblname: string = '';
  paramName: string = '';
  systolic: number = 0;
  diastolic: number = 0;
  pulserate: number = 0;
  language: string = '';
  requestFrom: string = '';
  token: string = '';
    synced?: boolean = false; 
      forwardto?: string = ''; 
}