//Hemoglobin
export class SaveHemoglobinDataRequest {
  _id?: string = '';
  _rev?: string = '';
  type: string = '';
  action: string = '';
  consultationId: number = 0;
  patientId: number = 0;
  domain: number = 0;
  hemoglobin: number = 0;
  token: string = '';
    synced?: boolean = false;  
      forwardto?: string = '';
}
