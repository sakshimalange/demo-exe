export interface SpirometerRecord {
  type: 'icare_spirometer_record';
  timestamp: string;
  fvc: number;
  fev1: number;
  fev1_percentage: number;
  pef: number;
  fef25: number;
  fef50: number;
  fef75: number;
  tv: number;
  tlc: number;
  synced?: boolean; // Optional field to track sync status
    _id?: string; // Optional field for PouchDB document ID
    _rev?: string; // Optional field for PouchDB document revision
    token?: string; // Optional field for authentication token
domain: number;
  consultationId: number;
  patientId: number;
  isNewReading: string;
}


export interface JettySpirometerRecord {
  type: string;
  timestamp: string;

  domain: string;
  consultationId: string;
  patientId: number;
  isNewReading: string;

  FVC: string;
  FEV1: string;
  FEV1_per: string;
  FEF25: string;
  FEF50: string;
  FEF75: string;
  TLC: string;
  PEF: string;
  TV: string;
  FEV1_FVC?: string;
  FEF25_75?: string;
  FET?: string;
  FIVC?: string;
  PIF?: string;

  spiroDataChunk: string;

  token?: string;
  synced?: boolean;
  _id?: string;
  _rev?: string;
  language?:string,
  requestFrom?: string,
  responsetype?: string,
  forwardto?:string,
}
