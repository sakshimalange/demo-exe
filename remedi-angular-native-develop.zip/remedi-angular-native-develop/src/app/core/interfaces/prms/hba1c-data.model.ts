export class Hba1cData
{
  action: string = 'save_HBA1C_Data'; // Action to be performed
  domain: number = 0; // Domain of the data
  finalValue: object = {
    hba1c_value: '', // HBA1C value
    hba1c_mmol_value: '', // HBA1C mmol value
    hba1c_eag_value: '' // HBA1C estimated average glucose value

  }; // HBA1C values
  consultationId: number = 0; // Date of consultation
  patientId: number = 0; // Patient ID
  token: string = ''; // Authentication token
  synced:boolean = false; // Indicates if the data is synced
  
}
export class Hba1cjettysave{
   _id?: string;               // PouchDB document ID
  consultationId?: string;     // consultation ID
  patientId?: string;          // patient ID
  token?: string;              // auth token
  domain?: string;             // domain ID
  tblname?: string;            // table name, e.g., "prms_parameters"
  paramName?: string;  
  Hba1cHemoglobin_manual?: number | null; // HbA1c (%)
  Hba1cMMOL_manual?: number | null;      // HbA1c mmol
  Hba1cAUG_manual?: number | null;       // eAG value
  
  deviceusername?: string;      // device user
  deviceid?: string;            // device ID
  language?: string;            // language
  createdAt?: Date;             // record creation timestamp
  synced?: boolean;             // local sync flag
  action: any;
  requestFrom: any;
  type?: string;
}


