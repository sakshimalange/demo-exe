export class GlucoData
{
  action: string = 'save_Glucose_Data'; // Action to be performed
  domain: number = 0; // Domain of the data
  finalValue: string = ''; // Hemoglobin value
  consultationId: number = 0; // Date of consultation
  patientId: number = 0; // Patient ID
  token: string = ''; // Authentication token
  paramName: string = ''; // Parameter name
  readingType: string = ''; // Type of reading (e.g., 'fasting', 'postprandial', etc.)
  synced:boolean = false; // Indicates if the data is synced
  _id?: string; // Unique identifier for the record
  _rev?: string; // Revision identifier for the record
  _doc_id_rev?: string; // For PouchDB compatibility
  language: string = ''; // Language for the data
  requestFrom: string = ''; // Indicates the request source
  tblname: string = ''; // Table name for the data storage
}

