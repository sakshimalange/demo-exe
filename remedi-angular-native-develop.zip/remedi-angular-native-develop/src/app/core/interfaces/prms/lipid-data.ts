export interface LipidData {
}
