export interface UrineTestApiPayload {
  // PouchDB specific fields (added automatically)
  _id?: string;              // PouchDB document ID
  _rev?: string;             // PouchDB revision ID (required for updates/deletes)

  // API Payload fields (exact match to your urine test API structure)
  action: string;            // "save_Urine_Data"
  consultationId: string;    // "12345"
  domain: string;            // "21"
  patientId: string;         // "67890"
  urinetestresult: string;   // "Protein:Negative_Glucose:Negative_RBC:0-2/hpf" - NOTE: underscore format from WebSocket
  isManualEntry: number;     // 0 (for automated test) or 1 (for manual entry)
  saveimgtoserver?: string | null;   // Very long encrypted base64 string
  language: string;          // "English"
  requestFrom: string;       // "angular"
  token: string;             // Authentication token (should not be stored locally)

  synced?: boolean;          // Has this been synced to server?
  forwardto?: string;
}


export interface UrineTestApiPayloadforicare {
  // PouchDB specific fields (added automatically)
  _id?: string;              // PouchDB document ID
  _rev?: string;             // PouchDB revision ID (required for updates/deletes)
  
  // API Payload fields (exact match to your urine test API structure)
  action: string;            // "SaveUrineTest" (updated for new API)
  consultationId: string;    // Dynamic from localStorage
  domain: string;            // Dynamic from localStorage
  patientId: string;         // Dynamic from localStorage
  urinetestresult: string;   // Legacy format for PouchDB compatibility
  isManualEntry: number;     // 0 (for automated test) or 1 (for manual entry)
  saveimgtoserver?: string | null;   // Very long encrypted base64 string
  language: string;          // "English" or dynamic from localStorage
  requestFrom: string;       // "angular"
  token: string;             // Authentication token (should not be stored locally)
  
  synced?: boolean;          // Has this been synced to server?
  forwardto?: string;        // "RemediNovaAPI.do" (updated endpoint)
  
  // Individual urine test parameters for new API format
  GLU?: string;              // Glucose
  BIL?: string;              // Bilirubin
  KET?: string;              // Ketone
  SG?: string;               // Specific Gravity
  BLO?: string;              // Blood
  pH?: string;               // pH Level
  PRO?: string;              // Protein
  URO?: string;              // Urobilinogen
  NIT?: string;              // Nitrite
  LEU?: string;              // Leukocytes
}