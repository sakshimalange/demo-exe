export interface LipidProfileDBModel {
  _id?: string;
  consultationId: string;
  domain: string;
  tc: number;
  tg: number;
  hdl: number;
  ldlf: number;
  ldli: number;
  token: string;
  createdAt: number;
}
