//Temperature
export class SaveTemperatureDataRequest {
  _id?: string = '';
  _rev?: string = '';
  type: string = '';
  action: string = '';
  consultationId: number = 0;
  patientId: number = 0;
  domain: number = 0;
  temp: number = 0;
  language: string = '';
  token: string = '';
  timestamp: string = '';
    synced?: boolean = false;  
      forwardto?: string = '';
}