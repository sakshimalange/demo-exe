export interface GlucoseTestApiPayload {
  // PouchDB specific fields (added automatically)
  _id?: string;              // PouchDB document ID
  _rev?: string;             // PouchDB revision ID (required for updates/deletes)

  // API Payload fields (exact match to your glucose API structure)
  action: string;            // "save_Glucose_Data"
  consultationId: string;    // "88579"
  patientId: string;         // "6956" 
  paramName: string;         // "glucose"
  finalValue: number;        // 121
  readingType: string;       // "fasting" | "postprandial" | "random"
  language: string;          // "English"
  requestFrom: string;       // "angular"
  token: string;             // Authentication token (should not be stored locally)

  synced?: boolean;          // Has this been synced to server?
  forwardto?: string;
}