export class SaveSpo2DataRequest {
  _id?: string = '';
  _rev?: string = '';
  type: string = 'spo2_record';
  action: string = '';
  consultationId: number = 0;
  patientId: number = 0;
  domain: number = 0;
  spo2Percentage: number = 0;
  spo2Pulse: number = 0;
  tblname?: string = '';
  language?: string = '';
  token?: string = '';
  requestFrom?: string = '';
  synced?: boolean = false;
  forwardto?: string = '';
}

export class SaveSpo2FileDataRequest {
  _id?: string = '';                // Local PouchDB document ID
  _rev?: string = '';               // PouchDB revision (auto-updated)
  type: string = 'spo2_file_record'; // To filter SPO2 file records
  action: string = 'saveSpo2_file_Data';
  consultationId: number = 0;
  patientId: number = 0;
  domain: number = 0;
  isBle: string = 'true';
  isNewReading: string = '1';
  isSPO2ReadingCompleted: string = '1';
  spo2CompleteData: string = '';    // Encrypted SpO₂ data
  token: string = '';
  language?: string = 'English';
  requestFrom?: string = 'angular';
  synced?: boolean = false;     
  forwardto?: string = '';
}
