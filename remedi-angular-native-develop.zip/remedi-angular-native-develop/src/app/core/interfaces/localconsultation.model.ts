// 🌍 Global Record Interface
export class GlobalRecord {
  _id?: string = '';       // Unique Document ID
  _rev?: string = '';      // Revision ID (for update/delete)
  type?: string = '';      // Record type (e.g. 'patient', 'user')

  // Common Fields
  first_name: string = '';
  last_name: string = '';
  gender: string = '';
  dob: string = '';
  email?: string = '';
  phone?: string = '';
  synced?: boolean = false; // Sync status
}

// ✅ Complaint Model
export class Complaint {
  _id?: string;
  _rev?: string;
  ChiefComplaint: string = '';
  complaint: string = '';
  duration: string = '';
  spec: string = '';
  createdAt: string = new Date().toISOString();
  type: string = 'complaint';
  synced?: boolean;     // Track if synced to server
  domain?: string;
  action: string = '';
  patientId: string = '';
  consultationId: string = '';
  localConsultationId: string = '';
  username?: string = '';
  paramName: string = '';
  tblname: string = '';
  token: string = '';
  forwardto: string = '';
}


// ✅ Referral Model
export class Referral {
  _id?: string;
  _rev?: string;
  referralName: string = '';
  referralNote: string = '';
  createdAt: string = new Date().toISOString();
  type: string = 'referral';
    synced?: boolean;     // Track if synced to server
  domain?: string;
  action: string = '';
   username:string = '';
  patientId: string = '';
  consultationId: string = '';
  paramName: string = '';
  tblname: string = '';
  token: string = '';
  forwardto: string = '';
}


//  Intervention Model
export class Intervention {
  _id?: string;
  _rev?: string;
  Treatment_Plan: string = '';
  Clinical_Observations: string = '';
  Follow_Up_Schedule: string | null = null;
  createdAt: string = new Date().toISOString();
  type: string = 'intervention';
  synced?: boolean;     // Track if synced to server
  domain?: string;
  action: string = '';
  patientId: string = '';
  consultationId: string = '';
  username: string = '';
  paramName: string = '';
  tblname: string = '';
  token: string = '';
  forwardto: string = '';
}

// ✅ Patient History Model
export class PatientHistory {
  _id?: string;
  _rev?: string;
  History_Of_Present_Illness: string = '';
  Personal_History: string = '';
  Past_Medical_Surgical_History: string = '';
  Family_History: string = '';
  Current_And_Recent_Medications: string = '';
  Medical_Allergies: string = '';
  Other_Allergies_Or_Sensitivities: string = '';
  Additional_Notes: string = '';
 Physical_Examination: string = '';
  Review_Note: string = '';
  createdAt: string = new Date().toISOString();
  type: string = 'patient-history';
  synced?: boolean;     // Track if synced to server
  action: string = '';
  patientId: string = '';
  consultationId: string = '';
  username:string = '';
  paramName: string = '';
domain: string ='';
  token: string = '';
  forwardto: string = '';

}

// ✅ Counseling Model
export class Counseling {
  _id?: string;
  _rev?: string;
  instructionCategory: string = '';
  // check: string='';
  instruction: string = '';
  createdAt: string = new Date().toISOString();
  type: string = 'counseling';
   isSync?: boolean;
  domain?: number;
    synced?: boolean;     // Track if synced to server
  action: string = '';
  patientId: string = '';
  consultationId: string = '';
  username:string = '';
  paramName: string = '';
  tblname: string = '';
  token: string = '';
  forwardto: string = '';
}

// ✅ Diagnosis Model
export class Diagnosis {
  _id?: string;
  _rev?: string;
  icdCode: string = '';  // ICD Code
  freetext: string = '';
  isProvisional: boolean = false;
  createdAt: string = new Date().toISOString();
  type: string = 'diagnosis';
  code?: string;         //  Added for backward compatibility
  description?: string;
   synced?: boolean;     // Track if synced to server
  domain?: number;
  action: string = '';
  patientId: string = '';
  consultationId: string = '';
  username:string = '';
  paramName: string = '';
  tblname: string = '';
  token: string = '';
  forwardto: string = '';
}

// ✅ Investigation Model
export class Investigation {
  _id?: string;
  _rev?: string;
  lab: string = '';
  labId: string = '';
  // labId: string = '';
  test: string = '';
  mandatory: boolean = false;
  isMandatory: boolean = false;
  investigationMode: 'select' | 'chapter' | 'manual' = 'select';
  createdAt: string = new Date().toISOString();
  type: string = 'investigation';
    synced?: boolean;     // Track if synced to server
  domain?: number;
  action: string = '';
  patientId: string = '';
  consultationId: string = '';
  username:string = '';
  paramName: string = '';
  tblname: string = '';
  token: string = '';
  forwardto: string = '';
}

// ✅ Medicine Model
export class Medicine {
  _id?: string;
  _rev?: string;
  Drug_Form: string = '';
  freetext: string = '';
  specialInstruction: string = '';
  dose: string = '';
  frequency: string = '';
  numberOfDays: number = 0;
  createdAt: string = new Date().toISOString();
  type: string = 'medicine';
       synced?: boolean;     // Track if synced to server
  domain?: number;
  action: string = '';
  patientId: string = '';
  consultationId: string = '';
  username:string = '';
  usertype: string = '';
  tblname: string = '';
  token: string = '';
  forwardto: string = '';
}


