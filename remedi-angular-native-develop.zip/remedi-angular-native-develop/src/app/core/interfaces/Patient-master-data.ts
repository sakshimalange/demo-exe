export interface PatientDetail {
  contact_number: string;
  dob: string;
  _id?: string;            
  _rev?: string;       
  type: 'patient_detail';   

  domainwisepid: number;
  patientid: number;

  first_name: string | null;
  last_name: string | null;
  patient_title?: string | null;

  EhealthId: string | null;
  MRN: string | null;
  address: string | null;
  age: string | null;
  ageYears: string | null;
  block: number | null;
  centerName: string | null;
  consentformcheckstatus: number | null;
  country: number | null;
  createdat: string | null;
  createdby: string | null;
  date_of_birth: string | null;
  district: number | null;
  domain: number | null;
  email: string | null;
  ethnicity: string | null;
  fingerPrintTemplate: string | null;
  gender: string | null;
  head_of_household_fname: string | null;
  head_of_household_lname: string | null;
  head_of_household_mobile: string | null;
  health_address: string | null;
  health_number: string | null;
  height: string | null;
  isAbhaPatient: boolean;
  localId: string | null;
  maritalstatus: string | null;
  mobile: string | null;
  nationalId: string | null;
  password: string | null;
  pastrecord: string | null;
  patient_status: string | null;
  postCode: string | null;
  prefix: string | null;
  profile: string | null;
  projid: string | null;
  state: number | null;
  status: string | null;
  subscriptionDetails: string | null;
  synced: boolean;
  updated?: boolean;        // New flag for local modifications
  lastModified?: string;    // Timestamp for tracking changes
  uid: string | null;
  unique_id: string | null;
  village: number | null;
  weight: string | null;
}


export interface PatientRecord {
  _id: string;
  _rev?: string;
  type:"patient_detail"
  sync: boolean;
  timestamp: string;

  // Patient info
  patientid?: string;
  first_name?: string;
  last_name?: string;
  age?: string;
  gender?: string;
  marital?: string;
  address?: string;
  height?: string | number;
  weight?: string | number;
  mobile?: string;
  email?: string;
  date_of_birth?: string;
  hoh_fname?: string;
  hoh_lname?: string;
  uid?: string;
  country?: string;
  state?: string;
  district?: string;
  block?: string;
  village?: string;

  // Profile & fingerprint
  profile?: { base64Image?: string; S3URL?: string };
  profilePic?: string;
  fingerPrintTemplate?: string;

  // API-specific fields
  query: string;
  formData: any;
  [key: string]: any;
}