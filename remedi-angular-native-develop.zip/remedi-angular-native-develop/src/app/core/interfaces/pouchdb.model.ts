import { flag } from "ionicons/icons";

// Define a generic structure for any record (User/Patient/Customer etc.)
export class GlobalRecord {
  _id?: string = '';       // Unique Document ID (Generated Automatically)
  _rev?: string = '';      // Revision ID (Required for Update/Delete)
  type?: string = '';      // Record type (example: 'patient', 'user', 'customer')
  // Common Fields (Can Add More as per Requirement)
  first_name: string = '';
  last_name: string = '';
  gender: string = '';
  dob: string = '';
  email?: string = '';
  phone?: string = '';

  synced?: boolean;         // Used for Sync Status
}






//login
export class Login {
  profiledetail: Profiledetail = new Profiledetail();
  WorkFlowChanges: boolean = false;
  commondetail: Commondetail = new Commondetail();
  secretKey: string = '';
  photopath: Photopath = new Photopath();
  isMinsaWorkflow: boolean = false;
  token: string = '';
  Offset: string = '';
  status: string = '';
  synced?: boolean = false;
}

export class LoginRecord extends Login {
  _id: string = 'login_data';
  _rev?: string;
  type: string = 'login';
}
export class Commondetail {
  videomode: string = '';
  phonelength: string = '';
  logintime: string = '';
  usertype: string = '';
  domainImage: string = '';
  domainId: string = '';
  isSurveyEnabled: number = 0;
  locationhierarchy: Locationhierarchy = new Locationhierarchy();
  imagetypes: Imagetype[] = [];
  domainName: string = '';
  currency: Currency[] = [];
  domainExpDate: string = '';
  dateformat: string = '';
}

export class Currency {
  symbol: string = '';
  currency: string = '';
  id: string = '';
}

export class Imagetype {
  imagetype: string = '';
  isEnabled: string = '';
  id: string = '';
}

export class Locationhierarchy {
  label_4: string = '';
  label_3: string = '';
  labeles: number = 0;
  label_2: string = '';
  label_1: string = '';
}

export class Photopath {
  DOCTOR_PHOTO_PATH: string = '';
  PATIENT_PHOTO_PATH: string = '';
  DOCTOR_SIGN_PATH: string = '';
  LOGO_IMAGE_PATH: string = '';
  PATIENT_PASTRECORD_PATH: string = '';
  NURSE_PHOTO_PATH: string = '';
}

export class Profiledetail {
  country: string = '';
  rhes_emp_no: any;
  default_Is_DomainDtFormat: string = '';
  fee: string = '';
  groupId: string = '';
  sign: string = '';
  language: string = '';
  createdAt: Date = new Date();
  password: string = '';
  isCalenderEnabled: string = '';
  block: string = '';
  state: string = '';
  isABHAEnabled: string = '';
  isOPRoom: string = '';
  profile: string = '';
  rhes_emp_category: any;
  S3SignUrl: string = '';
  op_doc_id: any;
  qualification: string = '';
  installer: string = '';
  rhes_dept_code: any;
  dob: string = '';
  district: string = '';
  domain: string = '';
  name: string = '';
  specialization: string = '';
  designation: string = '';
  isEmailNotificationEnabled: string = '';
  gender: string = '';
  eHealthId: any;
  isDeleted: string = '';
  doctorId: string = '';
  locationId: string = '';
  village: string = '';
  followup_discount: string = '';
  email: string = '';
  honorific: string = '';
  isSmsNotificationEnabled: string = '';
  centerId: string = '';
  mobile: string = '';
  ophthalmoscope_access: string = '';
  userName: string = '';
  isMedicineManufacturerEnabled: string = '';
  forAndroid: string = '';
  createdBy: string = '';
  registrationNumber: string = '';
  organization: string = '';
  S3ImageUrl: string = '';
  dateformat: string = '';
}
export class SaveDomainConfigRequest {
  _id?: string = '';       // Unique Document ID (Generated Automatically)
  _rev?: string = '';      // Revision ID (Required for Update/Delete)
  type?: string = '';
  action: string = '';
  username: string = '';
  domainName: string = '';
  token: string = '';
  domainLogo: string = ''; //  Add this line
  synced?: boolean = false;
}

export interface GlucoseTestApiPayload {
  // PouchDB specific fields (added automatically)
  _id?: string;              // PouchDB document ID
  _rev?: string;             // PouchDB revision ID (required for updates/deletes)

  // API Payload fields (exact match to your glucose API structure)
  action: string;            // "save_Glucose_Data"
  consultationId: string;    // "88579"
  patientId: string;         // "6956" 
  paramName: string;         // "glucose"
  finalValue: number;        // 121
  readingType: string;       // "fasting" | "postprandial" | "random"
  language: string;          // "English"
  requestFrom: string;       // "angular"
  token: string;             // Authentication token (should not be stored locally)

  synced?: boolean;          // Has this been synced to server?
}


export interface UrineTestApiPayload {
  // PouchDB specific fields (added automatically)
  _id?: string;              // PouchDB document ID
  _rev?: string;             // PouchDB revision ID (required for updates/deletes)

  // API Payload fields (exact match to your urine test API structure)
  action: string;            // "save_Urine_Data"
  consultationId: string;    // "12345"
  domain: string;            // "21"
  patientId: string;         // "67890"
  urinetestresult: string;   // "Protein:Negative_Glucose:Negative_RBC:0-2/hpf" - NOTE: underscore format from WebSocket
  isManualEntry: number;     // 0 (for automated test) or 1 (for manual entry)
  saveimgtoserver?: string | null;   // Very long encrypted base64 string
  language: string;          // "English"
  requestFrom: string;       // "angular"
  token: string;             // Authentication token (should not be stored locally)

  synced?: boolean;          // Has this been synced to server?
}

// medical-image.model.ts
export class Consultation {
  _id!: string;
  type: string = 'consultation';
  consultationId!: number;
  patientId!: number;
  data!: any; // Replace `any` with a specific interface if you know it
  synced?: boolean; // optional field for sync tracking
}


export class MedicalImage {
  _id!: string;
  type: string = 'medical_image';
  consultationId!: number;
  patientId!: number;
  data!: any; // Replace with exact type when available
  synced?: boolean;
}


export class FinishConsultationRecord {
  _id: string = ''; // unique id, e.g. timestamp or uuid
  type: string = 'finish_consultation'; 
  action: string = '';
  domain: number = 0;
  username: string = '';
  consultationId: number = 0;
  localConsultationId?: string = '';
  usertype: string = '';
  patientId: number = 0;
  token: string = '';
  synced: boolean = false;
  forwardto: string = '';

}


// suspend-request.model.ts
// export class SuspendRequest {
//   _id?: string;
//   action = 'suspendLocalConsultation';
//   username: string = '';
//   domain: string = '';
//   ConsId: number = 0;
//   usertype = 'Doctor';
//   token: string = '';
//   status?: 'pending' | 'synced' = 'pending';
//   createdAt: string = new Date().toISOString();
//   synced: boolean = false;


// }


export class SuspendRequest {
  _id: string = ''; // unique id
  action: string = 'suspendLocalConsultation';
  domain: number = 0;
  username: string = '';
  consultationId: number = 0;
  localConsultationId?: string = '';
  usertype: string = '';
  token: string = '';
  synced: boolean = false;
  forwardto?: string = '';
}


export class OtpRequestRecord {
  _id: string = '';
  type:string = 'otp_request';
  action: string ='sendotpbyusername';
  username: string = '';
  domain: string = '';
  requestFrom: string = '';
  // token: string = '';
  synced: boolean = false;
   forwardto?: string = '';
}

export class OtpVerifyRecord {
  _id: string  = '';
  type: string = 'otp_verify_record';
  action: string = 'verifyotpbyusername';
  username: string = '';
  otp: string = '';
  domain: string ='';
  requestFrom: string = '';
  synced: boolean = false;
   forwardto?: string = '';
}
export class ChangePasswordRecord {
  _id: string = '';  
  type: string = 'change_password_record';
  action: string = 'changePasswordForPatient';
  username: string = '';
  newPassword: string = '';
  userType: string = '';
  domain: string = '';
  requestFrom: string = '';
  synced: boolean = false;
  forwardto?: string = '';
}


export class DomainLookupRecord {
  _id: string = '';
  type:string = 'domain_lookup_record';
  action: string = '';
  domainName: string = '';
  requestFrom: string = '';
  response?: {
    domainId?: string;
    language?: string;
    offset?: string;
  };
   synced: boolean = false;
     forwardto?: string = '';
}
export interface SaveBloodPressureDataRequest {
  action: string;
  consultationId: string;
  patientId: number;
  domain: number;
  tblname: string;
  paramName: string;
  systolic: number;
  diastolic: number;
  pulserate: number;
  language: string;
  requestFrom: string;
  token: string;
  type: string;
  synced: boolean;
  _id?: string;
}
