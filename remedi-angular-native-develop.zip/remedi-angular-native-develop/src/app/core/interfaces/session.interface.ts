export interface SessionDocument {
  _id: 'user_session';
  _rev?: string;
  token: string;
  userId: string;
  username: string;
  loginTime: number;
  expiryTime?: number;
  userProfile?: any;
  loginResponse: any;
  consultationId?: string; // <--- add this
  clientId: string;
  domainId: string;
  language: string;
  isActive: boolean;
  platform: string;
  lastActivity: number;
}

export interface SessionValidationResult {
  isValid: boolean;
  isExpired: boolean;
  session?: SessionDocument;
  reason?: string;
}

export interface LoginSessionData {
  token: string;
  userId: string;
  username: string;
  clientId: string;
  domainId: string;
  language: string;
  userProfile?: any;
  loginResponse: any;
  expiryHours?: number;
}
