export interface ConsultationRecord {
  _id?: string;
  _rev?: string;
  local_consultation_id: string;
  consultationId?: string | null;
  patientName: string;
  startTime: string;
  patientId: string;
  doctorId: string;
  userName: string;
  domain: string;
  usertype: string;
  nurseId: string;
  status: 'offline' | 'online';
  synced: boolean;
  createdAt: string;
  syncedAt?: string;
  type: 'consultation_record';
  action: string;
  token: string;
  consultation_state: 'progress' | 'suspend' | 'finish';
}
