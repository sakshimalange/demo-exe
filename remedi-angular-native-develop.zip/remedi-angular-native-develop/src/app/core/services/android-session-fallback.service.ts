import { Injectable } from '@angular/core';
import { Observable, from, throwError, BehaviorSubject } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { SessionDocument, LoginSessionData } from '../interfaces/session.interface';

/**
 * Android Session Fallback Service
 * Uses multiple storage strategies for maximum reliability on Android WebView
 */
@Injectable({
  providedIn: 'root'
})
export class AndroidSessionFallbackService {
  private readonly SESSION_KEY = 'REMEDI_SESSION_ANDROID';
  private readonly BACKUP_KEYS = [
    'REMEDI_SESSION_BACKUP_1',
    'REMEDI_SESSION_BACKUP_2', 
    'REMEDI_SESSION_BACKUP_3'
  ];

  private sessionState$ = new BehaviorSubject<SessionDocument | null>(null);

  constructor() {
    console.log('🤖 Android Session Fallback Service initialized');
  }

  get currentSession$(): Observable<SessionDocument | null> {
    return this.sessionState$.asObservable();
  }

  get currentSession(): SessionDocument | null {
    return this.sessionState$.value;
  }

  get isLoggedIn(): boolean {
    const session = this.currentSession;
    return !!(session && session.token && session.isActive);
  }

  saveSession(sessionData: LoginSessionData): Observable<SessionDocument> {
    const sessionDoc: SessionDocument = {
      _id: 'user_session',
      token: sessionData.token,
      userId: sessionData.userId,
      username: sessionData.username,
      loginTime: Date.now(),
      expiryTime: Date.now() + (24 * 60 * 60 * 1000), // 24 hours
      userProfile: sessionData.userProfile,
      loginResponse: sessionData.loginResponse,
      clientId: sessionData.clientId,
      domainId: sessionData.domainId,
      language: sessionData.language,
      isActive: true,
      platform: 'android',
      lastActivity: Date.now()
    };

    console.log('🔄 Starting Android session save with improved error handling...');

    // Set session in memory immediately for UI responsiveness
    this.sessionState$.next(sessionDoc);

    return from(this.saveSessionToMultipleStorages(sessionDoc)).pipe(
      tap(() => {
        console.log('✅ Android session saved to storage successfully');
      }),
      map(() => sessionDoc),
      catchError((error) => {
        console.error('❌ Android session storage failed but continuing login:', error);
        console.log('✅ Session available in memory, login can proceed');
        return from([sessionDoc]); // Return session anyway to continue login
      })
    );
  }

  restoreSession(): Observable<SessionDocument | null> {
    console.log('🔄 Attempting to restore Android session...');
    
    return from(this.loadSessionFromStorages()).pipe(
      tap((session) => {
        if (session && this.isSessionValid(session)) {
          this.sessionState$.next(session);
          console.log('✅ Android session restored successfully:', 
            `User: ${session.username}, Platform: ${session.platform}, LoginTime: ${new Date(session.loginTime).toLocaleString()}`
          );
        } else {
          if (session) {
            console.log('🗑️ Found invalid session, clearing corrupted data...');
            this.clearSession().subscribe({
              next: () => console.log('✅ Corrupted session cleared'),
              error: (error) => console.warn('⚠️ Failed to clear corrupted session:', error)
            });
          } else {
            console.log('ℹ️ No Android session found');
          }
          this.sessionState$.next(null);
        }
      }),
      catchError((error) => {
        console.error('Failed to restore Android session:', error);
        // Try to clear potentially corrupted data
        this.clearSession().subscribe({
          next: () => console.log('Cleared data after restore failure'),
          error: (clearError) => console.warn('Failed to clear after restore failure:', clearError)
        });
        this.sessionState$.next(null);
        return from([null]);
      })
    );
  }

  clearSession(): Observable<boolean> {
    console.log('🗑️ Clearing Android session from all storages...');
    
    return from(this.clearAllStorages()).pipe(
      tap(() => {
        this.sessionState$.next(null);
        console.log('Android session cleared from all storages');
      }),
      map(() => true),
      catchError((error) => {
        console.error('Error clearing Android session:', error);
        this.sessionState$.next(null);
        return from([true]); // Still return true even if some storages fail
      })
    );
  }

  updateLastActivity(): Observable<boolean> {
    const session = this.currentSession;
    if (!session) return from([false]);

    const updatedSession = {
      ...session,
      lastActivity: Date.now()
    };

    return from(this.saveSessionToMultipleStorages(updatedSession)).pipe(
      tap(() => {
        this.sessionState$.next(updatedSession);
      }),
      map(() => true),
      catchError(() => from([false]))
    );
  }

  private async saveSessionToMultipleStorages(session: SessionDocument): Promise<void> {
    const sessionJson = JSON.stringify(session);
    const errors: string[] = [];

    // Strategy 1: localStorage (most common)
    try {
      localStorage.setItem(this.SESSION_KEY, sessionJson);
      console.log(' Session saved to localStorage');
    } catch (error) {
      errors.push('localStorage failed');
      console.warn(' localStorage save failed:', error);
    }

    // Strategy 2: sessionStorage (as backup)
    try {
      sessionStorage.setItem(this.SESSION_KEY, sessionJson);
      console.log('📱 Session saved to sessionStorage');
    } catch (error) {
      errors.push('sessionStorage failed');
      console.warn('⚠️ sessionStorage save failed:', error);
    }

    // Strategy 3: Multiple localStorage keys (redundancy)
    this.BACKUP_KEYS.forEach((key, index) => {
      try {
        localStorage.setItem(key, sessionJson);
        console.log(`📱 Session saved to backup storage ${index + 1}`);
      } catch (error) {
        errors.push(`backup${index + 1} failed`);
        console.warn(`⚠️ Backup storage ${index + 1} save failed:`, error);
      }
    });

    // Strategy 4: IndexedDB - Make it synchronous with timeout for better error handling
    try {
      await Promise.race([
        this.saveToIndexedDB(session),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('IndexedDB timeout after 2s')), 2000)
        )
      ]);
      console.log('📱 Session saved to IndexedDB');
    } catch (error) {
      errors.push('IndexedDB failed');
      console.warn('IndexedDB save failed:', error);
    }

    const successfulStorages = 4 - errors.length;
    console.log(`Session save summary: ${successfulStorages}/4 storage methods succeeded`);
    
    // Only throw error if ALL critical storage methods failed
    if (errors.length >= 4) {
      throw new Error('All storage methods failed: ' + errors.join(', '));
    }
  }

  private async loadSessionFromStorages(): Promise<SessionDocument | null> {
    console.log('Checking all Android storage methods...');

    // Strategy 1: Primary localStorage
    let session = this.tryLoadFromStorage(() => localStorage.getItem(this.SESSION_KEY), 'localStorage');
    if (session) return session;

    // Strategy 2: sessionStorage
    session = this.tryLoadFromStorage(() => sessionStorage.getItem(this.SESSION_KEY), 'sessionStorage');
    if (session) return session;

    // Strategy 3: Backup localStorage keys
    for (let i = 0; i < this.BACKUP_KEYS.length; i++) {
      session = this.tryLoadFromStorage(() => localStorage.getItem(this.BACKUP_KEYS[i]), `backup${i + 1}`);
      if (session) return session;
    }

    // Strategy 4: IndexedDB
    try {
      session = await this.loadFromIndexedDB();
      if (session) {
        console.log('Session loaded from IndexedDB');
        return session;
      }
    } catch (error) {
      console.warn('IndexedDB load failed:', error);
    }

    console.log('No session found in any Android storage method');
    return null;
  }

  private tryLoadFromStorage(loadFn: () => string | null, storageName: string): SessionDocument | null {
    try {
      const sessionJson = loadFn();
      if (sessionJson) {
        const session = JSON.parse(sessionJson) as SessionDocument;
        if (this.isSessionValid(session)) {
          console.log(`Valid session loaded from ${storageName}`);
          return session;
        } else {
          console.log(`Invalid session found in ${storageName}`);
        }
      }
    } catch (error) {
      console.warn(`Failed to load from ${storageName}:`, error);
    }
    return null;
  }

  private isSessionValid(session: SessionDocument): boolean {
    try {
      if (!session || !session.token || !session.username) {
        console.log(' Session invalid: missing required fields');
        return false;
      }

      // Check if session structure is corrupted
      if (typeof session !== 'object' || !session._id) {
        console.log(' Session invalid: corrupted structure');
        return false;
      }

      // Check if session is expired
      if (session.expiryTime && Date.now() > session.expiryTime) {
        console.log(' Session expired at:', new Date(session.expiryTime).toLocaleString());
        return false;
      }

      // Check if session is too old (7 days max)
      const sevenDaysInMs = 7 * 24 * 60 * 60 * 1000;
      if (Date.now() - session.loginTime > sevenDaysInMs) {
        console.log(' Session too old (>7 days)');
        return false;
      }

      // Check if session is marked as inactive
      if (session.isActive === false) {
        console.log(' Session marked as inactive');
        return false;
      }

      console.log(' Session validation passed for user:', session.username);
      return true;
    } catch (error) {
      console.error(' Session validation error:', error);
      return false;
    }
  }

  private async clearAllStorages(): Promise<void> {
    // Clear localStorage
    try {
      localStorage.removeItem(this.SESSION_KEY);
      this.BACKUP_KEYS.forEach(key => localStorage.removeItem(key));
      console.log('Cleared localStorage');
    } catch (error) {
      console.warn('Failed to clear localStorage:', error);
    }

    // Clear sessionStorage
    try {
      sessionStorage.removeItem(this.SESSION_KEY);
      console.log('📱 Cleared sessionStorage');
    } catch (error) {
      console.warn('Failed to clear sessionStorage:', error);
    }

    // Clear IndexedDB
    try {
      await this.clearIndexedDB();
      console.log('Cleared IndexedDB');
    } catch (error) {
      console.warn('Failed to clear IndexedDB:', error);
    }
  }

  // IndexedDB manual implementation for Android compatibility
  private async saveToIndexedDB(session: SessionDocument): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        const request = indexedDB.open('RemediSessionDB', 1);
        
        request.onerror = () => {
          console.warn('IndexedDB open failed:', request.error);
          reject(new Error('IndexedDB open failed: ' + String(request.error)));
        };
        
        request.onupgradeneeded = () => {
          try {
            const db = request.result;
            if (!db.objectStoreNames.contains('sessions')) {
              db.createObjectStore('sessions');
            }
          } catch (error) {
            console.warn('IndexedDB upgrade failed:', error);
            reject(new Error('IndexedDB upgrade failed: ' + String(error)));
          }
        };
        
        request.onsuccess = () => {
          let db: IDBDatabase | null = null;
          try {
            db = request.result;
            const transaction = db.transaction(['sessions'], 'readwrite');
            
            transaction.onerror = () => {
              console.warn('IndexedDB transaction failed:', transaction.error);
              reject(new Error('IndexedDB transaction failed: ' + String(transaction.error)));
            };
            
            const store = transaction.objectStore('sessions');
            const putRequest = store.put(session, 'current_session');
            
            putRequest.onsuccess = () => {
              db?.close();
              resolve();
            };
            
            putRequest.onerror = () => {
              db?.close();
              console.warn('IndexedDB put failed:', putRequest.error);
              reject(new Error('IndexedDB put failed: ' + String(putRequest.error)));
            };
          } catch (error) {
            db?.close();
            console.warn('IndexedDB operation failed:', error);
            reject(new Error('IndexedDB operation failed: ' + String(error)));
          }
        };
      } catch (error) {
        console.warn('IndexedDB initialization failed:', error);
        reject(new Error('IndexedDB initialization failed: ' + String(error)));
      }
    });
  }

  private async loadFromIndexedDB(): Promise<SessionDocument | null> {
    return new Promise((resolve, reject) => {
      try {
        const request = indexedDB.open('RemediSessionDB', 1);
        
        request.onerror = () => {
          console.warn('IndexedDB load open failed:', request.error);
          reject(new Error('IndexedDB load open failed: ' + String(request.error)));
        };
        
        request.onsuccess = () => {
          let db: IDBDatabase | null = null;
          try {
            db = request.result;
            if (!db.objectStoreNames.contains('sessions')) {
              db.close();
              resolve(null);
              return;
            }
            
            const transaction = db.transaction(['sessions'], 'readonly');
            
            transaction.onerror = () => {
              console.warn('IndexedDB load transaction failed:', transaction.error);
              db?.close();
              reject(new Error('IndexedDB load transaction failed: ' + String(transaction.error)));
            };
            
            const store = transaction.objectStore('sessions');
            const getRequest = store.get('current_session');
            
            getRequest.onsuccess = () => {
              db?.close();
              resolve(getRequest.result || null);
            };
            
            getRequest.onerror = () => {
              db?.close();
              console.warn('IndexedDB get failed:', getRequest.error);
              reject(new Error('IndexedDB get failed: ' + String(getRequest.error)));
            };
          } catch (error) {
            db?.close();
            console.warn('IndexedDB load operation failed:', error);
            reject(new Error('IndexedDB load operation failed: ' + String(error)));
          }
        };
      } catch (error) {
        console.warn('IndexedDB load initialization failed:', error);
        reject(new Error('IndexedDB load initialization failed: ' + String(error)));
      }
    });
  }

  private async clearIndexedDB(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('RemediSessionDB', 1);
      
      request.onerror = () => reject(request.error);
      
      request.onsuccess = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('sessions')) {
          resolve();
          return;
        }
        
        const transaction = db.transaction(['sessions'], 'readwrite');
        const store = transaction.objectStore('sessions');
        const clearRequest = store.clear();
        
        clearRequest.onsuccess = () => resolve();
        clearRequest.onerror = () => reject(clearRequest.error);
      };
    });
  }

  // Debug method
  getSessionInfo(): any {
    const session = this.currentSession;
    
    // Check what's available in each storage method
    const storageCheck = {
      localStorage: this.checkStorage(() => localStorage.getItem(this.SESSION_KEY)),
      sessionStorage: this.checkStorage(() => sessionStorage.getItem(this.SESSION_KEY)),
      backup1: this.checkStorage(() => localStorage.getItem(this.BACKUP_KEYS[0])),
      backup2: this.checkStorage(() => localStorage.getItem(this.BACKUP_KEYS[1])),
      backup3: this.checkStorage(() => localStorage.getItem(this.BACKUP_KEYS[2])),
      indexedDB: 'checking_async'
    };

    if (!session) {
      return { 
        hasSession: false, 
        storageMethod: 'none',
        storageCheck,
        currentTime: new Date().toLocaleString()
      };
    }

    return {
      hasSession: true,
      isValid: this.isSessionValid(session),
      username: session.username,
      loginTime: new Date(session.loginTime).toLocaleString(),
      expiryTime: session.expiryTime ? new Date(session.expiryTime).toLocaleString() : 'No expiry',
      platform: session.platform,
      lastActivity: new Date(session.lastActivity).toLocaleString(),
      storageMethod: 'multiple_fallback',
      storageCheck,
      currentTime: new Date().toLocaleString()
    };
  }

  private checkStorage(getFunc: () => string | null): string {
    try {
      const data = getFunc();
      if (!data) return 'empty';
      const parsed = JSON.parse(data);
      return parsed?.username ? `valid(${parsed.username})` : 'invalid_data';
    } catch (error) {
      return 'error';
    }
  }
}