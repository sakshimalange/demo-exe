// ...existing imports...
import { Component, Inject } from '@angular/core';
import {
  MAT_SNACK_BAR_DATA,
  MatSnackBarRef,
} from '@angular/material/snack-bar';

@Component({
  selector: 'app-snackbar2',
  template: `
    <div class="snackbar-container">
      <div class="snackbar-row">
        <div class="snackbar-icon">
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M21.5306 7.28055L9.53055 19.2806C9.4609 19.3503 9.37818 19.4056 9.28713 19.4433C9.19609 19.4811 9.09849 19.5005 8.99993 19.5005C8.90137 19.5005 8.80377 19.4811 8.71272 19.4433C8.62168 19.4056 8.53896 19.3503 8.4693 19.2806L3.2193 14.0306C3.07857 13.8898 2.99951 13.699 2.99951 13.4999C2.99951 13.3009 3.07857 13.11 3.2193 12.9693C3.36003 12.8286 3.55091 12.7495 3.74993 12.7495C3.94895 12.7495 4.13982 12.8286 4.28055 12.9693L8.99993 17.6896L20.4693 6.2193C20.61 6.07857 20.8009 5.99951 20.9999 5.99951C21.199 5.99951 21.3898 6.07857 21.5306 6.2193C21.6713 6.36003 21.7503 6.55091 21.7503 6.74993C21.7503 6.94895 21.6713 7.13982 21.5306 7.28055Z"
              fill="white"
            />
          </svg>
        </div>
        <div class="snackbar-message">{{ data.message }}</div>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        background: transparent !important;
      }
      .snackbar-container {
        width: 100%;
        max-width: 424px;
        padding: 10px;
        //background: #4B5563;
        border-radius: 4px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: flex-start;
        gap: 24px;
      }
      .snackbar-row {
        width: 100%;
        display: flex;
        justify-content: flex-start;
        align-items: center;
        gap: 16px;
      }
      .snackbar-icon {
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .snackbar-icon svg {
        width: 100%;
        height: 100%;
      }
      .snackbar-message {
        flex: 1;
        color: white;
        font-size: 12px;
        font-family: 'DM Sans', sans-serif;
        font-weight: 400;
        line-height: 16.8px;
      }
    `,
  ],
})
export class Snackbar2 {
  constructor(
    @Inject(MAT_SNACK_BAR_DATA) public data: { title: string; message: string },
    private snackBarRef: MatSnackBarRef<Snackbar2>
  ) {}

  close() {
    this.snackBarRef.dismiss();
  }
}
