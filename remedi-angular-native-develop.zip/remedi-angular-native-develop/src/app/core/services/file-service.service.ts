import { Injectable } from '@angular/core';
import { Capacitor } from '@capacitor/core';
import { Directory, Filesystem } from '@capacitor/filesystem';

@Injectable({
  providedIn: 'root'
})
export class FileService {
  
  // ✅ Better Electron detection
  private get isElectron(): boolean {
    return !!(window as any).electronAPI;
  }

  async writeFile(fileName: string, base64Data: string): Promise<string> {
    console.log('🔍 Platform check:', {
      isElectron: this.isElectron,
      capacitorPlatform: Capacitor.getPlatform(),
      hasElectronAPI: !!(window as any).electronAPI
    });

    if (this.isElectron) {
      console.log('💻 Using Electron file system');
      const result = await (window as any).electronAPI.writeFile(fileName, base64Data);
      if (result.success) {
        console.log('✅ Electron write success:', fileName);
        return fileName; // Return only filename
      } else {
        throw new Error(result.error);
      }
    } else {
      console.log('📱 Using Capacitor file system');
      // Fallback to Capacitor for mobile
      const savedFile = await Filesystem.writeFile({
        path: fileName,
        data: base64Data,
        directory: Directory.Data,
      });
      return fileName;
    }
  }

  async readFile(fileName: string): Promise<string> {
    console.log('🔍 Reading file - Platform check:', {
      isElectron: this.isElectron,
      fileName: fileName
    });

    if (this.isElectron) {
      console.log('💻 Reading from Electron file system');
      const result = await (window as any).electronAPI.readFile(fileName);
      if (result.success) {
        console.log('✅ Electron read success:', fileName);
        return result.data;
      } else {
        throw new Error(result.error);
      }
    } else {
      console.log('📱 Reading from Capacitor file system');
      // Fallback to Capacitor for mobile
      const fileData = await Filesystem.readFile({
        path: fileName,
        directory: Directory.Data,
      });
      return fileData.data as string;
    }
  }

  // ✅ Get storage path for debugging
  async getStoragePath(): Promise<string> {
    if (this.isElectron) {
      return await (window as any).electronAPI.getStoragePath();
    }
    return 'Capacitor Data directory';
  }

  // ✅ Open storage folder (Electron only)
  async openStorageFolder(): Promise<void> {
    if (this.isElectron) {
      await (window as any).electronAPI.openStorageFolder();
    } else {
      console.warn('Open folder only available in Electron');
    }
  }

  // ✅ List all files
  async listFiles(): Promise<any> {
    if (this.isElectron) {
      return await (window as any).electronAPI.listFiles();
    } else {
      console.warn('List files only available in Electron');
      return { success: false, files: [] };
    }
  }
}