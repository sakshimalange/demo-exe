import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { ConstantService } from './constant.service';
import { BehaviorSubject } from 'rxjs';
import * as OT from '@opentok/client';

export type TokboxRole = 'doctor' | 'nurse';

export interface TokBoxSession {
  API_KEY: string;
  SESSION_ID: string;
  TOKEN: string;
  STATUS: string;
}

export interface VideoCallState {
  isConnected: boolean;
  isPublishing: boolean;
  isSubscribing: boolean;
  connectionCount: number;
  error?: string;
}

export interface SpeakingState {
  publisherSpeaking: boolean;
  subscriberSpeaking: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class TokboxService {
  private session: any = null;
  private publisher: any = null;
  private subscribers: any[] = [];

  private videoCallState = new BehaviorSubject<VideoCallState>({
    isConnected: false,
    isPublishing: false,
    isSubscribing: false,
    connectionCount: 0
  });

  public videoCallState$ = this.videoCallState.asObservable();

  private speakingState = new BehaviorSubject<SpeakingState>({
    publisherSpeaking: false,
    subscriberSpeaking: false
  });

  public speakingState$ = this.speakingState.asObservable();

  constructor(
    private apiSvc: ApiService,
    private constantSvc: ConstantService
  ) {}

  /**
   * Get TokBox session credentials from backend
   */
  async getTokBoxSession(consultationId: string, doctorId: string): Promise<TokBoxSession> {
    try {
      const data = `action=36&consId=${consultationId}&doctorId=${doctorId}`;
      const response = await this.apiSvc
        .postServiceByQuery(this.constantSvc.APIConfig.GETCOMMONSERVICES, data)
        .toPromise();

      if (response && response.STATUS === 'success') {
        return {
          API_KEY: response.API_KEY,
          SESSION_ID: response.SESSION_ID,
          TOKEN: response.TOKEN,
          STATUS: response.STATUS
        };
      } else {
        throw new Error('Failed to get TokBox session credentials');
      }
    } catch (error) {
      console.error('Error getting TokBox session:', error);
      throw error;
    }
  }

  /**
   * Start consultation session
   */
  async startConsultation(consultationId: string): Promise<any> {
    try {
      const data = `action=11&consultationId=${consultationId}`;
      const response = await this.apiSvc
        .postServiceByQuery(this.constantSvc.APIConfig.GETCOMMONSERVICES.replace('RemediNovaDoctorAPI.do', 'ConsultationServlet'), data)
        .toPromise();

      return response;
    } catch (error) {
      console.error('Error starting consultation:', error);
      throw error;
    }
  }

  /**
   * Initialize TokBox session
   */
  async initializeSession(sessionCredentials: TokBoxSession, role: TokboxRole): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        this.session = OT.initSession(sessionCredentials.API_KEY, sessionCredentials.SESSION_ID);
        this.setupSessionEventListeners(role);

        this.session.connect(sessionCredentials.TOKEN, (error: any) => {
          if (error) {
            console.error('Failed to connect to session:', error);
            this.updateVideoCallState({ error: error.message });
            reject(error);
          } else {
            console.log('Connected to TokBox session');
            this.updateVideoCallState({ isConnected: true });
            resolve();
          }
        });
      } catch (error) {
        console.error('Error initializing session:', error);
        reject(error);
      }
    });
  }

  /**
   * Setup session event listeners
   */
  private setupSessionEventListeners(role: TokboxRole): void {
    if (!this.session) return;

    this.session.on('streamCreated', (event: any) => {
      console.log('Stream created:', event.stream);
      this.subscribeToStream(event.stream, role);
    });

    this.session.on('streamDestroyed', (event: any) => {
      console.log('Stream destroyed:', event.stream);
      this.updateConnectionCount();
    });

    this.session.on('connectionCreated', (event: any) => {
      console.log('Connection created:', event.connection);
      this.updateConnectionCount();
    });

    this.session.on('connectionDestroyed', (event: any) => {
      console.log('Connection destroyed:', event.connection);
      this.updateConnectionCount();
    });

    this.session.on('sessionDisconnected', (event: any) => {
      console.log('Session disconnected:', event.reason);
      this.updateVideoCallState({
        isConnected: false,
        isPublishing: false,
        isSubscribing: false,
        connectionCount: 0
      });
      this.updateSpeakingState({ publisherSpeaking: false, subscriberSpeaking: false });
    });

    // Add audio level monitoring for speaking detection
    this.session.on('audioLevelUpdated', (event: any) => {
      const audioLevel = event.audioLevel;
      const isSpeaking = audioLevel > 0.1; // Threshold for speaking detection

      if (event.target === this.publisher) {
        this.updateSpeakingState({ publisherSpeaking: isSpeaking });
      } else if (this.subscribers.includes(event.target)) {
        this.updateSpeakingState({ subscriberSpeaking: isSpeaking });
      }
    });
  }

  /**
   * Start publishing video
   */
  async startPublishing(role: TokboxRole, targetElement: string | HTMLElement): Promise<void> {
    return new Promise(async (resolve, reject) => {
      try {
        if (!this.session) {
          reject(new Error('Session not initialized'));
          return;
        }

        // Check media devices availability before initializing publisher
        const deviceCheck = await this.checkMediaDevices();
        if (!deviceCheck.hasCamera || !deviceCheck.hasMicrophone) {
          const errorMessage = !deviceCheck.hasCamera && !deviceCheck.hasMicrophone
            ? 'No camera or microphone found. Please connect media devices and try again.'
            : !deviceCheck.hasCamera
            ? 'No camera found. Please connect a camera and try again.'
            : 'No microphone found. Please connect a microphone and try again.';
          reject(new Error(errorMessage));
          return;
        }

        // Check if running in Electron and adjust settings accordingly
        const isElectron = !!(window as any).electronAPI?.isElectron;
        console.log('Initializing publisher for role:', role, 'in Electron:', isElectron);

        // Adjust publisher settings for Electron compatibility
        const publisherOptions: any = {
          insertMode: 'append',
          // width: '100%', // Commented out to allow CSS control
          // height: isElectron ? '35vh' : '38vh', // Commented out to allow CSS control
          name: role === 'doctor' ? 'Doctor' : 'Nurse',
          publishAudio: true,
          publishVideo: true,
          resolution: '640x480',
          frameRate: 30
        };

        // Add Electron-specific settings if needed
        if (isElectron) {
          // Ensure video constraints are properly set for Electron
          publisherOptions.videoSource = undefined; // Let browser choose default
          publisherOptions.audioSource = undefined; // Let browser choose default
        }

        this.publisher = OT.initPublisher(targetElement, publisherOptions, (error: any) => {
          if (error) {
            console.error('Error initializing publisher:', error);
            let userFriendlyError = 'Failed to access camera or microphone.';
            if (error.code === 1500) {
              userFriendlyError = 'Camera or microphone is already in use by another application. Please close other apps using media devices and try again.';
            }
            reject(new Error(userFriendlyError));
          } else {
            this.session.publish(this.publisher, (publishError: any) => {
              if (publishError) {
                console.error('Error publishing:', publishError);
                reject(new Error('Failed to start video publishing.'));
              } else {
                console.log('Publishing started successfully');
                this.updateVideoCallState({ isPublishing: true });
                resolve();
              }
            });
          }
        });
      } catch (error: unknown) {
        console.error('Error starting publishing:', error);
        if (error instanceof Error) {
          reject(error);
        } else {
          reject(new Error('Unknown error occurred while starting video.'));
        }
      }
    });
  }

  /**
   * Subscribe to a stream
   */
  private subscribeToStream(stream: any, role: TokboxRole): void {
    try {
      const containerId = role === 'doctor' ? 'subscriber-container' : 'doctor-subscriber-container';
      const subscriber = this.session.subscribe(stream, containerId, {
        insertMode: 'append',
        // width: '100%', // Commented out to allow CSS control
        // height: '38vh', // Commented out to allow CSS control
        name: role === 'doctor' ? 'Nurse' : 'Doctor'
      }, (error: any) => {
        if (error) {
          console.error('Error subscribing to stream:', error);
        } else {
          console.log('Subscribed to stream');
          this.subscribers.push(subscriber);
          this.updateVideoCallState({ isSubscribing: true });
        }
      });
    } catch (error) {
      console.error('Error subscribing to stream:', error);
    }
  }

  /**
   * Stop publishing
   */
  stopPublishing(): void {
    if (this.publisher) {
      this.session?.unpublish(this.publisher);
      this.publisher.destroy();
      this.publisher = null;
      this.updateVideoCallState({ isPublishing: false });
    }
  }

  /**
   * Disconnect from session
   */
  disconnect(): void {
    if (this.session) {
      this.session.disconnect();
      this.session = null;
      this.publisher = null;
      this.subscribers = [];
      this.updateVideoCallState({
        isConnected: false,
        isPublishing: false,
        isSubscribing: false,
        connectionCount: 0
      });
    }
  }

  /**
   * Toggle audio
   */
  toggleAudio(): boolean {
    if (this.publisher) {
      const currentState = this.publisher.getAudioSource();
      if (currentState) {
        this.publisher.publishAudio(false);
        return false;
      } else {
        this.publisher.publishAudio(true);
        return true;
      }
    }
    return false;
  }

  /**
   * Toggle video
   */
  toggleVideo(): boolean {
    if (this.publisher) {
      const currentState = this.publisher.getVideoSource();
      if (currentState) {
        this.publisher.publishVideo(false);
        return false;
      } else {
        this.publisher.publishVideo(true);
        return true;
      }
    }
    return false;
  }

  /**
   * Update video call state
   */
  private updateVideoCallState(updates: Partial<VideoCallState>): void {
    const currentState = this.videoCallState.value;
    this.videoCallState.next({ ...currentState, ...updates });
  }

  /**
   * Update speaking state
   */
  private updateSpeakingState(updates: Partial<SpeakingState>): void {
    const currentState = this.speakingState.value;
    this.speakingState.next({ ...currentState, ...updates });
  }

  /**
   * Update connection count
   */
  private updateConnectionCount(): void {
    if (this.session) {
      const connectionCount = Object.keys(this.session.connection ? this.session.connections : {}).length;
      this.updateVideoCallState({ connectionCount });
    }
  }

  /**
   * Check if media devices (camera and microphone) are available and request permissions
   */
  async checkMediaDevices(): Promise<{ hasCamera: boolean; hasMicrophone: boolean; error?: string }> {
    try {
      // First, request camera and microphone permissions explicitly
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });

      // Stop the stream immediately after getting permissions
      stream.getTracks().forEach(track => track.stop());

      // Now enumerate devices after permissions are granted
      const devices = await navigator.mediaDevices.enumerateDevices();
      const hasCamera = devices.some(device => device.kind === 'videoinput');
      const hasMicrophone = devices.some(device => device.kind === 'audioinput');

      return { hasCamera, hasMicrophone };
    } catch (error: unknown) {
      console.error('Error checking media devices:', error);

      let errorMessage = 'Unknown error occurred while accessing media devices.';
      if (error instanceof Error) {
        switch (error.name) {
          case 'NotAllowedError':
          case 'PermissionDeniedError':
            errorMessage = 'Camera and microphone permissions are required. Please allow access to camera and microphone in your browser settings and try again.';
            break;
          case 'NotFoundError':
          case 'DevicesNotFoundError':
            errorMessage = 'No camera or microphone found. Please connect a camera and microphone and try again.';
            break;
          case 'NotReadableError':
          case 'TrackStartError':
            errorMessage = 'Camera or microphone is being used by another application. Please close other apps using media devices and try again.';
            break;
          case 'OverconstrainedError':
          case 'ConstraintNotSatisfiedError':
            errorMessage = 'Camera does not meet the required specifications. Please check your camera settings.';
            break;
          case 'NotSupportedError':
            errorMessage = 'Camera access is not supported in this browser. Please try using a different browser.';
            break;
          case 'TypeError':
            errorMessage = 'Invalid media constraints. Please check your camera configuration.';
            break;
          default:
            errorMessage = error.message || errorMessage;
        }
      }

      return { hasCamera: false, hasMicrophone: false, error: errorMessage };
    }
  }

  /**
   * Get current video call state
   */
  getCurrentState(): VideoCallState {
    return this.videoCallState.value;
  }

  /**
   * Get local video stream
   */
  // getLocalStream(): MediaStream | null {
  //   if (this.publisher && this.publisher.stream) {
  //     return this.publisher.stream;
  //   }
  //   return null;
  // }

  // /**
  //  * Get remote video stream (first subscriber)
  //  */
  // getRemoteStream(): MediaStream | null {
  //   if (this.subscribers.length > 0 && this.subscribers[0].stream) {
  //     return this.subscribers[0].stream;
  //   }
  //   return null;
  // }
}
