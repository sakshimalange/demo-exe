import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ConstantService } from './constant.service';
import { ApiService } from './api.service';

/** =========
 *  Payloads
 *  ========= */
export interface PendingInReviewParams {
  domain: string | number;
  usertype: 'Doctor';
  username: string;
  token: string;
}

export interface ConnectedConsultationParams {
  domain: string | number;
  consultationId: string | number;
  username: string;
  token: string;
}

export interface GetWssUrlParams {
  username: string;
  consultationId: string | number;
  token: string;
}

export interface WebRtcParams {
  consId: string | number;
  token: string;
}

export interface FetchResourceMappingParams {
  userType: 'Doctor';
  domainId: string | number;
  token: string;
}

export interface SearchPatientParams {
  patientid: string | number;
  domain: string;          // e.g. "s3test2"
  username: string;
  iswithdash: 0 | 1;       // as per your working call
  token: string;
}

export interface CheckNurseStatusParams {
  username: string;
  consultationId: string | number;
  token: string;
}

/** Nurse-side payloads to hit RemediPatientPortalAPI.do */
export interface NurseStartConsultationBody {
  forwardto: 'AndroidRemoteConsultaionWPSevices.do';
  action: 'Startconsultaion';
  domain: string;               // e.g., "s3test2"
  consultationId: string | number;
  userName: string;             // note: backend expects userName key
  token: string;
}

export interface NurseCheckDoctorStatusBody {
  forwardto: 'AndroidRemoteConsultaionWPSevices.do';
  action: 'checkDoctorStatus';
  domain: string;               // e.g., "s3test2"
  offset: string;               // e.g., "5:30"
  consultationId: string | number;
  userName: string;
  token: string;
}

export interface NurseInitiateConsultationBody {
  forwardto: 'AndroidRemoteConsultaionWPSevices.do';
  action: 'InitiateConsultation';
  domain: string;
  offset: string;
  userType: 'Nurse';
  consType: 'remote';
  consultationId: string | number;
  userName: string;
  token: string;
}


/** =========
 *  Responses (loose typing because backend varies)
 *  ========= */
export interface ApiBaseResponse<T = any> {
  status?: 'success' | 'error';
  STATUS?: 'success' | 'error';      // some services use uppercase
  message?: string;
  msg?: string;
  data?: T;
  [k: string]: any;
}
export interface NurseInitiateConsultationBody {
  forwardto: 'AndroidRemoteConsultaionWPSevices.do';
  action: 'InitiateConsultation';
  domain: string;
  offset: string;
  userType: 'Nurse';
  consType: 'remote';
  consultationId: string | number;
  userName: string;
  token: string;
}

@Injectable({ providedIn: 'root' })
export class DoctorConsultationApiService {
  /** Most of your app uses the same constant for this endpoint. */
  private readonly DOCTOR_API = this.constantSvc.APIConfig.GETCOMMONSERVICES; // points to RemediNovaDoctorAPI.do

  constructor(
    private http: HttpClient,
    private constantSvc: ConstantService,
    private api: ApiService, // reuse your wrapper helpers
  ) {}

  /** Build ?key=val&key2=val2 safely */
  private qs(params: Record<string, any>): string {
    const u = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') u.set(k, String(v));
    });
    return `?${u.toString()}`;
  }

  /** 1) Pending & In-Review list */
  pendingAndInReview(p: PendingInReviewParams): Observable<ApiBaseResponse> {
    const query = this.qs({ action: 'pendingAndInreview', ...p });
    return this.api.postServiceByQueryBasic<ApiBaseResponse>(this.DOCTOR_API, query);
  }

  /** 2) Connect doctor to a consultation */
  connectedConsultation(p: ConnectedConsultationParams): Observable<ApiBaseResponse> {
    const query = this.qs({ action: 'Connectedconsultaion', ...p });
    return this.api.postServiceByQueryBasic<ApiBaseResponse>(this.DOCTOR_API, query);
  }

  /** 3) Fetch WSS url for signaling */
  getWssUrl(p: GetWssUrlParams): Observable<ApiBaseResponse<{ wssUrl?: string }>> {
    const query = this.qs({ action: 'getwssurl', ...p });
    return this.api.postServiceByQueryBasic<ApiBaseResponse>(this.DOCTOR_API, query);
  }

  /** 4) Get WebRTC credentials (usually OpenTok keys) */
  getWebRtcCredentials(p: WebRtcParams): Observable<ApiBaseResponse<{
    API_KEY?: string;
    SESSION_ID?: string;
    TOKEN?: string;
  }>> {
    const query = this.qs({ action: 'webrtc', ...p });
    return this.api.postServiceByQueryBasic<ApiBaseResponse>(this.DOCTOR_API, query);
  }

  /** 5) Resource mapping for Doctor */
  fetchResourceMapping(p: FetchResourceMappingParams): Observable<ApiBaseResponse> {
    const query = this.qs({ action: 'fetchResourceMapping', ...p });
    return this.api.postServiceByQueryBasic<ApiBaseResponse>(this.DOCTOR_API, query);
  }

  /** 6) Search patient */
  searchPatient(p: SearchPatientParams): Observable<ApiBaseResponse> {
    const query = this.qs({ action: 'search', ...p });
    return this.api.postServiceByQueryBasic<ApiBaseResponse>(this.DOCTOR_API, query);
  }

  /** 7) Check Nurse Status */
  checkNurseStatus(p: CheckNurseStatusParams): Observable<ApiBaseResponse<{ status?: string }>> {
    const query = this.qs({ action: 'checkNurseStatus', ...p });
    return this.api.postServiceByQueryBasic<ApiBaseResponse>(this.DOCTOR_API, query);
  }

  /** 8) Nurse: Start consultation (RemediPatientPortalAPI.do) */
  startConsultationAsNurse(body: NurseStartConsultationBody): Observable<ApiBaseResponse> {
    return this.api.postServiceWithJsonBody<ApiBaseResponse>(
      this.constantSvc.APIConfig.PATIENTPORTAL,
      body
    );
  }

  /** 9) Nurse: Check doctor status (RemediPatientPortalAPI.do) */
  checkDoctorStatusAsNurse(body: NurseCheckDoctorStatusBody): Observable<ApiBaseResponse> {
    return this.api.postServiceWithJsonBody<ApiBaseResponse>(
      this.constantSvc.APIConfig.PATIENTPORTAL,
      body
    );
  }

  /** 10) Nurse: Initiate consultation (RemediPatientPortalAPI.do) */
  initiateConsultationAsNurse(body: NurseInitiateConsultationBody): Observable<ApiBaseResponse> {
    return this.api.postServiceWithJsonBody<ApiBaseResponse>(
      this.constantSvc.APIConfig.PATIENTPORTAL,
      body
    );
  }
}
