import { TestBed } from '@angular/core/testing';

import { Snackbar2 } from './snackbar2';

describe('Snackbar2', () => {
  let service: Snackbar2;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Snackbar2);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
