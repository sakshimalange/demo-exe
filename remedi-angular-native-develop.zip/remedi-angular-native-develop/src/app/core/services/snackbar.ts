// ...existing imports...
import { Component, Inject } from '@angular/core';
import { MAT_SNACK_BAR_DATA, MatSnackBarRef } from '@angular/material/snack-bar';

@Component({
  selector: 'app-snackbar',
  template: `
    <div class="custom-snackbar-content">
      <div>
        <div class="custom-snackbar-title">{{ data.title }}</div>
        <div class="custom-snackbar-message">{{ data.message }}</div>
      </div>
      <button mat-button class="custom-snackbar-action" (click)="close()">OK</button>
    </div>
  `,
  styles: [`
    :host {
      background: transparent !important;
    }
    .custom-snackbar-content {
      width: 424px;
      height: 74px;
      background: #4B5563;
      border-radius: 4px;
      padding: 16px;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      gap: 24px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    .custom-snackbar-title {
      color: #fff;
      font-size: 14px;
      font-family: 'DM Sans', sans-serif;
      font-weight: 500;
      line-height: 21px;
      margin: 0;
    }
    .custom-snackbar-message {
      color: #fff;
      font-size: 12px;
      font-family: 'DM Sans', sans-serif;
      font-weight: 400;
      line-height: 16.8px;
      margin: 0;
    }
    .custom-snackbar-action {
      color: #fff;
      font-size: 14px;
      font-family: 'DM Sans', sans-serif;
      font-weight: 600;
      letter-spacing: 0.4px;
      background: transparent;
      border: none;
      cursor: pointer;
      padding: 8px 16px;
      border-radius: 4px;
      transition: background-color 0.2s;
    }
    .custom-snackbar-action:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
  `]
})
export class Snackbar {
  constructor(
    @Inject(MAT_SNACK_BAR_DATA) public data: { title: string, message: string },
    private snackBarRef: MatSnackBarRef<Snackbar>
  ) {}

  close() {
    this.snackBarRef.dismiss();
  }
}