// Debug utility to check patient save process
export class DebugPatientSave {
  
  static async checkPatientStructure(pouchdbService: any) {
    console.log('🔍 Checking patient structure in PouchDB...');
    
    try {
      // Initialize the correct database
      pouchdbService.initDB('patientdetail');
      
      // Get all records
      const allRecords = await pouchdbService.getAllRecords();
      console.log(`📊 Total records in database: ${allRecords.length}`);
      
      // Filter patient records
      const patientRecords = allRecords.filter((r: any) => 
        r.type === 'patient' || r.type === 'patient_detail'
      );
      
      console.log(`👥 Patient records found: ${patientRecords.length}`);
      
      if (patientRecords.length === 0) {
        console.log('ℹ️ No patient records found. Try registering a patient first.');
        return;
      }
      
      // Check the structure of the most recent patient
      const latestPatient = patientRecords[patientRecords.length - 1];
      
      console.log('📋 Latest patient record structure:');
      console.log('- _id:', latestPatient._id);
      console.log('- type:', latestPatient.type);
      console.log('- firstname:', latestPatient.firstname);
      console.log('- synced:', latestPatient.synced);
      console.log('- updated:', latestPatient.updated);
      console.log('- lastModified:', latestPatient.lastModified);
      
      // Check if updated field exists
      const hasUpdatedField = 'updated' in latestPatient;
      const hasLastModifiedField = 'lastModified' in latestPatient;
      
      console.log('✅ Field presence check:');
      console.log('- Has updated field:', hasUpdatedField ? '✅' : '❌');
      console.log('- Has lastModified field:', hasLastModifiedField ? '✅' : '❌');
      
      if (!hasUpdatedField) {
        console.log('❌ ISSUE FOUND: updated field is missing from patient records!');
        console.log('📝 Full patient object:', JSON.stringify(latestPatient, null, 2));
      } else {
        console.log('✅ SUCCESS: updated field is present in patient records');
      }
      
      // Check all patients for updated field
      const patientsWithUpdated = patientRecords.filter((p: any) => 'updated' in p);
      const patientsWithoutUpdated = patientRecords.filter((p: any) => !('updated' in p));
      
      console.log('📈 Summary:');
      console.log(`- Patients with updated field: ${patientsWithUpdated.length}/${patientRecords.length}`);
      console.log(`- Patients without updated field: ${patientsWithoutUpdated.length}/${patientRecords.length}`);
      
      if (patientsWithoutUpdated.length > 0) {
        console.log('❌ Some patients are missing the updated field');
        console.log('Missing updated field:', patientsWithoutUpdated.map((p: any) => ({
          id: p._id,
          name: `${p.firstname} ${p.lastname}`,
          type: p.type
        })));
      }
      
      return {
        totalPatients: patientRecords.length,
        withUpdated: patientsWithUpdated.length,
        withoutUpdated: patientsWithoutUpdated.length,
        latestPatientHasUpdated: hasUpdatedField
      };
      
    } catch (error) {
      console.error('❌ Error checking patient structure:', error);
      return null;
    }
  }
  
  static async testPatientSave(pouchdbService: any) {
    console.log('🧪 Testing patient save with updated field...');
    
    try {
      pouchdbService.initDB('patientdetail');
      
      // Create test patient with explicit updated field
      const testPatient = {
        _id: `test_patient_${Date.now()}`,
        type: 'patient',
        firstname: 'Test',
        lastname: 'Patient',
        contactNo: '9999999999',
        gender: 'Male',
        dob: '1990-01-01',
        synced: false,
        updated: false,
        lastModified: new Date().toISOString()
      };
      
      console.log('📝 Test patient object:', testPatient);
      
      // Save using addRecord
      const result = await pouchdbService.addRecord(testPatient);
      console.log('💾 Save result:', result);
      
      // Retrieve and verify
      const savedPatient = await pouchdbService.getRecordById(result.id);
      
      console.log('🔍 Retrieved patient:');
      console.log('- updated field present:', 'updated' in savedPatient ? '✅' : '❌');
      console.log('- updated value:', savedPatient.updated);
      console.log('- lastModified present:', 'lastModified' in savedPatient ? '✅' : '❌');
      console.log('- lastModified value:', savedPatient.lastModified);
      
      // Clean up
      await pouchdbService.deleteRecord({
        _id: savedPatient._id,
        _rev: savedPatient._rev
      });
      
      console.log('🧹 Test patient cleaned up');
      
      return {
        success: 'updated' in savedPatient && savedPatient.updated === false,
        hasUpdatedField: 'updated' in savedPatient,
        updatedValue: savedPatient.updated
      };
      
    } catch (error) {
      console.error('❌ Test failed:', error);
      return { success: false, error: error.message };
    }
  }
}

// Usage in browser console:
// DebugPatientSave.checkPatientStructure(this.objPouchdbService);
// DebugPatientSave.testPatientSave(this.objPouchdbService);