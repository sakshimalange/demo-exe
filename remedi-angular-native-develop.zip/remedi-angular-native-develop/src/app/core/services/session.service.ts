import { Injectable } from '@angular/core';
import { Observable, from, throwError, BehaviorSubject } from 'rxjs';
import { catchError, map, tap, switchMap } from 'rxjs/operators';
import { PouchdbService } from './pouchdb.service';
import { PlatformDetectorService } from './platform-detector.service';
import { ApiService } from './api.service';
import { ConstantService } from './constant.service';
import {
  SessionDocument,
  SessionValidationResult,
  LoginSessionData
} from '../interfaces/session.interface';

import { AndroidSessionFallbackService } from './android-session-fallback.service';

@Injectable({
  providedIn: 'root'
})
export class SessionService {
  private readonly SESSION_DOC_ID = 'user_session';
  private readonly DEFAULT_EXPIRY_HOURS = 24;

  private sessionState$ = new BehaviorSubject<SessionDocument | null>(null);
  private isInitialized = false;

  constructor(
    private pouchdbService: PouchdbService,
    private platformDetector: PlatformDetectorService,
    private apiService: ApiService,
    private constantService: ConstantService,
    private androidFallback: AndroidSessionFallbackService
  ) {
    this.initializeSession();
  }

  get currentSession$(): Observable<SessionDocument | null> {
    return this.sessionState$.asObservable();
  }

  get currentSession(): SessionDocument | null {
    console.log('this.sessionState$.value: ', this.sessionState$)
    return this.sessionState$.value;
  }

  get isLoggedIn$(): Observable<boolean> {
    return this.sessionState$.pipe(
      map(session => this.isValidSession(session))
    );
  }

  get isLoggedIn(): boolean {
    console.log('isLoggedIn() 02 method called', this.currentSession)
    return this.isValidSession(this.currentSession);
  }

  // private initializeSession(): void {
  //   if (this.isInitialized) return;

  //   const platform = this.platformDetector.getCurrentPlatform();
  //   console.log(' Initializing session service...');
  //   console.log('📱 Platform detected:', platform);
  //   console.log('📱 Is Android:', this.isAndroid);
  //   console.log('📱 Using Android fallback:', this.isAndroid);
  //   console.log("Login status", localStorage.getItem("isLoggedInStatus"));

  //   if (localStorage.getItem("isLoggedInStatus") === "true") {
  //     // Small delay to ensure all services are ready
  //     setTimeout(() => {
  //       this.restoreSession().subscribe({
  //         next: (session) => {
  //           if (session) {
  //             console.log(' Session restored successfully on', platform, '- User:', session.username);
  //             this.updateLastActivity();
  //           } else {
  //             console.log('ℹ️ No existing session found on', platform);
  //           }
  //           this.isInitialized = true;
  //         },
  //         error: (error) => {
  //           console.error(' Failed to restore session on', platform);
  //           this.logError('Session Restore', error);
  //           this.isInitialized = true;
  //         }
  //       });
  //     }, 100);
  //   }
  // }

  private initializeSession(): void {
  if (this.isInitialized) return;

  console.log(' Initializing session service...');
  const storedSession = localStorage.getItem('FULL_SESSION');

  if (storedSession) {
    try {
      const parsedSession: SessionDocument = JSON.parse(storedSession);
      const validation = this.validateSession(parsedSession);

      if (validation.isValid && validation.session) {
        console.log('✅ Session restored from localStorage');
        this.sessionState$.next(validation.session);
      } else {
        console.log('⚠️ Invalid or expired session in localStorage');
        this.clearLegacyStorage();
      }
    } catch (err) {
      console.error('❌ Failed to parse session from localStorage', err);
      this.clearLegacyStorage();
    }
  }

  // Fallback: also try PouchDB/Android restore
  this.restoreSession().subscribe({
    next: (session) => {
      if (session) {
        console.log(' Session restored successfully from DB');
        this.updateLastActivity();
      } else {
        console.log('ℹ️ No session found in DB');
      }
      this.isInitialized = true;
    },
    error: (error) => {
      console.error(' Failed to restore session from DB', error);
      this.isInitialized = true;
    }
  });
}


  private get isAndroid(): boolean {
    const platform = this.platformDetector.getCurrentPlatform().toLowerCase();
    const isAndroidPlatform = platform.includes('android');
    const isCapacitorAndroid = this.platformDetector.isAndroid;
    const result = isAndroidPlatform || isCapacitorAndroid;

    console.log('🤖 Android detection:',
      `Platform: ${this.platformDetector.getCurrentPlatform()}, IsAndroidPlatform: ${isAndroidPlatform}, IsCapacitorAndroid: ${isCapacitorAndroid}, Result: ${result}`
    );

    // this.pouchdbService.getRecordById("user_session").subscribe(
    //   res => {
    //     this.pouchdbService.deleteRecord(res);
    //   });
    this.pouchdbService.getAllRecords().subscribe(res => {
      console.log("getAllRecords", res);
    });
    console.log("sessionState getvalue", this.sessionState$.getValue());
    return result;
  }

  createSession(data: LoginSessionData): Observable<SessionDocument> {
    const platform = this.platformDetector.getCurrentPlatform();
    console.log('🔧 Creating session for platform:', platform);
    console.log('📊 Is Android detected:', this.isAndroid);
    console.log('📊 Login data received:', {
      hasToken: !!data.token,
      username: data.username,
      userId: data.userId
    });

    // Use Android fallback for better reliability
    if (this.isAndroid) {
      console.log('📱  Using Android fallback storage for session creation');
      return this.androidFallback.saveSession(data).pipe(
        tap((sessionDoc) => {
          this.sessionState$.next(sessionDoc);
          this.syncToLegacyStorage(sessionDoc);
          console.log(' Android session created successfully - login can proceed:', {
            username: sessionDoc.username,
            platform: sessionDoc.platform,
            hasToken: !!sessionDoc.token,
            isActive: sessionDoc.isActive
          });
        }),
        catchError((error) => {
          console.error(' Android fallback session creation failed, using minimal session...');
          this.logError('Android Fallback Error', error);

          // If Android fallback fails, create a minimal session and continue
          return this.createMinimalSession(data);
        })
      );
    }

    // Use PouchDB for other platforms
    console.log('💾 Using PouchDB storage for session creation');
    return this.createSessionWithPouchDB(data);
  }

  private createSessionWithPouchDB(data: LoginSessionData): Observable<SessionDocument> {
    console.log('💾 Starting PouchDB session creation...');
    const now = Date.now();
    const expiryTime = data.expiryHours
      ? now + (data.expiryHours * 60 * 60 * 1000)
      : now + (this.DEFAULT_EXPIRY_HOURS * 60 * 60 * 1000);

    // First, check if session document already exists to get _rev
    return this.pouchdbService.getRecordById<SessionDocument>(this.SESSION_DOC_ID).pipe(
      catchError((error) => {
        // If document doesn't exist (404), that's fine - we'll create a new one
        if (error.status === 404) {
          console.log('💾 No existing session document found, creating new one');
          return from([null]);
        }
        // For other errors, still continue with creation attempt
        console.warn(' Error checking existing session:', error);
        return from([null]);
      }),
      switchMap((existingSession) => {
        const sessionDoc: SessionDocument = {
          _id: this.SESSION_DOC_ID,
          token: data.token,
          userId: data.userId,
          username: data.username,
          loginTime: now,
          expiryTime: expiryTime,
          userProfile: data.userProfile,
          loginResponse: data.loginResponse,
          clientId: data.clientId,
          domainId: data.domainId,
          language: data.language,
          isActive: true,
          platform: this.platformDetector.getCurrentPlatform(),
          lastActivity: now
        };

        // If existing session found, include the _rev to avoid conflict
        if (existingSession && existingSession._rev) {
          sessionDoc._rev = existingSession._rev;
          console.log('💾 Updating existing session document with _rev:', existingSession._rev);
        } else {
          console.log('💾 Creating new session document');
        }

        console.log('💾 Session document prepared:', {
          _id: sessionDoc._id,
          username: sessionDoc.username,
          platform: sessionDoc.platform,
          hasToken: !!sessionDoc.token,
          hasRev: !!sessionDoc._rev
        });

        return this.pouchdbService.addRecord(sessionDoc).pipe(
          tap(() => {
            this.sessionState$.next(sessionDoc);
            this.syncToLegacyStorage(sessionDoc);
            console.log(' PouchDB session created/updated successfully');
          }),
          map(() => sessionDoc),
          catchError((error) => {
            console.error(' PouchDB session creation failed - detailed error:');
            this.logError('PouchDB Session Creation', error);

            // If still getting conflict error, try to clear the existing document and retry once
            if (error.status === 409 && !sessionDoc._rev) {
              console.log(' Conflict detected, attempting to clear and retry...');
              return this.clearSessionPouchDB().pipe(
                switchMap(() => {
                  // Retry without _rev after clearing
                  const retrySessionDoc = { ...sessionDoc };
                  delete retrySessionDoc._rev;
                  return this.pouchdbService.addRecord(retrySessionDoc);
                }),
                tap(() => {
                  this.sessionState$.next(sessionDoc);
                  this.syncToLegacyStorage(sessionDoc);
                  console.log(' PouchDB session created successfully after retry');
                }),
                map(() => sessionDoc),
                catchError(() => {
                  // If retry also fails, create minimal session for login continuation
                  console.log(' PouchDB retry failed, creating minimal session');
                  return this.createMinimalSession(data);
                })
              );
            }

            // For other errors, create minimal session to continue login
            console.log(' PouchDB creation failed, creating minimal session');
            return this.createMinimalSession(data);
          })
        );
      })
    );
  }

  private logError(context: string, error: any): void {
    console.group(` ${context} Error Details`);
    console.log('Error type:', typeof error);
    console.log('Error constructor:', error?.constructor?.name);

    if (error instanceof Error) {
      console.log('Error name:', error.name);
      console.log('Error message:', error.message);
      console.log('Error stack:', error.stack);
    }

    if (error && typeof error === 'object') {
      Object.keys(error).forEach(key => {
        console.log(`Error.${key}:`, error[key]);
      });
    }

    console.log('Raw error:', error);
    console.groupEnd();
  }

  private createSessionFallbackToPouchDB(data: LoginSessionData): Observable<SessionDocument> {
    console.log(' Falling back to PouchDB for session creation');
    return this.createSessionWithPouchDB(data);
  }

  private createMinimalSession(data: LoginSessionData): Observable<SessionDocument> {
    console.log('🆘 Creating minimal session for login continuation');

    const sessionDoc: SessionDocument = {
      _id: this.SESSION_DOC_ID,
      token: data.token,
      userId: data.userId,
      username: data.username,
      loginTime: Date.now(),
      expiryTime: Date.now() + (24 * 60 * 60 * 1000),
      userProfile: data.userProfile,
      loginResponse: data.loginResponse,
      clientId: data.clientId,
      domainId: data.domainId,
      language: data.language,
      isActive: true,
      platform: 'android-minimal',
      lastActivity: Date.now()
    };

    // Store in memory and sync to legacy storage only
    this.sessionState$.next(sessionDoc);
    this.syncToLegacyStorage(sessionDoc);

    console.log(' Minimal session created successfully - login redirect should work:', {
      username: sessionDoc.username,
      hasToken: !!sessionDoc.token,
      isActive: sessionDoc.isActive
    });
    return from([sessionDoc]);
  }

  restoreSession(): Observable<SessionDocument | null> {
    console.log(' Attempting to restore session on platform:', this.platformDetector.getCurrentPlatform());

    // Use Android fallback for better reliability
    if (this.isAndroid) {
      console.log('📱 Using Android fallback storage for session restoration');
      return this.androidFallback.restoreSession().pipe(
        switchMap((session) => {
          if (session) {
            this.sessionState$.next(session);
            this.syncToLegacyStorage(session);
            return from([session]);
          } else {
            // Try PouchDB as fallback
            console.log(' Android fallback found no session, trying PouchDB...');
            return this.restoreSessionFromPouchDB();
          }
        })
      );
    }

    // Use PouchDB for other platforms
    return this.restoreSessionFromPouchDB();
  }

  private restoreSessionFromPouchDB(): Observable<SessionDocument | null> {
    return this.pouchdbService.getRecordById<SessionDocument>(this.SESSION_DOC_ID).pipe(
      map(session => {
        console.log("session restoreSessionFromPouchDB ", session);

        const validation = this.validateSession(session);

        if (validation.isValid && validation.session) {
          this.sessionState$.next(validation.session);
          this.syncToLegacyStorage(validation.session);
          return validation.session;
        } else {
          console.log(` Invalid PouchDB session: ${validation.reason}`);
          return null;
        }
      }),
      catchError((error) => {
        if (error.status === 404) {
          console.log('ℹ️ No existing PouchDB session document found');
          return from([null]);
        }
        console.error(' Error restoring PouchDB session:', error);
        return from([null]);
      })
    );
  }

  validateSession(session: SessionDocument | null): SessionValidationResult {
    // console.log('validateSession() method called :', session)
    if (!session) {
      return { isValid: false, isExpired: false, reason: 'No session found' };
    }

    if (!session.isActive) {
      return { isValid: false, isExpired: false, reason: 'Session is inactive' };
    }

    if (!session.token || session.token.trim() === '') {
      return { isValid: false, isExpired: false, reason: 'No token in session' };
    }

    const now = Date.now();

    // Check expiry if set
    if (session.expiryTime && now > session.expiryTime) {
      return { isValid: false, isExpired: true, reason: 'Session expired' };
    }

    // Check for very old sessions (7 days) as fallback
    const sevenDaysInMs = 7 * 24 * 60 * 60 * 1000;
    if (now - session.loginTime > sevenDaysInMs) {
      return { isValid: false, isExpired: true, reason: 'Session too old' };
    }

    return { isValid: true, isExpired: false, session };
  }

  updateLastActivity(): Observable<boolean> {
    const currentSession = this.currentSession;
    if (!currentSession) return from([false]);

    // Use Android fallback for updates
    if (this.isAndroid) {
      return this.androidFallback.updateLastActivity().pipe(
        tap((success) => {
          if (success) {
            // Update the main session state
            const updatedSession = {
              ...currentSession,
              lastActivity: Date.now()
            };
            this.sessionState$.next(updatedSession);
          }
        }),
        catchError(() => {
          // Fallback to PouchDB update
          return this.updateLastActivityPouchDB();
        })
      );
    }

    return this.updateLastActivityPouchDB();
  }

  private updateLastActivityPouchDB(): Observable<boolean> {
    const currentSession = this.currentSession;
    if (!currentSession) return from([false]);

    const updatedSession = {
      ...currentSession,
      lastActivity: Date.now()
    };

    return this.pouchdbService.updateRecord(updatedSession).pipe(
      tap(() => {
        this.sessionState$.next(updatedSession);
      }),
      map(() => true),
      catchError(() => from([false]))
    );
  }

  extendSession(additionalHours: number = 24): Observable<SessionDocument> {
    const currentSession = this.currentSession;
    if (!currentSession) {
      return throwError(() => new Error('No active session to extend'));
    }

    const now = Date.now();
    const newExpiryTime = now + (additionalHours * 60 * 60 * 1000);

    const extendedSession = {
      ...currentSession,
      expiryTime: newExpiryTime,
      lastActivity: now
    };

    return this.pouchdbService.updateRecord(extendedSession).pipe(
      tap(() => {
        this.sessionState$.next(extendedSession);
        this.syncToLegacyStorage(extendedSession);
        console.log(` Session extended by ${additionalHours} hours`);
      }),
      map(() => extendedSession),
      catchError(this.handleError)
    );
  }

  clearSession(): Observable<boolean> {
    console.log('🗑️ Clearing session from all storage methods...');

    // Use Android fallback for clearing
    if (this.isAndroid) {
      return this.androidFallback.clearSession().pipe(
        tap(() => {
          // Clear memory state and legacy storage
          this.sessionState$.next(null);
          this.clearLegacyStorage();
          console.log(' Android session cleared successfully');
        }),
        catchError((error) => {
          console.error(' Android session clear failed:', error);
          // Fallback to PouchDB clear
          return this.clearSessionPouchDB();
        })
      );
    }

    return this.clearSessionPouchDB();
  }

  private clearSessionPouchDB(): Observable<boolean> {
    console.log('🗑️ Clearing PouchDB session...', this.SESSION_DOC_ID);
    // this.pouchdbService.getAllRecords().subscribe(res => {
    //   console.log("getAllRecords logout", res);
    // });
    // this.pouchdbService.getRecordById("user_session").subscribe(
    //   res => {
    //     this.pouchdbService.deleteRecord(res);
    //   });
    return this.pouchdbService.getRecordById<SessionDocument>(this.SESSION_DOC_ID).pipe(
      switchMap((sessionDoc) => {
        if (sessionDoc && sessionDoc._rev) {
          console.log('🗑️ Deleting existing session document with _rev:', sessionDoc._rev);
          return this.pouchdbService.deleteRecord(sessionDoc);
        } else {
          console.log('🗑️ No session document found to delete');
          return from([true]);
        }
      }),
      tap(() => {
        // Clear memory state
        console.log("sessionState getvalue logout", this.sessionState$.getValue());
        this.sessionState$.next(null);
        // this.sessionState$.complete();
        // Clear legacy storage
        this.clearLegacyStorage();
        console.log('PouchDB session cleared completely');
      }),
      map(() => true),
      catchError((error) => {
        console.warn('Error clearing PouchDB session, continuing anyway:', error);
        // Try to get current session document to delete properly
        // this.pouchdbService.clearDatabase().then(() => {
        localStorage.clear();
        for (let i = 0; i < sessionStorage.length; i++) {
          if (sessionStorage.key(i) !== "isLoggedInStatus") {
            sessionStorage.removeItem(sessionStorage.key(i) || "");
          }
        }
        this.pouchdbService.getRecordById("user_session").subscribe(res => {
          this.pouchdbService.deleteRecord(res);
        });
        // sessionStorage.clear();
        // sessionStorage.getItem("isLoggedInStatus")
        this.sessionState$.next(null);
        // this.sessionState$.complete();
        // Clear legacy storage
        this.clearLegacyStorage();
        // });
        return from([true]);
      })
    );
  }

  getToken(): string | null {
    return this.currentSession?.token || null;
  }

  getUserProfile(): any | null {
    return this.currentSession?.userProfile || null;
  }

  getLoginResponse(): any | null {
    return this.currentSession?.loginResponse || null;
  }

  // Legacy compatibility methods
  // private syncToLegacyStorage(session: SessionDocument): void {
  //   console.log("session syncToLegacyStorage", session);

  //   try {
  //     // Sync to localStorage for legacy compatibility
  //     localStorage.setItem('authToken', session.token);
  //     localStorage.setItem('token', session.token);
  //     sessionStorage.setItem('token', session.token);
  //     localStorage.setItem('client_Id', session.clientId);
  //     localStorage.setItem('domainId', session.domainId);
  //     localStorage.setItem('language', session.language);
  //     localStorage.setItem('LOGIN_RESPONSE', JSON.stringify(session.loginResponse));

  //     if (session.userProfile) {
  //       localStorage.setItem('USER', JSON.stringify(session.userProfile));
  //     }

  //     // Also sync to sessionStorage
  //     sessionStorage.setItem('LOGIN_RESPONSE', JSON.stringify(session.loginResponse));
  //     sessionStorage.setItem('language', session.language);

  //     if (session.userProfile) {
  //       sessionStorage.setItem('USER', JSON.stringify(session.userProfile));
  //     }
  //   } catch (error) {
  //     console.warn(' Failed to sync to legacy storage:', error);
  //   }
  // }

  private syncToLegacyStorage(session: SessionDocument): void {
  try {
    localStorage.setItem('FULL_SESSION', JSON.stringify(session)); // 👈 new line

    // keep your old code for backward compatibility
    localStorage.setItem('authToken', session.token);
    localStorage.setItem('token', session.token);
    sessionStorage.setItem('token', session.token);
    localStorage.setItem('client_Id', session.clientId);
    // localStorage.setItem('domainId', session.domainId);
    localStorage.setItem('language', session.language);
    localStorage.setItem('LOGIN_RESPONSE', JSON.stringify(session.loginResponse));

    if (session.userProfile) {
      localStorage.setItem('USER', JSON.stringify(session.userProfile));
    }

    sessionStorage.setItem('LOGIN_RESPONSE', JSON.stringify(session.loginResponse));
    sessionStorage.setItem('language', session.language);

    if (session.userProfile) {
      sessionStorage.setItem('USER', JSON.stringify(session.userProfile));
    }
  } catch (error) {
    console.warn(' Failed to sync to legacy storage:', error);
  }
}


  private clearLegacyStorage(): void {
    try {
      // Clear localStorage
       localStorage.removeItem('FULL_SESSION'); 
       
      localStorage.removeItem('authToken');
      localStorage.removeItem('token');
      localStorage.removeItem('client_Id');
      // localStorage.removeItem('domainId');
      localStorage.removeItem('language');
      localStorage.removeItem('LOGIN_RESPONSE');
      localStorage.removeItem('USER');

      // Clear sessionStorage
      sessionStorage.removeItem('LOGIN_RESPONSE');
      sessionStorage.removeItem('language');
      sessionStorage.removeItem('USER');
    } catch (error) {
      console.warn(' Failed to clear legacy storage:', error);
    }
  }

  private isValidSession(session: SessionDocument | null): boolean {
    console.log('sessionsessionsession:', session)
    console.log('isValidSession() method called', this.validateSession(session), this.validateSession(session).isValid)
    return this.validateSession(session).isValid;
  }

  private handleError(error: any) {
    // Better error logging to avoid [object Object]
    let errorMessage = 'Unknown error';
    console.log('Session unknown error log')
    try {
      if (error instanceof Error) {
        errorMessage = `${error.name}: ${error.message}`;
      } else if (error && typeof error === 'object') {
        errorMessage = JSON.stringify(error, null, 2);
      } else {
        errorMessage = String(error);
      }
    } catch (e) {
      errorMessage = 'Error serialization failed: ' + String(error);
    }

    console.error(' Session service error details:', errorMessage);
    console.error(' Raw error object:', error);
    return throwError(() => error);
  }

  // Sync session with backend API
  syncSessionWithBackend(): Observable<boolean> {
    const currentSession = this.currentSession;
    if (!currentSession) {
      return throwError(() => new Error('No session to sync'));
    }

    console.log(' Validating session with backend API...');

    return this.validateTokenWithBackend(currentSession.token).pipe(
      tap((isValid) => {
        if (isValid) {
          console.log(' Session validated with backend API');
          this.updateLastActivity();
        } else {
          console.log(' Session invalid according to backend, clearing...');
          this.clearSession();
        }
      }),
      catchError((error) => {
        console.error(' Session validation failed:', error);
        // Don't clear session on network errors, just return false
        return from([false]);
      })
    );
  }

  // Validate token with your existing backend API
  private validateTokenWithBackend(token: string): Observable<boolean> {
    if (!token || token.trim() === '') {
      return from([false]);
    }

    // Use your existing API endpoint to validate the token
    const queryParams = `?action=validateToken&token=${encodeURIComponent(token)}`;

    return this.apiService.postServiceByQueryBasic<any>(
      this.constantService.APIConfig.GETCOMMONSERVICES,
      queryParams
    ).pipe(
      map((response: any) => {
        console.log('🔍 Token validation response:', response);
        return response?.status === 'success' && response?.valid === true;
      }),
      catchError((error) => {
        console.error(' Token validation API error:', error);
        // If the API call fails, we'll assume the token might still be valid
        // to avoid logging out users due to network issues
        return from([true]);
      })
    );
  }

  // Sync local session data with backend (for analytics/audit trail)
  syncSessionDataWithBackend(): Observable<any> {
    const currentSession = this.currentSession;
    if (!currentSession) {
      return from([{ message: 'No session to sync' }]);
    }

    console.log('📤 Syncing session data with backend...');

    const sessionData = {
      action: 'syncSessionData',
      sessionId: currentSession._id,
      userId: currentSession.userId,
      username: currentSession.username,
      platform: currentSession.platform,
      loginTime: currentSession.loginTime,
      lastActivity: currentSession.lastActivity,
      token: currentSession.token
    };

    return this.apiService.post<any>(
      this.constantService.APIConfig.GETCOMMONSERVICES + '?action=syncSessionData',
      sessionData,
      true
    ).pipe(
      map((response: any) => {
        console.log(' Session data synced with backend:', response);
        return response;
      }),
      catchError((error) => {
        console.warn(' Failed to sync session data with backend:', error);
        return from([{ message: 'Sync failed but session remains valid locally' }]);
      })
    );
  }

  // Debug methods
  getSessionInfo(): any {
    const session = this.currentSession;
    if (!session) {
      return {
        hasSession: false,
        platform: this.platformDetector.getCurrentPlatform(),
        isAndroid: this.isAndroid,
        usingAndroidFallback: this.isAndroid
      };
    }

    const androidInfo = this.isAndroid ? this.androidFallback.getSessionInfo() : null;

    return {
      hasSession: true,
      isValid: this.isValidSession(session),
      userId: session.userId,
      username: session.username,
      loginTime: new Date(session.loginTime).toLocaleString(),
      expiryTime: session.expiryTime ? new Date(session.expiryTime).toLocaleString() : 'No expiry',
      platform: session.platform,
      lastActivity: new Date(session.lastActivity).toLocaleString(),
      timeUntilExpiry: session.expiryTime ? Math.max(0, session.expiryTime - Date.now()) : null,
      canSyncWithBackend: true,
      isAndroid: this.isAndroid,
      usingAndroidFallback: this.isAndroid,
      androidFallbackInfo: androidInfo
    };
  }
}
