import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WebsocketConfigService {
  
  private readonly BASE_BLE_PORT = 8444;
  private readonly BASE_PARAM_PORT = 8444;
  
  constructor() {}

  /**
   * Get WebSocket URLs based on session instance
   * First instance: ports 8444
   * Second instance: ports 8445
   */
  getWebSocketUrls(): { bleUrl: string; paramUrl: string } {
    const instanceId = this.getInstanceId();
    const isFirstInstance = this.isFirstInstance();
    
    // First browser tab/window gets original port, second gets offset
    const portOffset = isFirstInstance ? 0 : 1;
    
    const blePort = this.BASE_BLE_PORT + portOffset;
    const paramPort = this.BASE_PARAM_PORT + portOffset;
    
    const config = {
      bleUrl: `ws://localhost:${blePort}/bleWS/`,
      paramUrl: `ws://localhost:${paramPort}/paramWS/`
    };
    
    console.log(`🔧 WebSocket Config (Instance: ${instanceId}, First: ${isFirstInstance}):`, config);
    
    return config;
  }

  private getUserType(): string {
    try {
      const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
      return loginResponse.commondetail?.usertype || loginResponse.usertype || 'Doctor';
    } catch {
      return 'Doctor';
    }
  }

  private getInstanceId(): string {
    // Generate or retrieve instance ID for this browser tab/window
    let instanceId = sessionStorage.getItem('websocket_instance_id');
    if (!instanceId) {
      instanceId = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('websocket_instance_id', instanceId);
    }
    return instanceId;
  }

  private isFirstInstance(): boolean {
    // Check if this is the first instance by using localStorage counter
    const instanceCount = parseInt(localStorage.getItem('websocket_instance_count') || '0');
    const myInstanceNumber = parseInt(sessionStorage.getItem('websocket_instance_number') || '0');
    
    if (myInstanceNumber === 0) {
      // This is a new instance, assign it a number
      const newInstanceNumber = instanceCount + 1;
      sessionStorage.setItem('websocket_instance_number', newInstanceNumber.toString());
      localStorage.setItem('websocket_instance_count', newInstanceNumber.toString());
      
      // Clean up on page unload
      window.addEventListener('beforeunload', () => {
        const currentCount = parseInt(localStorage.getItem('websocket_instance_count') || '1');
        if (currentCount > 1) {
          localStorage.setItem('websocket_instance_count', (currentCount - 1).toString());
        } else {
          localStorage.removeItem('websocket_instance_count');
        }
      });
      
      return newInstanceNumber === 1;
    }
    
    return myInstanceNumber === 1;
  }

  /**
   * Check if ports are available (for future enhancement)
   */
  async checkPortAvailability(port: number): Promise<boolean> {
    try {
      const ws = new WebSocket(`ws://localhost:${port}/test`);
      return new Promise((resolve) => {
        ws.onopen = () => {
          ws.close();
          resolve(true);
        };
        ws.onerror = () => resolve(false);
        setTimeout(() => resolve(false), 1000);
      });
    } catch {
      return false;
    }
  }
}