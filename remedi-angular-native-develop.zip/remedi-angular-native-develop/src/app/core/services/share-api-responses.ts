import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class SharedDataService<T = any> {
  private dataSource = new BehaviorSubject<T | null>(null);

  // Observable to subscribe to the data changes
  getData(): Observable<T | null> {
    return this.dataSource.asObservable();
  }

  // Method to update the data
  setData(data: T): void {
    this.dataSource.next(data);
  }

  // Optional: clear data if needed
  clearData(): void {
    this.dataSource.next(null);
  }
}
