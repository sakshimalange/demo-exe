// Define a generic structure for any record (User/Patient/Customer etc.)
export class GlobalRecord {
  _id?: string = '';       // Unique Document ID (Generated Automatically)
  _rev?: string = '';      // Revision ID (Required for Update/Delete)
  type?: string = '';      // Record type (example: 'patient', 'user', 'customer')
  // Common Fields (Can Add More as per Requirement)
  first_name: string = '';
  last_name: string = '';
  gender: string = '';
  dob: string = '';
  email?: string = '';
  phone?: string = '';
  synced?: boolean;         // Used for Sync Status
}


export interface Root {
   _id?: string    
  action: string
  domain: string
  consultationId: number
  patientId: number
  isNewReading: boolean
  isBle: string
  ecgPulse: string
  ecgDataChunk: string
  token: string
  synced?: boolean
  timestamp?: string
}


export interface Root {
  patientId: number
  domain: string
  consultationId: number
  token: string
  isEcgBle: boolean
  isBleEcgReadingComplet: number
}

