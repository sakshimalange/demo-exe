import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'arrayify' })
export class ArrayifyPipe implements PipeTransform {
  transform(value: any): any[] {
    if (!value) return [];
    return Array.isArray(value) ? value : [value];
  }
}
