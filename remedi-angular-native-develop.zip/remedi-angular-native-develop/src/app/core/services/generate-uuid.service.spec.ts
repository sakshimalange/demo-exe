import { TestBed } from '@angular/core/testing';

import { GenerateUuidService } from './generate-uuid.service';

describe('GenerateUuidService', () => {
  let service: GenerateUuidService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GenerateUuidService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
