import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, from, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { generateUUIDv4 } from './generate-uuid.service';
import PouchDB from 'pouchdb-browser';
import PouchDBFind from 'pouchdb-find';
import { environment } from 'src/environments/environment';
interface PouchDbResponse {
  rows: { doc: any }[];
}
@Injectable({
  providedIn: 'root',
})
export class PouchdbService {
  getRecord(MASTER_DOC_ID: string, DB_NAME: string): Observable<unknown> { // Here you would integrate with your existing API endpoints
    throw new Error('Method not implemented.');
  }
  saveDocument: any;
  save(record: {
    _id: string;
    hba1c: number | null;
    mmol: number | null;
    eag: number | null;
    units: string;
    createdAt: Date;
  }) {
    throw new Error('Method not implemented.');
  }
  saveData(p0: string, doc: { _id: string; type: string; batchCode: string; hemoglobin: number; patientId: any; consultationId: any; createdAt: string; }, record: {
  _id: string;
  hba1c: number | null;
  mmol: number | null;
  eag: number | null;
  units: string;
  createdAt: Date;
}) {
    throw new Error('Method not implemented.');
  }
  private db!: any;
  private remoteDB!: any;
  private masterData: { [tableName: string]: any[] } = {};
  private masterDataSubject = new BehaviorSubject<Record<string, any[]> | null>(
    null
  );

  constructor() {
    PouchDB.plugin(PouchDBFind);
    this.initDB('consultation_db');
  }

  // Method to manually trigger database check
  async checkOfflineSearchSetup(): Promise<void> {
    console.log('🔍 Checking offline search setup...');

    // Check if patientdetail database exists and has data
    this.initDB('patientdetail');
    const patientCheck = await this.checkPatientsExist();
    console.log('👥 Patient database check:', patientCheck);

    if (!patientCheck.exists) {
      console.warn('⚠️ No patient data found in offline database. Make sure to sync patient data when online.');
    }
  }

  initDB(dbName: string): void {
    this.db = new PouchDB(dbName, { adapter: 'idb' });
    console.log(`PouchDB Initialized: ${dbName}`);

    // ✅ Create index for type field to avoid "no_usable_index"
    this.db
      .createIndex({
        index: { fields: ['type'] },
      })
      .then(() => {
        console.log(' Index on "type" created successfully');
        // Debug: Check what's in the database
        this.debugDatabaseContents();
      })
      .catch((err: any) => {
        console.error(' Error creating index:', err);
      });
  }

  // Debug method to check database contents
  async debugDatabaseContents(): Promise<void> {
    try {
      const info = await this.db.info();
      console.log('📊 Database info:', info);

      const allDocs = await this.db.allDocs({ include_docs: true, limit: 5 });
      console.log(`📦 Database contains ${allDocs.total_rows} documents`);

      if (allDocs.rows.length > 0) {
        console.log('📄 Sample documents:');
        allDocs.rows.forEach((row: any, index: number) => {
          console.log(`  Document ${index + 1}:`, {
            id: row.doc._id,
            type: row.doc.type,
            keys: Object.keys(row.doc).slice(0, 10) // First 10 keys
          });
        });
      } else {
        console.log('📭 Database is empty');
      }
    } catch (err) {
      console.error('❌ Error checking database contents:', err);
    }
  }

  addRecord(data: any): Observable<any> {
    data._id = data._id || generateUUIDv4();

    //  Clean up invalid _rev before saving
    if (
      data._rev &&
      (typeof data._rev !== 'string' || !data._rev.includes('-'))
    ) {
      // console.warn(' Invalid _rev detected, removing:', data._rev);
      delete data._rev;
    }

    // Ensure updated field is set for patient records
    if (data.type === 'patient' && data.updated === undefined) {
      data.updated = false;
    }
    if (data.type === 'patient' && !data.lastModified) {
      data.lastModified = new Date().toISOString();
    }

    console.log('💾 PouchDB addRecord attempt:', {
      _id: data._id,
      hasRev: !!data._rev,
      rev: data._rev,
      type: data.type,
      synced: data.synced,
      updated: data.updated,
      lastModified: data.lastModified,
      firstname: data.firstname
    });

    console.log('💾 Full data object being saved:', JSON.stringify(data, null, 2));

    return from(this.db.put(data)).pipe(
      map((res: any) => {
        // console.log('PouchDB put successful:', { id: res.id, rev: res.rev });
        return res;
      }),
      catchError((error: any) => {
        console.error(' PouchDB put failed:', {
          error: error.name,
          status: error.status,
          id: error.id || data._id,
        });
        return this.handleError(error);
      })
    );
  }

  getAllRecords<T>(): Observable<T[]> {
    return from(this.db.allDocs({ include_docs: true })).pipe(
      map((res: any) => res.rows.map((r: any) => r.doc as T)),
      catchError(this.handleError)
    );
  }

  getRecordById<T>(id: string): Observable<T> {
    return from(this.db.get(id)).pipe(
      map((res) => res as T),
      catchError(this.handleError)
    );
  }

  updateRecord(data: any): Observable<any> {
    if (!data._id) {
      return throwError(() => new Error('Record must have _id to update'));
    }

    //  Get existing document to get the correct _rev
    return from(
      this.db.get(data._id).then((existingDoc: { _rev: any }) => {
        const updatedDoc = {
          ...existingDoc,
          ...data,
          _rev: existingDoc._rev, //  Proper revision
        };
        return this.db.put(updatedDoc);
      })
    ).pipe(
      map((res) => res),
      catchError(this.handleError)
    );
  }

  deleteRecord(data: any): Observable<any> {
    if (!data._id || !data._rev) {
      return throwError(
        () => new Error('Record must have _id and _rev to delete')
      );
    }

    return from(this.db.remove(data._id, data._rev)).pipe(
      map((res) => res),
      catchError(this.handleError)
    );
  }

  // Sync with backend API instead of remote PouchDB
  syncWithBackendAPI(): Observable<any> {
    console.log('Syncing local PouchDB data with backend APIs...');

    return new Observable((observer) => {
      // Get all unsynced records and sync them with backend
      this.getUnsyncedRecords('session').subscribe({
        next: (unsyncedSessions) => {
          if (unsyncedSessions.length === 0) {
            console.log(' No session data to sync');
            observer.next({ synced: 0, message: 'No data to sync' });
            observer.complete();
            return;
          }

          console.log(
            `Found ${unsyncedSessions.length} unsynced session records`
          );
          // Here you would integrate with your existing API endpoints
          // For now, we'll just mark them as synced locally
          observer.next({
            synced: unsyncedSessions.length,
            message: 'Session data synced locally (API integration pending)',
          });
          observer.complete();
        },
        error: (error) => {
          console.error(' Sync failed:', error);
          observer.error(error);
        },
      });
    });
  }

  // Alternative sync method - you can remove this if not using remote PouchDB
  syncWithRemotePouchDB(remoteURL?: string): Observable<any> {
    if (!remoteURL) {
      console.warn('No remote PouchDB URL configured, skipping sync');
      return from([{ message: 'Remote sync skipped - no URL configured' }]);
    }

    this.remoteDB = new PouchDB(remoteURL);
    return new Observable((observer) => {
      const syncHandler = this.db
        .sync(this.remoteDB, {
          live: false, // Changed to false for one-time sync
          retry: true,
        })
        .on('change', (info: any) => observer.next(info))
        .on('paused', (err: any) => console.log('Sync paused:', err))
        .on('active', () => console.log('Sync active'))
        .on('complete', () => {
          console.log('✅ Remote PouchDB sync completed');
          observer.complete();
        })
        .on('error', (err: any) => observer.error(err));

      return () => syncHandler.cancel();
    });
  }

  private handleError(error: any) {
    // Better error logging to avoid [object Object]
    let errorMessage = 'Unknown PouchDB error';
    try {
      if (error instanceof Error) {
        errorMessage = `${error.name}: ${error.message}`;
      } else if (error && typeof error === 'object') {
        errorMessage = JSON.stringify(error, null, 2);
      } else {
        errorMessage = String(error);
      }
    } catch (e) {
      errorMessage = 'PouchDB error serialization failed: ' + String(error);
    }

    // console.error('❌ PouchDB Error details:', errorMessage);
    // console.error('❌ PouchDB Raw error:', error);
    return throwError(() => error);
  }

  getUnsyncedRecords<T>(type: string): Observable<T[]> {
    return from(
      this.db.find({
        selector: {
          type: type,
          synced: { $ne: true }, // not synced yet
        },
      })
    ).pipe(
      map((result: any) => result.docs as T[]),
      catchError((error) => {
        console.error('❌ Error getting unsynced records:', error);
        return throwError(() => error);
      })
    );
  }

  // 🔹================ MASTER DATA FUNCTIONS =================

  /** Add/Update Master Data in PouchDB */
  // addOrUpdateMasterData(data: any): Observable<any> {
  //   const docId = 'master_data';
  //   return from(
  //     this.db.get(docId).then((doc: any) => this.db.put({ ...doc, ...data, _id: docId, _rev: doc._rev }))
  //       .catch(() => this.db.put({ _id: docId, ...data }))
  //   ).pipe(
  //     map(res => res),
  //     catchError(this.handleError)
  //   );
  // }

  async saveMasterData(masterJson: any) {
    try {
      console.log('masterJson', masterJson)
      const existing = await this.db.get('master_data');
      console.log('existing', existing)
      masterJson._id = existing._id;
      masterJson._rev = existing._rev;
      await this.db.put(masterJson);
    } catch (err: any) {
      if (err.status === 404) {
        masterJson._id = 'master_data';
        await this.db.put(masterJson);
      } else {
        throw err;
      }
    }
  }

  async getMasterData11(): Promise<any> {
    try {
      this.db = new PouchDB('master_data');
      const doc = await this.db.get('master_data');
      // this.db.close();
      return doc;
    } catch (err) {
      console.error('Error getting master data:', err);
      return null;
    }
  }

  /**
   * Fetch required "table" by name from masterData
   */
  async getTable(tableName: string): Promise<any[]> {
    const master = await this.getMasterData11();

    console.log('all_master: ', master);
    if (!master || !master.data) return [];

    const tableObj = master.data.find((t: any) => t[tableName]);
    return tableObj ? tableObj[tableName] : [];
  }

  /** Fetch entire master data from PouchDB */
  // getMasterData(): Observable<any> {
  //   const docId = 'master_data';
  //   return from(
  //     this.db.get(docId).catch((err: any) => {
  //       if (err.status === 404) {
  //         console.warn(` ${docId} not found. Initializing empty doc...`);
  //         const initDoc = { _id: docId, data: {} };
  //         return this.db.put(initDoc).then(() => initDoc);
  //       }
  //       throw err;
  //     })
  //   ).pipe(
  //     map(res => res),
  //     catchError(this.handleError)
  //   );
  // }

  /** Fetch specific table from master data in PouchDB */
  // getMasterTable(tableName: string): Observable<any[]> {
  //   return from(this.db.get('master_data')).pipe(
  //     map((res: any) => res[tableName] || []),
  //     catchError(this.handleError)
  //   );
  // }

  // Expose as observable
  // masterData$ = this.masterDataSubject.asObservable();

  // processMasterData(raw: any, filterDeleted = true): void {
  //   if (!raw) return console.warn(' No master data provided');

  //   const masterArray = Array.isArray(raw?.data) ? raw.data : [raw];
  //   this.masterData = {};

  //   masterArray.forEach((item: any) => {
  //     Object.keys(item).forEach((tableName) => {
  //       let tableData = Array.isArray(item[tableName])
  //         ? [...item[tableName]]
  //         : [];
  //       if (filterDeleted)
  //         tableData = tableData.filter(
  //           (r) => r.IsDeleted === undefined || r.IsDeleted === '0'
  //         );
  //       this.masterData[tableName] = tableData;
  //     });
  //   });

  //   // 🔹 Notify all subscribers
  //   this.masterDataSubject.next(this.masterData);

  //   console.log(
  //     ' Master data processed. Tables:',
  //     Object.keys(this.masterData)
  //   );
  // }

  /**
   * Get processed table data (already in memory)
   * @param tableName Table name
   * @param sortField Optional field to sort by
   * @param sortAsc Ascending order (default: true)
   */
  // getMasterList<T>(
  //   tableName: string,
  //   sortField?: keyof T,
  //   sortAsc = true,
  //   lastOnly = false
  // ): T[] {
  //   let list: T[] = this.masterData?.[tableName] || [];

  //   if (sortField) {
  //     list = [...list].sort((a, b) => {
  //       const av = (a[sortField] ?? '')
  //         .toString()
  //         .normalize('NFD')
  //         .replace(/[\u0300-\u036f]/g, '')
  //         .trim()
  //         .toLowerCase();
  //       const bv = (b[sortField] ?? '')
  //         .toString()
  //         .normalize('NFD')
  //         .replace(/[\u0300-\u036f]/g, '')
  //         .trim()
  //         .toLowerCase();
  //       return sortAsc ? av.localeCompare(bv) : bv.localeCompare(av);
  //     });
  //   }

  //   if (lastOnly && list.length > 0) {
  //     return [list[list.length - 1]]; // 🔹 return only last record
  //   }

  //   return list;
  // }
  // private handleError(err: any) {
  //   console.error('❌ PouchDB Error:', err);
  //   return throwError(() => err);
  // }

  // 🔹================ CONSULTATION DATA FUNCTIONS =================

  /**  Get records by type (for consultation data like complaints, diagnosis, etc.) */
  getRecordsByType<T>(type: string): Observable<T[]> {
    if (!this.db) {
      return throwError(() => new Error('Database not initialized'));
    }

    return from(
      this.db.find({
        selector: { type: type },
      })
    ).pipe(
      map((result: any) => result.docs as T[]),
      catchError((error) => {
        console.error('❌ Find failed, falling back to allDocs:', error);
        return from(this.db.allDocs({ include_docs: true })).pipe(
          map((res: any) =>
            res.rows
              .map((r: any) => r.doc as T)
              .filter((doc: any) => doc.type === type)
          )
        );
      })
    );
  }

  clearDatabase(): Promise<void> {
    return this.db.destroy().then(() => {
      console.log('Database destroyed successfully');
      // Reinitialize if needed
      this.db = new PouchDB('mydb');
    }).catch((err: any) => {
      console.error('Error destroying database:', err);
    });
  }
  /** Close the current PouchDB instance */
public closeDB(): Promise<void> {
  if (!this.db) return Promise.resolve();
  return this.db.close().then(() => {
    console.log('PouchDB instance closed');
  }).catch((err: any) => {
    console.error('Error closing PouchDB:', err);
  });
}

async upsertPatient(patient: any, synced = false): Promise<any> {
  if (!patient || !patient.patientid) {
    throw new Error('Patient object must have patientid');
  }

  const patientId = `patient_${patient.patientid}`;

  try {
    const existingDoc = await this.db.get(patientId);

    const updatedDoc = {
      ...existingDoc,
      ...patient,
      _id: patientId,
      type: 'patient_detail',
      _rev: existingDoc._rev,
      synced,
      // Preserve or set updated flag
      updated: patient.updated !== undefined ? patient.updated : existingDoc.updated,
      lastModified: patient.lastModified || existingDoc.lastModified,
      // ✅ Always merge profile
      profile: patient.profile
        ? { ...(existingDoc.profile || {}), ...patient.profile }
        : (existingDoc.profile || {})
    };

    // console.log("🔄 Saving patient to pouchdb:", updatedDoc);

    return await this.db.put(updatedDoc);
  } catch (err: any) {
    if (err.status === 404) {
      const newDoc = {
        _id: patientId,
        type: 'patient_detail',
        ...patient,
        synced,
        updated: patient.updated !== undefined ? patient.updated : false,
        lastModified: patient.lastModified || new Date().toISOString(),
        profile: patient.profile || {} // ✅ insert fresh
      };

      // console.log("🆕 Inserting new patient to pouchdb:", newDoc);

      return await this.db.put(newDoc);
    } else {
      throw err;
    }
  }
}

async clearAllPatients(): Promise<void> {
  try {
    const existingPatients = await this.db.find({ selector: { type: 'patient_detail' } });
    for (const doc of existingPatients.docs) {
      await this.db.remove(doc._id, doc._rev);
    }
    console.log('Cleared all existing patient records');
  } catch (err) {
    console.error('Error clearing old patient records:', err);
  }
}

/**
 * Offline search patients by domainwise ID, first name, or full name
 */
async searchPatientsOffline(input: string): Promise<any[]> {
  if (!input || !input.trim()) {
    console.log('🔍 Empty search input, returning empty results');
    return [];
  }

  const term = input.trim().toLowerCase();
  console.log('🔍 Searching for term:', term);

  try {
    // Get all documents and filter for patient records
    const allDocs = await this.db.allDocs({ include_docs: true });
    console.log('📦 Total documents in DB:', allDocs.rows.length);
    
    // Extract all patient documents
    const patientDocs = allDocs.rows
      .map((row: any) => row.doc)
      .filter((doc: any) => 
        doc && doc._id && !doc._id.startsWith('_design') && (
          doc.patientid || 
          doc.patientId ||
          doc.first_name || 
          doc.firstname ||
          doc.firstName ||
          doc.last_name ||
          doc.lastname ||
          doc.lastName ||
          doc.domainwisepid ||
          doc.domainWisePid
        )
      );
    
    console.log('🔍 Found patient documents:', patientDocs.length);
    
    if (patientDocs.length > 0) {
      console.log('📄 Sample patient doc fields:', Object.keys(patientDocs[0]));
      console.log('🔍 Sample patient data:', {
        first_name: patientDocs[0].first_name,
        last_name: patientDocs[0].last_name,
        firstname: patientDocs[0].firstname,
        lastname: patientDocs[0].lastname
      });
    }

    return this.filterPatients(patientDocs, term);
  } catch (err) {
    console.error('❌ Offline search error:', err);
    return [];
  }
}

private filterPatients(docs: any[], term: string): any[] {
  return docs.filter((doc: any) => {
    // Handle all possible field name variations
    const domainId = (doc.domainwisepid || doc.domainWisePid || doc.domain_wise_pid || '').toString().toLowerCase();
    const first = (doc.first_name || doc.firstname || doc.firstName || doc.fname || '').toLowerCase();
    const last = (doc.last_name || doc.lastname || doc.lastName || doc.lname || '').toLowerCase();
    const mobile = (doc.mobile || doc.mobileNumber || doc.mobile_number || doc.phone || doc.contactNo || '').toString().toLowerCase();
    const patientId = (doc.patientid || doc.patientId || doc.patient_id || '').toString().toLowerCase();
    const fullName = `${first} ${last}`.trim();

    // Check if term matches any field
    const matches = (
      domainId.includes(term) ||     // Domain wise ID
      first.includes(term) ||        // First name
      last.includes(term) ||         // Last name
      fullName.includes(term) ||     // Full name
      mobile.includes(term) ||       // Mobile number
      patientId.includes(term)       // Patient ID
    );
    
    if (matches) {
      console.log('✅ Match found:', { 
        first, 
        last, 
        domainId, 
        mobile, 
        patientId,
        docId: doc._id 
      });
    }
    
    return matches;
  });
}
async searchPatientsOfflineAdvanced(formData: any): Promise<any[]> {
  if (!formData) {
    console.warn('⚠️ No form data provided');
    return [];
  }

  try {
    // First check what's in the database
    const allDocs = await this.db.allDocs({ include_docs: true });
    console.log('📦 Total documents in DB:', allDocs.rows.length);

    // Try to find patient documents
    let patientDocs = [];

    // Extract all patient documents
    patientDocs = allDocs.rows
      .map((row: any) => row.doc)
      .filter((doc: any) =>
        doc && doc._id && !doc._id.startsWith('_design') && (
          doc.patientid ||
          doc.patientId ||
          doc.first_name ||
          doc.firstname ||
          doc.firstName ||
          doc.last_name ||
          doc.lastname ||
          doc.lastName ||
          doc.domainwisepid ||
          doc.domainWisePid
        )
      );

    console.log(`📦 Found ${patientDocs.length} patient documents in local DB`);
    console.log('🔍 Search criteria:', formData);

    if (patientDocs.length > 0) {
      console.log('📄 Sample patient document structure:', patientDocs[0]);
    }

    const filtered = patientDocs.filter((doc: any) => {
      // Handle different field name variations
      const first = (doc.first_name || doc.firstname || doc.firstName || '').toLowerCase();
      const last = (doc.last_name || doc.lastname || doc.lastName || '').toLowerCase();
      const gender = (doc.gender || '').toLowerCase();
      const dob = (doc.date_of_birth || doc.dateOfBirth || doc.dob || '').toLowerCase();
      const mobile = (doc.mobile || doc.mobileNumber || doc.contactNo || '').toLowerCase();
      const uid = (doc.uid || '').toLowerCase();
      const patientid = (doc.patientid || doc.patientId || '').toString();
      const domainId = (doc.domainwisepid || doc.domainWisePid || '').toString();

      // Debug log for first patient
      if (patientDocs.indexOf(doc) === 0) {
        console.log('🔍 Debug first patient fields:', { first, last, formData });
      }

      // build conditions with more flexible matching
      const firstNameMatch = formData.firstName ? first.includes(formData.firstName.toLowerCase()) : true;
      const lastNameMatch = formData.lastName ? last.includes(formData.lastName.toLowerCase()) : true;
      const genderMatch = formData.gender ? gender === formData.gender.toLowerCase() : true;
      const dobMatch = formData.dob ? dob.includes(formData.dob.toLowerCase()) : true;
      const mobileMatch = formData.contactNumber ? mobile.includes(formData.contactNumber.toLowerCase()) : true;

      // uid/patientid/domainwiseid match
      const uidMatch = formData.uid && formData.uid !== '1'
        ? (
            (uid && uid !== 'null' && uid.includes(formData.uid.toLowerCase())) ||
            patientid.includes(formData.uid) ||
            domainId.includes(formData.uid)
          )
        : true;

      const matches = firstNameMatch && lastNameMatch && genderMatch && dobMatch && mobileMatch && uidMatch;

      if (matches) {
        console.log('✅ Advanced search match:', { first, last, gender, mobile, domainId });
      }

      return matches;
    });

    if (filtered.length === 0) {
      console.warn('❌ No matching patients found for:', formData);
      return [{
        name: 'No record found',
        isNoRecord: true
      }];
    }

    console.log(`✅ Found ${filtered.length} matching patients`);
    return filtered;

  } catch (err) {
    console.error('❌ Offline advanced search error:', err);
    return [{
      name: 'Search error',
      isNoRecord: true
    }];
  }
}
async upsertGenericRecord(dbName: string, record: any, type: string) {
  if (!record) return;

  this.initDB(dbName);

  const uniqueKey =
    record.consultationId ||
    record.consultationid ||
    record.patientId ||
    record.patientid ||
    new Date().toISOString() + '_' + Math.random().toString(36).substring(2);

  const docId = `${type}_${uniqueKey}`;

  try {
    const existingDoc = await this.db.get(docId);
    const updatedDoc = {
      ...existingDoc,
      ...record,
      _id: docId,
      type,
      isSynced: false,
      isUpdated: false,
      _rev: existingDoc._rev,
    };
    // Preserve updated field for patient records
    if (type === 'patient' || type === 'patient_detail') {
      updatedDoc.updated = record.updated !== undefined ? record.updated : existingDoc.updated;
      updatedDoc.lastModified = record.lastModified || new Date().toISOString();
    }
    return await this.db.put(updatedDoc);
  } catch (err: any) {
    if (err.status === 404) {
      const newDoc = {
        _id: docId,
        type,
        ...record,
        isSynced: false,
        isUpdated: false,
      };
      // Set updated field for new patient records
      if (type === 'patient' || type === 'patient_detail') {
        newDoc.updated = record.updated !== undefined ? record.updated : false;
        newDoc.lastModified = record.lastModified || new Date().toISOString();
      }
      return await this.db.put(newDoc);
    } else {
      throw err;
    }
  }
}

// Mark patient as updated when modified locally
async markPatientAsUpdated(patientId: string): Promise<void> {
  try {
    const patient = await this.db.get(`patient_${patientId}`);
    patient.updated = true;
    patient.lastModified = new Date().toISOString();
    await this.db.put(patient);
  } catch (err) {
    console.error('Failed to mark patient as updated:', err);
  }
}

// Get patients that need sync (either unsynced or updated)
async getPatientsNeedingSync(): Promise<any[]> {
  try {
    const result = await this.db.find({
      selector: {
        type: 'patient_detail',
        $or: [
          { synced: { $ne: true } },
          { updated: true }
        ]
      }
    });
    return result.docs;
  } catch (err) {
    console.error('Error getting patients needing sync:', err);
    return [];
  }
}

// Get only updated patients
async getUpdatedPatients(): Promise<any[]> {
  try {
    const result = await this.db.find({
      selector: {
        type: 'patient_detail',
        updated: true
      }
    });
    return result.docs;
  } catch (err) {
    console.error('Error getting updated patients:', err);
    return [];
  }
}

// Method to check if patients exist in database
async checkPatientsExist(): Promise<{ exists: boolean; count: number; sampleDoc?: any }> {
  try {
    const allDocs = await this.db.allDocs({ include_docs: true });
    const patientDocs = allDocs.rows
      .map((row: any) => row.doc)
      .filter((doc: any) =>
        doc && (
          doc.type === 'patient_detail' ||
          doc.type === 'patient' ||
          doc.patientid ||
          doc.first_name ||
          doc.firstname
        )
      );

    return {
      exists: patientDocs.length > 0,
      count: patientDocs.length,
      sampleDoc: patientDocs.length > 0 ? patientDocs[0] : null
    };
  } catch (err) {
    console.error('Error checking if patients exist:', err);
    return { exists: false, count: 0 };
  }
}



}
