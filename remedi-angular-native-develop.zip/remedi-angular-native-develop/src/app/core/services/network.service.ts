import { Injectable, NgZone } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class NetworkService {
  private onlineStatus = new BehaviorSubject<boolean>(navigator.onLine);

  constructor(private zone: NgZone) {
    window.addEventListener('online', () => this.zone.run(() => this.onlineStatus.next(true)));
    window.addEventListener('offline', () => this.zone.run(() => this.onlineStatus.next(false)));
  }

  getStatus() {
    return this.onlineStatus.asObservable();
  }

  isOnline(): boolean {
    return this.onlineStatus.getValue();
  }
}
