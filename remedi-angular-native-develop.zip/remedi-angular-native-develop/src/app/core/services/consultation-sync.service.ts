import { Injectable } from '@angular/core';
import { PouchdbService } from './pouchdb.service';
import { ApiService } from './api.service';
import { ConstantService } from './constant.service';
import { firstValueFrom } from 'rxjs';
import { ConsultationRecord } from '../interfaces/consultation-record.model';

@Injectable({
  providedIn: 'root'
})
export class ConsultationSyncService {

  constructor(
    private pouchdbService: PouchdbService,
    private apiService: ApiService,
    private constantService: ConstantService
  ) {
    this.initializeSync();
  }

  private initializeSync() {
    // Initialize database
    this.pouchdbService.initDB('consultation-record');

    // Setup network listener
    window.addEventListener('online', () => {
      console.log('🌐 Back online - Syncing consultation records...');
      this.syncAllUnsyncedConsultations();
    });

    // Try initial sync if online
    if (navigator.onLine) {
      this.syncAllUnsyncedConsultations();
    }
  }

  async saveConsultationRecord(consultationData: Partial<ConsultationRecord>): Promise<string> {
    const localConsultationId = this.generateLocalConsultationId();

    const patientName = consultationData.patientName || 'Unknown Patient';

    const consultationRecord: ConsultationRecord = {
      local_consultation_id: localConsultationId,
      patientId: consultationData.patientId || '',
      doctorId: consultationData.doctorId || '',
      userName: consultationData.userName || '',
      domain: consultationData.domain || '',
      usertype: consultationData.usertype || '',
      nurseId: consultationData.nurseId || '',
      patientName: patientName,
      startTime: new Date().toISOString(),
      status: 'offline',
      synced: false,
      consultationId: null,
      createdAt: new Date().toISOString(),
      type: 'consultation_record',
      action: 'StartLocalConsultation',
      token: consultationData.token || '',
      consultation_state: 'progress'
    };

    try {
      this.pouchdbService.initDB('consultation-record');
      await firstValueFrom(this.pouchdbService.addRecord(consultationRecord));
      console.log(' Consultation record saved to PouchDB');

      // Try immediate sync if online
      if (navigator.onLine) {
        await this.syncConsultationWithAPI(consultationRecord);
      }

      return localConsultationId;
    } catch (error) {
      console.error(' Error saving consultation record:', error);
      throw error;
    }
  }

  private async syncAllUnsyncedConsultations() {
    try {
      this.pouchdbService.initDB('consultation-record');
      const records = await firstValueFrom(this.pouchdbService.getAllRecords<ConsultationRecord>());
      const unsyncedRecords = records.filter(r =>
        r.type === 'consultation_record' && !r.synced
      );

      console.log(` Found ${unsyncedRecords.length} unsynced consultation records`);

      for (const record of unsyncedRecords) {
        await this.syncConsultationWithAPI(record);
      }
    } catch (error) {
      console.error(' Error syncing consultation records:', error);
    }
  }

  private async syncConsultationWithAPI(consultationRecord: ConsultationRecord) {
    const queryParams = `?action=StartLocalConsultation&domain=${consultationRecord.domain}&userName=${consultationRecord.userName}&patientId=${consultationRecord.patientId}&usertype=${consultationRecord.usertype}&patid=${consultationRecord.patientId}&doctorId=${consultationRecord.doctorId}&iswithdash=0&paramName=getContID&nurseId=${consultationRecord.nurseId}&token=${consultationRecord.token}&confirmconsentcheck=true`;

    try {
      const res: any = await firstValueFrom(
        this.apiService.postServiceByQueryBasic(this.constantService.APIConfig.GETCOMMONSERVICES, queryParams)
      );

      if (res?.status === 'success' && res.consultationId) {
        console.log('✅ Consultation API sync successful');

        // Update record with API response
        await this.updateConsultationRecord(consultationRecord.local_consultation_id, {
          consultationId: res.consultationId,
          status: 'online',
          synced: true,
          syncedAt: new Date().toISOString()
        });

        // Update localStorage with real consultation ID from API
        localStorage.setItem('consultationId', res.consultationId);
        sessionStorage.setItem('consultationId', res.consultationId);

        // Call duration capture
        this.captureConsultationDuration(consultationRecord.userName, res.consultationId, consultationRecord.domain, consultationRecord.token);
      }
    } catch (error) {
      console.error(' Consultation API sync failed:', error);
    }
  }

  private async updateConsultationRecord(localId: string, updates: Partial<ConsultationRecord>) {
    try {
      this.pouchdbService.initDB('consultation-record');
      const records = await firstValueFrom(this.pouchdbService.getAllRecords<ConsultationRecord>());
      const record = records.find(r => r.local_consultation_id === localId);

      if (record) {
        const updatedRecord = { ...record, ...updates };
        await firstValueFrom(this.pouchdbService.updateRecord(updatedRecord));
        console.log(' Consultation record updated in PouchDB');
      }
    } catch (error) {
      console.error(' Error updating consultation record:', error);
    }
  }

  private captureConsultationDuration(userName: string, consultationId: string, domain: string, token: string) {
    const captureDurationQuery = `?action=CaptureConsultationDuration&username=${userName}&consultationId=${consultationId}&domain=${domain}&token=${token}`;

    this.apiService.postServiceByQueryBasic(this.constantService.APIConfig.GETCOMMONSERVICES, captureDurationQuery)
      .subscribe({
        next: (durationRes: any) => {
          if (durationRes?.status === 'success') {
            console.log('✅ Consultation duration captured successfully');
          }
        },
        error: (err) => console.error('❌ Error capturing consultation duration:', err)
      });
  }

  private generateLocalConsultationId(): string {
   const randomNum = Math.floor(1000 + Math.random() * 9000); // generates a 4-digit number
  return `l_${randomNum}`;
  }

  // Public method to get consultation status
  async getConsultationStatus(localId: string): Promise<ConsultationRecord | null> {
    try {
      this.pouchdbService.initDB('consultation-record');
      const records = await firstValueFrom(this.pouchdbService.getAllRecords<ConsultationRecord>());
      return records.find(r => r.local_consultation_id === localId) || null;
    } catch (error) {
      console.error(' Error getting consultation status:', error);
      return null;
    }
  }

  // Update consultation state (suspend/finish/progress)
  async updateConsultationState(localId: string, state: 'suspend' | 'finish' | 'progress'): Promise<void> {
    try {
      this.pouchdbService.initDB('consultation-record');
      const records = await firstValueFrom(this.pouchdbService.getAllRecords<ConsultationRecord>());
      const record = records.find(r => r.local_consultation_id === localId);

      if (record) {
        const updatedRecord = {
          ...record,
          consultation_state: state,
          syncedAt: new Date().toISOString()
        };
        await firstValueFrom(this.pouchdbService.updateRecord(updatedRecord));
        console.log(` Consultation state updated to ${state} for consultation ${localId}`);
      } else {
        console.warn(` Consultation record not found for localId: ${localId}`);
      }
    } catch (error) {
      console.error(' Error updating consultation state:', error);
      throw error;
    }
  }

  // Get suspended consultations for offline mode
  async getSuspendedConsultations(): Promise<ConsultationRecord[]> {
    try {
      this.pouchdbService.initDB('consultation-record');
      const records = await firstValueFrom(this.pouchdbService.getAllRecords<ConsultationRecord>());
      return records.filter(r =>
        r.type === 'consultation_record' &&
        r.consultation_state === 'suspend'
      );
    } catch (error) {
      console.error('❌ Error getting suspended consultations:', error);
      return [];
    }
  }

  // Restart suspended consultation
  async restartConsultation(localId: string): Promise<ConsultationRecord | null> {
    try {
      await this.updateConsultationState(localId, 'progress');
      return await this.getConsultationStatus(localId);
    } catch (error) {
      console.error('❌ Error restarting consultation:', error);
      throw error;
    }
  }
}
