import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class GlobalCounterService {
  private patientCountKey = 'patient_count';

  constructor() {
    if (!localStorage.getItem(this.patientCountKey)) {
      localStorage.setItem(this.patientCountKey, '0');
      console.log('Initialized patient count to 0 in localStorage.');
    }
  }

  getCurrentCount(): number {
    return Number(localStorage.getItem(this.patientCountKey)) || 0;
  }

  incrementAndGet(): number {
    const newCount = this.getCurrentCount() + 1;
    localStorage.setItem(this.patientCountKey, newCount.toString());
    return newCount;
  }

  resetCount(): void {
    localStorage.setItem(this.patientCountKey, '0');
  }
}
