import { Injectable } from '@angular/core';
import { ToastController, ToastOptions } from '@ionic/angular';


@Injectable({
  providedIn: 'root'
})
export class ToastService {


  constructor(private toastCtrl: ToastController) { }

  async presentToast(
    message: string,
    color: string = 'dark', /**
   * @method presentErrorToast
   * @description
   * Presents a toast with an error message.
   *
   * @param message The message to display.
   * @param position The position of the toast ('top', 'bottom', or 'middle').
   * @param duration The duration of the toast in milliseconds.
   */
    position: 'top' | 'bottom' | 'middle' = 'bottom',
    duration: number = 5000,
    icon: string = 'information-circle',
    options?: ToastOptions
  ) {
    const toast = await this.toastCtrl.create({
      message, color, position, duration, icon, ...options });
    toast.present();
  }


  async presentSuccessToast(
    message: string,
    position: 'top' | 'bottom' | 'middle' = 'bottom',
    duration: number = 2000
  ) {
    await this.presentToast(message, 'success', position, duration, 'checkmark-circle');
  }


  async presentWarningToast(
    message: string,
    position: 'top' | 'bottom' | 'middle' = 'bottom',
    duration: number = 2000
  ) {
    await this.presentToast(message, 'warning', position, duration, 'warning');
  }


  async presentErrorToast(
    message: string,
    position: 'top' | 'bottom' | 'middle' = 'bottom',
    duration: number = 2000
  ) {
    await this.presentToast(message, 'danger', position, duration, 'close-circle');
  }
}
/**
 * @class ToastService
 * @description
 * This service provides a centralized and easy way to present Ionic toasts throughout the application.
 * It encapsulates the logic for creating and showing toasts, making the component code cleaner.
 * It also includes dedicated methods for common toast types like success, warning, and error.
 *
 * It can be injected into any component, service, or directive.
 *
 * Example Usage in a component:
 *
 * constructor(private toastService: ToastService) {}
 *
 * async someMethod() {
 * await this.toastService.presentSuccessToast('Data saved successfully!');
 * await this.toastService.presentErrorToast('Failed to connect to server.');
 * await this.toastService.presentToast('A general message.', 'light');
 * }
 */
  /**
   * @method presentToast
   * @description
   * Presents a toast with a given message and optional configuration.
   * This is the main method for showing toasts.
   *
   * @param message The message to display in the toast.
   * @param color The color of the toast (e.g., 'primary', 'secondary', 'success', 'warning', 'danger', 'light', 'medium', 'dark').
   * @param position The position of the toast ('top', 'bottom', or 'middle').
   * @param duration The duration of the toast in milliseconds.
   * @param icon The name of the Ionicons icon to display.
   * @param options Additional options for the toast.
   */

  /**
   * @method presentSuccessToast
   * @description
   * Presents a toast with a success message.
   *
   * @param message The message to display.
   * @param position The position of the toast ('top', 'bottom', or 'middle').
   * @param duration The duration of the toast in milliseconds.
   */

   /**
   * @method presentWarningToast
   * @description
   * Presents a toast with a warning message.
   *
   * @param message The message to display.
   * @param position The position of the toast ('top', 'bottom', or 'middle').
   * @param duration The duration of the toast in milliseconds.
   */

   /**
   * @method presentErrorToast
   * @description
   * Presents a toast with an error message.
   *
   * @param message The message to display.
   * @param position The position of the toast ('top', 'bottom', or 'middle').
   * @param duration The duration of the toast in milliseconds.
   */
