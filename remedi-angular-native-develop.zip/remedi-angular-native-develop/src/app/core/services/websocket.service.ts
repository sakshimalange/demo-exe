import { Injectable, NgZone, OnDestroy } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { WebsocketPortManagerService } from './websocket-port-manager.service';

export interface ExtendedWebSocket extends WebSocket {
  next: (msg: string) => void;
  complete: () => void;
}

@Injectable({
  providedIn: 'root',
})
export class WebsocketsService implements OnDestroy {

  private mainSocket$: ExtendedWebSocket | null = null;
  private bleSocket$: ExtendedWebSocket | null = null;
  private paramSocket$: ExtendedWebSocket | null = null;

  private readonly mainUrl = 'ws://localhost:5000';
  private readonly bleUrl: string;
  private readonly paramUrl: string;

  constructor(
    private zone: NgZone,
    private portManager: WebsocketPortManagerService
  ) {
    const portOffset = this.portManager.getPortOffset();
    this.bleUrl = `ws://localhost:${8444 + portOffset}/bleWS/`;
    this.paramUrl = `ws://localhost:${8444 + portOffset}/paramWS/`;
    
    console.log(`🔌 WebSocket URLs (offset: ${portOffset}):`, {
      bleUrl: this.bleUrl,
      paramUrl: this.paramUrl
    });
  }

  public currentVal = new BehaviorSubject<any>(null);
  public valueObs$ = new BehaviorSubject<any>(null);
  public bleValueObs$ = new BehaviorSubject<any>(null);
  public paramValueObs$ = new BehaviorSubject<any>(null);

  private jettyConnectionSubject = new BehaviorSubject<boolean>(false);
  jettyConnection$ = this.jettyConnectionSubject.asObservable();



  /**
   * Create native WebSocket with .next() and .complete() for compatibility
   */
  private createSocket(url: string, onMessage: (data: any) => void): ExtendedWebSocket {
    const socket = new WebSocket(url) as ExtendedWebSocket;

    socket.onopen = () => {
      console.log(`WebSocket connected: ${url}`);
      this.zone.run(() => this.jettyConnectionSubject.next(true));
    };

    socket.onmessage = (event) => {
      console.log(" ======socket onmessage", event);
      this.zone.run(() => onMessage(event.data));
    };

    socket.onclose = () => {
      console.log(`🔌 WebSocket disconnected: ${url}`);
      this.zone.run(() => this.jettyConnectionSubject.next(false));
    };

    socket.onerror = (err) => {
      console.error(` WebSocket error at ${url}:`, err);
    };

    // Add methods for compatibility
    socket.next = (msg: string) => {
      if (socket.readyState === WebSocket.OPEN) {
        console.warn('WebSocket open, message sent:', msg);
        socket.send(msg);
        // socket.send(msg);
      } else {
        console.warn('WebSocket not open, message not sent:', msg);
      }
    };

    socket.complete = () => {
      socket.close();
    };

    return socket;
  }

  /** ------------------ Main Socket ------------------ */
  public connectMainSocket(): void {
    this.mainSocket$ = this.createSocket(this.mainUrl, (msg) => {
      this.valueObs$.next(msg);
    });
  }

  public sendMainMessage(message: string): void {
    this.mainSocket$?.next(message);
  }

  public disconnectMainSocket(): void {
    this.mainSocket$?.complete();
    this.mainSocket$ = null;
  }

  /** ------------------ BLE Socket ------------------ */
  public connectBleSocket(): void {
    this.bleSocket$ = this.createSocket(this.bleUrl, (msg) => {
      this.bleValueObs$.next(msg);
    });
  }

  public sendBleMessage(message: string): void {
    this.bleSocket$?.next(message);
  }

  public disconnectBleSocket(): void {
    this.bleSocket$?.complete();
    this.bleSocket$ = null;
  }

  /** ------------------ Param Socket ------------------ */
  public connectParamSocket(): void {
    this.paramSocket$ = this.createSocket(this.paramUrl, (msg) => {
      this.paramValueObs$.next(msg);
    });
  }

  public sendParamMessage(message: string): void {
    this.paramSocket$?.next(message);
  }

  public disconnectParamSocket(): void {
    this.paramSocket$?.complete();
    this.paramSocket$ = null;
  }

  /** ------------------ Getters ------------------ */
  public getMainSocketInstance(): ExtendedWebSocket | null {
    return this.mainSocket$;
  }

  public getBleSocketInstance(): ExtendedWebSocket | null {
    return this.bleSocket$;
  }

  public getParamSocketInstance(): ExtendedWebSocket | null {
    return this.paramSocket$;
  }

  /** ------------------ Utility ------------------ */
  public setCurrentVal(val: any) {
    this.currentVal.next(val);
  }

  /** ------------------ Cleanup ------------------ */
  ngOnDestroy(): void {
    this.disconnectMainSocket();
    this.disconnectBleSocket();
    this.disconnectParamSocket();
  }
}
