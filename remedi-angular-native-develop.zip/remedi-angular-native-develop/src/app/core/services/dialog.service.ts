// import { Injectable } from '@angular/core';
// import { AlertController } from '@ionic/angular';

// export interface DialogMessage {
//   type: 'success' | 'error' | 'warning' | 'info' | 'confirm';
//   message: string;
//   title?: string;
// }

// @Injectable({ providedIn: 'root' })
// export class DialogService {
//   private readonly symbols: Record<Exclude<DialogMessage['type'], 'confirm'>, string> = {
//     success: '✅',
//     error: '❌',
//     warning: '⚠️',
//     info: 'ℹ️'
//   };

//   // Track active dialogs to prevent multiple dialogs of same type
//   private activeDialogs = new Set<string>();

//   constructor(private alertCtrl: AlertController) {}

//   async success(message: string, title = 'Success'): Promise<void> {
//     await this.showAlert({ type: 'success', message, title });
//   }

//   async error(message: string, title = 'Error'): Promise<void> {
//     await this.showAlert({ type: 'error', message, title });
//   }

//   async warning(message: string, title = 'Warning'): Promise<void> {
//     await this.showAlert({ type: 'warning', message, title });
//   }

//   async info(message: string, title = 'Information'): Promise<void> {
//     await this.showAlert({ type: 'info', message, title });
//   }

//   async confirm(message: string, title = 'Confirm'): Promise<boolean> {

//     const dialogKey = `confirm-${message}`;

//     // Prevent duplicate confirm dialogs
//     if (this.activeDialogs.has(dialogKey)) {
//       console.log(`Confirm dialog already active for: ${dialogKey}`);
//       return false; // Return false for duplicate confirms
//     }

//     this.activeDialogs.add(dialogKey);

//     return new Promise<boolean>(async (resolve) => {
//       const alert = await this.alertCtrl.create({
//         header: `❓ ${title}`,
//         message,
//         buttons: [
//           {
//             text: 'Cancel',
//             role: 'cancel',
//             handler: () => {

//               this.activeDialogs.delete(dialogKey);

//               resolve(false);
//             }
//           },
//           {
//             text: 'OK',
//             handler: () => {

//               this.activeDialogs.delete(dialogKey);

//               resolve(true);
//             }
//           }
//         ]
//       });
//       await alert.present();
//     });
//   }

//   private async showAlert(msg: DialogMessage): Promise<void> {

//     // Create a unique key for this dialog type and message
//     const dialogKey = `${msg.type}-${msg.message}`;

//     // Prevent duplicate dialogs
//     if (this.activeDialogs.has(dialogKey)) {
//       console.log(`Dialog already active for: ${dialogKey}`);
//       return;
//     }

//     // Mark this dialog as active
//     this.activeDialogs.add(dialogKey);

//     const icon = msg.type !== 'confirm' ? this.symbols[msg.type] : '';
//     const alert = await this.alertCtrl.create({
//       header: `${icon} ${msg.title ?? ''}`.trim(),
//       message: msg.message,
//        cssClass: 'wide-alert registration-alert',
//       buttons: ['OK']
//     });

//     // Remove from active dialogs when dismissed
//     alert.onDidDismiss().then(() => {
//       this.activeDialogs.delete(dialogKey);
//     });

//     await alert.present();
//   }
// }
import { Injectable } from '@angular/core';

export interface DialogMessage {
  type: 'success' | 'error' | 'warning' | 'info' | 'confirm';
  message: string;
  title?: string;
}

@Injectable({ providedIn: 'root' })
export class DialogService {
  private readonly symbols: Record<
    Exclude<DialogMessage['type'], 'confirm'>,
    string
  > = {
    success: '',
    error: '',
    warning: '',
    info: 'ℹ',
  };

  private activeDialogs = new Set<string>();

  constructor() {
    this.addModalStyles();
  }

  async success(message: string, title = 'Success'): Promise<void> {
    await this.showAlert({ type: 'success', message, title });
  }

  async successAsync(message: string, title = 'Success'): Promise<void> {
    return this.showAlertAsync({ type: 'success', message, title });
  }

  async error(message: string, title = 'Error'): Promise<void> {
    await this.showAlert({ type: 'error', message, title });
  }

  async warning(message: string, title = 'Warning'): Promise<void> {
    await this.showAlert({ type: 'warning', message, title });
  }

  async info(message: string, title = 'Information'): Promise<void> {
    await this.showAlert({ type: 'info', message, title });
  }

  async confirm(message: string, title = 'Confirm'): Promise<boolean> {
    const dialogKey = `confirm-${message}`;

    if (this.activeDialogs.has(dialogKey)) {
      console.log(`Confirm dialog already active for: ${dialogKey}`);
      return false;
    }

    this.activeDialogs.add(dialogKey);

    return new Promise<boolean>(async (resolve) => {
      const modal = this.createModal({
        type: 'confirm',
        message: message,
        title: title,
      });

      const okBtn = modal.querySelector('.modal-ok-btn');
      const cancelBtn = modal.querySelector('.modal-cancel-btn');

      const onDismiss = (result: boolean) => {
        this.activeDialogs.delete(dialogKey);
        modal.remove();
        resolve(result);
      };

      okBtn?.addEventListener('click', () => onDismiss(true));
      cancelBtn?.addEventListener('click', () => onDismiss(false));

      document.body.appendChild(modal);
    });
  }

  private async showAlert(msg: DialogMessage): Promise<void> {
    const dialogKey = `${msg.type}-${msg.message}`;

    if (this.activeDialogs.has(dialogKey)) {
      console.log(`Dialog already active for: ${dialogKey}`);
      return;
    }

    this.activeDialogs.add(dialogKey);

    const modal = this.createModal(msg);
    const closeBtn = modal.querySelector('.modal-close-btn');

    const onDismiss = () => {
      this.activeDialogs.delete(dialogKey);
      modal.remove();
    };

     closeBtn?.addEventListener('click', (event) => {
    if (msg.message === "No patients found matching the search criteria." ) {  
        event.stopPropagation(); 
        }
    onDismiss();
  });

    // Also remove the modal when the backdrop is clicked
    modal.addEventListener('click', (event) => {
      if (event.target === modal) {
       if (msg.message === "No patients found matching the search criteria." ) {  
        event.stopPropagation(); 
        }
        onDismiss();
      }
    });

    document.body.appendChild(modal);
  }

  private async showAlertAsync(msg: DialogMessage): Promise<void> {
    const dialogKey = `${msg.type}-${msg.message}`;

    if (this.activeDialogs.has(dialogKey)) {
      console.log(`Dialog already active for: ${dialogKey}`);
      return Promise.resolve();
    }

    this.activeDialogs.add(dialogKey);

    const modal = this.createModal(msg);
    const closeBtn = modal.querySelector('.modal-close-btn');

    return new Promise<void>((resolve) => {
      const onDismiss = () => {
        this.activeDialogs.delete(dialogKey);
        modal.remove();
        resolve();
      };

       closeBtn?.addEventListener('click', (event) => {
   if (msg.message === "No patients found matching the search criteria." ) {  
        event.stopPropagation(); 
        } 
    onDismiss();
  });


      // Also remove the modal when the backdrop is clicked
      modal.addEventListener('click', (event) => {
        if (event.target === modal) {
        if (msg.message === "No patients found matching the search criteria." ) {  
        event.stopPropagation(); 
        }
          onDismiss();
        }
      });

      document.body.appendChild(modal);
    });
  }

  /**
   * Dynamically creates the HTML element for the modal, using the class names
   * that correspond to the injected CSS.
   */
  private createModal(msg: DialogMessage): HTMLElement {
    const isConfirm = msg.type === 'confirm';
    const icon = msg.type !== 'confirm' ? this.symbols[msg.type] : '❓';
    const modal = document.createElement('div');
    modal.className = `modal-overlay`;

    // Determine the class for the alert wrapper based on the message type
    let wrapperClass = 'alert-wrapper';
    switch (msg.type) {
      case 'success':
        wrapperClass += ' success-dialog';
        break;
      case 'error':
        wrapperClass += ' error-dialog';
        break;
      case 'warning':
        wrapperClass += ' warning-dialog';
        break;
      case 'info':
        wrapperClass += ' info-dialog';
        break;
    }

    modal.innerHTML = `
      <div class="${wrapperClass}">
        <div class="alert-message">
          <p>${icon} ${msg.message}</p>
        </div>
        <div class="alert-button-group">
          ${
            isConfirm
              ? `
            <button class="modal-button modal-cancel-btn alert-button" role="cancel">Cancel</button>
            <button class="modal-button modal-ok-btn alert-button">OK</button>
          `
              : `
            <button class="modal-button modal-close-btn alert-button">OK</button>
          `
          }
        </div>
      </div>
    `;

    return modal;
  }

  /**
   * Dynamically injects the required CSS styles into the document's <head>.
   */
  private addModalStyles(): void {
    const styleId = 'modal-styles';
    if (!document.getElementById(styleId)) {
      const style = document.createElement('style');
      style.id = styleId;
      style.textContent = `
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          background-color: rgba(0, 0, 0, 0.5);
          z-index: 9999;
          animation: dialogFadeIn 0.3s ease-out;
        }
        .success-dialog,
        .error-dialog,
        .warning-dialog,
        .info-dialog {
          --background: #ffffff;
          --border-radius: 12px;
          --box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
          --backdrop-opacity: 0.6;
          --backdrop-color: rgba(0, 0, 0, 0.5);
        }

        .alert-wrapper {
          width: 398px !important;
          background:white;
          border-radius: 5px; 
          overflow: hidden;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
          border: 1px solid rgba(0, 0, 0, 0.1);
          background: var(--background);
          border-color: var(--border-color);
          animation: dialogFadeIn 0.3s ease-out;
        }
        .alert-head {
          display: none !important;
        }
        .alert-message {
          padding: 20px 24px 16px;
          font-size: 16px;
          line-height: 1.5;
          color: #555;

        }
        .alert-button-group {
          padding: 0 24px 24px;
          display: flex;
          justify-content: flex-end;

          gap: 12px;
        }
        .alert-button {
          border: none !important;
    font-size: 14px !important;
    font-weight: 500 !important;
    cursor: pointer !important;
    transition: all 0.3s ease !important;
    color: #fff !important;
    width: 120px !important;
    height: 48px !important;
    min-width: 120px !important;
    min-height: 48px !important;
    opacity: 1 !important;
    border-radius: 8px !important;
    gap: 8px !important;
    padding-top: 12px !important;
    padding-right: 24px !important;
    padding-bottom: 12px !important;
    padding-left: 24px !important;
        }
        .alert-button.activated {
          transform: scale(0.95) !important;
        }
        .alert-button[role="cancel"] {
          background-color: #f5f5f5 !important;
          color: #666 !important;
          border: 1px solid #ddd !important;
        }
        .alert-button[role="cancel"]:hover {
          background-color: #e0e0e0 !important;
        }
        .alert-button:not([role="cancel"]) {
          background-color: white !important;
          border: 1px solid #007AFF !important;
          color: #007AFF !important;
        }
        .alert-button:not([role="cancel"]):hover {
            background-color: #b3d4f7 !important;
        }
        @media (max-width: 480px) {
          .alert-wrapper {
            margin: 16px;
            max-width: calc(100vw - 32px);
          }
          .alert-title {
            font-size: 18px;
          }
          .alert-message {
            font-size: 14px;
          }
          .alert-button {
            min-width: 80px;
            padding: 10px 20px;
            font-size: 14px;
          }
        }
        @keyframes dialogFadeIn {
          from {
            opacity: 0;
            transform: scale(0.9);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
      `;
      document.head.appendChild(style);
    }
  }
}
