import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { DialogService } from './dialog.service';

export interface DialogRoute {
  source: string;
  target: 'dashboard' | 'doctor-dashboard';
  message: any;
}

@Injectable({
  providedIn: 'root'
})
export class DialogRoutingService {
  private routeSubject = new Subject<DialogRoute>();
  public routeMessage$: Observable<DialogRoute> = this.routeSubject.asObservable();

  constructor(private dialogService: DialogService) {}

  public routeDialog(source: string, target: 'dashboard' | 'doctor-dashboard', message: any): void {
    this.routeSubject.next({
      source,
      target,
      message
    });
  }

  public routeToDoctorDashboard(source: string, message: any): void {
    this.routeDialog(source, 'doctor-dashboard', message);
  }

  public routeToDashboard(source: string, message: any): void {
    this.routeDialog(source, 'dashboard', message);
  }
}
