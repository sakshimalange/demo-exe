import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WebsocketPortManagerService {
  
  private static readonly STORAGE_KEY = 'websocket_port_assignments';
  private myPortAssignment: number | null = null;

  constructor() {
    this.assignPort();
  }

  getPortOffset(): number {
    return this.myPortAssignment || 0;
  }

  private assignPort(): void {
    // Get existing port assignments from localStorage
    const assignments = this.getPortAssignments();
    const sessionId = this.getSessionId();
    
    // Check if this session already has a port assigned
    if (assignments[sessionId]) {
      this.myPortAssignment = assignments[sessionId];
      console.log(`🔌 Using existing port offset: ${this.myPortAssignment}`);
      return;
    }

    // Find the next available port offset
    const usedOffsets = Object.values(assignments);
    let nextOffset = 0;
    
    while (usedOffsets.includes(nextOffset)) {
      nextOffset++;
    }

    // Assign this offset to current session
    assignments[sessionId] = nextOffset;
    this.myPortAssignment = nextOffset;
    
    // Save back to localStorage
    localStorage.setItem(WebsocketPortManagerService.STORAGE_KEY, JSON.stringify(assignments));
    
    console.log(`🔌 Assigned new port offset: ${nextOffset} to session: ${sessionId}`);

    // Clean up on page unload
    window.addEventListener('beforeunload', () => {
      this.releasePort();
    });
  }

  private getPortAssignments(): { [sessionId: string]: number } {
    try {
      const stored = localStorage.getItem(WebsocketPortManagerService.STORAGE_KEY);
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  }

  private getSessionId(): string {
    let sessionId = sessionStorage.getItem('websocket_session_id');
    if (!sessionId) {
      sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('websocket_session_id', sessionId);
    }
    return sessionId;
  }

  private releasePort(): void {
    const assignments = this.getPortAssignments();
    const sessionId = this.getSessionId();
    
    if (assignments[sessionId]) {
      delete assignments[sessionId];
      localStorage.setItem(WebsocketPortManagerService.STORAGE_KEY, JSON.stringify(assignments));
      console.log(`🔌 Released port offset for session: ${sessionId}`);
    }
  }
}