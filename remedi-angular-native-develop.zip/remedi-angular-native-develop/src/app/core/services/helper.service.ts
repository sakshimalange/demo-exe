import { Injectable } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, } from '@angular/material/snack-bar';
import { BehaviorSubject, Observable } from 'rxjs';


// declare var NProgress: any;
// NProgress.configure({ showSpinner: false });

@Injectable({
  providedIn: 'root'
})
export class HelperService {

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  private data = {};
  private isVideo = false;
  private timerData = {};
  private patientStatus = '';
  private followUp = '';
  private walkin = false;
  private reviewCase = false;
  private buttonHide = false;
  private toUnsubscribe = {};
  private wssurl: string = '';

  constructor(private _snackBar: MatSnackBar) { }

  public loaderStart() {
    // NProgress.start();
  }

  public loaderStop() {
    // NProgress.done();
  }
  valueObs = new BehaviorSubject<boolean>(false);
  isvalueObs = this.valueObs.asObservable();
  valueConnect = new BehaviorSubject<boolean>(false);
  valueSuspend = new BehaviorSubject<boolean>(false);
  valueComplete = new BehaviorSubject<boolean>(false);
  logout = new BehaviorSubject<boolean>(false);
  finishConsultation = new BehaviorSubject<boolean>(false);
  tickerSubscriber = new BehaviorSubject<boolean>(false);
  parameterData = new BehaviorSubject({});
  valueSuspendDoctor = new BehaviorSubject<boolean>(false);



  public setTickerSubscriber(value: boolean): void {
    this.tickerSubscriber.next(value);
  }
  public getTickerSubscriber(): Observable<boolean> {
    return this.tickerSubscriber;
  }
  public setLogout(value: boolean): void {
    this.logout.next(value);
  }
  public getLogout(): Observable<boolean> {
    return this.logout;
  }
  public setfinishConsultation(value: boolean): void {
    this.finishConsultation.next(value);
  }
  public getfinishConsultation(): Observable<boolean> {
    return this.finishConsultation;
  }

  public setValue(value: boolean): void {
    this.valueObs.next(value);
  }
  public getValue(): Observable<boolean> {
    return this.valueObs;
  }
  public setConnectValue(value: boolean): void {
    this.valueConnect.next(value);
  }
  public getConnectValue(): Observable<boolean> {
    return this.valueConnect;
  }
  public setSuspendValue(value: boolean): void {
    this.valueSuspend.next(value);
  }
  public getSuspendValue(): Observable<boolean> {
    return this.valueSuspend;
  }
  public setSuspendValueDoctor(value: boolean): void {
    this.valueSuspendDoctor.next(value);
  }
  public getSuspendValueDoctor(): Observable<boolean> {
    return this.valueSuspendDoctor;
  }
  public setCompleteValue(value: boolean): void {
    this.valueComplete.next(value);
  }
  public getCompleteValue(): Observable<boolean> {
    return this.valueComplete;
  }

  public setparameterData(value: any): void {
    this.parameterData.next(value);
  }
  public getparameterData(): Observable<any> {
    return this.parameterData;
  }

  //Function to set value in localStorage
  public lsSetItem(key: string, value: any) {
    return localStorage.setItem(key, JSON.stringify(value));
  }

  //Function to get value from localStorage
  public lsGetItem<T>(key: string): T | null {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) as T : null;
  }

  //Function to remove a value from localStorage
  public lsRemoveItem(key: string) {
    return localStorage.removeItem(key);
  }

  //Function to clear localStorage
  public lsClear() {
    return localStorage.clear();
  }

  //Function to set value in sessionStorage
  public ssSetItem(key: string, value: any) {
    return sessionStorage.setItem(key, JSON.stringify(value));
  }

  //Function to get value from sessionStorage
  public ssGetItem<T>(key: string): T | null {
    const item = sessionStorage.getItem(key);
    return item ? JSON.parse(item) as T : null;
  }
  //Function to remove a value from sessionStorage
  public ssRemoveItem(key: string) {
    return sessionStorage.removeItem(key);
  }

  //Function to remove a value from sessionStorage
  public ssClear() {
    return sessionStorage.clear();
  }

  openSnackBar(msg: string) {
    let config = new MatSnackBarConfig();
    config.panelClass = 'material-snackbar';
    config.duration = 5000,
      config.horizontalPosition = this.horizontalPosition,
      config.verticalPosition = this.verticalPosition,
      this._snackBar.open(msg, 'Close', config
        // {
        // duration: 500,
        // config,
        // horizontalPosition: this.horizontalPosition,
        // verticalPosition: this.verticalPosition,
        // }
      );
  }

  public setOption(value: {}) {
    this.data = value;
  }

  public getOption() {
    return this.data;
  }

  public setVideoOption(value: boolean) {
    this.isVideo = value;
  }

  public getVideoOption() {
    return this.isVideo;
  }


  public setTimerOption(value: {}) {
    this.timerData = value;
  }

  public getTimerOption() {
    return this.timerData;
  }

  public setPtStatusOption(value: string) {
    this.patientStatus = value;
  }

  public getPtStatusOption() {
    return this.patientStatus;
  }

  public setFollowUp(value: string) {
    this.followUp = value;
  }

  public getFollowUp() {
    return this.followUp;
  }

  public setWalkIn(value: boolean) {
    this.walkin = value;
  }

  public getWalkIn() {
    return this.walkin;
  }


  public setReviewCase(value: boolean) {
    this.reviewCase = value;
  }

  public getReviewCase() {
    return this.reviewCase;
  }

  public setButtonHideCase(value: boolean) {
    this.buttonHide = value;
  }

  public getButtonHideCase() {
    return this.buttonHide;
  }


  public setUnsubscribe(value: {}) {
    this.toUnsubscribe = value;
  }

  public getUnsubscribe() {
    return this.toUnsubscribe;
  }

  public getLocalUser() {
    return sessionStorage.getItem('localConsult');
  }
  public getWalkinUser() {
    return sessionStorage.getItem('walkinConsult');
  }
  public getReviewUser() {
    return sessionStorage.getItem('reviewConsult');
  }

  //add by lokesh sir 
  public setWssurl(value: string) {
    this.wssurl = value;
  }

  public getWssurl() {
    return this.wssurl;
  }

}
