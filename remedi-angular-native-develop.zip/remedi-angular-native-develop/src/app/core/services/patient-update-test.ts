// Simple test utility to verify updated flag functionality
// This can be called from browser console for testing

export class PatientUpdateTest {
  
  static async testUpdatedFlag(pouchdbService: any) {
    console.log('🧪 Testing updated flag functionality...');
    
    try {
      // Test 1: Get patients needing sync
      const needingSync = await pouchdbService.getPatientsNeedingSync();
      console.log(`📊 Patients needing sync: ${needingSync.length}`);
      
      // Test 2: Get only updated patients
      const updatedPatients = await pouchdbService.getUpdatedPatients();
      console.log(`📝 Updated patients: ${updatedPatients.length}`);
      
      // Test 3: Mark a patient as updated (if any exist)
      if (needingSync.length > 0) {
        const testPatient = needingSync[0];
        await pouchdbService.markPatientAsUpdated(testPatient.patientid);
        console.log(`✅ Marked patient ${testPatient.patientid} as updated`);
        
        // Verify the update
        const verifyUpdated = await pouchdbService.getUpdatedPatients();
        console.log(`✅ Verification: Updated patients count: ${verifyUpdated.length}`);
      }
      
      console.log('🎉 Test completed successfully!');
      
    } catch (error) {
      console.error('❌ Test failed:', error);
    }
  }
  
  static logPatientFlags(patients: any[]) {
    console.log('📋 Patient Flags Summary:');
    patients.forEach((p, index) => {
      console.log(`${index + 1}. ${p.first_name} ${p.last_name} - synced: ${p.synced}, updated: ${p.updated}`);
    });
  }
}