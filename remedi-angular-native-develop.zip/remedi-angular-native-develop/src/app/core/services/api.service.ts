// Updated ApiService for Angular 20 with best practices
import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams,
  HttpBackend
} from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
interface LipidSaveResponse {
  status: string;
  message?: string;
  [key: string]: any; // optional for flexibility
}

const httpOptions = {
  headers: new HttpHeaders({
    "Content-Type": "application/x-www-form-urlencoded",
  }),
};

@Injectable({ providedIn: 'root' })
export class ApiService {
  getToken(): string {
    throw new Error('Method not implemented.');
  }
  postServiceBasicFormQueryFormData(
    DISPLAYAPPOINTMENTS: string,
    arg1: string,
    data: Record<string, any>
  ): Observable<any> {
    return this._http.post<any>(
      `${DISPLAYAPPOINTMENTS}/${arg1}`,
      data
    );
  }
  postServiceWithQueryAndFormData(
    baseUrl: string,
    queryParams: Record<string, any>,
    formData: Record<string, any>
  ): Observable<any> {
    // Build query parameters
    let params = new HttpParams();
    Object.keys(queryParams).forEach(key => {
      if (queryParams[key] !== null && queryParams[key] !== undefined) {
        params = params.set(key, queryParams[key].toString());
      }
    });

    // Create URL-encoded body instead of FormData
    let bodyParams = new HttpParams();
    Object.keys(formData).forEach(key => {
      if (formData[key] !== null && formData[key] !== undefined) {
        bodyParams = bodyParams.set(key, formData[key]);
      }
    });

    const headers = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });

    return this._http.post<any>(baseUrl, bodyParams.toString(), { params, headers });
  }

  // patientData = new BehaviorSubject({});

  private readonly jsonHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });
  private readonly formHeaders = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
  private readonly textHeaders = new HttpHeaders({ 'Content-Type': 'text/plain' });

  constructor(
    private _http: HttpClient,
    private handler: HttpBackend
  ) { }



  // public setPatientData(value: any): void {
  //   this.patientData.next(value);
  // }
  // public getPatientData(): Observable<any> {
  //   return this.patientData;
  // }



  post<T>(url: string, data: any, useBasic = false, useForm = false): Observable<T> {
    const endpoint = (useBasic ? environment.APIBaseURLBasic : environment.APIBaseURL) + url;

    // Conditionally set body and headers
    const body = data == null ? null : (useForm ? this.toFormUrlEncoded(data) : data);
    const headers = data == null ? undefined : (useForm ? this.formHeaders : this.jsonHeaders);

    return this._http.post<T>(endpoint, body, { headers }).pipe(
      map(this.handleSuccess),
      catchError(this.handleError)
    );
  }

  postWithTextResponse(url: string, data: any, useBasic = false, useForm = false): Observable<string> {
    const endpoint = (useBasic ? environment.APIBaseURLBasic : environment.APIBaseURL) + url;
    // Conditionally set body and headers (consistent with main post method)
    const body = data == null ? null : (useForm ? this.toFormUrlEncoded(data) : data);
    const headers = data == null ? undefined : (useForm ? this.formHeaders : this.jsonHeaders);
    return this._http.post(endpoint, body, {
      headers,
      responseType: 'text'
    }).pipe(
      catchError(this.handleError)
    );
  }

  get<T>(url: string, params: string = '', useBasic = false): Observable<T> {
    const endpoint = (useBasic ? environment.APIBaseURLBasic : environment.APIBaseURL) + url + params;
    return this._http.get<T>(endpoint).pipe(
      map(this.handleSuccess),
      catchError(this.handleError)
    );
  }

  postText<T>(url: string, data: any): Observable<T> {
    return this._http.post<T>(environment.APIBaseURLBasic + url, data, {
      headers: this.textHeaders
    }).pipe(
      map(this.handleSuccess),
      catchError(this.handleError)
    );
  }

  put<T>(url: string, data: any): Observable<T> {
    return this._http.put<T>(environment.APIBaseURL + url, data, {
      headers: this.jsonHeaders
    }).pipe(
      map(this.handleSuccess),
      catchError(this.handleError)
    );
  }

  postServiceByQueryBasic<T>(url: string, queryParams: string): Observable<T> {
    const fullUrl = environment.APIBaseURLBasic + url + queryParams;
    return this._http.post<T>(fullUrl, '').pipe(
      map(this.handleSuccess),
      catchError(this.handleError)
    );
  }

  getServiceByQueryBasic<T>(url: string, queryParams: string): Observable<T> {
    const fullUrl = environment.APIBaseURLBasic + url + queryParams;
    return this._http.get<T>(fullUrl).pipe(
      map(this.handleSuccess),
      catchError(this.handleError)
    );
  }

  postServiceByQueryBasicNew(url: string, queryParams: string): Observable<string> {
    const fullUrl = environment.APIBaseURLBasic + url + queryParams;

    return this._http.post(fullUrl, '', {
      headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' }),
      responseType: 'text' // ✅ Return plain text, not JSON
    }).pipe(
      map((res: string) => res.trim()), // ✅ Remove spaces/newlines
      catchError((error) => this.handleError(error))
    );
  }

  postServiceByQueryBasicSafe(url: string, queryParams: string): Observable<any> {
    const fullUrl = environment.APIBaseURLBasic + url + queryParams;

    return this._http.post(fullUrl, '', {
      headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' }),
      responseType: 'text' // ✅ Expect raw text
    }).pipe(
      map((res: string) => {
        try {
          // ✅ Try parsing JSON if possible
          const parsed = JSON.parse(res);
          return parsed;
        } catch (e) {
          // ✅ If parsing fails, return safe default object
          if (res && res.toLowerCase().includes('success')) {
            return { status: 'success', message: res.trim() };
          } else {
            return { status: 'error', message: res.trim() || 'Unexpected response' };
          }
        }
      }),
      catchError((error) => this.handleError(error))
    );
  }


  postServiceByQueryBasicTextforspo2(url: string, query: string) {
    const fullUrl = environment.APIBaseURLBasic + url;
    return this._http.get(url + query, { responseType: 'text' });
  }

  public postServiceByQuery(url: string, params: string): Observable<any> {
    return this._http
      .post(environment.APIBaseURL + url + params, "")
      .pipe(map(this.handleSuccess), catchError(this.handleError));
  }


  public postServiceBasicFormQueryregister(
    url: string,
    params: string,
    data: Record<string, any>
  ): Observable<any> {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded'
      })
    };

    return this._http
      .post(
        environment.APIBaseURLBasic + url + params,
        this.jsonTransformRequest(data),
        httpOptions
      )
      .pipe(
        map(this.handleSuccess),
        catchError(this.handleError)
      );
  }
  public postServiceByQueryBasicLogo(url: string, params: string): Observable<any> {
    return this._http.post(environment.APIBaseURLBasic + url + params, '')
      .pipe(
        map(this.handleSuccess),
        catchError(this.handleError)
      );
  }

  // Updated jsonTransformRequest with proper typing
  jsonTransformRequest(data: Record<string, any> | string): string {
    console.log('type of', typeof data);

    const param = (obj: Record<string, any>): string => {
      let query = '';

      for (const name in obj) {
        if (!Object.prototype.hasOwnProperty.call(obj, name)) continue;

        const value = obj[name];

        if (Array.isArray(value)) {
          value.forEach((subValue, i) => {
            const fullSubName = `${name}[${i}]`;
            const innerObj: Record<string, any> = {};
            innerObj[fullSubName] = subValue;
            query += param(innerObj) + '&';
          });
        } else if (typeof value === 'object' && value !== null) {
          for (const subName in value) {
            if (!Object.prototype.hasOwnProperty.call(value, subName)) continue;
            const subValue = value[subName];
            const fullSubName = `${name}.${subName}`;
            const innerObj: Record<string, any> = {};
            innerObj[fullSubName] = subValue;
            query += param(innerObj) + '&';
          }
        } else if (value !== undefined && value !== null) {
          query += encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&';
        }
      }
      return query.length ? query.slice(0, -1) : query;
    };

    return typeof data === 'object' && data !== null
      ? param(data as Record<string, any>)
      : (data as string);
  }



  delete<T>(url: string, params: string = ''): Observable<T> {
    return this._http.delete<T>(environment.APIBaseURL + url + params).pipe(
      map(this.handleSuccess),
      catchError(this.handleError)
    );
  }

  postWithoutInterceptor<T>(url: string, params: string = ''): Observable<T> {
    const httpClient = new HttpClient(this.handler);
    return httpClient.post<T>(environment.APIBaseURL + url + params, '', {
      responseType: 'text' as 'json'
    }).pipe(
      map(this.handleSuccess),
      catchError(this.handleError)
    );
  }


  private toFormUrlEncoded(data: any): string {
    const params = new URLSearchParams();
    for (const key in data) {
      if (Object.prototype.hasOwnProperty.call(data, key) && data[key] !== undefined && data[key] !== null) {
        params.append(key, data[key]);
      }
    }
    return params.toString();
  }

  private handleSuccess<T>(res: T): T {
    return res;
  }

  private handleError(error: HttpErrorResponse) {
    let message = 'Something went wrong!';

    if (error.error instanceof ErrorEvent) {
      message = `Client Error: ${error.error.message}`;
    } else if (typeof error.error === 'string') {
      // API returned text response but Angular failed to parse JSON
      message = error.error;
    } else if (error.status === 200 && error.statusText === 'OK') {
      message = 'API returned success, but response format is not JSON';
    } else {
      message = `Server Error ${error.status}: ${error.message}`;
    }

    console.error('API Error:', message);
    return throwError(() => new Error(message));
  }


public postServiceByQueryBasic1(url: string, params: any): Observable<any> {
  const finalUrl = environment.APIBaseURLBasic + url;
  console.log("API being hit:", finalUrl);
  console.log("Payload:", params);
  return this._http.post<any>(environment.APIBaseURLBasic + url, params, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
  }).pipe(
    map(this.handleSuccess),
    catchError(this.handleError)
  );
}

  /**
   * Safely stringify errors for better logging
   */
  private stringifyError(error: any): string {
    if (error instanceof Error) {
      return `${error.name}: ${error.message}`;
    }

    if (typeof error === 'object' && error !== null) {
      try {
        // Handle HttpErrorResponse specifically
        if (error.error && error.status && error.url) {
          return `HTTP ${error.status} ${error.statusText || ''} at ${error.url}: ${this.stringifyError(error.error)}`;
        }
        return JSON.stringify(error, null, 2);
      } catch {
        return String(error);
      }
    }

    return String(error);
  }


  postServiceJson<T>(url: string, data: any): Observable<T> {
    const fullUrl = environment.APIBaseURLBasic + url;
    return this._http.post(fullUrl, data, { responseType: 'text' }).pipe(
      map(res => {
        // res is string here, but cast to T for type compatibility
        return res as unknown as T;
      }),
      catchError(this.handleError.bind(this))
    );
  }
  public postServiceByQueryBasicGetComment(url: string): Observable<any> {
    // console.log("api", url);
    return this._http
      .post(url, "")
      .pipe(map(this.handleSuccess), catchError(this.handleError));
  }


postServiceBasicForm1(url: string, data: Record<string, any>): Observable<any> {
  const fullUrl = environment.APIBaseURLBasic + url;

  const headers = new HttpHeaders({
    'Content-Type': 'application/json'  // ✅ Send JSON
  });

  return this._http.post<any>(fullUrl, data, { headers }).pipe(
    map(this.handleSuccess),
    catchError(this.handleError)
  );
}
postServiceBasicForm(url: string, data: Record<string, any>): Observable<any> {
  const fullUrl = environment.APIBaseURLBasic + url;

    const headers = new HttpHeaders({
      'Content-Type': 'application/json'  // ✅ Send JSON
    });

    return this._http.post<any>(fullUrl, data, { headers }).pipe(
      map(this.handleSuccess),
      catchError(this.handleError)
    );
  }




  public postServiceBasicFormQueryFormDatafrospiro(url: string, params: string, data: any): Observable<any> {
    return this._http
      .post(
        environment.APIBaseURLBasic + url + params,
        this.jsonTransformRequestForm(data),
        httpOptions
      )
      .pipe(
        // return this._http.post(environment.APIBaseURL + url, data).pipe(
        map(this.handleSuccess),
        catchError(this.handleError)
      );
  }
  jsonTransformRequestForm(data: null) {
    const param = (obj: { [x: string]: any }) => {
      let query = "";
      let name, value, fullSubName, subValue, innerObj, i;

      for (name in obj) {
        value = obj[name];

        if (value instanceof Array) {
          for (i = 0; i < value.length; ++i) {
            subValue = value[i];
            fullSubName = name;
            innerObj = {} as Record<string, any>; // ✅ fixed typing
            innerObj[fullSubName] = subValue;
            query += param(innerObj) + "&";
          }
        } else if (value instanceof Object) {
          for (let subName in value) {
            subValue = value[subName];
            fullSubName = name + "." + subName;
            innerObj = {} as Record<string, any>; // ✅ fixed typing
            innerObj[fullSubName] = subValue;
            query += param(innerObj) + "&";
          }
        } else if (value !== undefined && value !== null) {
          query +=
            encodeURIComponent(name) + "=" + encodeURIComponent(value) + "&";
        }
      }
      return query.length ? query.substr(0, query.length - 1) : query;
    };

    return data != null && typeof data === "object" ? param(data) : data;
  }

  postServiceByQueryBasicText(url: string, queryParams: string): Observable<string> {
    const fullUrl = environment.APIBaseURLBasic + url + queryParams;
    return this._http.post(fullUrl, '', {
      headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' }),
      responseType: 'text'
    }).pipe(
      catchError(this.handleError)
    );
  }
  // In ApiService
  postServiceWithJsonBody<T>(url: string, body: any): Observable<T> {
    const fullUrl = environment.APIBaseURLBasic + url;

    return this._http.post<T>(fullUrl, body, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }).pipe(
      map(this.handleSuccess),
      catchError(this.handleError)
    );
  }

  postServiceByQueryBasicforecgi<T>(url: string, queryParams: string): Observable<T | string> {
  const fullUrl = environment.APIBaseURLBasic + url + queryParams;
  return this._http.post<T | string>(fullUrl, '', { responseType: 'text' as 'json' }).pipe(
    map(this.handleSuccess),
    catchError(this.handleError)
  );
}

}