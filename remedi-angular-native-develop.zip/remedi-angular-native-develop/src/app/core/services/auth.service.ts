import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, throwError, of } from 'rxjs';
import { catchError, map, tap, switchMap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { SessionService } from './session.service';
// import { SessionService } from './session.service';
import { LoginSessionData } from '../interfaces/session.interface';

export interface LoginPayload {
  action: string;
  username: string;
  password: string;
  offset: string;
  domainName: string;
  requestFromAngular: string;
  clientId: string;
}

export interface UserResponse {
  status: string;
  token?: string;
  usertype?: string;
  commondetail?: {
    usertype: string;
  };
  profiledetail?: {
    language: string;
  };
  msg?: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  tokenRequest: string | undefined;
  private initialized = false;
  private ipcRenderer: any;
  constructor(
    private http: HttpClient,
    private router: Router,
    private sessionService: SessionService
  ) {
    if ((window as any).require) {
      try {
        this.ipcRenderer = (window as any).require('electron').ipcRenderer;
      } catch (err) {
        console.warn('Could not load electron ipcRenderer', err);
      }
    }

    this.initializeAuth();
  }

  

  private initializeAuth(): void {
    if (this.initialized) return;

    console.log('Initializing AuthService...');
    // Session service handles restoration automatically
    this.initialized = true;
  }

  get isLoggedIn(): Observable<boolean> {
    return this.sessionService.isLoggedIn$;
  }

  get isLoggedInSync(): boolean {
    console.log('isLoggedInSync() method called', this.sessionService.isLoggedIn);
    return this.sessionService.isLoggedIn;
  }

  login(payload: LoginPayload): Observable<UserResponse> {
    const params = new HttpParams()
      .set('action', payload.action)
      .set('username', payload.username)
      .set('password', payload.password)
      .set('offset', payload.offset ?? '')
      .set('domainName', payload.domainName)
      .set('requestFromAngular', payload.requestFromAngular)
      .set('clientId', payload.clientId);

    const url = environment.APIBaseURLBasic + 'RemediNovaDoctorAPI.do';

    return this.http.post<UserResponse>(url, null, { params }).pipe(
      switchMap((res) => {
        if (res.status === 'success' && res.token) {
          // Create session data
          const sessionData: LoginSessionData = {
            token: res.token,
            userId: res.commondetail?.usertype || 'unknown',
            username: payload.username,
            clientId: payload.clientId,
            domainId: localStorage.getItem('domainId') || payload.domainName,
            language:
              res.profiledetail?.language ||
              localStorage.getItem('language') ||
              'en',
            userProfile: res.profiledetail,
            loginResponse: res,
            expiryHours: 24, // Default 24 hours
          };

          // Create session in PouchDB
          console.log('Creating session for user:', sessionData.username);
          return this.sessionService.createSession(sessionData).pipe(
            tap((sessionDoc) => {
              console.log(' Session document created:', {
                username: sessionDoc.username,
                hasToken: !!sessionDoc.token,
                isActive: sessionDoc.isActive,
                platform: sessionDoc.platform,
              });
            }),
            map(() => {
              console.log('Login successful and session ready for redirect');
              return res;
            })
          );
        }
        return [res];
      }),
      catchError((error) => {
        console.error(' Login failed:', error);
        return throwError(() => error);
      })
    );
  }

  getToken(): string | null {
    return this.sessionService.getToken();
  }

  getUserProfile(): any | null {
    return this.sessionService.getUserProfile();
  }

  getLoginResponse(): any | null {
    return this.sessionService.getLoginResponse();
  }

  getCurrentSession() {
    return this.sessionService.currentSession;
  }

  extendSession(hours: number = 24): Observable<any> {
    return this.sessionService.extendSession(hours);
  }

  updateActivity(): Observable<boolean> {
    return this.sessionService.updateLastActivity();
  }

  validateToken(token: string): Observable<boolean> {
    const url = environment.APIBaseURLBasic + 'RemediNovaDoctorAPI.do';

    const params = new HttpParams()
      .set('action', 'validateToken')
      .set('token', token);

    return this.http.post<any>(url, null, { params }).pipe(
      map((res) => {
        return res?.status === 'success';
      }),
      catchError((error) => {
        console.error(' Token validation failed:', error);

        return of(false);
      })
    );
  }
// chaitanya
  // logout(): Observable<boolean> {
  //   return this.sessionService.clearSession().pipe(
  //     tap(() => {
  //       console.log(' Logout completed');
  //       this.router.navigate(['/login']);
  //     }),
  //     catchError((error) => {
  //       console.error('⚠️ Error during logout:', error);
  //       // Navigate to login even if logout fails
  //       this.router.navigate(['/login']);
  //       return [true];
  //     })
  //   );
  // }



///function changes by sangeeta
  logout(): Observable<boolean> {
    return this.sessionService.clearSession().pipe(
      tap(() => {
        console.log('Clearing session and storage...');

        // Backup temperatureFVal
        const tempFVal = sessionStorage.getItem('temperatureFVal');

        // Clear session + local storage
        localStorage.removeItem('isLoggedInStatus');
        localStorage.removeItem('token');
    
        localStorage.removeItem('patientId');

        //  Restore temperatureFVal
        if (tempFVal) {
          sessionStorage.setItem('temperatureFVal', tempFVal);
        }

        console.log(' Storage cleared (temperatureFVal preserved)');
        this.router.navigate(['/login']);
      }),
      catchError((error) => {
        console.error(' Error during logout:', error);

        //  Backup temperatureFVal before force clear
        const tempFVal = sessionStorage.getItem('temperatureFVal');

        // Force clear everything


        //  Restore temperatureFVal if exists
        if (tempFVal) {
          sessionStorage.setItem('temperatureFVal', tempFVal);
        }

        this.router.navigate(['/login']);
        return of(true);
      })
    );
  }


  // Debug method
  getSessionInfo(): any {
    return this.sessionService.getSessionInfo();
  }
}
