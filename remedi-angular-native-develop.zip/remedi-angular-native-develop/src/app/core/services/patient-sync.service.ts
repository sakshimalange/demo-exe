import { Injectable } from '@angular/core';
import { PouchdbService } from './pouchdb.service';
import { ApiService } from './api.service';
import { ConstantService } from './constant.service';
import { firstValueFrom, lastValueFrom } from 'rxjs';
import moment from 'moment';
import { mPatientData } from '../interfaces/patient-registration';

@Injectable({
  providedIn: 'root'
})
export class PatientSyncService {
  private isSyncing: boolean = false;
  private onlineListener: any;

  constructor(
    private objPouchdbService: PouchdbService,
    private apiSvc: ApiService,
    private constantSvc: ConstantService
  ) {
    this.initializeBackgroundSync();
  }

  private initializeBackgroundSync(): void {
    console.log('🔄 Initializing PatientSyncService background sync...');

    // Initialize PouchDB for patient registration data
    this.objPouchdbService.initDB('patientdetail');

    // Set up online listener for automatic sync
    this.onlineListener = () => {
      console.log('📶 Device came online, triggering patient sync...');
      setTimeout(() => {
        this.debugPatientData();
        this.syncAllUnsyncedPatients();
      }, 2000);
    };
    window.addEventListener('online', this.onlineListener);

    console.log('✅ PatientSyncService initialized successfully');

    // Try initial sync if online
    if (navigator.onLine) {
      console.log('🌐 Device is online, starting initial sync...');
      setTimeout(() => {
        this.debugPatientData();
        this.syncAllUnsyncedPatients();
      }, 3000);
    } else {
      console.log('📴 Device is offline, sync will start when online');
    }
  }

  // Public method to manually trigger sync
  public triggerSync(): void {
    console.log('🔄 Manual sync triggered');
    this.syncAllUnsyncedPatients();
  }

  async syncAllUnsyncedPatients(): Promise<void> {
    if (this.isSyncing) {
      console.log('Sync is already in progress. Skipping this attempt.');
      return;
    }

    this.isSyncing = true;

    try {
      // Ensure we're using the correct database
      this.objPouchdbService.initDB('patientdetail');

      // Load all local patients
      const allDocs = await firstValueFrom(this.objPouchdbService.getAllRecords<mPatientData>());
      const toSync = (allDocs || []).filter((p: any) =>
        (p.type === 'patient_detail' || p.type === 'patient') && (!p.synced || p.updated)
      );

      if (!toSync.length) {
        console.log('No pending patients to sync.');
        return ;
      }

      let syncFailureCount = 0;
      let syncSuccessCount = 0;

      // Process each unsynced record
      for (const doc of toSync) {
        try {
          console.log(`🔄 Syncing patient: ${doc.first_name} ${doc.last_name} (Documents: ${Array.isArray(doc.documents) ? doc.documents.length : 0})`);
          const synced = await this.syncWithBackend({ ...doc });

          console.log(`🔍 Sync result for ${doc.first_name}: synced=${synced.synced}`);

          if (!synced.synced) {
            console.warn(`❌ Sync failed for ${doc.first_name} ${doc.last_name}`);
            syncFailureCount++;
            continue;
          }

          // Update local DB with synced data - preserve PouchDB metadata
          const updateData = {
            ...synced,
            _id: (doc as any)._id,
            _rev: (doc as any)._rev,
            synced: true, // Ensure synced flag is set
            updated: false // Reset updated flag on successful sync
          };

          console.log(`💾 Updating local record for ${doc.first_name} ${doc.last_name}:`, updateData._id);
          const updateResult = await firstValueFrom(this.objPouchdbService.updateRecord(updateData));

          // Verify the update was successful
          if (updateResult?.ok) {
            console.log('✅ Local record updated successfully with synced: true');

            // Double-check by reading the record back
            try {
              const verifyDoc = await firstValueFrom(this.objPouchdbService.getRecordById(updateData._id));
              if ((verifyDoc as any).synced === true) {
                console.log('✅ Verified: Record synced flag is properly set to true');
              } else {
                console.error('❌ Verification failed: synced flag not set correctly');
              }
            } catch (verifyError) {
              console.error('❌ Could not verify sync status update:', verifyError);
            }
          } else {
            console.error('❌ Failed to update local record with synced status');
            throw new Error('Failed to update local sync status');
          }
          syncSuccessCount++;
        } catch (e) {
          console.warn('Sync attempt failed for a patient, will retry later.', e);
          syncFailureCount++;
        }
      }

      // Log results
      if (syncFailureCount > 0) {
        console.log(`${syncFailureCount} patient record(s) failed to sync. They will retry automatically when connection improves.`);
      }
      if (syncSuccessCount > 0) {
        console.log(`${syncSuccessCount} patient record(s) synced successfully from offline storage.`);
      }

    } catch (e) {
      console.error('Failed to fetch pending patients for sync:', e);
    } finally {
      this.isSyncing = false;
    }
  }

  private async syncWithBackend(patientData: mPatientData): Promise<mPatientData> {
    try {
      const loginResponse = JSON.parse(
        localStorage.getItem('LOGIN_RESPONSE') ||
        localStorage.getItem('loginResponse') ||
        '{}'
      );

      const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
      const apiUrl = this.constantSvc.APIConfig.GETCOMMONSERVICES;

      if (patientData.dob) {
        const formattedDob = moment(patientData.dob).format('MM/DD/YYYY');
        const calculatedAge = this.calculateAge(patientData.dob);
        patientData.dob = formattedDob;
        patientData.age = calculatedAge.ageYears;
        patientData.ageMonths = calculatedAge.ageMonths;
        patientData.ageDays = calculatedAge.ageDays;
      }

      // Prepare query string
      let data =
        '?firstname=' + encodeURIComponent(patientData.first_name || '') +
        '&lastname=' + encodeURIComponent(patientData.last_name || '') +
        '&age=' + encodeURIComponent((patientData.age || '') + ' years,' + (patientData.ageMonths || 0) + ' months,' + (patientData.ageDays || 0) + ' days') +
        '&gender=' + encodeURIComponent(patientData.gender || '') +
        '&marital=' + encodeURIComponent(patientData.marital || '') +
        '&address=' + encodeURIComponent(patientData.address || '') +
        '&height=' + encodeURIComponent(patientData.height || '') +
        '&weight=' + encodeURIComponent(patientData.weight || '') +
        '&contactNo=' + encodeURIComponent(patientData.contactNo || '') +
        '&email=' + encodeURIComponent(patientData.email || '') +
        '&dob=' + encodeURIComponent(patientData.dob || '') +
        '&hoh_fname=' + encodeURIComponent(patientData.hoh_fname || '') +
        '&hoh_lname=' + encodeURIComponent(patientData.hoh_lname || '') +
        '&uid=' + encodeURIComponent(patientData.uid || '') +
        '&country=' + encodeURIComponent(patientData.country?.toString() || '') +
        '&state=' + encodeURIComponent(patientData.state?.toString() || '') +
        '&district=' + encodeURIComponent(patientData.district?.toString() || '') +
        '&block=' + encodeURIComponent(patientData.block?.toString() || '') +
        '&village=' + encodeURIComponent(patientData.village?.toString() || '') +
        '&imagetype=' + encodeURIComponent(patientData.imagetype || '') +
        '&consentcheckstatus=1' +
        '&username=' + encodeURIComponent(patientData.username?.toString() || '') +
        // '&domain=' + encodeURIComponent(patientData.domain || '') +
        '&domain=21' +
        '&action=registerPatient' +
        '&token=' + encodeURIComponent(token) +
        '&isABHAPatient=' + encodeURIComponent(patientData.isAbhaPatient ? 'true' : 'false') +
        '&health_number=' + encodeURIComponent(patientData.health_number || '') +
        '&health_address=' + encodeURIComponent(patientData.health_address || '');

      // Prepare FormData
      let formData: any = {
        record: patientData.record || '',
        fingerPrintTemplate: patientData.fingerPrintTemplate || '',
      };

      // Add profile image as base64
      let profileDataUrl = '';
      if (patientData.profile?.imagepath?.startsWith?.('data:')) {
        profileDataUrl = patientData.profile.imagepath;
      } else if ((patientData.profile as any)?.data?.startsWith?.('data:')) {
        profileDataUrl = (patientData.profile as any).data;
      } else if (patientData.profile?.base64Image?.startsWith?.('data:')) {
        profileDataUrl = patientData.profile.base64Image as any;
      }
      if (profileDataUrl) {
        formData.profilePic = profileDataUrl;
      }

      // Handle documents with better error checking
      if (Array.isArray(patientData.documents) && patientData.documents.length > 0) {
        console.log(`📄 Processing ${patientData.documents.length} document(s) for sync`);
        patientData.documents.forEach((doc: any, index: number) => {
          const docData = doc.data || doc.preview || '';
          if (docData) {
            formData[`document_${index}`] = docData;
            console.log(`📄 Added document ${index + 1} to form data`);
          } else {
            console.warn(`⚠️ Document ${index + 1} has no data to sync`);
          }
        });
      } else {
        console.log('📄 No documents to sync');
      }

      const response: any = await lastValueFrom(
        this.apiSvc.postServiceBasicFormQueryregister(apiUrl, data, formData)
      );

      console.log('🔍 API Response:', {
        status: response?.status,
        Status: response?.Status,
        success: response?.success,
        code: response?.code,
        response: response
      });

      // More comprehensive success check
      const status = (response && (response.status || response.Status || response.success)) as any;
      const hasSuccessCode = response && (response.code === 200 || response.statusCode === 200);
      const hasSuccessStatus = status === 'success' || status === true || status === 'Success' || status === 'SUCCESS';
      const hasResponse = response && typeof response === 'object';

      const ok = hasResponse && (hasSuccessStatus || hasSuccessCode || (!response.error && !response.Error));

      console.log('🔍 Sync decision:', {
        status,
        hasSuccessCode,
        hasSuccessStatus,
        hasResponse,
        ok,
        hasDocuments: Array.isArray(patientData.documents) && patientData.documents.length > 0
      });

      if (ok) {
        console.log('✅ API sync successful, preparing updated patient data');

        // Create updated patient with explicit synced flag
        const updatedPatient: mPatientData = {
          ...patientData,
          synced: true, // Explicitly set synced to true
          updated: false // Reset updated flag on successful sync
        };

        // Merge backend S3 URLs if present
        const respData: any = (response as any).data || {};
        if (respData?.profile?.S3URL) {
          updatedPatient.profile = { ...(updatedPatient.profile || {}), S3URL: respData.profile.S3URL };
        }

        // Extract backend patientid if available
        if (response.patientid || respData.patientid) {
          (updatedPatient as any).patientid = response.patientid || respData.patientid;
          (updatedPatient as any).domainwiseid = response.domainwiseid || respData.domainwiseid;
        }

        // Handle document S3 URLs properly
        if (Array.isArray(respData?.documents) && Array.isArray(updatedPatient.documents)) {
          respData.documents.forEach((doc: any, idx: number) => {
            if (updatedPatient.documents?.[idx] && doc.S3URL) {
              updatedPatient.documents[idx].S3URL = doc.S3URL;
            }
          });
        }

        console.log('✅ Returning updated patient with synced: true');
        // Double ensure synced flag is set
        return { ...updatedPatient, synced: true, updated: false };
      } else {
        console.warn('❌ API response indicates failure:', { response, status, ok });
        return { ...patientData, synced: false, updated: true };
      }
    } catch (error) {
      console.error('❌ Backend sync failed with error:', error);
      return { ...patientData, synced: false, updated: true };
    }
  }

  private calculateAge(dateOfBirth: string): {
    age: string;
    ageYears: string;
    ageMonths: string;
    ageDays: string;
  } {
    if (!dateOfBirth) {
      return { age: '', ageYears: '', ageMonths: '', ageDays: '' };
    }

    const birthDate = new Date(dateOfBirth);
    const today = new Date();

    let years = today.getFullYear() - birthDate.getFullYear();
    let months = today.getMonth() - birthDate.getMonth();
    let days = today.getDate() - birthDate.getDate();

    // Adjust days and months if negative
    if (days < 0) {
      months--;
      const lastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
      days += lastMonth.getDate();
    }

    if (months < 0) {
      years--;
      months += 12;
    }

    const age = `${years} Years, ${months} Months, ${days} Days`;
    const ageYears = `${years}`;
    const ageMonths = `${months}`;
    const ageDays = `${days}`;

    return { age, ageYears, ageMonths, ageDays };
  }

  /**
   * Get count of unsynced patients
   */
  async getUnsyncedCount(): Promise<number> {
    try {
      this.objPouchdbService.initDB('patientdetail');
      const allDocs = await firstValueFrom(this.objPouchdbService.getAllRecords<mPatientData>());
      return (allDocs || []).filter((p: any) => p.type === 'patient' && !p.synced).length;
    } catch (error) {
      console.error('Error getting unsynced count:', error);
      return 0;
    }
  }

  /**
   * Debug method to check patient data integrity
   */
  async debugPatientData(): Promise<void> {
    try {
      this.objPouchdbService.initDB('patientdetail');
      const allDocs = await firstValueFrom(this.objPouchdbService.getAllRecords<mPatientData>());
      const patients = (allDocs || []).filter((p: any) => p.type === 'patient' || p.type === 'patient_detail');

      console.log('=== PATIENT SYNC DEBUG ===');
      console.log(`Total patients in DB: ${patients.length}`);

      const synced = patients.filter((p: any) => p.synced === true);
      const unsynced = patients.filter((p: any) => p.synced !== true);

      console.log(`Synced patients: ${synced.length}`);
      console.log(`Unsynced patients: ${unsynced.length}`);

      if (unsynced.length > 0) {
        console.log('🔄 Unsynced patients:');
        unsynced.forEach((p: any, index: number) => {
          const hasDocuments = Array.isArray(p.documents) && p.documents.length > 0;
          console.log(`${index + 1}. ${p.first_name} ${p.last_name} - Documents: ${hasDocuments ? p.documents.length : 0} - Synced: ${p.synced}`);
        });
      }

      console.log('=== END DEBUG ===');
    } catch (error) {
      console.error('Error in debug method:', error);
    }
  }

  ngOnDestroy(): void {
    // Clean up event listener
    if (this.onlineListener) {
      window.removeEventListener('online', this.onlineListener);
    }
  }
}
