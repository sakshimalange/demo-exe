import { Injectable, NgZone, OnDestroy } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { WebsocketsService } from './websocket.service';

/**
 * 🌐 CENTRALIZED NULL WEBSOCKET SERVICE
 * ==================================================================================
 * Purpose: Single nullwebsocket connection shared across all doctor/nurse pages
 * Benefits: Eliminates multiple connections, reduces resource usage, prevents conflicts
 * Pattern: Singleton service with connection management and message broadcasting
 * Usage: Inject service, call connect(), use sendMessage() and subscribe to messages$
 * ==================================================================================
 */

@Injectable({
  providedIn: 'root'
})
export class NullWebsocketService implements OnDestroy {

  // ==================================================================================
  // CONNECTION MANAGEMENT
  // ==================================================================================
  private nullWebSocket$: any = null;                    // Single nullwebsocket connection instance
  private isConnected: boolean = false;                  // Connection status flag
  private isVideoConsultationActive: boolean = false;   // Video consultation status
  private consultationId: string | null = null;         // Current consultation ID
  private userType: string = '';                         // Current user type (Doctor/Nurse)
  private uniqueSessionId: string = '';                  // Unique session identifier for Angular ↔ Angular fix

  // ==================================================================================
  // MESSAGE BROADCASTING
  // ==================================================================================
  private messagesSubject = new BehaviorSubject<any>(null);
  public messages$ = this.messagesSubject.asObservable();

  private connectionStatusSubject = new BehaviorSubject<boolean>(false);
  public connectionStatus$ = this.connectionStatusSubject.asObservable();

  private videoConsultationStatusSubject = new BehaviorSubject<boolean>(false);
  public videoConsultationStatus$ = this.videoConsultationStatusSubject.asObservable();

  // ==================================================================================
  // DESTROY SUBJECT FOR CLEANUP
  // ==================================================================================
  private destroy$ = new Subject<void>();

  constructor(
    private websocketsService: WebsocketsService,
    private ngZone: NgZone
  ) {
    console.log('🔧 [NULL-WS] NullWebsocketService initialized');
    console.log('🔍 [NULL-WS] Initial platform info:', this.getPlatformInfo());
    this.initializeUserType();
    // Regenerate session ID when user type changes
    if (this.userType) {
      this.generateUniqueSessionId();
    }
    this.generateUniqueSessionId();
  }

  // ==================================================================================
  // INITIALIZATION METHODS
  // ==================================================================================

  /**
   * 🔍 INITIALIZE USER TYPE - Detect if user is Doctor or Nurse
   */
  private initializeUserType(): void {
    try {
      const loginResponseRaw = localStorage.getItem('LOGIN_RESPONSE');
      if (loginResponseRaw) {
        const loginResponse = JSON.parse(loginResponseRaw);
        this.userType = loginResponse.commondetail?.usertype || '';
        console.log('🔍 [NULL-WS] User type detected:', this.userType);
    console.log('🔍 [NULL-WS] Platform detection at init:', this.getPlatformInfo());
      }
    } catch (error) {
      console.error('❌ [NULL-WS] Error parsing LOGIN_RESPONSE:', error);
      this.userType = '';
    }
  }

  /**
   * 🔑 GENERATE UNIQUE SESSION ID - Create unique identifier for Angular ↔ Angular communication
   */
  private generateUniqueSessionId(): void {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substr(2, 9);

    // Get actual user name instead of user type
    let userName = 'user';
    try {
      const loginResponseRaw = localStorage.getItem('LOGIN_RESPONSE');
      if (loginResponseRaw) {
        const loginResponse = JSON.parse(loginResponseRaw);
        userName = loginResponse.profiledetail?.userName || loginResponse.profiledetail?.firstname || this.userType.toLowerCase() || 'user';
      }
    } catch (error) {
      console.error('❌ [NULL-WS] Error getting user name:', error);
      userName = this.userType.toLowerCase() || 'user';
    }

    this.uniqueSessionId = `${userName}_${timestamp}_${random}`;
    console.log('🔑 [NULL-WS] Generated unique session ID:', this.uniqueSessionId);
    console.log('🔍 [NULL-WS] Platform info after session ID generation:', this.getPlatformInfo());
  }

  /**
   * 🔌 CONNECT - Establish nullwebsocket connection for consultation
   * @param consultationId - The consultation room ID
   * @returns Promise<boolean> - Connection success status
   */
  public async connect(consultationId: string): Promise<boolean> {
    if (this.isConnected && this.consultationId === consultationId) {
      console.log('🔍 [NULL-WS] Already connected to consultation:', consultationId);
      return true;
    }

    // Disconnect existing connection if different consultation
    if (this.isConnected && this.consultationId !== consultationId) {
      console.log('🔄 [NULL-WS] Switching to new consultation, disconnecting current connection');
      this.disconnect();
    }

    this.consultationId = consultationId;

    try {
      // FIX: Create proper WebSocket URL based on platform and user type
      const baseUrl = 'wss://s3test2.remedi.co.in/RemediPRMS/consultationserverendpoint';
      const roomId = `room${consultationId}`;

      const endpoint = this.isAngularToAngular() ? this.uniqueSessionId : 'null';

      const socketUrl = `${baseUrl}/${roomId}/${endpoint}`;
      console.log('🔌 [NULL-WS] Establishing nullwebsocket connection:', socketUrl);
      console.log('🔍 [NULL-WS] Platform detection - Electron:', this.isElectronPlatform(), 'Angular-to-Angular:', this.isAngularToAngular());
      console.log('🔍 [NULL-WS] User type:', this.userType, 'Endpoint:', endpoint);
      console.log('🔍 [NULL-WS] User agent:', navigator.userAgent);
      console.log('🔍 [NULL-WS] Platform info:', this.getPlatformInfo());

      this.nullWebSocket$ = this.websocketsService['createSocket'](socketUrl, (msg: any) => {
        console.log('📨 [NULL-WS] Received message:', msg);
        this.handleIncomingMessage(msg);
      });

      this.isConnected = true;
      this.connectionStatusSubject.next(true);
      try {
        const loginResponseRaw = localStorage.getItem('LOGIN_RESPONSE');
        if (loginResponseRaw) {
          const loginResponse = JSON.parse(loginResponseRaw);
          // this.currentUserType = loginResponse.commondetail?.usertype || '';
          console.log('🔍 [TABS] Current user type:', loginResponse.commondetail?.usertype);
        }
      } catch (error) {
        console.error('❌ [TABS] Error parsing LOGIN_RESPONSE:', error);
        // this.currentUserType = '';
      }
      // Send initial "loggedin" message after connection establishment
      setTimeout(() => {
        this.sendMessage('loggedin');
        console.log('✅ [NULL-WS] Sent initial "loggedin" message');
      }, 500);

      console.log('✅ [NULL-WS] Nullwebsocket connection established successfully');
      return true;

    } catch (error) {
      console.error('❌ [NULL-WS] Failed to establish nullwebsocket connection:', error);
      this.isConnected = false;
      this.connectionStatusSubject.next(false);
      return false;
    }
  }

  /**
   * 📤 SEND MESSAGE - Send message via nullwebsocket
   * @param message - Message to send (string)
   * @returns boolean - Send success status
   */
  public sendMessage(message: string): boolean {
    if (!this.isConnected || !this.nullWebSocket$) {
      console.error('[NULL-WS] Cannot send message - not connected');
      return false;
    }

    try {
      this.nullWebSocket$.next(message);
      console.log(`[NULL-WS] Sent message: ${message}`);
      return true;
    } catch (error) {
      console.error(' [NULL-WS] Error sending message:', error);
      return false;
    }
  }

  /**
   * 🔌 DISCONNECT - Close nullwebsocket connection
   */
  public disconnect(): void {
    if (this.nullWebSocket$) {
      try {
        this.nullWebSocket$.complete();
        this.nullWebSocket$ = null;
        this.isConnected = false;
        this.isVideoConsultationActive = false;
        this.consultationId = null;

        this.connectionStatusSubject.next(false);
        this.videoConsultationStatusSubject.next(false);

        console.log('🔌 [NULL-WS] Nullwebsocket disconnected');
      } catch (error) {
        console.error('❌ [NULL-WS] Error disconnecting nullwebsocket:', error);
      }
    }
  }

  // ==================================================================================
  // MESSAGE HANDLING
  // ==================================================================================

  /**
   * 📨 HANDLE INCOMING MESSAGE - Process messages from nullwebsocket
   */
  private handleIncomingMessage(message: any): void {
    console.log('[NULL-WS] Received message:', message);
    try {
      console.log('[NULL-WS] Received message:', message);

      // Parse message if it's a JSON string
      let parsedMessage = message;
      if (typeof message === 'string') {
        try {
          parsedMessage = JSON.parse(message);
        } catch {
          // If not JSON, treat as plain string
          parsedMessage = { message: message };
        }
      }

      // FIX: Filter messages for Angular ↔ Angular communication
      if (this.isAngularToAngular() && this.shouldFilterMessage(parsedMessage)) {
        console.log('🔄 [NULL-WS] Filtering message for Angular ↔ Angular communication');
        return;
      }

      // Handle video consultation status messages
      if (parsedMessage?.message === 'loggedinsuccess' || message === 'loggedinsuccess') {
        console.log(' [NULL-WS] Video consultation activated');
        this.isVideoConsultationActive = true;
        this.videoConsultationStatusSubject.next(true);
      } else if (parsedMessage?.message === 'loggedout' || message === 'loggedout') {
        console.log(' [NULL-WS] Video consultation ended');
        this.isVideoConsultationActive = false;
        this.videoConsultationStatusSubject.next(false);
      }

      // Broadcast message to all subscribers
      this.messagesSubject.next(parsedMessage);

    } catch (error) {
      console.error(' [NULL-WS] Error handling incoming message:', error);
    }
  }

  // ==================================================================================
  // GETTERS
  // ==================================================================================

  /**
   * 🔍 GET CONNECTION STATUS
   */
  public getConnectionStatus(): boolean {
    return this.isConnected;
  }

  /**
   * 🔍 GET VIDEO CONSULTATION STATUS
   */
  public getVideoConsultationStatus(): boolean {
    return this.isVideoConsultationActive;
  }

  /**
   * 🔍 GET CURRENT CONSULTATION ID
   */
  public getCurrentConsultationId(): string | null {
    return this.consultationId;
  }

  /**
   * 🔍 GET USER TYPE
   */
  public getUserType(): string {
    return this.userType;
  }

  /**
   * 🔍 GET PLATFORM INFO - Debug method to check platform detection
   */
  public getPlatformInfo(): any {
    return {
      userType: this.userType,
      isElectron: this.isElectronPlatform(),
      isAngularToAngular: this.isAngularToAngular(),
      userAgent: navigator.userAgent,
      windowElectronAPI: !!(window as any).electronAPI,
      windowIsElectronApp: !!(window as any).isElectronApp,
      uniqueSessionId: this.uniqueSessionId
    };
  }

  // ==================================================================================
  // ANGULAR ↔ ANGULAR COMMUNICATION FIX
  // ==================================================================================

  /**
   * 🔍 CHECK IF RUNNING IN ELECTRON
   */
  private isElectronPlatform(): boolean {
    if (typeof window === 'undefined') return false;

    // Multiple ways to detect Electron
    return !!(window as any).electronAPI?.isElectron ||
           !!(window as any).isElectronApp ||
           navigator.userAgent.includes('RemediElectronApp') ||
           navigator.userAgent.includes('Electron');
  }

  /**
   * 🔍 CHECK IF ANGULAR TO ANGULAR COMMUNICATION
   */
  private isAngularToAngular(): boolean {
    // Always use unique endpoints for Angular clients (including Electron)
    // Only use 'null' endpoint for JSP clients
    const isElectron = !!(window as any).electronAPI || !!(window as any).require;
    const isAngular = typeof window !== 'undefined' && (
      !!(window as any).ng ||
      isElectron ||
      window.location.pathname.includes('angular') ||
      !!this.userType // If we have userType, we're in Angular
    );

    console.log('🔍 [NULL-WS] Platform detection:', {
      isElectron,
      isAngular,
      userType: this.userType,
      pathname: window.location.pathname
    });

    return !!isAngular;
  }

  /**
   * 🔄 SHOULD FILTER MESSAGE - Determine if message should be filtered for Angular ↔ Angular
   */
  private shouldFilterMessage(message: any): boolean {
    // For now, we don't filter any messages to maintain existing behavior
    // This method is prepared for future enhancements if needed
    return false;
  }

  /**
   * 🔍 TEST WEBSOCKET ENDPOINT GENERATION - Debug method
   */
  public testEndpointGeneration(consultationId: string): string {
    const baseUrl = 'wss://s3test2.remedi.co.in/RemediPRMS/consultationserverendpoint';
    const roomId = `room${consultationId}`;

    let endpoint: string;
    if (this.isElectronPlatform()) {
      endpoint = this.userType.toLowerCase() || 'null';
    } else if (this.isAngularToAngular()) {
      endpoint = `${this.userType.toLowerCase()}_${this.uniqueSessionId}`;
    } else {
      endpoint = 'null';
    }

    return `${baseUrl}/${roomId}/${endpoint}`;
  }

  // ==================================================================================
  // CLEANUP
  // ==================================================================================

  ngOnDestroy(): void {
    console.log('🧹 [NULL-WS] Service destroying, cleaning up connections');
    console.log('🔍 [NULL-WS] Final platform info:', this.getPlatformInfo());
    this.disconnect();
    this.destroy$.next();
    this.destroy$.complete();
  }
}
