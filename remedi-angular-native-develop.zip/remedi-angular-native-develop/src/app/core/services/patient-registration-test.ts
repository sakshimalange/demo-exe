// Test to verify updated field is saved during patient registration
export class PatientRegistrationTest {
  
  static async testUpdatedFieldInRegistration(pouchdbService: any) {
    console.log('🧪 Testing updated field in patient registration...');
    
    try {
      // Initialize database
      pouchdbService.initDB('patientdetail');
      
      // Create a test patient record
      const testPatient = {
        type: 'patient',
        firstname: 'Test',
        lastname: 'Patient',
        contactNo: '1234567890',
        gender: 'Male',
        dob: '1990-01-01',
        synced: false,
        updated: false,
        lastModified: new Date().toISOString()
      };
      
      console.log('📝 Creating test patient with updated field:', testPatient.updated);
      
      // Add the record
      const result = await pouchdbService.addRecord(testPatient);
      console.log('✅ Patient added with ID:', result.id);
      
      // Retrieve the record to verify
      const savedPatient = await pouchdbService.getRecordById(result.id);
      
      console.log('🔍 Verification Results:');
      console.log('- Has updated field:', 'updated' in savedPatient ? '✅' : '❌');
      console.log('- Updated value:', savedPatient.updated);
      console.log('- Has lastModified field:', 'lastModified' in savedPatient ? '✅' : '❌');
      console.log('- LastModified value:', savedPatient.lastModified);
      console.log('- Has synced field:', 'synced' in savedPatient ? '✅' : '❌');
      console.log('- Synced value:', savedPatient.synced);
      
      // Clean up - remove test record
      await pouchdbService.deleteRecord({
        _id: savedPatient._id,
        _rev: savedPatient._rev
      });
      console.log('🧹 Test record cleaned up');
      
      return {
        success: 'updated' in savedPatient && savedPatient.updated === false,
        hasUpdatedField: 'updated' in savedPatient,
        updatedValue: savedPatient.updated,
        hasLastModified: 'lastModified' in savedPatient,
        lastModifiedValue: savedPatient.lastModified
      };
      
    } catch (error) {
      console.error('❌ Test failed:', error);
      return { success: false, error: error.message };
    }
  }
  
  static async testExistingPatientStructure(pouchdbService: any) {
    console.log('🔍 Testing existing patient records structure...');
    
    try {
      pouchdbService.initDB('patientdetail');
      
      const allRecords = await pouchdbService.getAllRecords();
      const patientRecords = allRecords.filter((r: any) => 
        r.type === 'patient' || r.type === 'patient_detail'
      );
      
      console.log(`📊 Found ${patientRecords.length} patient records`);
      
      if (patientRecords.length === 0) {
        console.log('ℹ️ No existing patient records to test');
        return { noRecords: true };
      }
      
      const results = {
        total: patientRecords.length,
        withUpdatedField: 0,
        withoutUpdatedField: 0,
        withLastModified: 0,
        samples: []
      };
      
      patientRecords.forEach((patient: any, index: number) => {
        const hasUpdated = 'updated' in patient;
        const hasLastModified = 'lastModified' in patient;
        
        if (hasUpdated) results.withUpdatedField++;
        else results.withoutUpdatedField++;
        
        if (hasLastModified) results.withLastModified++;
        
        // Store first 3 as samples
        if (index < 3) {
          results.samples.push({
            id: patient._id,
            name: `${patient.firstname || patient.first_name || 'Unknown'} ${patient.lastname || patient.last_name || ''}`,
            hasUpdated,
            updatedValue: patient.updated,
            hasLastModified,
            lastModifiedValue: patient.lastModified,
            synced: patient.synced
          });
        }
      });
      
      console.log('📈 Structure Analysis:');
      console.log(`- Records with updated field: ${results.withUpdatedField}/${results.total}`);
      console.log(`- Records without updated field: ${results.withoutUpdatedField}/${results.total}`);
      console.log(`- Records with lastModified: ${results.withLastModified}/${results.total}`);
      
      console.log('📋 Sample Records:');
      results.samples.forEach((sample: any, i: number) => {
        console.log(`${i + 1}. ${sample.name}`);
        console.log(`   - updated: ${sample.hasUpdated ? sample.updatedValue : 'MISSING'}`);
        console.log(`   - lastModified: ${sample.hasLastModified ? 'Present' : 'MISSING'}`);
        console.log(`   - synced: ${sample.synced}`);
      });
      
      return results;
      
    } catch (error) {
      console.error('❌ Analysis failed:', error);
      return { success: false, error: error.message };
    }
  }
}

// Usage:
// PatientRegistrationTest.testUpdatedFieldInRegistration(pouchdbService);
// PatientRegistrationTest.testExistingPatientStructure(pouchdbService);