declare module 'pouchdb-browser';
declare module 'pouchdb-find';
