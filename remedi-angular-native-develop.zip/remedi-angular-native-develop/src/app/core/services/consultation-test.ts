// Test utility for consultation record system
export class ConsultationTest {
  
  static async testConsultationFlow(pouchdbService: any, consultationSyncService: any) {
    console.log('🧪 Testing consultation record flow...');
    
    try {
      // Test 1: Check database initialization
      pouchdbService.initDB('consultation-record');
      console.log('✅ Database initialized');
      
      // Test 2: Create test consultation data
      const testConsultationData = {
        patientId: 'test_patient_123',
        doctorId: 'test_doctor_456',
        userName: 'testuser',
        domain: '21',
        usertype: 'Doctor',
        nurseId: 'test_nurse_789',
        token: 'test_token'
      };
      
      // Test 3: Save consultation record
      const localId = await consultationSyncService.saveConsultationRecord(testConsultationData);
      console.log('✅ Consultation record saved with local ID:', localId);
      
      // Test 4: Verify record exists in PouchDB
      const allRecords = await pouchdbService.getAllRecords();
      const consultationRecords = allRecords.filter((r: any) => r.type === 'consultation_record');
      
      console.log('📊 Consultation records in database:', consultationRecords.length);
      
      if (consultationRecords.length > 0) {
        const latestRecord = consultationRecords[consultationRecords.length - 1];
        console.log('📋 Latest consultation record:');
        console.log('- local_consultation_id:', latestRecord.local_consultation_id);
        console.log('- status:', latestRecord.status);
        console.log('- synced:', latestRecord.synced);
        console.log('- patientId:', latestRecord.patientId);
        console.log('- createdAt:', latestRecord.createdAt);
      }
      
      // Test 5: Check consultation status
      const status = await consultationSyncService.getConsultationStatus(localId);
      console.log('✅ Consultation status retrieved:', status?.status);
      
      // Test 6: Clean up test record
      const recordToDelete = consultationRecords.find((r: any) => r.local_consultation_id === localId);
      if (recordToDelete) {
        await pouchdbService.deleteRecord(recordToDelete);
        console.log('🧹 Test record cleaned up');
      }
      
      console.log('🎉 Consultation test completed successfully!');
      
      return {
        success: true,
        localId: localId,
        recordsCount: consultationRecords.length
      };
      
    } catch (error) {
      console.error('❌ Consultation test failed:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  static async checkConsultationDatabase(pouchdbService: any) {
    console.log('🔍 Checking consultation database...');
    
    try {
      pouchdbService.initDB('consultation-record');
      const allRecords = await pouchdbService.getAllRecords();
      const consultationRecords = allRecords.filter((r: any) => r.type === 'consultation_record');
      
      console.log('📊 Database Summary:');
      console.log(`- Total records: ${allRecords.length}`);
      console.log(`- Consultation records: ${consultationRecords.length}`);
      
      if (consultationRecords.length > 0) {
        const syncedCount = consultationRecords.filter((r: any) => r.synced).length;
        const unsyncedCount = consultationRecords.filter((r: any) => !r.synced).length;
        const onlineCount = consultationRecords.filter((r: any) => r.status === 'online').length;
        const offlineCount = consultationRecords.filter((r: any) => r.status === 'offline').length;
        
        console.log('📈 Status Breakdown:');
        console.log(`- Synced: ${syncedCount}`);
        console.log(`- Unsynced: ${unsyncedCount}`);
        console.log(`- Online: ${onlineCount}`);
        console.log(`- Offline: ${offlineCount}`);
        
        console.log('📋 Recent Records:');
        consultationRecords.slice(-3).forEach((record: any, index: number) => {
          console.log(`${index + 1}. ID: ${record.local_consultation_id}`);
          console.log(`   Status: ${record.status}, Synced: ${record.synced}`);
          console.log(`   Patient: ${record.patientId}, Created: ${record.createdAt}`);
        });
      }
      
      return {
        totalRecords: allRecords.length,
        consultationRecords: consultationRecords.length,
        synced: consultationRecords.filter((r: any) => r.synced).length,
        unsynced: consultationRecords.filter((r: any) => !r.synced).length
      };
      
    } catch (error) {
      console.error('❌ Database check failed:', error);
      return null;
    }
  }
}

// Usage in browser console:
// ConsultationTest.testConsultationFlow(this.PouchdbService, this.consultationSyncService);
// ConsultationTest.checkConsultationDatabase(this.PouchdbService);