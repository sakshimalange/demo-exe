import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { AuthService } from 'src/app/core/services/auth.service';
import { SessionService } from 'src/app/core/services/session.service';
import { Subscription, interval } from 'rxjs';

@Component({
  selector: 'app-session-debug',
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule],
  template: `
    <ion-card class="session-debug-card">
      <ion-card-header>
        <ion-card-title>🔐 Session Debug Info</ion-card-title>
      </ion-card-header>
      
      <ion-card-content>
        <!-- Session Status -->
        <div class="debug-section">
          <h4>Session Status</h4>
          <div class="status-item">
            <span class="label">Logged In:</span>
            <ion-badge [color]="isLoggedIn ? 'success' : 'danger'">
              {{ isLoggedIn ? '✅ Yes' : '❌ No' }}
            </ion-badge>
          </div>
        </div>

        <!-- Session Details -->
        <div class="debug-section" *ngIf="sessionInfo.hasSession">
          <h4>Session Details</h4>
          <div class="session-details">
            <div class="detail-item">
              <span class="label">User:</span>
              <span class="value">{{ sessionInfo.username }}</span>
            </div>
            <div class="detail-item">
              <span class="label">User ID:</span>
              <span class="value">{{ sessionInfo.userId }}</span>
            </div>
            <div class="detail-item">
              <span class="label">Platform:</span>
              <span class="value">{{ sessionInfo.platform }}</span>
            </div>
            <div class="detail-item">
              <span class="label">Login Time:</span>
              <span class="value">{{ sessionInfo.loginTime }}</span>
            </div>
            <div class="detail-item">
              <span class="label">Expires:</span>
              <span class="value">{{ sessionInfo.expiryTime }}</span>
            </div>
            <div class="detail-item">
              <span class="label">Last Activity:</span>
              <span class="value">{{ sessionInfo.lastActivity }}</span>
            </div>
            <div class="detail-item">
              <span class="label">Valid:</span>
              <ion-badge [color]="sessionInfo.isValid ? 'success' : 'danger'">
                {{ sessionInfo.isValid ? '✅ Valid' : '❌ Invalid' }}
              </ion-badge>
            </div>
          </div>
        </div>

        <!-- Actions -->
        <div class="debug-actions">
          <ion-button 
            fill="outline" 
            size="small" 
            (click)="refreshSession()"
            [disabled]="loading">
            <ion-icon name="refresh-outline"></ion-icon>
            Refresh
          </ion-button>
          
          <ion-button 
            fill="outline" 
            size="small" 
            (click)="extendSession()"
            [disabled]="!isLoggedIn || loading"
            color="secondary">
            <ion-icon name="time-outline"></ion-icon>
            Extend +24h
          </ion-button>
          
          <ion-button 
            fill="outline" 
            size="small" 
            (click)="validateWithBackend()"
            [disabled]="!isLoggedIn || loading"
            color="tertiary">
            <ion-icon name="cloud-done-outline"></ion-icon>
            Validate API
          </ion-button>
          
          <ion-button 
            fill="clear" 
            size="small" 
            (click)="logout()"
            [disabled]="!isLoggedIn || loading"
            color="danger">
            <ion-icon name="log-out-outline"></ion-icon>
            Logout
          </ion-button>

          <ion-button 
            fill="clear" 
            size="small" 
            (click)="emergencyClear()"
            [disabled]="loading"
            color="warning">
            <ion-icon name="trash-outline"></ion-icon>
            Clear All Data
          </ion-button>
        </div>

        <!-- Auto Refresh Toggle -->
        <div class="debug-section">
          <ion-item lines="none">
            <ion-label>Auto Refresh (5s)</ion-label>
            <ion-toggle 
              [(ngModel)]="autoRefresh" 
              (ionChange)="toggleAutoRefresh()"
              color="primary">
            </ion-toggle>
          </ion-item>
        </div>
      </ion-card-content>
    </ion-card>
  `,
  styles: [`
    .session-debug-card {
      margin: 10px;
      max-width: 600px;
    }

    .debug-section {
      margin-bottom: 16px;
    }

    .debug-section h4 {
      color: var(--ion-color-primary);
      margin-bottom: 8px;
      font-size: 14px;
      font-weight: 600;
    }

    .status-item, .detail-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 4px 0;
    }

    .label {
      font-weight: 500;
      color: var(--ion-color-medium);
      font-size: 12px;
    }

    .value {
      font-family: monospace;
      font-size: 11px;
      color: var(--ion-color-dark);
    }

    .session-details {
      background: var(--ion-color-light);
      padding: 8px;
      border-radius: 4px;
      font-size: 12px;
    }

    .debug-actions {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-top: 16px;
    }

    .debug-actions ion-button {
      --padding-start: 8px;
      --padding-end: 8px;
    }

    ion-item {
      --padding-start: 0;
      --inner-padding-end: 0;
    }
  `]
})
export class SessionDebugComponent implements OnInit, OnDestroy {
  sessionInfo: any = { hasSession: false };
  isLoggedIn: boolean = false;
  loading: boolean = false;
  autoRefresh: boolean = false;
  
  private refreshSubscription?: Subscription;
  private sessionSubscription?: Subscription;

  constructor(
    private authService: AuthService,
    private sessionService: SessionService
  ) {}

  ngOnInit(): void {
    this.refreshSession();
    this.subscribeToSessionChanges();
  }

  ngOnDestroy(): void {
    this.refreshSubscription?.unsubscribe();
    this.sessionSubscription?.unsubscribe();
  }

  private subscribeToSessionChanges(): void {
    this.sessionSubscription = this.authService.isLoggedIn.subscribe(
      (loggedIn) => {
        this.isLoggedIn = loggedIn;
        this.refreshSession();
      }
    );
  }

  refreshSession(): void {
    this.sessionInfo = this.authService.getSessionInfo();
    console.log('🔍 Session Debug Refresh:', this.sessionInfo);
  }

  extendSession(): void {
    if (!this.isLoggedIn) return;
    
    this.loading = true;
    this.authService.extendSession(24).subscribe({
      next: () => {
        console.log('✅ Session extended by 24 hours');
        this.refreshSession();
        this.loading = false;
      },
      error: (error) => {
        console.error('❌ Failed to extend session:', error);
        this.loading = false;
      }
    });
  }

  validateWithBackend(): void {
    if (!this.isLoggedIn) return;
    
    this.loading = true;
    this.sessionService.syncSessionWithBackend().subscribe({
      next: (isValid) => {
        console.log('🔍 Backend validation result:', isValid);
        this.refreshSession();
        this.loading = false;
      },
      error: (error) => {
        console.error('❌ Backend validation failed:', error);
        this.loading = false;
      }
    });
  }

  logout(): void {
    this.loading = true;
    this.authService.logout().subscribe({
      next: () => {
        console.log('✅ Logout completed from debug component');
        this.loading = false;
      },
      error: (error) => {
        console.error('❌ Logout error:', error);
        this.loading = false;
      }
    });
  }

  emergencyClear(): void {
    this.loading = true;
    console.log('🚨 Emergency clear: Clearing all session data and storage...');
    
    // Clear all possible storage locations
    try {
      // Clear localStorage
      localStorage.clear();
      console.log('🗑️ localStorage cleared');
      
      // Clear sessionStorage  
      // sessionStorage.clear();
       for (let i = 0; i < sessionStorage.length; i++) {
        if (sessionStorage.key(i) !== "isLoggedInStatus") {
          sessionStorage.removeItem(sessionStorage.key(i) || "");
        }
      }
      console.log('🗑️ sessionStorage cleared');
      
      // Clear session service
      this.sessionService.clearSession().subscribe({
        next: () => {
          console.log('🗑️ Session service cleared');
          this.refreshSession();
          this.loading = false;
          
          // Force reload the page to ensure clean state
          setTimeout(() => {
            window.location.reload();
          }, 1000);
        },
        error: (error) => {
          console.error('❌ Error during emergency clear:', error);
          this.loading = false;
          
          // Force reload anyway
          setTimeout(() => {
            window.location.reload();
          }, 1000);
        }
      });
    } catch (error) {
      console.error('❌ Emergency clear error:', error);
      this.loading = false;
      
      // Force reload anyway
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    }
  }

  toggleAutoRefresh(): void {
    if (this.autoRefresh) {
      // Start auto refresh every 5 seconds
      this.refreshSubscription = interval(5000).subscribe(() => {
        this.refreshSession();
      });
    } else {
      // Stop auto refresh
      this.refreshSubscription?.unsubscribe();
    }
  }
}