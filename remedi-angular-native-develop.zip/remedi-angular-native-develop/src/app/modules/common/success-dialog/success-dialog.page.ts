import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-success-dialog',
  standalone: true,
  templateUrl: './success-dialog.page.html',
  styleUrls: ['./success-dialog.page.scss'],
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatButtonModule,
  ],
})
export class SuccessDialogPage {
  constructor(
    public dialogRef: MatDialogRef<SuccessDialogPage>,
    @Inject(MAT_DIALOG_DATA) public data: { message: string }
  ) {}

  onClose() {
    this.dialogRef.close();
  }
}
