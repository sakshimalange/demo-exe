import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-patient-id-dialog',
  standalone: true,
  templateUrl: './patient-id-dialog.page.html',
  styles: [`
    .patient-id-dialog {
      min-width: 400px;
      padding: 20px;
    }
    .dialog-title {
      margin: 0 0 16px 0;
      font-size: 20px;
      font-weight: 500;
      color: rgba(0, 0, 0, 0.87);
    }
    .dialog-content {
      margin-bottom: 20px;
    }
    .dialog-content p {
      margin-bottom: 16px;
      color: rgba(0, 0, 0, 0.6);
    }
    .form-field {
      position: relative;
      margin-bottom: 16px;
    }
    .form-label {
      display: block;
      font-size: 12px;
      font-weight: 400;
      color: rgba(0, 0, 0, 0.6);
      margin-bottom: 4px;
    }
    .form-input {
      width: 100%;
      padding: 12px 16px;
      border: 1px solid rgba(0, 0, 0, 0.12);
      border-radius: 4px;
      font-size: 14px;
      box-sizing: border-box;
    }
    .form-input:focus {
      outline: none;
      border-color: #1976d2;
      box-shadow: 0 0 0 2px rgba(25, 118, 210, 0.2);
    }
    .dialog-actions {
      display: flex;
      justify-content: flex-end;
      gap: 8px;
      padding-top: 16px;
    }
    .dialog-actions button {
      padding: 8px 16px;
      border-radius: 4px;
      border: 1px solid #ccc;
      background: white;
      cursor: pointer;
      font-size: 14px;
    }
    .dialog-actions button:last-child {
      background: #1976d2;
      color: white;
      border-color: #1976d2;
    }
    .dialog-actions button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `],
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
  ],
})
export class PatientIdDialogPage {
  patientId: string = '';

  constructor(
    public dialogRef: MatDialogRef<PatientIdDialogPage>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  onCancel(): void {
    this.dialogRef.close();
  }

  onConfirm(): void {
    if (this.patientId.trim()) {
      this.dialogRef.close(this.patientId.trim());
    }
  }
}
