import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { ApiService } from 'src/app/core/services/api.service';
import { ConstantService } from 'src/app/core/services/constant.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { TranslateService, TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-common-dialog',
  standalone: true,
  templateUrl: './common-dialog.page.html',
  styleUrls: ['./common-dialog.page.scss'],
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    TranslateModule,
  ],
})
export class CommonDialogPage {
  slotAction: any;
  patid: any;
  followup: any = false;
  screenHeight!: number;
  screenWidth!: number;
  currUserType: any;
  currDomainId: any;

  constructor(
    private constantSvc: ConstantService,
    private router: Router,
    private _route: ActivatedRoute,
    // private helperSvc: HelperService,
    private apiSvc: ApiService,
      private authService: AuthService,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<CommonDialogPage>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.slotAction = data;
    this.followup = data?.followUp || false;
    console.log("follow up", this.slotAction)

    // this.patid = this.patid
  }
  isDisabled = false
  ngOnInit(): void {


     const currentSession = this.authService.getCurrentSession();
    console.log("getCurrentSession",currentSession)
  
  }

  onDialogSuccess() {
    this.dialogRef.close(true);
  }


  onDialogSuccessNurse() {
    this.dialogRef.close({data: this.slotAction.patid});
  
  }

  onDialogCloseMed() {
    this.dialogRef.close();
  }
  onDialogClose() {
    this.dialogRef.close();
  }

  onDialogCloseConfirm() {
    this.dialogRef.close('yes');
  }

  onDialogCloseConfirmSuspend() {
    this.dialogRef.close('suspend');
               
  }

  onDialogCloseConfirmFinish() {
    this.dialogRef.close('finish');
  }

  onDialogCloseConfirmFollowUp() {
    this.dialogRef.close('ok');
  }

  cancel() {
    this.dialogRef.close(); // Close without data
  }
}
