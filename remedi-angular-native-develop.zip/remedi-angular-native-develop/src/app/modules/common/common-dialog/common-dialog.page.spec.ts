import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonDialogPage } from './common-dialog.page';

describe('CommonDialogPage', () => {
  let component: CommonDialogPage;
  let fixture: ComponentFixture<CommonDialogPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonDialogPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
