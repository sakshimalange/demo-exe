import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-patient-info-dialog',
  standalone: true,
  templateUrl: './patient-info-dialog.page.html',
  styles: [`
    .patient-info-dialog {
      min-width: 400px;
      padding: 20px;
    }
    .dialog-title {
      margin: 0 0 16px 0;
      font-size: 20px;
      font-weight: 500;
      color: rgba(0, 0, 0, 0.87);
    }
    .dialog-content {
      margin-bottom: 20px;
    }
    .info-row {
      display: flex;
      margin-bottom: 8px;
    }
    .info-label {
      font-weight: bold;
      width: 120px;
      color: rgba(0, 0, 0, 0.6);
    }
    .info-value {
      color: rgba(0, 0, 0, 0.87);
    }
    .dialog-actions {
      display: flex;
      justify-content: flex-end;
      gap: 8px;
      padding-top: 16px;
    }
    .dialog-actions button {
      padding: 8px 16px;
      border-radius: 4px;
      border: 1px solid #ccc;
      background: white;
      cursor: pointer;
      font-size: 14px;
    }
    .dialog-actions button:last-child {
      background: #1976d2;
      color: white;
      border-color: #1976d2;
    }
  `],
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
  ],
})
export class PatientInfoDialogPage {
  constructor(
    public dialogRef: MatDialogRef<PatientInfoDialogPage>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  onCancel(): void {
    this.dialogRef.close();
  }

  onConfirm(): void {
    console.log('Patient Info Dialog: Confirm clicked, returning patient ID:', this.data.patientid);
    this.dialogRef.close(this.data.patientid);
  }
}
