import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PatientinfoPage } from './patientinfo.page';

describe('PatientinfoPage', () => {
  let component: PatientinfoPage;
  let fixture: ComponentFixture<PatientinfoPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientinfoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
