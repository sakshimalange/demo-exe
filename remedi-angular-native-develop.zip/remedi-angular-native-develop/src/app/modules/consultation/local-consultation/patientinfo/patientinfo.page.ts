// import { IonicModule, ModalController, Platform } from '@ionic/angular';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { Router, RouterModule } from '@angular/router';
// import { Component, OnInit, ChangeDetectorRef, NgZone, Input, HostListener, effect, viewChild } from '@angular/core';
// import {
//   ElementRef,
//   ViewChild,
//   OnDestroy,
//   AfterViewInit,
//   Inject,
// } from '@angular/core';
// import { Observable, Subscription, BehaviorSubject } from 'rxjs';
// import * as Highcharts from 'highcharts/highstock';
// import { WebsocketsService } from 'src/app/core/services/websocket.service';
// import { NullWebsocketService } from 'src/app/core/services/null-websocket.service';
// import { MatTooltipModule } from '@angular/material/tooltip';
// import { PouchdbService } from 'src/app/core/services/pouchdb.service';
// import { SaveSpo2DataRequest, SaveSpo2FileDataRequest } from 'src/app/core/interfaces/prms/spo2-data.model';
// import { ApiService } from 'src/app/core/services/api.service';
// import { ConstantService } from 'src/app/core/services/constant.service';
// import * as CryptoJS from 'crypto-js';
// import { NetworkService } from 'src/app/core/services/network.service';
// import { SidebarPage } from '../sidebar/sidebar.page';
// import { TabsPage } from '../tabs/tabs.page';
// import { FinishConsultationRecord, SuspendRequest } from 'src/app/core/interfaces/pouchdb.model';
// import { AuthService } from 'src/app/core/services/auth.service';
// import { environment } from 'src/environments/environment';
// import { DialogService } from 'src/app/core/services/dialog.service';
// import { CommonDialogPage } from 'src/app/modules/common/common-dialog/common-dialog.page';
// import { MatDialogModule, MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
// import { FinishConsulDialogPage } from '../finish-consul-dialog/finish-consul-dialog.page';

// // import { DialogService } from 'src/app/core/services/dialog.service';
// import { SendToDoctorPage } from 'src/app/modules/doctor-dashboard/send-to-doctor/send-to-doctor.page';
// import * as OT from '@opentok/client';
// import { TokboxService } from 'src/app/core/services/tokbox.service';
// import { DoctorConsultationApiService } from 'src/app/core/services/doctor-consultation-api.service';
// import { ConsultationSyncService } from 'src/app/core/services/consultation-sync.service';
// import { firstValueFrom } from 'rxjs';

// import { ViewconsultationPage } from '../viewconsultation/viewconsultation.page';

// import { StethoscopeDevicePage } from 'src/app/modules/prms/ble-device/stethoscope-device/stethoscope-device.page';
// import { FetalDopplerDevicePage } from 'src/app/modules/prms/ble-device/fetal-doppler-device/fetal-doppler-device.page';
// import { ThermometerPage } from 'src/app/modules/prms/ble-device/thermometer/thermometer.page';
// import { Snackbar } from 'src/app/core/services/snackbar';
// import { MatSnackBar } from '@angular/material/snack-bar';
// import { ViewPatientReadingsPage } from '../view-patient-readings/view-patient-readings.page';
// import { ParametersPage } from '../parameters/parameters.page';
// import { Spo2DevicePage } from 'src/app/modules/prms/ble-device/spo2-device/spo2-device.page';
// import { EcgJettyDevicePage } from 'src/app/modules/prms/ble-device/ecg-jetty-device/ecg-jetty-device.page';
// import { EcgInterpretationManualJettyComponent } from 'src/app/modules/prms/manual_entry/ecg-interpretation-manual-jetty/ecg-interpretation-manual-jetty.component';
// import { EcgInterpretationJettyDeviceComponent } from 'src/app/modules/prms/ble-device/ecg-interpretation-jetty-device/ecg-interpretation-jetty-device.component';
// import { SpirometerJettyDevicePage } from 'src/app/modules/prms/ble-device/spirometer-jetty-device/spirometer-jetty-device.page';


// interface SuspendResponse {
//   status: string;
//   message: string;
// }
// interface ApiResponse {
//   status: string;
//   message?: string;
// }

// @Component({
//   selector: 'app-patientinfo',
//   templateUrl: './patientinfo.page.html',
//   styleUrls: ['./patientinfo.page.scss'],
//   standalone: true,
//   imports: [IonicModule, CommonModule, FormsModule, TabsPage],
// })
// export class PatientinfoPage implements OnInit, OnDestroy {
//   @Input() followUpVal: any;
//   @Input() userType: string = ''; //  Added to identify doctor/nurse

//   @ViewChild('tabsComponent') tabsComponent!: TabsPage;
//   @ViewChild('tabsComponent2') tabsComponent2!: TabsPage;

//   // Follow-up checkbox state
//   isFollowUpChecked: boolean = false;


//   doctorName: string = '';
//   currDomainId: any;
//   tokenRequest: any;
//   username: any;
//   usertype: any;
//   tab: any = "";
//   consultationId: any;
//   patientId: any;
//   domainwisepid: any;
//   language!: string;
//   first_name: any;
//   last_name: any;
//   currUserType = '';

//   consultationStartTime = new Date();
//   reportWindow: any = null;
//   patientData: any = {};
//   patientImageUrl = 'assets/images/Patients.png';
//   isLocalConsultation: boolean = false;
//   timeIntervalStore: undefined;
//   showMoreActions: boolean = false;

//   session!: OT.Session;
//   publisher!: OT.Publisher;

//   // ✅ For Nurse Video Call
//   isNurseVideoActive = false;

//   // ✅ Video state tracking
//   isDoctorVideoActive = false;
//   isPatientVideoActive = false;

//   // ✅ Loader state for Connect to Doctor functionality
//   isConnectingToDoctor = false;
//   isVideoStarted = false;
//   isDoctorInitiated = false; // Flag to track if doctor started the consultation

//   // ✅ Speaking state tracking
//   isPublisherSpeaking = false;
//   isSubscriberSpeaking = false;

//   // ✅ New properties for device activation signaling
//   private signalingSubscription: Subscription | null = null;
//   kitActivated = false; // Tracks if the medical device kit has been activated
//   activeDevices: Set<string> = new Set(); // Tracks which specific devices are currently active

//   // Camera and Microphone selection properties
//   videoDevices: MediaDeviceInfo[] = [];
//   audioDevices: MediaDeviceInfo[] = [];
//   selectedCameraId: string = '';
//   selectedMicId: string = '';
//   showCameraDropdown: boolean = false;
//   showMicDropdown: boolean = false;

//   // Video mute/unmute properties
//   isVideoMuted: boolean = false;

//   // ✅ New properties for mute state tracking
//   isMicMuted: boolean = false;
//   isCameraMuted: boolean = false;

//   // ✅ Flag to prevent multiple clicks on Connect to Doctor button
//   isConnectToDoctorClicked: boolean = false;

//   @ViewChild(ParametersPage, {static: false}) paramsPage!: ParametersPage;
//   constructor(
//     private tokboxService: TokboxService,
//     private modalCtrl: ModalController,
//     private websocketsService: WebsocketsService,
//     private nullWebsocketService: NullWebsocketService,
//     private pouchdbService: PouchdbService,
//     private authService: AuthService,
//     private constantSvc: ConstantService,
//     private apiSvc: ApiService,
//     private networkService: NetworkService,
//     private router: Router,
//     private dialog: MatDialog,
//     private dialogService: DialogService,
//     private docApi: DoctorConsultationApiService,
//     private consultationSyncService: ConsultationSyncService,
//     private snackBar: MatSnackBar,
//     private platform: Platform,
//     private ngZone: NgZone,
//   ) {
//     this.tokboxService.speakingState$.subscribe(state => {
//       this.isDoctorVideoActive = state.publisherSpeaking;
//       this.isPatientVideoActive = state.subscriberSpeaking;
//       this.isPublisherSpeaking = state.publisherSpeaking;
//       this.isSubscriberSpeaking = state.subscriberSpeaking;
//     });
//   }

//   async ngOnInit(): Promise<void> {
//     // Initialize PouchDB databases
//     // this.pouchdbService.initDB('suspend_consultations');
//     // this.pouchdbService.initDB('finishconsultation_data');
//     const flag = localStorage.getItem('isLocalConsultation') === 'true';
//     console.log('Flag from storage:', flag);
//     this.isLocalConsultation = flag;

//     // Initialize mute states from Tokbox publisher if available
//     if (this.tokboxService.getCurrentState().isPublishing) {
//       this.isMicMuted = !this.tokboxService.getCurrentState().isPublishing; // Assuming true means unmuted
//       this.isCameraMuted = !this.tokboxService.getCurrentState().isPublishing; // Assuming true means unmuted
//     }


//     this.currDomainId = Number(localStorage.getItem('domainId'));
//     const loginResponseStr = localStorage.getItem('LOGIN_RESPONSE');

//     const currentSession = this.authService.getCurrentSession();
//     this.tokenRequest = this.authService.getToken() || '';
//     this.username = currentSession?.username || '';
//     this.currDomainId = currentSession?.domainId || '';
//     this.language = currentSession?.language || '';

//     // Patient & consultation info
//     const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
//     this.patientId = patientDetails.patientid || '';
//     this.domainwisepid = patientDetails.domainwisepid || '';
//     this.first_name = patientDetails.first_name || '';
//     this.last_name = patientDetails.last_name || '';
//     this.patientData = patientDetails;
//     this.consultationId = localStorage.getItem('consultationId') || '';

//     // Get login/session info
//     const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
//     this.tokenRequest = loginResponse.token ?? localStorage.getItem('token') ?? '';
//     this.currDomainId = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
//     this.username = loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? '';
//     this.usertype = loginResponse.commondetail?.usertype ?? localStorage.getItem('usertype') ?? '';
//     const usertype = sessionStorage.getItem('USER');
//     // const currentSession = this.authService.getCurrentSession();
//     const userName = currentSession?.username || '';

//     this.patientId = patientDetails.patientid || '';
//     this.first_name = patientDetails.first_name || '';
//     this.last_name = patientDetails.last_name || '';

//     this.patientData = patientDetails;

//     // ✅ Initialize video call only for doctor
//     if (this.userType === 'doctor') {
//       this.initDoctorVideoCall();
//       // Establish WebSocket connection for doctor
//       this.establishDoctorWebSocketConnection();
//     }

//     // ✅ Check if doctor initiated consultation from router state
//     const navigation = this.router.getCurrentNavigation();
//     if (navigation?.extras?.state?.['appointment']) {
//       this.isDoctorInitiated = true;
//       this.isVideoStarted = true;
//       console.log('Doctor initiated consultation detected');
//     }

//     //  Load patient profile image
//     const profile = patientDetails.profile;
//     if (profile?.S3URL) {
//       this.patientImageUrl = profile?.S3URL
//         ? profile.S3URL
//         : profile?.imagepath
//           ? `https://remedi-dev-server-data.s3.ap-south-1.amazonaws.com/${profile.imagepath}.jpg`
//           : 'assets/images/Patients.png';
//     }


//     const usertypeStorage = sessionStorage.getItem('USER');
//     if (usertypeStorage) {
//       try {
//         const userData = JSON.parse(usertypeStorage);
//         this.doctorName = `${userData.honorific} ${userData.name}`;
//       } catch (e) {
//         console.error('Error parsing USER', e);
//         this.doctorName = 'Doctor';
//       }
//     }
//     const loginResponseRaw = localStorage.getItem('LOGIN_RESPONSE');
//     if (loginResponseRaw) {
//       try {
//         const loginResponse = JSON.parse(loginResponseRaw);
//         this.currUserType = loginResponse.usertype || loginResponse.commondetail?.usertype || '';
//         console.log('Current User Type:', this.currUserType);
//       } catch (e) {
//         console.error('Error parsing LOGIN_RESPONSE:', e);
//         this.currUserType = '';
//       }
//     }

//     // Enumerate available video input devices (cameras) and audio input devices (microphones)
//     if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
//       try {
//         const devices = await navigator.mediaDevices.enumerateDevices();
//         this.videoDevices = devices.filter(device => device.kind === 'videoinput');
//         this.audioDevices = devices.filter(device => device.kind === 'audioinput');
//         if (this.videoDevices.length > 0) {
//           this.selectedCameraId = this.videoDevices[0].deviceId;
//         }
//         if (this.audioDevices.length > 0) {
//           this.selectedMicId = this.audioDevices[0].deviceId;
//         }
//       } catch (error) {
//         console.error('Error enumerating devices:', error);
//       }
//     }
//   }

//   confirmDialogSuspend(data: any, checkslot: number) {
//     const dialogRef = this.dialog.open(CommonDialogPage, {
//       width: "auto",
//       height: "auto",
//       data: data,
//       panelClass: "slot-dialog",
//       disableClose: true,
//     });

//     dialogRef.afterClosed().subscribe((result) => {
//       console.log('Dialog closed with result:', result);

//       if (result === "suspend") {
//         console.log('User confirmed suspend → checking online/offline status');

//         // Check if user is online or offline
//         if (this.networkService.isOnline()) {
//           console.log('User is online → following existing process');

//           // Send WebSocket message ONLY after user confirms suspend
//           if (!this.isLocalConsultation) {
//             try {
//               this.nullWebsocketService.sendMessage('SuspendByDoctor');
//               console.log('✅ [DOCTOR] Sent SuspendByDoctor message to nurse after confirmation');
//             } catch (error) {
//               console.error('❌ [ERROR] Failed to send WebSocket message:', error);
//             }
//           }

//           // Follow existing process with API response check
//           this.saveSuspendRequestToPouch();
//         } else {
//           console.log('User is offline → skipping API response check, using localConsultationId');

//           // Get localConsultationId from localStorage
//           const localConsultationId = localStorage.getItem('localConsultationId') || this.consultationId;
//           console.log('Using localConsultationId:', localConsultationId);

//           // Follow existing process without API response check
//           this.saveSuspendRequestToPouchOffline(localConsultationId);
//         }
//       } else if (result === "yes") {
//         console.log('User confirmed YES → different action');
//       } else {
//         console.log('User canceled');
//       }
//     });
//   }


//   suspendConsultationConfirm() {
//     console.log('🔍 [DEBUG] Suspend button clicked');
//     console.log('🔍 [DEBUG] isLocalConsultation:', this.isLocalConsultation);
//     console.log('🔍 [DEBUG] WebSocket connected:', this.nullWebsocketService.getConnectionStatus());

//     // Open confirmation dialog first - WebSocket message will be sent only after confirmation
//     this.confirmDialogSuspend(
//       { data: "suspend-consultation", type: "local", tab: this.tab },
//       0
//     );

//     // Save patient data for suspend action
//     this.patientData = JSON.parse(sessionStorage.getItem("patientDetails") || '{}');
//   }


//   // Save suspend request locally
//   toggleMoreActions(): void {
//     this.showMoreActions = !this.showMoreActions;
//   }

//   saveSuspendRequestToPouch() {
//     this.consultationId = localStorage.getItem('consultationId') || '';
//     const suspendRecord: SuspendRequest = {
//       _id: new Date().toISOString(),
//       action: 'suspendLocalConsultation',
//       username: this.username || '',
//       domain: this.currDomainId || 0,
//       consultationId: parseInt(this.consultationId) || 0,
//       usertype: 'Doctor',
//       token: this.tokenRequest || '',
//       synced: false,
//       forwardto: 'RemediNovaDoctorAPI.do',

//     };
//     this.pouchdbService.initDB('suspend_consultations');


//     this.pouchdbService.addRecord(suspendRecord).subscribe({
//       next: async () => {
//         console.log('Suspend request saved locally to PouchDB');
        
//         // Update consultation state to 'suspend'
//         try {
//           const localConsultationId = localStorage.getItem('localConsultationId') || this.consultationId;
//           await this.consultationSyncService.updateConsultationState(localConsultationId, 'suspend');
//         } catch (error) {
//           console.error('Failed to update consultation state:', error);
//         }
        
//         // Optional: sync immediately if online
//         if (this.networkService.isOnline()) {
//           this.syncUnsyncedSuspendRequests();
//         }
//       },
//       error: (err) => {
//         console.error('Failed to save suspend request:', err);
//       }
//     });
//   }

//   saveSuspendRequestToPouchOffline(localConsultationId: string) {
//     const suspendRecord: SuspendRequest = {
//       _id: new Date().toISOString(),
//       action: 'suspendLocalConsultation',
//       username: this.username || '',
//       domain: this.currDomainId || 0,
//       consultationId: parseInt(localConsultationId) || 0,
//       localConsultationId: localStorage.getItem('localConsultationId') || localConsultationId,
//       usertype: 'Doctor',
//       token: this.tokenRequest || '',
//       synced: false,
//       forwardto: 'RemediNovaDoctorAPI.do',
//     };

//     this.pouchdbService.initDB('suspend_consultations');

//     this.pouchdbService.addRecord(suspendRecord).subscribe({
//       next: async () => {
//         console.log('Offline suspend request saved locally to PouchDB with localConsultationId:', suspendRecord.localConsultationId);

//         // Update consultation state to 'suspend'
//         try {
//           await this.consultationSyncService.updateConsultationState(localConsultationId, 'suspend');
//         } catch (error) {
//           console.error('Failed to update consultation state:', error);
//         }

//         // Clean up and navigate without API call
//         localStorage.removeItem('isLocalConsultation');
//         sessionStorage.removeItem('isLocalConsultation');
//         sessionStorage.removeItem('walkinCon');

//         // Navigate to dashboard immediately
//         this.router.navigate(['/doctor-dashboard']);
//       },
//       error: (err) => {
//         console.error('Failed to save offline suspend request:', err);
//         // Still navigate even if save fails
//         this.router.navigate(['/doctor-dashboard']);
//       }
//     });
//   }


//   syncUnsyncedSuspendRequests() {
//     this.pouchdbService.initDB('suspend_consultations');

//     this.pouchdbService.getAllRecords<SuspendRequest>().subscribe(records => {
//       this.consultationId = localStorage.getItem('consultationId') || '';
//       const unsynced = records.filter(r => !r.synced &&
//         r.consultationId == this.consultationId &&
//         r.action === 'suspendLocalConsultation'
//       );

//       console.log('Unsynced suspend requests:', unsynced);

//       unsynced.forEach(record => {
//         const query = `?action=${record.action}` +
//           `&username=${record.username}` +
//           `&domain=${record.domain}` +
//           `&ConsId=${record.consultationId}` +
//           `&usertype=${record.usertype}` +
//           `&token=${record.token}` +
//           `&language=${this.language}`;

//         this.apiSvc.postServiceByQueryBasic(this.constantSvc.APIConfig.DISPLAYAPPOINTMENTS, query)
//           .subscribe({
//             next: (res: any) => {
//               if (res.status === 'success') {
//                 console.log('Synced suspend request:', record);
//                 localStorage.removeItem('isLocalConsultation');
//                 sessionStorage.removeItem('isLocalConsultation');
//                 sessionStorage.removeItem('walkinCon');
//                 // Mark synced
//                 record.synced = true;
//                 this.pouchdbService.initDB('suspend_consultations');

//                 this.pouchdbService.updateRecord(record).subscribe({
//                   next: () => {
//                     console.log('Updated PouchDB record as synced');
//                   },
//                   error: (err) => console.error(' Failed to update record:', err)
//                 });

//                 // Redirect to dashboard
//                 this.router.navigate(['/doctor-dashboard']);
//               } else {
//                 console.warn(' Failed to sync suspend request:', res);
//               }
//             },
//             error: (err) => {
//               console.error(' Error syncing suspend request:', err);
//             }
//           });
//       });
//     });
//   }

//   finsishConsultationConfirm(ptData?: any) {
//     if (this.timeIntervalStore != undefined) {
//       clearInterval(this.timeIntervalStore);
//     }
//     setTimeout(() => {
//       clearInterval(this.timeIntervalStore);
//     }, 100)

//     sessionStorage.removeItem('walkinCon');
//     this.confirmDialog({ data: 'finish-consultation', followUp: this.followUpVal });

//     this.patientData = ptData;
//   }


//   confirmDialog(data: any) {
//     console.log("data", data);
//     const dialogRef = this.dialog.open(CommonDialogPage, {
//       width: 'auto',
//       height: 'auto',
//       data: { ...data, followUp: this.isFollowUpChecked },
//       panelClass: 'slot-dialog'
//       // position: {top: '10%', right:'10%'}
//     });

//     dialogRef.afterClosed().subscribe(result => {
//       if (result != undefined) {
//         console.log("result----", result)
//         console.log("tab----", this.tab)


//         if (result == 'finish') {


//           if (this.tab == 'walkin' || this.tab == 'review') {
//             if (this.tab == 'walkin') {

//               this.confirmFinishDialog(this.patientData);
//             }
//           } else {

//             this.confirmFinishDialog(this.patientData);
//           }
//         }
//         if (result == 'yes') {
//         } else {

//         }
//       }
//     });
//   }
//   confirmFinishDialog(data?: any) {
//     const dialogRef = this.dialog.open(FinishConsulDialogPage, {
//       width: '400px',
//       height: 'auto',
//       data: data,
//       disableClose: true,
//       panelClass: 'slot-dialog'
//     });

//     dialogRef.afterClosed().subscribe((result: any) => {
//       if (result !== undefined) {
//         console.log('User confirmed finish → checking online/offline status');

//         // Check if user is online or offline
//         if (this.networkService.isOnline()) {
//           console.log('User is online → following existing process');

//           // Send WebSocket message ONLY after user confirms finish
//           if (!this.isLocalConsultation) {
//             try {
//               this.nullWebsocketService.sendMessage('FinishByDoctor');
//               console.log('✅ [DOCTOR] Sent FinishByDoctor message to nurse after confirmation');
//             } catch (error) {
//               console.error('❌ [ERROR] Failed to send WebSocket message:', error);
//             }
//           }

//           this.executeFinishConsultation();
//         } else {
//           console.log('User is offline → skipping API response check, using localConsultationId');

//           // Get localConsultationId from localStorage
//           const localConsultationId = localStorage.getItem('localConsultationId') || this.consultationId;
//           console.log('Using localConsultationId:', localConsultationId);

//           // Follow existing process without API response check
//           this.executeFinishConsultationOffline(localConsultationId);
//         }
//       }
//     });
//   }

//   private executeFinishConsultationOffline(localConsultationId: string): void {
//     const record: FinishConsultationRecord = {
//       _id: new Date().toISOString(),
//       type: 'finish_consultation',
//       action: 'finishconsultation',
//       domain: this.currDomainId,
//       username: this.username,
//       consultationId: parseInt(localConsultationId) || 0,
//       localConsultationId: localStorage.getItem('localConsultationId') || localConsultationId,
//       usertype: 'Doctor',
//       patientId: this.patientId,
//       token: this.tokenRequest,
//       synced: false,
//       forwardto: 'RemediNovaDoctorAPI.do',
//     };

//     this.pouchdbService.initDB('finishconsultation_data');

//     this.pouchdbService.addRecord(record).subscribe({
//       next: async () => {
//         console.log('Offline finish consultation saved locally to PouchDB with localConsultationId:', record.localConsultationId);

//         // Update consultation state to 'finish'
//         try {
//           await this.consultationSyncService.updateConsultationState(localConsultationId, 'finish');
//         } catch (error) {
//           console.error('Failed to update consultation state:', error);
//         }

//         // Always set session storage to know we came from finish consultation
//         sessionStorage.setItem('dialogRef', 'finish');

//         // Clean up and navigate without API call
//         localStorage.removeItem('isLocalConsultation');
//         sessionStorage.removeItem('isLocalConsultation');
//         sessionStorage.removeItem('walkinCon');

//         // Navigate to dashboard and show report
//         this.router.navigate(['/doctor-dashboard']).then(() => {
//           this.viewConsultationReport();
//         });
//       },
//       error: (err) => {
//         console.error('Failed to save offline finish consultation:', err);
//         // Still navigate even if save fails
//         this.router.navigate(['/doctor-dashboard']);
//       }
//     });
//   }

//   private executeFinishConsultation(): void {
//     this.finishConsultation().subscribe({
//       next: (res: any) => {
//         console.log("Consultation finished successfully", res);

//         // Always set session storage to know we came from finish consultation
//         sessionStorage.setItem('dialogRef', 'finish');

//         localStorage.removeItem('isLocalConsultation');
//         sessionStorage.removeItem('isLocalConsultation');
//         sessionStorage.removeItem('walkinCon');

//         // Navigate to doctor dashboard first
//         this.router.navigate(['/doctor-dashboard']).then(() => {
//           // After navigation is done, show the report
//           this.viewConsultationReport();
//         });
//       },
//       error: (err: any) => {
//         console.error("Error finishing consultation", err);
//       }
//     });
//   }




//   finishConsultation(): Observable<any> {
//     return new Observable((observer) => {
//       const record: FinishConsultationRecord = {
//         _id: new Date().toISOString(),
//         type: 'finish_consultation',
//         action: 'finishconsultation',
//         domain: this.currDomainId,
//         username: this.username,
//         consultationId: this.consultationId,
//         usertype: 'Doctor',
//         patientId: this.patientId,
//         token: this.tokenRequest,
//         synced: false,
//         forwardto: 'RemediNovaDoctorAPI.do',

//       };
//       this.pouchdbService.initDB('finishconsultation_data');

//       // Save locally first
//       this.pouchdbService.addRecord(record).subscribe({
//         next: async () => {
//           console.log('Finish consultation saved locally to PouchDB');

//           // Update consultation state to 'finish'
//           try {
//             const localConsultationId = localStorage.getItem('localConsultationId') || this.consultationId;
//             await this.consultationSyncService.updateConsultationState(localConsultationId, 'finish');
//           } catch (error) {
//             console.error('Failed to update consultation state:', error);
//           }

//           // Sync unsynced records and notify when done
//           this.syncUnsyncedFinishConsultations().subscribe({
//             next: (res) => {
//               console.log('Finish consultation synced successfully', res);
//               observer.next(res);
//               observer.complete();
//             },
//             error: (err) => {
//               console.error('Failed to sync finish consultation', err);
//               observer.error(err);
//             }
//           });
//         },
//         error: (err) => {
//           console.error('Failed to save finish consultation locally:', err);
//           observer.error(err);
//         }
//       });
//     });
//   }


//   syncUnsyncedFinishConsultations(): Observable<any> {
//     this.pouchdbService.initDB('finishconsultation_data');

//     return new Observable((observer) => {
//       this.pouchdbService.getAllRecords<FinishConsultationRecord>().subscribe(records => {
//         const unsynced = records.filter(r => r.synced === false && r.type === 'finish_consultation' && r.consultationId === this.consultationId);

//         if (unsynced.length === 0) {
//           console.log('No unsynced records found');
//           observer.next({ status: 'no_records' });
//           observer.complete();
//           return;
//         }

//         let processed = 0;

//         unsynced.forEach(record => {
//           const query = `?action=${record.action}` +
//             `&domain=${record.domain}` +
//             `&username=${record.username}` +
//             `&consultationId=${record.consultationId}` +
//             `&usertype=${record.usertype}` +
//             `&patientId=${record.patientId}` +
//             `&token=${record.token}`;

//           this.apiSvc.postServiceByQueryBasic<ApiResponse>(this.constantSvc.APIConfig.GETCOMMONSERVICES, query)
//             .subscribe({
//               next: (res) => {
//                 if (res.status === 'success') {
//                   console.log('Synced finish consultation record:', record);
//                   record.synced = true;
//                   this.pouchdbService.initDB('finishconsultation_data');

//                   this.pouchdbService.updateRecord(record).subscribe(() => {
//                     processed++;
//                     if (processed === unsynced.length) {
//                       console.log('All records synced successfully');
//                       observer.next(res);
//                       observer.complete();
//                     }
//                   });
//                 } else {
//                   console.warn('Sync failed:', res);
//                   processed++;
//                   if (processed === unsynced.length) {
//                     observer.error(res);
//                   }
//                 }
//               },
//               error: (err) => {
//                 console.error('Error syncing finish consultation:', err);
//                 processed++;
//                 if (processed === unsynced.length) {
//                   observer.error(err);
//                 }
//               }
//             });
//         });
//       });
//     });
//   }


//   viewConsultationReport() {
//     console.log('View consultation report clicked');
//     const consultationnId = localStorage.getItem('consultationId') || '';
//     const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
//     const patienttId = patientDetails.patientid || patientDetails.domainwisepid || '';

//     console.log('Retrieved consultationId from localStorage:', consultationnId);
//     console.log('Retrieved patientId from localStorage:', patienttId);

//     if (!consultationnId) {
//       console.error('No consultation ID found in localStorage');
//       return;
//     }

//     if (!patienttId) {
//       console.error('No patient ID found in localStorage');
//       return;
//     }

//     // Pass data through MatDialog data parameter
//     const dialogRef = this.dialog.open(ViewconsultationPage, {
//       width: '95vw',
//       height: '95vh',
//       maxWidth: '95vw',
//       maxHeight: '95vh',
//       data: {
//         id: consultationnId,        // Pass consultation ID
//         ptId: patienttId,          // Pass patient ID
//         dt: new Date().toISOString() // Pass current datetime
//       },
//       panelClass: 'consultation-report-dialog',
//       disableClose: true
//     });

//     dialogRef.afterClosed().subscribe(result => {
//       console.log('Consultation report dialog closed');
//     });
//   }

//   // viewConsultationReport() {
//   //   console.log('View consultation report clicked');

//   //   const consultationId = localStorage.getItem('consultationId') || '';
//   //   const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
//   //   const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
//   //   const patientId = patientDetails.patientid || patientDetails.domainwisepid || '';

//   //   this.currUserType = loginResponse.usertype || loginResponse.commondetail?.usertype || '';
//   //   this.patientImageUrl = patientDetails.profile?.S3URL
//   //       || (patientDetails.profile?.imagepath ? `https://remedi-dev-server-data.s3.ap-south-1.amazonaws.com/${patientDetails.profile.imagepath}.jpg` : 'assets/images/avtar.png');

//   //   const isCapacitor = !!(window as any).Capacitor;

//   //   if (!isCapacitor) {
//   //     let baseUrl = environment.locationURL;
//   //     const hostname = window.location.hostname;
//   //     if (hostname !== 'localhost' && !baseUrl.includes('/remediprmsang')) {
//   //       baseUrl += '/remediprmsang';
//   //     }

//   //     const reportUrl = `${baseUrl}/consultation-report?id=${consultationId}&ptId=${patientId}`;
//   //     console.log('Generated Report URL:', reportUrl);

//   //     this.reportWindow = window.open(reportUrl, '', "width=1000,height=800,toolbar=no,menubar=no,resizable=yes");

//   //     if (this.reportWindow) {
//   //       (this.reportWindow as any).fromConsult = "viewFull";

//   //       if (patientDetails.startTime) {
//   //         const [h, m, s] = patientDetails.startTime.split(":").map(Number);
//   //         this.consultationStartTime.setHours(h, m, s);
//   //       }

//   //       (this.reportWindow as any).startTime = this.consultationStartTime;

//   //       const interval = setInterval(() => {
//   //         if (this.reportWindow?.closed) {



//   //           sessionStorage.setItem("dialogRef", "");
//   //          // this.router.navigate(['/doctor-dashboard']);
//   //           clearInterval(interval);
//   //         }
//   //       }, 500);
//   //     }
//   //   } else {
//   //     // Mobile app
//   //     this.router.navigate(['/consultation-report'], {
//   //       queryParams: { id: consultationId, ptId: patientId }
//   //     });
//   //   }
//   // }

//   // viewConsultationReport() {
//   //   console.log('View consultation report clicked');

//   //   const consultationId = localStorage.getItem('consultationId') || '';
//   //   const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
//   //   const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
//   //   const patientId = patientDetails.patientid || patientDetails.domainwisepid || '';

//   //   this.currUserType = loginResponse.usertype || loginResponse.commondetail?.usertype || '';
//   //   this.patientImageUrl = patientDetails.profile?.S3URL
//   //     || (patientDetails.profile?.imagepath ? `https://remedi-dev-server-data.s3.ap-south-1.amazonaws.com/${patientDetails.profile.imagepath}.jpg` : 'assets/images/avtar.png');

//   //   const isElectron = this.platform.is('electron') || !!(window as any).require || !!(window as any).electronAPI;
//   //   const isNativeMobile = this.platform.is('capacitor') || this.platform.is('cordova');
//   //   const isMobileDevice = this.platform.is('android') || this.platform.is('ios');
//   //   const isActualMobileApp = isNativeMobile && isMobileDevice;

//   //   console.log('Environment:', {
//   //     isElectron,
//   //     isNativeMobile,
//   //     isMobileDevice,
//   //     isActualMobileApp,
//   //     hasElectronAPI: !!(window as any).electronAPI
//   //   });

//   //   if (!isActualMobileApp) {
//   //     console.log(' Opening in new window');

//   //     // if (isElectron) {
//   //     //   console.log('isElectron Opening in new window');

//   //     //    const route = `/#/consultation-report?id=${consultationId}&ptId=${patientId}&print=true&electron=true`;

//   //     //   console.log('Electron - Opening route:', route);

//   //     //   // window.open will be caught by setWindowOpenHandler in main.js
//   //     //    window.open(`#/${route}`, '_blank');


//   //     // }

//   // if (isElectron) {
//   //   console.log('isElectron Opening in browser');

//   //   let baseUrl = environment.locationURL;
//   //   const hostname = window.location.hostname;

//   //   if (hostname !== 'localhost' && !baseUrl.includes('/remediprmsang')) {
//   //     baseUrl += '/remediprmsang';
//   //   }

//   //   const reportUrl = `${baseUrl}/#/consultation-report?id=${consultationId}&ptId=${patientId}&print=true&electron=true`;

//   //   console.log('Electron - Opening in external browser:', reportUrl);

//   //   // Use electronAPI if available
//   //   if ((window as any).electronAPI?.openExternal) {
//   //     (window as any).electronAPI.openExternal(reportUrl);
//   //   } else {
//   //     console.error('electronAPI.openExternal not available');
//   //     // Fallback to window.open as last resort
//   //     window.open(reportUrl, '_blank');
//   //   }
//   // }
//   //     else {
//   //   // Web Browser - pass auth token in URL
//   //   let baseUrl = environment.locationURL;
//   //   const hostname = window.location.hostname;

//   //   if (hostname !== 'localhost' && !baseUrl.includes('/remediprmsang')) {
//   //     baseUrl += '/remediprmsang';
//   //   }

//   //   // Get auth data from localStorage
//   //   const token = localStorage.getItem('token') || '';
//   //   const loginResponseStr = encodeURIComponent(localStorage.getItem('LOGIN_RESPONSE') || '{}');


//   //    const reportUrl = `${baseUrl}/#/consultation-report?id=${consultationId}&ptId=${patientId}&print=true`;

//   //   console.log('Web Report URL:', reportUrl);


//   //   this.reportWindow =  window.open(
//   //     reportUrl,
//   //     'ConsultationReport',
//   //     "width=1200,height=900,toolbar=yes,menubar=yes,resizable=yes,scrollbars=yes"
//   //   );

//   //   if (this.reportWindow) {
//   //     (this.reportWindow as any).fromConsult = "viewFull";

//   //     if (patientDetails.startTime) {
//   //       const [h, m, s] = patientDetails.startTime.split(":").map(Number);
//   //       this.consultationStartTime.setHours(h, m, s);
//   //     }

//   //     (this.reportWindow as any).startTime = this.consultationStartTime;
//   //     (this.reportWindow as any).patientImageUrl = this.patientImageUrl;
//   //     (this.reportWindow as any).currUserType = this.currUserType;

//   //     this.reportWindow.focus();

//   //     const interval = setInterval(() => {
//   //       if (this.reportWindow?.closed) {
//   //         console.log('Consultation report window closed');
//   //         clearInterval(interval);
//   //       }
//   //     }, 1000);
//   //   } else {
//   //     console.warn('Failed to open new window');
//   //     this.showPopupBlockedAlert();
//   //   }
//   // }
//   //   } else {
//   //     console.log('📱 Opening in mobile app');
//   //     this.openInMobileApp(consultationId, patientId);
//   //   }
//   // }








//   // FIXED viewConsultationReport method
//   viewConsultationReportold() {
//     console.log('View consultation report clicked');
//     const consultationnId = localStorage.getItem('consultationId') || '';
//     const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
//     const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
//     const patienttId = patientDetails.patientid || patientDetails.domainwisepid || '';

//     console.log('Retrieved consultationId from localStorage:', consultationnId);
//     console.log('Retrieved patientId from localStorage:', patienttId);

//     try {
//       this.currUserType = loginResponse.usertype || loginResponse.commondetail?.usertype || '';
//     } catch (e) {
//       this.currUserType = '';
//     }

//     const profile = patientDetails.profile;
//     if (profile?.S3URL) {
//       this.patientImageUrl = profile.S3URL;
//     } else if (profile?.imagepath) {
//       this.patientImageUrl = `https://remedi-dev-server-data.s3.ap-south-1.amazonaws.com/${profile.imagepath}.jpg`;
//     } else {
//       this.patientImageUrl = 'assets/images/avtar.png';
//     }

//     const isCapacitor = !!(window as any).Capacitor;

//     if (!isCapacitor) {
//       let baseUrl = environment.locationURL;
//       const hostname = window.location.hostname;

//       if (hostname !== 'localhost') {
//         if (!baseUrl.includes('/remediprmsang')) {
//           baseUrl += '/remediprmsang';  // Append only if it's not already in the baseUrl
//         }
//       }

//       const reportUrl = `${baseUrl}/consultation-report?id=${consultationnId}&ptId=${patienttId}`;
//       console.log('Generated Report URL:', reportUrl);

//       this.reportWindow = window.open(reportUrl, '', "width=1000,height=800,toolbar=no,menubar=no,resizable=yes");

//       if (this.reportWindow) {
//         this.reportWindow["fromConsult"] = "viewFull";
//         window.focus();

//         let patientDetails;
//         if (localStorage.getItem("patientDetails")) {
//           patientDetails = JSON.parse(localStorage.getItem("patientDetails") || '{}');
//         }

//         if (patientDetails) {
//           if (patientDetails.startTime) {
//             this.consultationStartTime.setHours(patientDetails.startTime.split(":")[0]);
//             this.consultationStartTime.setMinutes(patientDetails.startTime.split(":")[1]);
//             this.consultationStartTime.setSeconds(patientDetails.startTime.split(":")[2]);
//             this.reportWindow.startTime = this.consultationStartTime;
//           } else {
//             this.reportWindow.startTime = this.consultationStartTime;
//           }
//         } else {
//           this.reportWindow.startTime = this.consultationStartTime;
//         }

//         console.log("this.consultationStartTime", this.patientData, this.consultationStartTime);
//         window.focus();

//         var interval = setInterval(() => {
//           console.log("this.reportWindow", this.reportWindow);

//           if (this.reportWindow.closed) {
//             sessionStorage.setItem("dialogRef", "  ");
//             console.log("reference url", this.reportWindow);
//             // this.router.navigate(['/doctor-dashboard']);
//             clearInterval(interval);
//           }
//         }, 100);
//       }
//     } else {
//       console.log("test mobile");

//       // MOBILE APP - Navigate to route
//       this.router.navigate(['/consultation-report'], {
//         queryParams: {
//           id: consultationnId,
//           ptId: patienttId
//         }
//       });
//     }
//   }
//   async sendToDoc() {
//     const dialogRef = this.dialog.open(SendToDoctorPage, {
//       width: "600px",
//       height: "auto",
//       disableClose: true,
//       // panelClass: 'slot-dialog'
//     });
//   }

//   //  Doctor video call logic - Fixed container IDs and removed full-screen settings
//   private async initDoctorVideoCall(): Promise<void> {
//     try {
//       const tokSession = await this.tokboxService.getTokBoxSession(this.consultationId, this.username);

//       this.session = OT.initSession(tokSession.API_KEY, tokSession.SESSION_ID);

//       //  Use correct publisher container ID and remove fixed width/height to prevent full-screen
//       this.publisher = OT.initPublisher('publisher-container', {
//         insertMode: 'append',
//         // Removed width and height to allow CSS control
//       });

//       this.session.on('streamCreated', (event) => {
//         //  Use correct subscriber container ID for doctor
//         this.session.subscribe(event.stream, 'subscriber-container', {
//           insertMode: 'append',
//           // Removed width and height to allow CSS control
//         });
//         //  Set video active state when stream is received (patient's video for doctor)
//         this.isPatientVideoActive = true;
//       });

//       this.session.connect(tokSession.TOKEN, (err) => {
//         if (!err) {
//           this.session.publish(this.publisher);
//           //  Set publishing state (doctor's video publishing)
//           this.isDoctorVideoActive = true;
//         } else {
//           console.error('TokBox connection failed:', err);
//         }
//       });
//     } catch (error) {
//       console.error('Error initializing doctor video call:', error);
//     }
//   }

//   //  Nurse video call logic - Fixed to remove full-screen settings
//   async startNurseVideoCall(): Promise<void> {
//     if (this.userType !== 'nurse') return;
//     try {
//       const tokSession = await this.tokboxService.getTokBoxSession(this.consultationId, this.username);
//       this.session = OT.initSession(tokSession.API_KEY, tokSession.SESSION_ID);

//       this.publisher = OT.initPublisher('publisher-container', {
//         insertMode: 'append',
//         width: '100%',
//         height: '100%',
//       });

//       this.session.on('streamCreated', (event) => {
//         this.session.subscribe(event.stream, 'subscriber-container', {
//           insertMode: 'append',
//           width: '100%',
//           height: '100%',
//         });
//       });

//       this.session.connect(tokSession.TOKEN, (error) => {
//         if (!error) {
//           this.session.publish(this.publisher);
//           this.isNurseVideoActive = true;
//         } else {
//           console.error('Error connecting nurse session:', error);
//         }
//       });
//     } catch (error) {
//       console.error('Error initializing nurse session:', error);
//     }
//   }


//   async onConnectToDoctor(): Promise<void> {
//     // Prevent multiple clicks
//     if (this.isConnectToDoctorClicked) {
//       console.log('Connect to Doctor already clicked, ignoring subsequent clicks');
//       return;
//     }

//     try {
//       // Set flag to prevent multiple clicks
//       this.isConnectToDoctorClicked = true;

//       // Show loader immediately when Connect to Doctor is clicked
//       this.isConnectingToDoctor = true;
//       this.isVideoStarted = false;

//       const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
//       const domainName: string = loginResponse?.commondetail?.domainname || loginResponse?.profiledetail?.domainname || 's3test2';
//       const token: string = loginResponse?.token || localStorage.getItem('token') || '';
//       const nurseUsername: string = loginResponse?.profiledetail?.userName || localStorage.getItem('userName') || '';

//       // Call InitiateConsultation API first
//       await firstValueFrom(this.docApi.initiateConsultationAsNurse({
//         forwardto: 'AndroidRemoteConsultaionWPSevices.do',
//         action: 'InitiateConsultation',
//         domain: domainName,
//         offset: '5:30',
//         userType: 'Nurse',
//         consType: 'remote',
//         consultationId: this.consultationId,
//         userName: nurseUsername,
//         token
//       }));

//       // First call checkDoctorStatus API
//       await firstValueFrom(this.docApi.checkDoctorStatusAsNurse({
//         forwardto: 'AndroidRemoteConsultaionWPSevices.do',
//         action: 'checkDoctorStatus',
//         domain: domainName,
//         offset: '5:30',
//         consultationId: this.consultationId,
//         userName: nurseUsername,
//         token
//       }));

//       // Switch to remote consultation mode to show video containers
//       this.isLocalConsultation = false;
//       localStorage.setItem('isLocalConsultation', 'false');
//       sessionStorage.setItem('isLocalConsultation', 'false');


//       // Establish WebSocket connection for nurse-doctor communication (non-blocking)
//       this.establishNurseWebSocketConnection();


//       // 1) Start consultation (nurse)
//       await firstValueFrom(this.docApi.startConsultationAsNurse({
//         forwardto: 'AndroidRemoteConsultaionWPSevices.do',
//         action: 'Startconsultaion',
//         domain: domainName,
//         consultationId: this.consultationId,
//         userName: nurseUsername,
//         token
//       }));

//       // 2) Fetch WebRTC credentials
//       const webrtcRes = await firstValueFrom(this.docApi.getWebRtcCredentials({
//         consId: this.consultationId,
//         token
//       }));

//       const status = webrtcRes?.status ?? webrtcRes?.STATUS;
//       if (status !== 'success') {
//         throw new Error(webrtcRes?.message || webrtcRes?.msg || 'Failed to get WebRTC credentials');
//       }

//       const creds = {
//         API_KEY: webrtcRes['API_KEY'] ?? webrtcRes?.data?.['API_KEY'],
//         SESSION_ID: webrtcRes['SESSION_ID'] ?? webrtcRes?.data?.['SESSION_ID'],
//         TOKEN: webrtcRes['TOKEN'] ?? webrtcRes?.data?.['TOKEN'],
//       };
//       if (!creds.API_KEY || !creds.SESSION_ID || !creds.TOKEN) {
//         throw new Error('Incomplete WebRTC credentials');
//       }

//       // 3) Initialize TokBox as nurse
//       await this.tokboxService.initializeSession({
//         API_KEY: creds.API_KEY,
//         SESSION_ID: creds.SESSION_ID,
//         TOKEN: creds.TOKEN,
//         STATUS: status || ''
//       }, 'nurse');

//       // 4) Publish to nurse container
//       await this.tokboxService.startPublishing('nurse', 'publisher-container');
//       this.isNurseVideoActive = true;

//       // Hide loader and show video section when video successfully starts
//       this.isConnectingToDoctor = false;
//       this.isVideoStarted = true;

//     } catch (err) {
//       console.error('Connect to Doctor failed:', err);
//       // Hide loader on error
//       this.isConnectingToDoctor = false;
//       this.isVideoStarted = false;
//       // Reset flag on error to allow retry
//       this.isConnectToDoctorClicked = false;
//     }
//   }

//   endNurseVideoCall(): void {
//     if (this.session) {
//       this.session.disconnect();
//       this.isNurseVideoActive = false;
//     }

//     // Reset video states
//     this.isVideoStarted = false;
//     this.isConnectingToDoctor = false;

//     // Also disconnect WebSocket when ending video call
//     this.disconnectNurseWebSocket();

//   }

//   // ==================================================================================
//   // NULLWEBSOCKET COMMUNICATION SYSTEM - NURSE SIDE
//   // ==================================================================================
//   // Purpose: Receive and respond to doctor control commands during video consultation
//   // Architecture: Nurse stays on patientinfo page during video consultation
//   // Communication: Single nullwebsocket connection for bidirectional messaging
//   // Pattern: Matches old application - nurse responds to doctor commands
//   // ==================================================================================

//   private isVideoConsultationActive = false;            // Flag to enable/disable doctor control response
//   private isDoctorControllingNurse = false;             // Flag indicating if doctor is actively controlling

//   // Removed individual dialog ref - now using deviceDialogRefs mapping


//   // ==================================================================================


//   /**
//    * ==================================================================================
//    * NULLWEBSOCKET CONNECTION ESTABLISHMENT - NURSE SIDE
//    * ==================================================================================
//    * Purpose: Establish single nullwebsocket connection for nurse-doctor communication
//    * Timing: Runs parallel to video consultation setup (non-blocking)
//    * URL Pattern: wss://domain/consultationserverendpoint/room{consultationId}/null
//    * Initial Message: "loggedin" (matches old application pattern)
//    * Safety: Only runs for remote consultations, skips local consultations
//    * ==================================================================================
//    */
//   private establishNurseWebSocketConnection(): void {
//     // Safety check: Only establish nullwebsocket for remote consultations
//     if (this.isLocalConsultation) {
//       console.log(' [NURSE] Skipping nullwebsocket connection for local consultation');
//       return;
//     }

//     // Run WebSocket connection asynchronously to avoid blocking video setup
//     // Small delay ensures TokBox video initialization starts first
//     setTimeout(async () => {
//       try {
//         console.log(`🔌 [NURSE] Establishing nullwebsocket connection for consultation ${this.consultationId}`);
//         const socketUrl = `wss://s3test2.remedi.co.in/RemediPRMS/consultationserverendpoint/room${this.consultationId}/null`;

//         // Create nullwebsocket connection using NullWebsocketService
//         const connected = await this.nullWebsocketService.connect(this.consultationId);

//         if (connected) {
//           // Subscribe to incoming messages
//           this.nullWebsocketService.messages$.subscribe(message => {
//             console.log('📨 [NURSE] Received nullwebsocket message:', message);
//             this.handleNullWebSocketMessage(message);
//           });
//           console.log(' [NURSE] Nullwebsocket connection established successfully');
//         }

//       } catch (error) {
//         console.warn(' [NURSE] Nullwebsocket connection failed (non-blocking):', error);
//         // Don't throw error - video consultation should continue even if nullwebsocket fails
//       }
//     }, 100); // Small delay to ensure video setup starts first
//   }


//   // Send message via nullwebsocket to doctor
//   private sendNullWebSocketMessage(message: string): void {
//     try {
//       this.nullWebsocketService.sendMessage(message);
//       console.log(`📤 Nurse sent nullwebsocket message: ${message}`);
//     } catch (error) {
//       // Silent error handling for nullwebsocket messages
//     }
//   }

//   // Handle incoming nullwebsocket messages from doctor
//   private handleNullWebSocketMessage(message: any): void {
//     try {
//       // Parse message if it's a JSON string
//       let parsedMessage = message;
//       if (typeof message === 'string') {
//         try {
//           parsedMessage = JSON.parse(message);
//         } catch {
//           // If not JSON, treat as plain string
//           parsedMessage = { message: message };
//         }
//       }

//       // Handle doctor's "loggedin" message
//       if (parsedMessage?.message === 'loggedin' || message === 'loggedin') {
//         this.sendNullWebSocketMessage('loggedinsuccess');
//         this.showDoctorConnectedFeedback();
//         this.isVideoConsultationActive = true;
//       }

//       // Handle doctor control messages during video consultation
//       else if (this.isVideoConsultationActive && !this.isLocalConsultation) {
//         this.handleDoctorControlMessage(parsedMessage);
//       }

//     } catch (error) {
//       // Silent error handling for nullwebsocket messages
//     }
//   }

//   // Device configuration for nurse-side handling
//   private nurseDeviceConfig: { [key: string]: { component: any; dialogConfig: any; activationMethod?: string } } = {
//     'stethoscope': {
//       component: StethoscopeDevicePage,
//       dialogConfig: {
//         width: "95vw", height: "95vh", maxWidth: "1400px", maxHeight: "900px",
//         minWidth: "800px", minHeight: "600px", panelClass: 'stethoscope-dialog-panel'
//       },
//       activationMethod: 'activateStethoscope'
//     },
//     'fetaldopler': {
//       component: FetalDopplerDevicePage,
//       dialogConfig: {
//         width: "95vw", height: "95vh", maxWidth: "1400px", maxHeight: "900px",
//         minWidth: "800px", minHeight: "600px", panelClass: 'fetal-doppler-dialog-panel'
//       },
//       activationMethod: 'activateFetalDoppler'
//     },
//     'temperature': {
//       component: ThermometerPage,
//       dialogConfig: {
//         width: "1000px", height: "480px", maxWidth: "1000px", maxHeight: "480px",
//         panelClass: 'spo2-dialog-panel'
//       },
//       activationMethod: 'activateTemperature'
//     } ,
//       'spo2': {
//       component: Spo2DevicePage,
//       dialogConfig: {
//         width: "1000px", height: "480px", maxWidth: "1000px", maxHeight: "480px",
//         panelClass: 'spo2-dialog-panel'
//       },
//       activationMethod: 'activatespo2'
//     },
//     'electrocardiogram': {
//           component: EcgJettyDevicePage,
//           dialogConfig: {
//             panelClass: 'ecg-dialog-panel'
//           },
//         activationMethod: 'activateelectrocardiogram'
//     },
//      'mecginterpretation': {
//           component: EcgInterpretationManualJettyComponent,
//           dialogConfig: {
//             panelClass: 'ecg-dialog-panel'
//           },
//         activationMethod: 'activatemecginterpretation'
//     },
//      'pecginterpretation': {
//           component: EcgInterpretationJettyDeviceComponent,
//           dialogConfig: {
//             panelClass: 'ecg-dialog-panel'
//           },
//         activationMethod: 'activatepecginterpretation'
//     },
//     'spirometer': { 
//       component: SpirometerJettyDevicePage,
//       dialogConfig: {
//         width: '1000px',
//         maxWidth: '1000px',
//         height: 'auto',
//         panelClass: 'custom-spiro-dialog'
//       },
//       activationMethod: 'activateSpirometer'
//     },
//     // Add other devices here as needed
//   };

//   private deviceDialogRefs: { [key: string]: MatDialogRef<any> | null } = {};

//   /**
//    * ==================================================================================
//    * HANDLE DOCTOR CONTROL MESSAGES - Nurse response to doctor commands
//    * ==================================================================================
//    * Purpose: Process doctor control commands and perform corresponding actions
//    * Pattern: Matches old application - nurse automatically responds to doctor
//    * Safety: Only processes messages when video consultation is active
//    * Actions: UI changes, device activation, automatic responses
//    * ==================================================================================
//    */
//   // Process doctor control commands and perform corresponding actions
//   private handleDoctorControlMessage(message: any): void {
//     const messageText = message?.message || message;
//     console.log('🤖 [NURSE] Processing doctor control message:', messageText);
//     // Only process messages if user is nurse
//     if (this.usertype !== 'Nurse') {
//       return;
//     }

//     // Handle kit control messages
//     if (messageText === 'Kit_Start') {
//       this.handleKitStart();
//       this.sendNullWebSocketMessage('connectedBle');
//       this.sendNullWebSocketMessage('kitstatus_1001');
//     } else if (messageText === 'Kit_Stop') {
//       this.handleKitStop();
//     }
//     // Handle device-specific messages
//     else if (messageText.startsWith('ble_')) {
//       this.handleDeviceMessage(messageText);
//     }
//     else if (messageText == 'open_spo2_manual'){
//       this.paramsPage.openPulseOximeterManual()
//     }
//     else if(messageText == 'open_Bp_manual'){
//       this.paramsPage.openBloodPressureComponent();
//     }
//      else if(messageText == 'open_spiro_manual'){
//       this.paramsPage.openSpirometerManualComponent();
//     }
//     else if(messageText == 'open_temp_manual'){
//     // Handle other messages
//     this.paramsPage.openTemperatureManualComponent();
//   }
//     else {
//       this.handleOtherMessages(messageText);
//     }
//   }

//   // Handle kit activation from doctor
//   private handleKitStart(): void {
//     this.isDoctorControllingNurse = true;
//     this.showParametersTab();
//     this.sendNullWebSocketMessage('ble_msgFromBLEApplet_true_Dongle connected successfully._2');
//   }

//   // Handle kit deactivation from doctor
//   private handleKitStop(): void {
//     this.hideParametersTab();
//     this.isDoctorControllingNurse = false;
//     this.sendNullWebSocketMessage('error_stop scan status');
//   }

//   // Process device-specific messages from doctor
//   private handleDeviceMessage(messageText: string): void {
//     console.log(`🩺🩺🩺🩺 [NURSE] Handling device message from doctor: ${messageText}`);
//     const deviceType = this.extractDeviceType(messageText);

//     if (messageText.includes('_start')) {
//       this.openDeviceDialog(deviceType);
//     } else if (messageText === 'ble_close') {
//       this.closeAllDeviceDialogs();
//     } else if (messageText.includes('enable') && messageText.includes('ble')) {
//       this.handleDeviceEnable(deviceType, messageText);
//     }
//   }

//   // Handle non-device messages from doctor
//   private handleOtherMessages(messageText: string): void {
//     switch (messageText) {
//       case 'ble_msgFromBLEApplet_true_Dongle connected successfully._2':
//         // Doctor sent dongle connection message - parameters tab will be active
//         break;
//       case 'SuspendByDoctor':
//         this.handleDoctorSuspend();
//         break;
//       case 'FinishByDoctor':
//         this.handleDoctorFinish();
//         break;
//     }
//   }

//   // Handle doctor suspend - redirect nurse to dashboard
//   private handleDoctorSuspend(): void {
//     try {
//       // Clean up video consultation
//       this.endNurseVideoCall();
//       this.disconnectNurseWebSocket();

//       // Clear consultation data
//       localStorage.removeItem('isLocalConsultation');
//       sessionStorage.removeItem('isLocalConsultation');
//       sessionStorage.removeItem('walkinCon');
//       localStorage.removeItem('consultationId');
//       sessionStorage.removeItem('consultationId');

//       // Use NgZone for Electron compatibility
//       this.ngZone.run(() => {
//         this.router.navigate(['/doctor-dashboard']);
//       });
//     } catch (error) {
//       // Still redirect even if cleanup fails
//       this.router.navigate(['/doctor-dashboard']);
//     }
//   }

//   // Handle doctor finish - redirect nurse to dashboard
//   private handleDoctorFinish(): void {
//     try {
//       // Clean up video consultation
//       this.endNurseVideoCall();
//       this.disconnectNurseWebSocket();

//       // Clear consultation data
//       localStorage.removeItem('isLocalConsultation');
//       sessionStorage.removeItem('isLocalConsultation');
//       sessionStorage.removeItem('walkinCon');
//       localStorage.removeItem('consultationId');
//       sessionStorage.removeItem('consultationId');
//       sessionStorage.setItem('dialogRef', 'finish');

//       // Use NgZone for Electron compatibility
//       this.ngZone.run(() => {
//         this.router.navigate(['/doctor-dashboard']);
//       });
//     } catch (error) {
//       // Silent error handling - still redirect
//       // Still redirect even if cleanup fails
//       this.router.navigate(['/doctor-dashboard']);
//     }
//   }

//   /**
//    * 🔍 EXTRACT DEVICE TYPE - Extract device type from message
//    */
//   private extractDeviceType(messageText: string): string {
//     if (messageText.includes('stetho')) return 'stethoscope';
//     if (messageText.includes('fetalDopler') || messageText.includes('fetal')) return 'fetaldopler';
//     if (messageText.includes('mecginterpretation')) return 'mecginterpretation';
//     if (messageText.includes('pecginterpretation')) return 'pecginterpretation';
//     if (messageText.includes('ecg')) return 'electrocardiogram';
//     if (messageText.includes('spo2')) return 'spo2';
//     if (messageText.includes('temp')) return 'temperature';
//     if (messageText.includes('bp')) return 'bloodpressure';
//     if (messageText.includes('hb')) return 'hemoglobin';
//     if (messageText.includes('glucose')) return 'glucose';
//     if (messageText.includes('spiro')) return 'spirometer';

//     return 'unknown';
//   }

//   /**
//    * 🎛️ HANDLE DEVICE ENABLE - Handle device enable messages
//    */
//   private handleDeviceEnable(deviceType: string, messageText: string): void {
//     console.log(`🩺 [NURSE] Doctor enabled ${deviceType} - activating device and opening parameters tab`);
//     this.isDoctorControllingNurse = true;
//     this.showParametersTab();

//     // Activate device if activation method exists
//     const config = this.nurseDeviceConfig[deviceType];
//     if (config?.activationMethod && typeof (this as any)[config.activationMethod] === 'function') {
//       (this as any)[config.activationMethod]();
//     }

//     // Send confirmation response
//     this.sendNullWebSocketMessage(messageText);
//   }

//   // ==================================================================================
//   // NURSE UI CONTROL METHODS - Automatic UI changes based on doctor commands
//   // ==================================================================================
//   // Purpose: Automatically control nurse-side UI based on doctor's actions
//   // Pattern: Doctor controls nurse dashboard remotely via nullwebsocket
//   // Safety: Only works during video consultation, preserves local consultation flow
//   // Methods: showParametersTab, hideParametersTab, activateStethoscope, startStethoscopeRecording
//   // ==================================================================================


//   private showParametersTab(): void {
//     try {
//       if (this.usertype !== 'Nurse') {
//         console.log('⚠️ [NURSE] Cannot show parameters tab - user is not nurse');
//         return;
//       }

//       console.log('🔧 [NURSE] Attempting to show parameters tab using multiple strategies...');

//       // Use NgZone to ensure DOM manipulation works in Electron
//       this.ngZone.runOutsideAngular(() => {
//         // Strategy 1: Direct DOM button click (most reliable for Electron)
//         setTimeout(() => {
//           const parametersButton = document.querySelector('button[role="tab"]:nth-child(4)') as HTMLElement;
//           if (parametersButton && parametersButton.textContent?.includes('Parameters')) {
//             parametersButton.click();
//             console.log('✅ [NURSE] Parameters tab activated via direct DOM click (Strategy 1)');
//             return;
//           }

//           // Strategy 2: Find button by text content
//           const buttons = document.querySelectorAll('button[role="tab"]');
//           for (let i = 0; i < buttons.length; i++) {
//             const button = buttons[i];
//             if (button.textContent?.includes('Parameters')) {
//               (button as HTMLElement).click();
//               console.log('✅ [NURSE] Parameters tab activated via text search (Strategy 2)');
//               return;
//             }
//           }

//           // Strategy 3: Use tabs component if available
//           if (this.tabsComponent) {
//             this.tabsComponent.switchTab('parameters');
//             console.log('✅ [NURSE] Parameters tab activated via tabs component (Strategy 3)');
//             return;
//           }

//           // Strategy 4: Trigger click event programmatically
//           const clickEvent = new MouseEvent('click', {
//             view: window,
//             bubbles: true,
//             cancelable: true
//           });

//           const paramButton = document.querySelector('button[onclick*="parameters"]') as HTMLElement;
//           if (paramButton) {
//             paramButton.dispatchEvent(clickEvent);
//             console.log('✅ [NURSE] Parameters tab activated via event dispatch (Strategy 4)');
//             return;
//           }

//           console.error('❌ [NURSE] All strategies failed to open parameters tab');
//         }, 100); // Small delay to ensure DOM is ready
//       }); // Close NgZone.runOutsideAngular

//     } catch (error) {
//       console.error('❌ [NURSE] Error showing parameters tab:', error);
//     }
//   }

//   /**
//    * Hide parameters tab when doctor stops kit
//    * Switches back to a default tab (patient history) using multiple strategies
//    */
//   private hideParametersTab(): void {
//     try {
//       if (this.usertype !== 'Nurse') {
//         console.log('⚠️ [NURSE] Cannot hide parameters tab - user is not nurse');
//         return;
//       }

//       console.log('🛑 [NURSE] Attempting to hide parameters tab and switch to patient history...');

//       // Use NgZone to ensure DOM manipulation works in Electron
//       this.ngZone.runOutsideAngular(() => {
//         // Strategy 1: Direct DOM button click for Patient History (first button)
//         setTimeout(() => {
//           const patientHistoryButton = document.querySelector('button[role="tab"]:first-child') as HTMLElement;
//           if (patientHistoryButton && patientHistoryButton.textContent?.includes('Patient')) {
//             patientHistoryButton.click();
//             console.log('✅ [NURSE] Switched to patient history via direct DOM click (Strategy 1)');
//             return;
//           }

//           // Strategy 2: Find button by text content
//           const buttons = document.querySelectorAll('button[role="tab"]');
//           for (let i = 0; i < buttons.length; i++) {
//             const button = buttons[i];
//             if (button.textContent?.includes('Patient History')) {
//               (button as HTMLElement).click();
//               console.log('✅ [NURSE] Switched to patient history via text search (Strategy 2)');
//               return;
//             }
//           }

//           // Strategy 3: Use tabs component if available
//           if (this.tabsComponent) {
//             this.tabsComponent.switchTab('patientHistory');
//             console.log('✅ [NURSE] Switched to patient history via tabs component (Strategy 3)');
//             return;
//           }

//           // Strategy 4: Trigger click event programmatically
//           const clickEvent = new MouseEvent('click', {
//             view: window,
//             bubbles: true,
//             cancelable: true
//           });

//           const historyButton = document.querySelector('button[onclick*="patientHistory"]') as HTMLElement;
//           if (historyButton) {
//             historyButton.dispatchEvent(clickEvent);
//             console.log('✅ [NURSE] Switched to patient history via event dispatch (Strategy 4)');
//             return;
//           }

//           console.error('❌ [NURSE] All strategies failed to switch to patient history tab');
//         }, 100); // Small delay to ensure DOM is ready
//       }); // Close NgZone.runOutsideAngular

//     } catch (error) {
//       console.error('❌ [NURSE] Error hiding parameters tab:', error);
//     }
//   }




//   /**
//    * 🩺 REUSABLE BLE DEVICE OPENER - Works for all BLE medical devices
//    * Handles BLE scanning, connection detection, and dialog opening
//    */
//   private async openBleDevicePage(deviceType: string, scanCode: string, connectionMessages: string[], sensorMessages: string[]): Promise<void> {
//     console.log(`[NURSE] ${deviceType} device triggered!`);
//     this.websocketsService.sendBleMessage(`startScanFromHtml~${scanCode}`);

//     try {
//       const deviceSubscription = this.websocketsService.bleValueObs$.subscribe((data) => {
//         console.log(`[NURSE] Received ${deviceType} BLE data:`, data);

//         if (data === "errorLableUpdate~start scan status : Success!") {
//           console.log(`[NURSE] ${deviceType} scan started successfully`);
//         } else if (connectionMessages.some(msg => data === msg || data.includes(msg))) {
//           console.log(`[NURSE] ${deviceType} sensor connected`);
//         } else if (sensorMessages.some(msg => data === msg || data.includes(msg))) {
//           console.log(`[NURSE] Opening ${deviceType} dialog`);

//           deviceSubscription.unsubscribe();

//           const config = this.nurseDeviceConfig[deviceType.toLowerCase()];
//           if (!config) {
//             console.error(`[NURSE] No configuration found for ${deviceType}`);
//             return;
//           }

//           const dialogRef = this.dialog.open(config.component, {
//             ...config.dialogConfig,
//             disableClose: true,
//             data: { api: "withoutApiCalling" }
//           });

//           dialogRef.afterClosed().subscribe((result) => {
//             console.log(`[NURSE] ${deviceType} dialog closed`);
//             this.websocketsService.sendBleMessage("ble_close");
//             if (result !== undefined) {
//               console.log(`[NURSE] ${deviceType} result:`, result);
//             }
//           });
//         }
//       });
//     } catch (error) {
//       console.error(`[NURSE] Error in open${deviceType}DevicePage:`, error);
//     }
//   }

//   /**
//    * Open Fetal Doppler Device Page - Uses reusable BLE opener
//    */
//   async openFetalDopplerDevicePage() {
//     // Send nullwebsocket messages for video consultation
//     // if (!this.isLocalConsultation) {
//     //   this.sendNullWebSocketMessage('connectedBle');
//     //   this.sendNullWebSocketMessage('kitstatus_1001');
//     // }

//     await this.openBleDevicePage(
//       'FetalDoppler',
//       '70',
//       ['errorLableUpdate~FETAL Doppler connected successfully.', 'errorLableUpdate~FETALDoppler connected successfully.'],
//       ['SensorConnected~FETALDoppler~70', 'FetalDopplerConnected', 'SensorConnected~FetalDoppler~70']
//     );
//   }

//   /**
//    * Open Temperature Device Page - Uses reusable BLE opener
//    */
//   async openTemperatureDevicePage() {
//     // Send nullwebsocket messages for video consultation
//     // if (!this.isLocalConsultation) {
//     //   this.sendNullWebSocketMessage('connectedBle');
//     //   this.sendNullWebSocketMessage('kitstatus_1001');
//     // }

//     await this.openBleDevicePage(
//       'Temperature',
//       '40',
//       ['errorLableUpdate~Temperature connected successfully.', 'TemperatureConnected'],
//       ['SensorConnected~Temperature~71', 'SensorConnected~Temperature~40']
//     );
//   }

//      async openECGDevicePage() {
//      await this.openBleDevicePage(
//       'Electrocardiogram',
//       '10',
//       ['errorLableUpdate~Electrocardiogram connected successfully.', 'ElectrocardiogramConnected'],
//       ['SensorConnected~Electrocardiogram~10', 'SensorConnected~Electrocardiogram']
//     );
//   }

//      async openMECGIPage() {
//      await this.openBleDevicePage(
//       'mecginterpretation',
//       '102',
//       ['errorLableUpdate~Electrocardiogram connected successfully.', 'ElectrocardiogramConnected'],
//       ['SensorConnected~Electrocardiogram~102', 'SensorConnected~Electrocardiogram']
//     );
//   }

//     async openPECGIPage() {
//      await this.openBleDevicePage(
//       'pecginterpretation',
//       '102',
//       ['errorLableUpdate~Electrocardiogram connected successfully.', 'ElectrocardiogramConnected'],
//       ['SensorConnected~Electrocardiogram~102', 'SensorConnected~Electrocardiogram']
//     );
//   }


//   /**
//    * 🎵 REUSABLE DEVICE DIALOG OPENER - Works for all medical devices
//    * Opens device-specific dialog on nurse side for doctor control
//    */
//   private openDeviceDialog(deviceType: string): void {
//     try {
//       if (this.usertype !== 'Nurse') {
//         console.log(`⚠️ [NURSE] Cannot open ${deviceType} dialog - user is not nurse`);
//         return;
//       }

//       if (this.deviceDialogRefs[deviceType]) {
//         console.log(`⚠️ [NURSE] ${deviceType} dialog already open`);
//         return;
//       }

//       const config = this.nurseDeviceConfig[deviceType];
//       if (!config) {
//         console.warn(`⚠️ [NURSE] No configuration found for device: ${deviceType}`);
//         return;
//       }

//       console.log(`🎵 [NURSE] Opening ${deviceType} dialog for doctor control`);

//       // Send nullwebsocket messages for video consultation
//       // if (!this.isLocalConsultation) {
//       //   this.sendNullWebSocketMessage('connectedBle');
//       //   this.sendNullWebSocketMessage('kitstatus_1001');
//       // }

//       // Open device dialog
//       this.deviceDialogRefs[deviceType] = this.dialog.open(config.component, {
//         ...config.dialogConfig,
//         disableClose: true,
//         data: { api: "withoutApiCalling" }
//       });

//       // Handle dialog close
//       this.deviceDialogRefs[deviceType]!.afterClosed().subscribe((result) => {
//         console.log(`🔒 [NURSE] ${deviceType} dialog closed`);
//         this.deviceDialogRefs[deviceType] = null;
//         // Send close confirmation to doctor
//         this.sendNullWebSocketMessage('ble_close');
//       });

//       console.log(`✅ [NURSE] ${deviceType} dialog opened successfully`);

//     } catch (error) {
//       console.error(`❌ [NURSE] Error opening ${deviceType} dialog:`, error);
//     }
//   }

//   /**
//    * 🔒 REUSABLE DEVICE DIALOG CLOSER - Works for all medical devices
//    * Closes specific device dialog on nurse side
//    */
//   private closeDeviceDialog(deviceType: string): void {
//     try {
//       if (this.usertype !== 'Nurse') {
//         console.log(`⚠️ [NURSE] Cannot close ${deviceType} dialog - user is not nurse`);
//         return;
//       }

//       if (!this.deviceDialogRefs[deviceType]) {
//         console.log(`⚠️ [NURSE] No ${deviceType} dialog to close`);
//         return;
//       }

//       console.log(`🔒 [NURSE] Closing ${deviceType} dialog by doctor command`);

//       // Close the dialog
//       this.deviceDialogRefs[deviceType]!.close();
//       this.deviceDialogRefs[deviceType] = null;

//       console.log(` [NURSE] ${deviceType} dialog closed successfully`);

//     } catch (error) {
//       console.error(` [NURSE] Error closing ${deviceType} dialog:`, error);
//     }
//   }

//   /**
//    * 🔒 CLOSE ALL DEVICE DIALOGS - Called when doctor sends ble_close
//    * Closes all open device dialogs on nurse side
//    */
//   private closeAllDeviceDialogs(): void {
//     console.log(' [NURSE] Closing all device dialogs by doctor command');

//     Object.keys(this.deviceDialogRefs).forEach(deviceType => {
//       if (this.deviceDialogRefs[deviceType]) {
//         this.closeDeviceDialog(deviceType);
//       }
//     });
//   }





//   /**
//    * Establish WebSocket connection for doctor side
//    */
//   private async establishDoctorWebSocketConnection(): Promise<void> {
//     if (this.isLocalConsultation) {
//       console.log('🔍 [DOCTOR] Skipping nullwebsocket connection for local consultation');
//       return;
//     }

//     try {
//       console.log(`🔌 [DOCTOR] Establishing nullwebsocket connection for consultation ${this.consultationId}`);
//       const connected = await this.nullWebsocketService.connect(this.consultationId);

//       if (connected) {
//         // Subscribe to incoming messages
//         this.nullWebsocketService.messages$.subscribe(message => {
//           console.log('📨 [DOCTOR] Received nullwebsocket message:', message);
//           this.handleDoctorWebSocketMessage(message);
//         });
//         console.log('✅ [DOCTOR] Nullwebsocket connection established successfully');
//       }
//     } catch (error) {
//       console.warn('⚠️ [DOCTOR] Nullwebsocket connection failed:', error);
//     }
//   }

//   /**
//    * Handle incoming WebSocket messages for doctor
//    */
//   private handleDoctorWebSocketMessage(message: any): void {
//     const messageText = message?.message || message;
//     console.log('🔄 [DOCTOR] Processing message:', messageText);

//     // Handle nurse responses here if needed
//     switch (messageText) {
//       case 'loggedinsuccess':
//         console.log('✅ [DOCTOR] Nurse connected successfully');
//         break;
//       case 'ble_msgFromBLEApplet_true_Dongle connected successfully._2':
//         console.log('✅ [DOCTOR] Nurse confirmed kit connection');
//         break;
//       default:
//         console.log(`📨 [DOCTOR] Received: ${messageText}`);
//         break;
//     }
//   }

//   /**
//    * Disconnect nullwebsocket connection
//    */
//   private disconnectNurseWebSocket(): void {
//     try {
//       this.nullWebsocketService.disconnect();
//       this.isVideoConsultationActive = false;
//       this.isDoctorControllingNurse = false;
//       console.log('🔌 Nurse nullwebsocket disconnected');
//     } catch (error) {
//       console.error('❌ Error disconnecting nurse nullwebsocket:', error);
//     }
//   }

//   /**
//    * Show UI feedback when doctor connects
//    */
//   private showDoctorConnectedFeedback(): void {
//     // Optional: Show snackbar or toast notification
//     console.log('🎉 Doctor is now connected to the consultation');
//     // You can add UI feedback here if needed
//     // this.snackBar.open('Doctor connected successfully', 'Close', { duration: 3000 });
//   }

//   /**
//    * Test method to validate nullwebsocket connection (for debugging)
//    */
//   testWebSocketConnection(): void {
//     console.log('🧪 Testing nullwebsocket connection status:');

//     console.log('NullWebSocket Connected:', this.nullWebsocketService.getConnectionStatus());
//     console.log('Video Consultation Active:', this.isVideoConsultationActive);
//     console.log('Doctor Controlling Nurse:', this.isDoctorControllingNurse);
//     console.log('Platform Info:', this.nullWebsocketService.getPlatformInfo());
//   }

//   /**
//    * Disable tabs for nurse during parameters session
//    */
//   private disableTabsForNurse(): void {
//     if (this.usertype === 'Nurse' && this.isVideoConsultationActive) {
//       if (this.tabsComponent) {
//         this.tabsComponent.disableTabs();
//         console.log('🔒 [NURSE] Tabs disabled during parameters session');
//       }
//     }
//   }

//   /**
//    * Enable tabs for nurse when parameters session ends
//    */
//   private enableTabsForNurse(): void {
//     if (this.usertype === 'Nurse' && this.isVideoConsultationActive) {
//       if (this.tabsComponent) {
//         this.tabsComponent.enableTabs();
//         console.log('✅ [NURSE] Tabs enabled after parameters session');
//       }
//     }
//   }



//   // Camera and Microphone selection methods
//   toggleCameraDropdown(): void {
//     this.showCameraDropdown = !this.showCameraDropdown;
//     this.showMicDropdown = false; // Close mic dropdown if open
//   }

//   selectCamera(device: MediaDeviceInfo): void {
//     this.selectedCameraId = device.deviceId;
//     this.showCameraDropdown = false;
//     console.log('Selected camera:', device.label);
//   }

//   toggleMicDropdown(): void {
//     this.showMicDropdown = !this.showMicDropdown;
//     this.showCameraDropdown = false; // Close camera dropdown if open
//   }

//   selectMic(device: MediaDeviceInfo): void {
//     this.selectedMicId = device.deviceId;
//     this.showMicDropdown = false;
//     console.log('Selected microphone:', device.label);
//   }

//   //  ngOnDestroy lifecycle hook to clean up signaling subscription
//   ngOnDestroy(): void {
//     if (this.signalingSubscription) {
//       this.signalingSubscription.unsubscribe();
//       this.signalingSubscription = null;
//     }
//   }

//   //  Toggle fullscreen for video containers
//   toggleFullscreen(containerId: string): void {
//     const container = document.getElementById(containerId);
//     if (container) {
//       if (document.fullscreenElement) {
//         // Exit fullscreen
//         document.exitFullscreen().catch(err => {
//           console.error('Error exiting fullscreen:', err);
//         });
//       } else {
//         // Enter fullscreen
//         container.requestFullscreen().catch(err => {
//           console.error('Error entering fullscreen:', err);
//         });
//       }
//     }
//   }

//   viewPatReadings() {
//      console.log('viewPatReadings report clicked');
//   const consultationnId = localStorage.getItem('consultationId') || '';
//   const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
//   const patienttId = patientDetails.patientid || patientDetails.domainwisepid || '';

//   console.log('Retrieved consultationId from localStorage:', consultationnId);
//   console.log('Retrieved patientId from localStorage:', patienttId);

//   if (!consultationnId) {
//     console.error('No consultation ID found in localStorage');
//     return;
//   }

//   if (!patienttId) {
//     console.error('No patient ID found in localStorage');
//     return;
//   }

//     const dialogRef = this.dialog.open(ViewPatientReadingsPage, {
//       maxWidth: "1289px", // Adjusted to match the modal's max-width
//       height: "auto",
//       maxHeight: "90vh", // Prevent overflow on smaller screens
//           data: {
//       id: consultationnId,        // Pass consultation ID
//       ptId: patienttId,          // Pass patient ID
//       dt: new Date().toISOString() // Pass current datetime
//     },
//       panelClass: 'view-patient-readings-dialog',
//       disableClose: true,
//       autoFocus: false // Prevents automatic focus on first element
//     });

//     dialogRef.afterClosed();
//   }

//   /** Other existing methods like suspendConsultationConfirm, saveSuspendRequestToPouch, etc., remain unchanged */

//   // Follow-up checkbox functionality
//   onFollowUpChange(event: any): void {
//     const isChecked = event.target.checked;
    
//     if (isChecked) {
//       // Show confirmation dialog
//       this.showFollowUpConfirmation();
//     } else {
//       // If unchecked, just update the state
//       this.isFollowUpChecked = false;
//     }
//   }

//   private showFollowUpConfirmation(): void {
//     const dialogRef = this.dialog.open(CommonDialogPage, {
//       width: 'auto',
//       height: 'auto',
//       data: {
//         data: 'follow-up-confirmation',
//         message: 'Consultation marked as follow up.'
//       },
//       panelClass: 'follow-up-dialog',
//       disableClose: true
//     });

//     dialogRef.afterClosed().subscribe(result => {
//       if (result === 'ok' || result === 'yes') {
//         // User confirmed - call API and update checkbox
//         this.callFollowUpAPI(true);
//         this.isFollowUpChecked = true;
//       } else {
//         // User cancelled - uncheck the checkbox
//         this.isFollowUpChecked = false;
//       }
//     });
//   }

//   private callFollowUpAPI(isFollowUp: boolean): void {
//     const domainId = localStorage.getItem('domainId') || '1';
//     const token = this.tokenRequest || localStorage.getItem('token') || '';
//     const consultationId = this.consultationId || localStorage.getItem('consultationId') || '';
    
//     const queryParams = `?action=checkoruncheckforfollowup&domain=${domainId}&token=${token}&check=${isFollowUp}&consultationId=${consultationId}`;
    
//     this.apiSvc.postServiceByQueryBasic(this.constantSvc.APIConfig.GETCOMMONSERVICES, queryParams).subscribe({
//       next: (response: any) => {
//         console.log('Follow-up API response:', response);
//         if (response.status === 'success') {
//           console.log('Follow-up status updated successfully');
//         } else {
//           console.warn('Follow-up API returned non-success status:', response);
//         }
//       },
//       error: (error) => {
//         console.error('Error calling follow-up API:', error);
//         // Reset checkbox on error
//         this.isFollowUpChecked = false;
//       }
//     });
//   }

// }








import { IonicModule, ModalController, Platform } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { Component, OnInit, ChangeDetectorRef, NgZone, Input, HostListener, effect, viewChild } from '@angular/core';
import {
  ElementRef,
  ViewChild,
  OnDestroy,
  AfterViewInit,
  Inject,
} from '@angular/core';
import { Observable, Subscription, BehaviorSubject } from 'rxjs';
import * as Highcharts from 'highcharts/highstock';
import { WebsocketsService } from 'src/app/core/services/websocket.service';
import { NullWebsocketService } from 'src/app/core/services/null-websocket.service';
import { MatTooltipModule } from '@angular/material/tooltip';
import { PouchdbService } from 'src/app/core/services/pouchdb.service';
import { SaveSpo2DataRequest, SaveSpo2FileDataRequest } from 'src/app/core/interfaces/prms/spo2-data.model';
import { ApiService } from 'src/app/core/services/api.service';
import { ConstantService } from 'src/app/core/services/constant.service';
import * as CryptoJS from 'crypto-js';
import { NetworkService } from 'src/app/core/services/network.service';
import { SidebarPage } from '../sidebar/sidebar.page';
import { TabsPage } from '../tabs/tabs.page';
import { FinishConsultationRecord, SuspendRequest } from 'src/app/core/interfaces/pouchdb.model';
import { AuthService } from 'src/app/core/services/auth.service';
import { environment } from 'src/environments/environment';
import { DialogService } from 'src/app/core/services/dialog.service';
import { CommonDialogPage } from 'src/app/modules/common/common-dialog/common-dialog.page';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FinishConsulDialogPage } from '../finish-consul-dialog/finish-consul-dialog.page';

// import { DialogService } from 'src/app/core/services/dialog.service';
import { SendToDoctorPage } from 'src/app/modules/doctor-dashboard/send-to-doctor/send-to-doctor.page';
import * as OT from '@opentok/client';
import { TokboxService } from 'src/app/core/services/tokbox.service';
import { DoctorConsultationApiService } from 'src/app/core/services/doctor-consultation-api.service';
import { ConsultationSyncService } from 'src/app/core/services/consultation-sync.service';
import { firstValueFrom } from 'rxjs';

import { ViewconsultationPage } from '../viewconsultation/viewconsultation.page';

import { StethoscopeDevicePage } from 'src/app/modules/prms/ble-device/stethoscope-device/stethoscope-device.page';
import { FetalDopplerDevicePage } from 'src/app/modules/prms/ble-device/fetal-doppler-device/fetal-doppler-device.page';
import { ThermometerPage } from 'src/app/modules/prms/ble-device/thermometer/thermometer.page';
import { Snackbar } from 'src/app/core/services/snackbar';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ViewPatientReadingsPage } from '../view-patient-readings/view-patient-readings.page';
import { ParametersPage } from '../parameters/parameters.page';
import { Spo2DevicePage } from 'src/app/modules/prms/ble-device/spo2-device/spo2-device.page';
import { EcgJettyDevicePage } from 'src/app/modules/prms/ble-device/ecg-jetty-device/ecg-jetty-device.page';
import { EcgInterpretationManualJettyComponent } from 'src/app/modules/prms/manual_entry/ecg-interpretation-manual-jetty/ecg-interpretation-manual-jetty.component';
import { EcgInterpretationJettyDeviceComponent } from 'src/app/modules/prms/ble-device/ecg-interpretation-jetty-device/ecg-interpretation-jetty-device.component';
import { SpirometerJettyDevicePage } from 'src/app/modules/prms/ble-device/spirometer-jetty-device/spirometer-jetty-device.page';


interface SuspendResponse {
  status: string;
  message: string;
}
interface ApiResponse {
  status: string;
  message?: string;
}

@Component({
  selector: 'app-patientinfo',
  templateUrl: './patientinfo.page.html',
  styleUrls: ['./patientinfo.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, TabsPage],
})
export class PatientinfoPage implements OnInit, OnDestroy {
  @Input() followUpVal: any;
  @Input() userType: string = ''; //  Added to identify doctor/nurse

  @ViewChild('tabsComponent') tabsComponent!: TabsPage;
  @ViewChild('tabsComponent2') tabsComponent2!: TabsPage;

 // Follow-up checkbox state
  isFollowUpChecked: boolean = false;
  doctorName: string = '';
  currDomainId: any;
  tokenRequest: any;
  username: any;
  usertype: any;
  tab: any = "";
  consultationId: any;
  patientId: any;
  domainwisepid: any;
  language!: string;
  first_name: any;
  last_name: any;
  currUserType = '';

  consultationStartTime = new Date();
  reportWindow: any = null;
  patientData: any = {};
  patientImageUrl = 'assets/images/Patients.png';
  isLocalConsultation: boolean = false;
  timeIntervalStore: undefined;
  showMoreActions: boolean = false;

  session!: OT.Session;
  publisher!: OT.Publisher;

  // ✅ For Nurse Video Call
  isNurseVideoActive = false;

  // ✅ Video state tracking
  isDoctorVideoActive = false;
  isPatientVideoActive = false;

  // ✅ Loader state for Connect to Doctor functionality
  isConnectingToDoctor = false;
  isVideoStarted = false;
  isDoctorInitiated = false; // Flag to track if doctor started the consultation

  // ✅ Speaking state tracking
  isPublisherSpeaking = false;
  isSubscriberSpeaking = false;

  // ✅ New properties for device activation signaling
  private signalingSubscription: Subscription | null = null;
  kitActivated = false; // Tracks if the medical device kit has been activated
  activeDevices: Set<string> = new Set(); // Tracks which specific devices are currently active

  // Camera and Microphone selection properties
  videoDevices: MediaDeviceInfo[] = [];
  audioDevices: MediaDeviceInfo[] = [];
  selectedCameraId: string = '';
  selectedMicId: string = '';
  showCameraDropdown: boolean = false;
  showMicDropdown: boolean = false;

  // Video mute/unmute properties
  isVideoMuted: boolean = false;

  // ✅ New properties for mute state tracking
  isMicMuted: boolean = false;
  isCameraMuted: boolean = false;

  // ✅ Flag to prevent multiple clicks on Connect to Doctor button
  isConnectToDoctorClicked: boolean = false;

  @ViewChild(ParametersPage, {static: false}) paramsPage!: ParametersPage;
  constructor(
    private tokboxService: TokboxService,
    private modalCtrl: ModalController,
    private websocketsService: WebsocketsService,
    private nullWebsocketService: NullWebsocketService,
    private pouchdbService: PouchdbService,
    private authService: AuthService,
    private constantSvc: ConstantService,
    private apiSvc: ApiService,
    private networkService: NetworkService,
    private router: Router,
    private dialog: MatDialog,
    private dialogService: DialogService,
    private docApi: DoctorConsultationApiService,
    private consultationSyncService: ConsultationSyncService,
    private snackBar: MatSnackBar,
    private platform: Platform,
    private ngZone: NgZone,
  ) {
    this.tokboxService.speakingState$.subscribe(state => {
      this.isDoctorVideoActive = state.publisherSpeaking;
      this.isPatientVideoActive = state.subscriberSpeaking;
      this.isPublisherSpeaking = state.publisherSpeaking;
      this.isSubscriberSpeaking = state.subscriberSpeaking;
    });
  }

  async ngOnInit(): Promise<void> {
    // Initialize PouchDB databases
    // this.pouchdbService.initDB('suspend_consultations');
    // this.pouchdbService.initDB('finishconsultation_data');
    const flag = localStorage.getItem('isLocalConsultation') === 'true';
    console.log('Flag from storage:', flag);
    this.isLocalConsultation = flag;

    // Initialize mute states from Tokbox publisher if available
    if (this.tokboxService.getCurrentState().isPublishing) {
      this.isMicMuted = !this.tokboxService.getCurrentState().isPublishing; // Assuming true means unmuted
      this.isCameraMuted = !this.tokboxService.getCurrentState().isPublishing; // Assuming true means unmuted
    }


    this.currDomainId = Number(localStorage.getItem('domainId'));
    const loginResponseStr = localStorage.getItem('LOGIN_RESPONSE');

    const currentSession = this.authService.getCurrentSession();
    this.tokenRequest = this.authService.getToken() || '';
    this.username = currentSession?.username || '';
    this.currDomainId = currentSession?.domainId || '';
    this.language = currentSession?.language || '';

    // Patient & consultation info
    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    this.patientId = patientDetails.patientid || '';
    this.domainwisepid = patientDetails.domainwisepid || '';
    this.first_name = patientDetails.first_name || '';
    this.last_name = patientDetails.last_name || '';
    this.patientData = patientDetails;
    this.consultationId = localStorage.getItem('consultationId') || '';

    // Get login/session info
    const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    this.tokenRequest = loginResponse.token ?? localStorage.getItem('token') ?? '';
    this.currDomainId = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
    this.username = loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? '';
    this.usertype = loginResponse.commondetail?.usertype ?? localStorage.getItem('usertype') ?? '';
    const usertype = sessionStorage.getItem('USER');
    // const currentSession = this.authService.getCurrentSession();
    const userName = currentSession?.username || '';

    this.patientId = patientDetails.patientid || '';
    this.first_name = patientDetails.first_name || '';
    this.last_name = patientDetails.last_name || '';

    this.patientData = patientDetails;

    // ✅ Initialize video call only for doctor
    if (this.userType === 'doctor') {
      this.initDoctorVideoCall();
      // Establish WebSocket connection for doctor
      this.establishDoctorWebSocketConnection();
    }

    // ✅ Check if doctor initiated consultation from router state
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras?.state?.['appointment']) {
      this.isDoctorInitiated = true;
      this.isVideoStarted = true;
      console.log('Doctor initiated consultation detected');
    }

    //  Load patient profile image
    const profile = patientDetails.profile;
    if (profile?.S3URL) {
      this.patientImageUrl = profile?.S3URL
        ? profile.S3URL
        : profile?.imagepath
          ? `https://remedi-dev-server-data.s3.ap-south-1.amazonaws.com/${profile.imagepath}.jpg`
          : 'assets/images/Patients.png';
    }


    const usertypeStorage = sessionStorage.getItem('USER');
    if (usertypeStorage) {
      try {
        const userData = JSON.parse(usertypeStorage);
        this.doctorName = `${userData.honorific} ${userData.name}`;
      } catch (e) {
        console.error('Error parsing USER', e);
        this.doctorName = 'Doctor';
      }
    }
    const loginResponseRaw = localStorage.getItem('LOGIN_RESPONSE');
    if (loginResponseRaw) {
      try {
        const loginResponse = JSON.parse(loginResponseRaw);
        this.currUserType = loginResponse.usertype || loginResponse.commondetail?.usertype || '';
        console.log('Current User Type:', this.currUserType);
      } catch (e) {
        console.error('Error parsing LOGIN_RESPONSE:', e);
        this.currUserType = '';
      }
    }

    // Enumerate available video input devices (cameras) and audio input devices (microphones)
    if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        this.videoDevices = devices.filter(device => device.kind === 'videoinput');
        this.audioDevices = devices.filter(device => device.kind === 'audioinput');
        if (this.videoDevices.length > 0) {
          this.selectedCameraId = this.videoDevices[0].deviceId;
        }
        if (this.audioDevices.length > 0) {
          this.selectedMicId = this.audioDevices[0].deviceId;
        }
      } catch (error) {
        console.error('Error enumerating devices:', error);
      }
    }
  }

  confirmDialogSuspend(data: any, checkslot: number) {
    const dialogRef = this.dialog.open(CommonDialogPage, {
      width: "auto",
      height: "auto",
      data: data,
      panelClass: "slot-dialog",
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('Dialog closed with result:', result);

      if (result === "suspend") {
        console.log('User confirmed suspend → checking online/offline status');

        // Check if user is online or offline
        if (this.networkService.isOnline()) {
          console.log('User is online → following existing process');

          // Send WebSocket message ONLY after user confirms suspend
          if (!this.isLocalConsultation) {
            try {
              this.nullWebsocketService.sendMessage('SuspendByDoctor');
              console.log('✅ [DOCTOR] Sent SuspendByDoctor message to nurse after confirmation');
            } catch (error) {
              console.error('❌ [ERROR] Failed to send WebSocket message:', error);
            }
          }

          // Follow existing process with API response check
          this.saveSuspendRequestToPouch();
        } else {
          console.log('User is offline → skipping API response check, using localConsultationId');

          // Get localConsultationId from localStorage
          const localConsultationId = localStorage.getItem('localConsultationId') || this.consultationId;
          console.log('Using localConsultationId:', localConsultationId);

          // Follow existing process without API response check
          this.saveSuspendRequestToPouchOffline(localConsultationId);
        }
      } else if (result === "yes") {
        console.log('User confirmed YES → different action');
      } else {
        console.log('User canceled');
      }
    });
  }

  suspendConsultationConfirm() {
    console.log('🔍 [DEBUG] Suspend button clicked');
    console.log('🔍 [DEBUG] isLocalConsultation:', this.isLocalConsultation);
    console.log('🔍 [DEBUG] nullWebSocket$ exists:', !!this.nullWebSocket$);

    // Try multiple approaches to send WebSocket message
    if (!this.isLocalConsultation) {
      console.log('🔍 [DEBUG] This is a remote consultation, attempting to send WebSocket message');

      // Approach 1: Check if nullWebSocket$ exists and send
      if (this.nullWebSocket$) {
        try {
          this.sendNullWebSocketMessage('SuspendByDoctor');
          console.log('✅ [DOCTOR] Sent SuspendByDoctor message to nurse before dialog');
        } catch (error) {
          console.error('❌ [ERROR] Failed to send WebSocket message:', error);
        }
      } else {
        console.warn('⚠️ [WARNING] nullWebSocket$ is not available');

        // Approach 2: Try to re-establish WebSocket connection
        if (this.userType === 'doctor') {
          console.log('🔄 [RETRY] Attempting to re-establish WebSocket connection');
          this.establishDoctorWebSocketConnection();

          // Wait a moment and try again
          setTimeout(() => {
            if (this.nullWebSocket$) {
              try {
                this.sendNullWebSocketMessage('SuspendByDoctor');
                console.log(' [DOCTOR] Sent SuspendByDoctor message after reconnection');
              } catch (error) {
                console.error(' [ERROR] Failed to send WebSocket message after reconnection:', error);
              }
            }
          }, 1000);
        }
      }
    } else {
      console.log('ℹ️ [INFO] This is a local consultation, no WebSocket message needed');
    }

    this.confirmDialogSuspend(
      { data: "suspend-consultation", type: "local", tab: this.tab },
      0
    );

    // Save patient data for suspend action
    this.patientData = JSON.parse(sessionStorage.getItem("patientDetails") || '{}');
  }


  // Save suspend request locally
  toggleMoreActions(): void {
    this.showMoreActions = !this.showMoreActions;
  }

  saveSuspendRequestToPouch() {
    this.consultationId = localStorage.getItem('consultationId') || '';
    const suspendRecord: SuspendRequest = {
      _id: new Date().toISOString(),
      action: 'suspendLocalConsultation',
      username: this.username || '',
      domain: this.currDomainId || 0,
      consultationId: parseInt(this.consultationId) || 0,
      usertype: 'Doctor',
      token: this.tokenRequest || '',
      synced: false,
      forwardto: 'RemediNovaDoctorAPI.do',

    };
    this.pouchdbService.initDB('suspend_consultations');


    this.pouchdbService.addRecord(suspendRecord).subscribe({
       next: async () => {
        console.log('Suspend request saved locally to PouchDB');
        
        // Update consultation state to 'suspend'
        try {
          const localConsultationId = localStorage.getItem('localConsultationId') || this.consultationId;
          await this.consultationSyncService.updateConsultationState(localConsultationId, 'suspend');
        } catch (error) {
          console.error('Failed to update consultation state:', error);
        }
                // Optional: sync immediately if online
        if (this.networkService.isOnline()) {
          this.syncUnsyncedSuspendRequests();
        }
      },
      error: (err) => {
        console.error('Failed to save suspend request:', err);
      }
    });
  }


  saveSuspendRequestToPouchOffline(localConsultationId: string) {
    const suspendRecord: SuspendRequest = {
      _id: new Date().toISOString(),
      action: 'suspendLocalConsultation',
      username: this.username || '',
      domain: this.currDomainId || 0,
      consultationId: parseInt(localConsultationId) || 0,
      localConsultationId: localStorage.getItem('localConsultationId') || localConsultationId,
      usertype: 'Doctor',
      token: this.tokenRequest || '',
      synced: false,
      forwardto: 'RemediNovaDoctorAPI.do',
    };

    this.pouchdbService.initDB('suspend_consultations');

    this.pouchdbService.addRecord(suspendRecord).subscribe({
      next: async () => {
        console.log('Offline suspend request saved locally to PouchDB with localConsultationId:', suspendRecord.localConsultationId);

        // Update consultation state to 'suspend'
        try {
          await this.consultationSyncService.updateConsultationState(localConsultationId, 'suspend');
        } catch (error) {
          console.error('Failed to update consultation state:', error);
        }

        // Clean up and navigate without API call
        localStorage.removeItem('isLocalConsultation');
        sessionStorage.removeItem('isLocalConsultation');
        sessionStorage.removeItem('walkinCon');

        // Navigate to dashboard immediately
        this.router.navigate(['/doctor-dashboard']);
      },
      error: (err) => {
        console.error('Failed to save offline suspend request:', err);
        // Still navigate even if save fails
        this.router.navigate(['/doctor-dashboard']);
      }
    });
  }

  syncUnsyncedSuspendRequests() {
    this.pouchdbService.initDB('suspend_consultations');

    this.pouchdbService.getAllRecords<SuspendRequest>().subscribe(records => {
      this.consultationId = localStorage.getItem('consultationId') || '';
      const unsynced = records.filter(r => !r.synced &&
        r.consultationId == this.consultationId &&
        r.action === 'suspendLocalConsultation'
      );

      console.log('Unsynced suspend requests:', unsynced);

      unsynced.forEach(record => {
        const query = `?action=${record.action}` +
          `&username=${record.username}` +
          `&domain=${record.domain}` +
          `&ConsId=${record.consultationId}` +
          `&usertype=${record.usertype}` +
          `&token=${record.token}` +
          `&language=${this.language}`;

        this.apiSvc.postServiceByQueryBasic(this.constantSvc.APIConfig.DISPLAYAPPOINTMENTS, query)
          .subscribe({
            next: (res: any) => {
              if (res.status === 'success') {
                console.log('Synced suspend request:', record);
                localStorage.removeItem('isLocalConsultation');
                sessionStorage.removeItem('isLocalConsultation');
                sessionStorage.removeItem('walkinCon');
                // Mark synced
                record.synced = true;
                this.pouchdbService.initDB('suspend_consultations');

                this.pouchdbService.updateRecord(record).subscribe({
                  next: () => {
                    console.log('Updated PouchDB record as synced');
                  },
                  error: (err) => console.error(' Failed to update record:', err)
                });

                // Redirect to dashboard
                this.router.navigate(['/doctor-dashboard']);
              } else {
                console.warn(' Failed to sync suspend request:', res);
              }
            },
            error: (err) => {
              console.error(' Error syncing suspend request:', err);
            }
          });
      });
    });
  }

  finsishConsultationConfirm(ptData?: any) {
    // Send WebSocket message BEFORE opening dialog for video consultation
    if (!this.isLocalConsultation && this.nullWebSocket$) {
      this.sendNullWebSocketMessage('FinishByDoctor');
      console.log('✅ [DOCTOR] Sent FinishByDoctor message to nurse before dialog');
    }

    if (this.timeIntervalStore != undefined) {
      clearInterval(this.timeIntervalStore);
    }
    setTimeout(() => {
      clearInterval(this.timeIntervalStore);
    }, 100)


    sessionStorage.removeItem('walkinCon');
    this.confirmDialog({ data: 'finish-consultation', followUp: this.followUpVal });

    this.patientData = ptData;
  }


  confirmDialog(data: any) {
    console.log("data", data);
    const dialogRef = this.dialog.open(CommonDialogPage, {
      width: 'auto',
      height: 'auto',
       data: { ...data, followUp: this.isFollowUpChecked },
      panelClass: 'slot-dialog'
      // position: {top: '10%', right:'10%'}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result != undefined) {
        console.log("result----", result)
        console.log("tab----", this.tab)


        if (result == 'finish') {


          if (this.tab == 'walkin' || this.tab == 'review') {
            if (this.tab == 'walkin') {

              this.confirmFinishDialog(this.patientData);
            }
          } else {

            this.confirmFinishDialog(this.patientData);
          }
        }
        if (result == 'yes') {
        } else {

        }
      }
    });
  }
  confirmFinishDialog(data?: any) {
    const dialogRef = this.dialog.open(FinishConsulDialogPage, {
      width: '400px',
      height: 'auto',
      data: data,
      disableClose: true,
      panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result !== undefined) {
        console.log('User confirmed finish → checking online/offline status');

        // Check if user is online or offline
        if (this.networkService.isOnline()) {
          console.log('User is online → following existing process');

          // Send WebSocket message ONLY after user confirms finish
          if (!this.isLocalConsultation) {
            try {
              this.nullWebsocketService.sendMessage('FinishByDoctor');
              console.log('✅ [DOCTOR] Sent FinishByDoctor message to nurse after confirmation');
            } catch (error) {
              console.error('❌ [ERROR] Failed to send WebSocket message:', error);
            }
          }

          this.executeFinishConsultation();
        } else {
          console.log('User is offline → skipping API response check, using localConsultationId');

          // Get localConsultationId from localStorage
          const localConsultationId = localStorage.getItem('localConsultationId') || this.consultationId;
          console.log('Using localConsultationId:', localConsultationId);

          // Follow existing process without API response check
          this.executeFinishConsultationOffline(localConsultationId);
        }
      }
    });
  }

  private executeFinishConsultationOffline(localConsultationId: string): void {
    const record: FinishConsultationRecord = {
      _id: new Date().toISOString(),
      type: 'finish_consultation',
      action: 'finishconsultation',
      domain: this.currDomainId,
      username: this.username,
      consultationId: parseInt(localConsultationId) || 0,
      localConsultationId: localStorage.getItem('localConsultationId') || localConsultationId,
      usertype: 'Doctor',
      patientId: this.patientId,
      token: this.tokenRequest,
      synced: false,
      forwardto: 'RemediNovaDoctorAPI.do',
    };

    this.pouchdbService.initDB('finishconsultation_data');

    this.pouchdbService.addRecord(record).subscribe({
      next: async () => {
        console.log('Offline finish consultation saved locally to PouchDB with localConsultationId:', record.localConsultationId);

        // Update consultation state to 'finish'
        try {
          await this.consultationSyncService.updateConsultationState(localConsultationId, 'finish');
        } catch (error) {
          console.error('Failed to update consultation state:', error);
        }

        // Always set session storage to know we came from finish consultation
        sessionStorage.setItem('dialogRef', 'finish');

        // Clean up and navigate without API call
        localStorage.removeItem('isLocalConsultation');
        sessionStorage.removeItem('isLocalConsultation');
        sessionStorage.removeItem('walkinCon');

        // Navigate to dashboard and show report
        this.router.navigate(['/doctor-dashboard']).then(() => {
          this.viewConsultationReport();
        });
      },
      error: (err) => {
        console.error('Failed to save offline finish consultation:', err);
        // Still navigate even if save fails
        this.router.navigate(['/doctor-dashboard']);
      }
    });
  }

  private executeFinishConsultation(): void {
    this.finishConsultation().subscribe({
      next: (res: any) => {
        console.log("Consultation finished successfully", res);

        // Always set session storage to know we came from finish consultation
        sessionStorage.setItem('dialogRef', 'finish');

        localStorage.removeItem('isLocalConsultation');
        sessionStorage.removeItem('isLocalConsultation');
        sessionStorage.removeItem('walkinCon');

        // Navigate to doctor dashboard first
        this.router.navigate(['/doctor-dashboard']).then(() => {
          // After navigation is done, show the report
          this.viewConsultationReport();
        });
      },
      error: (err: any) => {
        console.error("Error finishing consultation", err);
      }
    });
  }



  finishConsultation(): Observable<any> {
    return new Observable((observer) => {
      const record: FinishConsultationRecord = {
        _id: new Date().toISOString(),
        type: 'finish_consultation',
        action: 'finishconsultation',
        domain: this.currDomainId,
        username: this.username,
        consultationId: this.consultationId,
        usertype: 'Doctor',
        patientId: this.patientId,
        token: this.tokenRequest,
        synced: false,
        forwardto: 'RemediNovaDoctorAPI.do',

      };
      this.pouchdbService.initDB('finishconsultation_data');

      // Save locally first
      this.pouchdbService.addRecord(record).subscribe({
        next: async () => {
          console.log('Finish consultation saved locally to PouchDB');

          // Update consultation state to 'finish'
          try {
            const localConsultationId = localStorage.getItem('localConsultationId') || this.consultationId;
            await this.consultationSyncService.updateConsultationState(localConsultationId, 'finish');
          } catch (error) {
            console.error('Failed to update consultation state:', error);
          }
          // Sync unsynced records and notify when done
          this.syncUnsyncedFinishConsultations().subscribe({
            next: (res) => {
              console.log('Finish consultation synced successfully', res);
              observer.next(res);
              observer.complete();
            },
            error: (err) => {
              console.error('Failed to sync finish consultation', err);
              observer.error(err);
            }
          });
        },
        error: (err) => {
          console.error('Failed to save finish consultation locally:', err);
          observer.error(err);
        }
      });
    });
  }


  syncUnsyncedFinishConsultations(): Observable<any> {
    this.pouchdbService.initDB('finishconsultation_data');

    return new Observable((observer) => {
      this.pouchdbService.getAllRecords<FinishConsultationRecord>().subscribe(records => {
        const unsynced = records.filter(r => r.synced === false && r.type === 'finish_consultation' && r.consultationId === this.consultationId);

        if (unsynced.length === 0) {
          console.log('No unsynced records found');
          observer.next({ status: 'no_records' });
          observer.complete();
          return;
        }

        let processed = 0;

        unsynced.forEach(record => {
          const query = `?action=${record.action}` +
            `&domain=${record.domain}` +
            `&username=${record.username}` +
            `&consultationId=${record.consultationId}` +
            `&usertype=${record.usertype}` +
            `&patientId=${record.patientId}` +
            `&token=${record.token}`;

          this.apiSvc.postServiceByQueryBasic<ApiResponse>(this.constantSvc.APIConfig.GETCOMMONSERVICES, query)
            .subscribe({
              next: (res) => {
                if (res.status === 'success') {
                  console.log('Synced finish consultation record:', record);
                  record.synced = true;
                  this.pouchdbService.initDB('finishconsultation_data');

                  this.pouchdbService.updateRecord(record).subscribe(() => {
                    processed++;
                    if (processed === unsynced.length) {
                      console.log('All records synced successfully');
                      observer.next(res);
                      observer.complete();
                    }
                  });
                } else {
                  console.warn('Sync failed:', res);
                  processed++;
                  if (processed === unsynced.length) {
                    observer.error(res);
                  }
                }
              },
              error: (err) => {
                console.error('Error syncing finish consultation:', err);
                processed++;
                if (processed === unsynced.length) {
                  observer.error(err);
                }
              }
            });
        });
      });
    });
  }


  viewConsultationReport() {
    console.log('View consultation report clicked');
    const consultationnId = localStorage.getItem('consultationId') || '';
    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const patienttId =  patientDetails.patientId || patientDetails.patientid || ''; 
              

    console.log('Retrieved consultationId from localStorage:', consultationnId);
    console.log('Retrieved patientId from localStorage:', patienttId);

    if (!consultationnId) {
      console.error('No consultation ID found in localStorage');
      return;
    }

    if (!patienttId) {
      console.error('No patient ID found in localStorage');
      return;
    }

    // Pass data through MatDialog data parameter
    const dialogRef = this.dialog.open(ViewconsultationPage, {
      width: '95vw',
      height: '95vh',
      maxWidth: '95vw',
      maxHeight: '95vh',
      data: {
        id: consultationnId,        // Pass consultation ID
        ptId: patienttId,          // Pass patient ID
        dt: new Date().toISOString() // Pass current datetime
      },
      panelClass: 'consultation-report-dialog',
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('Consultation report dialog closed');
    });
  }

  // viewConsultationReport() {
  //   console.log('View consultation report clicked');

  //   const consultationId = localStorage.getItem('consultationId') || '';
  //   const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
  //   const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
  //   const patientId = patientDetails.patientid || patientDetails.domainwisepid || '';

  //   this.currUserType = loginResponse.usertype || loginResponse.commondetail?.usertype || '';
  //   this.patientImageUrl = patientDetails.profile?.S3URL
  //       || (patientDetails.profile?.imagepath ? `https://remedi-dev-server-data.s3.ap-south-1.amazonaws.com/${patientDetails.profile.imagepath}.jpg` : 'assets/images/avtar.png');

  //   const isCapacitor = !!(window as any).Capacitor;

  //   if (!isCapacitor) {
  //     let baseUrl = environment.locationURL;
  //     const hostname = window.location.hostname;
  //     if (hostname !== 'localhost' && !baseUrl.includes('/remediprmsang')) {
  //       baseUrl += '/remediprmsang';
  //     }

  //     const reportUrl = `${baseUrl}/consultation-report?id=${consultationId}&ptId=${patientId}`;
  //     console.log('Generated Report URL:', reportUrl);

  //     this.reportWindow = window.open(reportUrl, '', "width=1000,height=800,toolbar=no,menubar=no,resizable=yes");

  //     if (this.reportWindow) {
  //       (this.reportWindow as any).fromConsult = "viewFull";

  //       if (patientDetails.startTime) {
  //         const [h, m, s] = patientDetails.startTime.split(":").map(Number);
  //         this.consultationStartTime.setHours(h, m, s);
  //       }

  //       (this.reportWindow as any).startTime = this.consultationStartTime;

  //       const interval = setInterval(() => {
  //         if (this.reportWindow?.closed) {



  //           sessionStorage.setItem("dialogRef", "");
  //          // this.router.navigate(['/doctor-dashboard']);
  //           clearInterval(interval);
  //         }
  //       }, 500);
  //     }
  //   } else {
  //     // Mobile app
  //     this.router.navigate(['/consultation-report'], {
  //       queryParams: { id: consultationId, ptId: patientId }
  //     });
  //   }
  // }

  // viewConsultationReport() {
  //   console.log('View consultation report clicked');

  //   const consultationId = localStorage.getItem('consultationId') || '';
  //   const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
  //   const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
  //   const patientId = patientDetails.patientid || patientDetails.domainwisepid || '';

  //   this.currUserType = loginResponse.usertype || loginResponse.commondetail?.usertype || '';
  //   this.patientImageUrl = patientDetails.profile?.S3URL
  //     || (patientDetails.profile?.imagepath ? `https://remedi-dev-server-data.s3.ap-south-1.amazonaws.com/${patientDetails.profile.imagepath}.jpg` : 'assets/images/avtar.png');

  //   const isElectron = this.platform.is('electron') || !!(window as any).require || !!(window as any).electronAPI;
  //   const isNativeMobile = this.platform.is('capacitor') || this.platform.is('cordova');
  //   const isMobileDevice = this.platform.is('android') || this.platform.is('ios');
  //   const isActualMobileApp = isNativeMobile && isMobileDevice;

  //   console.log('Environment:', {
  //     isElectron,
  //     isNativeMobile,
  //     isMobileDevice,
  //     isActualMobileApp,
  //     hasElectronAPI: !!(window as any).electronAPI
  //   });

  //   if (!isActualMobileApp) {
  //     console.log(' Opening in new window');

  //     // if (isElectron) {
  //     //   console.log('isElectron Opening in new window');

  //     //    const route = `/#/consultation-report?id=${consultationId}&ptId=${patientId}&print=true&electron=true`;

  //     //   console.log('Electron - Opening route:', route);

  //     //   // window.open will be caught by setWindowOpenHandler in main.js
  //     //    window.open(`#/${route}`, '_blank');


  //     // }

  // if (isElectron) {
  //   console.log('isElectron Opening in browser');

  //   let baseUrl = environment.locationURL;
  //   const hostname = window.location.hostname;

  //   if (hostname !== 'localhost' && !baseUrl.includes('/remediprmsang')) {
  //     baseUrl += '/remediprmsang';
  //   }

  //   const reportUrl = `${baseUrl}/#/consultation-report?id=${consultationId}&ptId=${patientId}&print=true&electron=true`;

  //   console.log('Electron - Opening in external browser:', reportUrl);

  //   // Use electronAPI if available
  //   if ((window as any).electronAPI?.openExternal) {
  //     (window as any).electronAPI.openExternal(reportUrl);
  //   } else {
  //     console.error('electronAPI.openExternal not available');
  //     // Fallback to window.open as last resort
  //     window.open(reportUrl, '_blank');
  //   }
  // }
  //     else {
  //   // Web Browser - pass auth token in URL
  //   let baseUrl = environment.locationURL;
  //   const hostname = window.location.hostname;

  //   if (hostname !== 'localhost' && !baseUrl.includes('/remediprmsang')) {
  //     baseUrl += '/remediprmsang';
  //   }

  //   // Get auth data from localStorage
  //   const token = localStorage.getItem('token') || '';
  //   const loginResponseStr = encodeURIComponent(localStorage.getItem('LOGIN_RESPONSE') || '{}');


  //    const reportUrl = `${baseUrl}/#/consultation-report?id=${consultationId}&ptId=${patientId}&print=true`;

  //   console.log('Web Report URL:', reportUrl);


  //   this.reportWindow =  window.open(
  //     reportUrl,
  //     'ConsultationReport',
  //     "width=1200,height=900,toolbar=yes,menubar=yes,resizable=yes,scrollbars=yes"
  //   );

  //   if (this.reportWindow) {
  //     (this.reportWindow as any).fromConsult = "viewFull";

  //     if (patientDetails.startTime) {
  //       const [h, m, s] = patientDetails.startTime.split(":").map(Number);
  //       this.consultationStartTime.setHours(h, m, s);
  //     }

  //     (this.reportWindow as any).startTime = this.consultationStartTime;
  //     (this.reportWindow as any).patientImageUrl = this.patientImageUrl;
  //     (this.reportWindow as any).currUserType = this.currUserType;

  //     this.reportWindow.focus();

  //     const interval = setInterval(() => {
  //       if (this.reportWindow?.closed) {
  //         console.log('Consultation report window closed');
  //         clearInterval(interval);
  //       }
  //     }, 1000);
  //   } else {
  //     console.warn('Failed to open new window');
  //     this.showPopupBlockedAlert();
  //   }
  // }
  //   } else {
  //     console.log('📱 Opening in mobile app');
  //     this.openInMobileApp(consultationId, patientId);
  //   }
  // }








  // FIXED viewConsultationReport method
  viewConsultationReportold() {
    console.log('View consultation report clicked');
    const consultationnId = localStorage.getItem('consultationId') || '';
    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    const patienttId = patientDetails.patientid || patientDetails.domainwisepid || '';

    console.log('Retrieved consultationId from localStorage:', consultationnId);
    console.log('Retrieved patientId from localStorage:', patienttId);

    try {
      this.currUserType = loginResponse.usertype || loginResponse.commondetail?.usertype || '';
    } catch (e) {
      this.currUserType = '';
    }

    const profile = patientDetails.profile;
    if (profile?.S3URL) {
      this.patientImageUrl = profile.S3URL;
    } else if (profile?.imagepath) {
      this.patientImageUrl = `https://remedi-dev-server-data.s3.ap-south-1.amazonaws.com/${profile.imagepath}.jpg`;
    } else {
      this.patientImageUrl = 'assets/images/avtar.png';
    }

    const isCapacitor = !!(window as any).Capacitor;

    if (!isCapacitor) {
      let baseUrl = environment.locationURL;
      const hostname = window.location.hostname;

      if (hostname !== 'localhost') {
        if (!baseUrl.includes('/remediprmsang')) {
          baseUrl += '/remediprmsang';  // Append only if it's not already in the baseUrl
        }
      }

      const reportUrl = `${baseUrl}/consultation-report?id=${consultationnId}&ptId=${patienttId}`;
      console.log('Generated Report URL:', reportUrl);

      this.reportWindow = window.open(reportUrl, '', "width=1000,height=800,toolbar=no,menubar=no,resizable=yes");

      if (this.reportWindow) {
        this.reportWindow["fromConsult"] = "viewFull";
        window.focus();

        let patientDetails;
        if (localStorage.getItem("patientDetails")) {
          patientDetails = JSON.parse(localStorage.getItem("patientDetails") || '{}');
        }

        if (patientDetails) {
          if (patientDetails.startTime) {
            this.consultationStartTime.setHours(patientDetails.startTime.split(":")[0]);
            this.consultationStartTime.setMinutes(patientDetails.startTime.split(":")[1]);
            this.consultationStartTime.setSeconds(patientDetails.startTime.split(":")[2]);
            this.reportWindow.startTime = this.consultationStartTime;
          } else {
            this.reportWindow.startTime = this.consultationStartTime;
          }
        } else {
          this.reportWindow.startTime = this.consultationStartTime;
        }

        console.log("this.consultationStartTime", this.patientData, this.consultationStartTime);
        window.focus();

        var interval = setInterval(() => {
          console.log("this.reportWindow", this.reportWindow);

          if (this.reportWindow.closed) {
            sessionStorage.setItem("dialogRef", "  ");
            console.log("reference url", this.reportWindow);
            // this.router.navigate(['/doctor-dashboard']);
            clearInterval(interval);
          }
        }, 100);
      }
    } else {
      console.log("test mobile");

      // MOBILE APP - Navigate to route
      this.router.navigate(['/consultation-report'], {
        queryParams: {
          id: consultationnId,
          ptId: patienttId
        }
      });
    }
  }
  async sendToDoc() {
    const dialogRef = this.dialog.open(SendToDoctorPage, {
      width: "600px",
      height: "auto",
      disableClose: true,
      // panelClass: 'slot-dialog'
    });
  }

  //  Doctor video call logic - Fixed container IDs and removed full-screen settings
  private async initDoctorVideoCall(): Promise<void> {
    try {
      const tokSession = await this.tokboxService.getTokBoxSession(this.consultationId, this.username);

      this.session = OT.initSession(tokSession.API_KEY, tokSession.SESSION_ID);

      //  Use correct publisher container ID and remove fixed width/height to prevent full-screen
      this.publisher = OT.initPublisher('publisher-container', {
        insertMode: 'append',
        // Removed width and height to allow CSS control
      });

      this.session.on('streamCreated', (event) => {
        //  Use correct subscriber container ID for doctor
        this.session.subscribe(event.stream, 'subscriber-container', {
          insertMode: 'append',
          // Removed width and height to allow CSS control
        });
        //  Set video active state when stream is received (patient's video for doctor)
        this.isPatientVideoActive = true;
      });

      this.session.connect(tokSession.TOKEN, (err) => {
        if (!err) {
          this.session.publish(this.publisher);
          //  Set publishing state (doctor's video publishing)
          this.isDoctorVideoActive = true;
        } else {
          console.error('TokBox connection failed:', err);
        }
      });
    } catch (error) {
      console.error('Error initializing doctor video call:', error);
    }
  }

  //  Nurse video call logic - Fixed to remove full-screen settings
  async startNurseVideoCall(): Promise<void> {
    if (this.userType !== 'nurse') return;
    try {
      const tokSession = await this.tokboxService.getTokBoxSession(this.consultationId, this.username);
      this.session = OT.initSession(tokSession.API_KEY, tokSession.SESSION_ID);

      this.publisher = OT.initPublisher('publisher-container', {
        insertMode: 'append',
        width: '100%',
        height: '100%',
      });

      this.session.on('streamCreated', (event) => {
        this.session.subscribe(event.stream, 'subscriber-container', {
          insertMode: 'append',
          width: '100%',
          height: '100%',
        });
      });

      this.session.connect(tokSession.TOKEN, (error) => {
        if (!error) {
          this.session.publish(this.publisher);
          this.isNurseVideoActive = true;
        } else {
          console.error('Error connecting nurse session:', error);
        }
      });
    } catch (error) {
      console.error('Error initializing nurse session:', error);
    }
  }


  async onConnectToDoctor(): Promise<void> {
    // Prevent multiple clicks
    if (this.isConnectToDoctorClicked) {
      console.log('Connect to Doctor already clicked, ignoring subsequent clicks');
      return;
    }

    try {
      // Set flag to prevent multiple clicks
      this.isConnectToDoctorClicked = true;
      
      // Show loader immediately when Connect to Doctor is clicked
      this.isConnectingToDoctor = true;
      this.isVideoStarted = false;

      const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
      const domainName: string = loginResponse?.commondetail?.domainname || loginResponse?.profiledetail?.domainname || 's3test2';
      const token: string = loginResponse?.token || localStorage.getItem('token') || '';
      const nurseUsername: string = loginResponse?.profiledetail?.userName || localStorage.getItem('userName') || '';

      // Call InitiateConsultation API first
      await firstValueFrom(this.docApi.initiateConsultationAsNurse({
        forwardto: 'AndroidRemoteConsultaionWPSevices.do',
        action: 'InitiateConsultation',
        domain: domainName,
        offset: '5:30',
        userType: 'Nurse',
        consType: 'remote',
        consultationId: this.consultationId,
        userName: nurseUsername,
        token
      }));

      // First call checkDoctorStatus API
      await firstValueFrom(this.docApi.checkDoctorStatusAsNurse({
        forwardto: 'AndroidRemoteConsultaionWPSevices.do',
        action: 'checkDoctorStatus',
        domain: domainName,
        offset: '5:30',
        consultationId: this.consultationId,
        userName: nurseUsername,
        token
      }));

      // Switch to remote consultation mode to show video containers
      this.isLocalConsultation = false;
      localStorage.setItem('isLocalConsultation', 'false');
      sessionStorage.setItem('isLocalConsultation', 'false');


      // Establish WebSocket connection for nurse-doctor communication (non-blocking)
      this.establishNurseWebSocketConnection();


      // 1) Start consultation (nurse)
      await firstValueFrom(this.docApi.startConsultationAsNurse({
        forwardto: 'AndroidRemoteConsultaionWPSevices.do',
        action: 'Startconsultaion',
        domain: domainName,
        consultationId: this.consultationId,
        userName: nurseUsername,
        token
      }));

      // 2) Fetch WebRTC credentials
      const webrtcRes = await firstValueFrom(this.docApi.getWebRtcCredentials({
        consId: this.consultationId,
        token
      }));

      const status = webrtcRes?.status ?? webrtcRes?.STATUS;
      if (status !== 'success') {
        throw new Error(webrtcRes?.message || webrtcRes?.msg || 'Failed to get WebRTC credentials');
      }

      const creds = {
        API_KEY: webrtcRes['API_KEY'] ?? webrtcRes?.data?.['API_KEY'],
        SESSION_ID: webrtcRes['SESSION_ID'] ?? webrtcRes?.data?.['SESSION_ID'],
        TOKEN: webrtcRes['TOKEN'] ?? webrtcRes?.data?.['TOKEN'],
      };
      if (!creds.API_KEY || !creds.SESSION_ID || !creds.TOKEN) {
        throw new Error('Incomplete WebRTC credentials');
      }

      // 3) Initialize TokBox as nurse
      await this.tokboxService.initializeSession({
        API_KEY: creds.API_KEY,
        SESSION_ID: creds.SESSION_ID,
        TOKEN: creds.TOKEN,
        STATUS: status || ''
      }, 'nurse');

      // 4) Publish to nurse container
      await this.tokboxService.startPublishing('nurse', 'publisher-container');
      this.isNurseVideoActive = true;

      // Hide loader and show video section when video successfully starts
      this.isConnectingToDoctor = false;
      this.isVideoStarted = true;

    } catch (err) {
      console.error('Connect to Doctor failed:', err);
      // Hide loader on error
      this.isConnectingToDoctor = false;
      this.isVideoStarted = false;
      // Reset flag on error to allow retry
      this.isConnectToDoctorClicked = false;
    }
  }

  endNurseVideoCall(): void {
    if (this.session) {
      this.session.disconnect();
      this.isNurseVideoActive = false;
    }

    // Reset video states
    this.isVideoStarted = false;
    this.isConnectingToDoctor = false;

    // Also disconnect WebSocket when ending video call
    this.disconnectNurseWebSocket();

  }

  // ==================================================================================
  // NULLWEBSOCKET COMMUNICATION SYSTEM - NURSE SIDE
  // ==================================================================================
  // Purpose: Receive and respond to doctor control commands during video consultation
  // Architecture: Nurse stays on patientinfo page during video consultation
  // Communication: Single nullwebsocket connection for bidirectional messaging
  // Pattern: Matches old application - nurse responds to doctor commands
  // ==================================================================================

  private nullWebSocket$: any = null;                    // Single nullwebsocket connection instance
  private isVideoConsultationActive = false;            // Flag to enable/disable doctor control response
  private isDoctorControllingNurse = false;             // Flag indicating if doctor is actively controlling

  // Removed individual dialog ref - now using deviceDialogRefs mapping


  // ==================================================================================


  /**
   * ==================================================================================
   * NULLWEBSOCKET CONNECTION ESTABLISHMENT - NURSE SIDE
   * ==================================================================================
   * Purpose: Establish single nullwebsocket connection for nurse-doctor communication
   * Timing: Runs parallel to video consultation setup (non-blocking)
   * URL Pattern: wss://domain/consultationserverendpoint/room{consultationId}/null
   * Initial Message: "loggedin" (matches old application pattern)
   * Safety: Only runs for remote consultations, skips local consultations
   * ==================================================================================
   */
  private establishNurseWebSocketConnection(): void {
    // Safety check: Only establish nullwebsocket for remote consultations
    if (this.isLocalConsultation) {
      console.log(' [NURSE] Skipping nullwebsocket connection for local consultation');
      return;
    }

    // Run WebSocket connection asynchronously to avoid blocking video setup
    // Small delay ensures TokBox video initialization starts first
    setTimeout(async () => {
      try {
        console.log(`🔌 [NURSE] Establishing nullwebsocket connection for consultation ${this.consultationId}`);
        const socketUrl = `wss://s3test2.remedi.co.in/RemediPRMS/consultationserverendpoint/room${this.consultationId}/null`;

        // Create nullwebsocket connection using existing WebSocket service pattern
        // This connection will receive all doctor control commands
        this.nullWebSocket$ = this.websocketsService['createSocket'](socketUrl, (msg: any) => {
          console.log('📨 [NURSE] Received nullwebsocket message:', msg);
          this.handleNullWebSocketMessage(msg);
        });

        // Send initial "loggedin" message after connection establishment
        // This matches the old application pattern: Nurse sends "loggedin" after doctor
        setTimeout(() => {
          this.sendNullWebSocketMessage('loggedin');
          console.log('✅ [NURSE] Sent initial "loggedin" message via nullwebsocket');
        }, 500);

      } catch (error) {
        console.warn('⚠️ [NURSE] Nullwebsocket connection failed (non-blocking):', error);
        // Don't throw error - video consultation should continue even if nullwebsocket fails
      }
    }, 100); // Small delay to ensure video setup starts first
  }


  // Send message via nullwebsocket to doctor
  private sendNullWebSocketMessage(message: string): void {
    try {
      if (this.nullWebSocket$) {
        this.nullWebSocket$.next(message);
      }
    } catch (error) {
      // Silent error handling for nullwebsocket messages
    }
  }

  // Handle incoming nullwebsocket messages from doctor
  private handleNullWebSocketMessage(message: any): void {
    try {
      // Parse message if it's a JSON string
      let parsedMessage = message;
      if (typeof message === 'string') {
        try {
          parsedMessage = JSON.parse(message);
        } catch {
          // If not JSON, treat as plain string
          parsedMessage = { message: message };
        }
      }

      // Handle doctor's "loggedin" message
      if (parsedMessage?.message === 'loggedin' || message === 'loggedin') {
        this.sendNullWebSocketMessage('loggedinsuccess');
        this.showDoctorConnectedFeedback();
        this.isVideoConsultationActive = true;
      }

      // Handle doctor control messages during video consultation
      else if (this.isVideoConsultationActive && !this.isLocalConsultation) {
        this.handleDoctorControlMessage(parsedMessage);
      }

    } catch (error) {
      // Silent error handling for nullwebsocket messages
    }
  }

  // Device configuration for nurse-side handling
  private nurseDeviceConfig: { [key: string]: { component: any; dialogConfig: any; activationMethod?: string } } = {
    'stethoscope': {
      component: StethoscopeDevicePage,
      dialogConfig: {
        width: "95vw", height: "95vh", maxWidth: "1400px", maxHeight: "900px",
        minWidth: "800px", minHeight: "600px", panelClass: 'stethoscope-dialog-panel'
      },
      activationMethod: 'activateStethoscope'
    },
    'fetaldopler': {
      component: FetalDopplerDevicePage,
      dialogConfig: {
        width: "95vw", height: "95vh", maxWidth: "1400px", maxHeight: "900px",
        minWidth: "800px", minHeight: "600px", panelClass: 'fetal-doppler-dialog-panel'
      },
      activationMethod: 'activateFetalDoppler'
    },
    'temperature': {
      component: ThermometerPage,
      dialogConfig: {
        width: "1000px", height: "480px", maxWidth: "1000px", maxHeight: "480px",
        panelClass: 'spo2-dialog-panel'
      },
      activationMethod: 'activateTemperature'
    } ,
      'spo2': {
      component: Spo2DevicePage,
      dialogConfig: {
        width: "1000px", height: "480px", maxWidth: "1000px", maxHeight: "480px",
        panelClass: 'spo2-dialog-panel'
      },
      activationMethod: 'activatespo2'
   },
    'electrocardiogram': {
          component: EcgJettyDevicePage,
          dialogConfig: {
            panelClass: 'ecg-dialog-panel'
          },
        activationMethod: 'activateelectrocardiogram'
    },
     'mecginterpretation': {
          component: EcgInterpretationManualJettyComponent,
          dialogConfig: {
            panelClass: 'ecg-dialog-panel'
          },
        activationMethod: 'activatemecginterpretation'
    },
     'pecginterpretation': {
          component: EcgInterpretationJettyDeviceComponent,
          dialogConfig: {
            panelClass: 'ecg-dialog-panel'
          },
        activationMethod: 'activatepecginterpretation'
    },
    'spirometer': { 
      component: SpirometerJettyDevicePage,
      dialogConfig: {
        width: '1000px',
        maxWidth: '1000px',
        height: 'auto',
        panelClass: 'custom-spiro-dialog'
      },
      activationMethod: 'activateSpirometer'
    },    // Add other devices here as needed
  };

  private deviceDialogRefs: { [key: string]: MatDialogRef<any> | null } = {};

  /**
   * ==================================================================================
   * HANDLE DOCTOR CONTROL MESSAGES - Nurse response to doctor commands
   * ==================================================================================
   * Purpose: Process doctor control commands and perform corresponding actions
   * Pattern: Matches old application - nurse automatically responds to doctor
   * Safety: Only processes messages when video consultation is active
   * Actions: UI changes, device activation, automatic responses
   * ==================================================================================
   */
  // Process doctor control commands and perform corresponding actions
  private handleDoctorControlMessage(message: any): void {
    const messageText = message?.message || message;
    console.log('🤖 [NURSE] Processing doctor control message:', messageText);
    // Only process messages if user is nurse
    if (this.usertype !== 'Nurse') {
      return;
    }

    // Handle kit control messages
    if (messageText === 'Kit_Start') {
      this.handleKitStart();
      this.sendNullWebSocketMessage('connectedBle');
      this.sendNullWebSocketMessage('kitstatus_1001');
    } else if (messageText === 'Kit_Stop') {
      this.handleKitStop();
    }
    // Handle device-specific messages
    else if (messageText.startsWith('ble_')) {
      this.handleDeviceMessage(messageText);
    }
    else if (messageText == 'open_spo2_manual'){
      this.paramsPage.openPulseOximeterManual()
    }
 else if(messageText == 'open_Bp_manual'){
      this.paramsPage.openBloodPressureComponent();
    }
     else if(messageText == 'open_spiro_manual'){
      this.paramsPage.openSpirometerManualComponent();
    }
    else if(messageText == 'open_temp_manual'){
    // Handle other messages
    this.paramsPage.openTemperatureManualComponent();
  }    else {
      this.handleOtherMessages(messageText);
    }
  }

  // Handle kit activation from doctor
  private handleKitStart(): void {
    this.isDoctorControllingNurse = true;
    this.showParametersTab();
    this.sendNullWebSocketMessage('ble_msgFromBLEApplet_true_Dongle connected successfully._2');
  }

  // Handle kit deactivation from doctor
  private handleKitStop(): void {
    this.hideParametersTab();
    this.isDoctorControllingNurse = false;
    this.sendNullWebSocketMessage('error_stop scan status');
  }

  // Process device-specific messages from doctor
  private handleDeviceMessage(messageText: string): void {
    const deviceType = this.extractDeviceType(messageText);

    if (messageText.includes('_start')) {
      this.openDeviceDialog(deviceType);
    } else if (messageText === 'ble_close') {
      this.closeAllDeviceDialogs();
    } else if (messageText.includes('enable') && messageText.includes('ble')) {
      this.handleDeviceEnable(deviceType, messageText);
    }
  }

  // Handle non-device messages from doctor
  private handleOtherMessages(messageText: string): void {
    switch (messageText) {
      case 'ble_msgFromBLEApplet_true_Dongle connected successfully._2':
        // Doctor sent dongle connection message - parameters tab will be active
        break;
      case 'SuspendByDoctor':
        this.handleDoctorSuspend();
        break;
      case 'FinishByDoctor':
        this.handleDoctorFinish();
        break;
    }
  }

  // Handle doctor suspend - redirect nurse to dashboard
  private handleDoctorSuspend(): void {
    try {
      // Clean up video consultation
      this.endNurseVideoCall();
      this.disconnectNurseWebSocket();

      // Clear consultation data
      localStorage.removeItem('isLocalConsultation');
      sessionStorage.removeItem('isLocalConsultation');
      sessionStorage.removeItem('walkinCon');
      localStorage.removeItem('consultationId');
      sessionStorage.removeItem('consultationId');

      // Use NgZone for Electron compatibility
      this.ngZone.run(() => {
        this.router.navigate(['/doctor-dashboard']);
      });
    } catch (error) {
      // Still redirect even if cleanup fails
      this.router.navigate(['/doctor-dashboard']);
    }
  }

  // Handle doctor finish - redirect nurse to dashboard
  private handleDoctorFinish(): void {
    try {
      // Clean up video consultation
      this.endNurseVideoCall();
      this.disconnectNurseWebSocket();

      // Clear consultation data
      localStorage.removeItem('isLocalConsultation');
      sessionStorage.removeItem('isLocalConsultation');
      sessionStorage.removeItem('walkinCon');
      localStorage.removeItem('consultationId');
      sessionStorage.removeItem('consultationId');
      sessionStorage.setItem('dialogRef', 'finish');

      // Use NgZone for Electron compatibility
      this.ngZone.run(() => {
        this.router.navigate(['/doctor-dashboard']);
      });
    } catch (error) {
      // Silent error handling - still redirect
      // Still redirect even if cleanup fails
      this.router.navigate(['/doctor-dashboard']);
    }
  }

  /**
   * 🔍 EXTRACT DEVICE TYPE - Extract device type from message
   */
  private extractDeviceType(messageText: string): string {
    if (messageText.includes('stetho')) return 'stethoscope';
    if (messageText.includes('fetalDopler') || messageText.includes('fetal')) return 'fetaldopler'; if (messageText.includes('fetalDopler') || messageText.includes('fetal')) return 'fetaldopler';
    if (messageText.includes('mecginterpretation')) return 'mecginterpretation';
    if (messageText.includes('pecginterpretation')) return 'pecginterpretation';
    if (messageText.includes('ecg')) return 'electrocardiogram';
    if (messageText.includes('spo2')) return 'spo2';
    if (messageText.includes('temp')) return 'temperature';
    if (messageText.includes('bp')) return 'bloodpressure';
    if (messageText.includes('hb')) return 'hemoglobin';
    if (messageText.includes('glucose')) return 'glucose';
    if (messageText.includes('spiro')) return 'spirometer';
    return 'unknown';
  }

  /**
   * 🎛️ HANDLE DEVICE ENABLE - Handle device enable messages
   */
  private handleDeviceEnable(deviceType: string, messageText: string): void {
    console.log(`🩺 [NURSE] Doctor enabled ${deviceType} - activating device and opening parameters tab`);
    this.isDoctorControllingNurse = true;
    this.showParametersTab();

    // Activate device if activation method exists
    const config = this.nurseDeviceConfig[deviceType];
    if (config?.activationMethod && typeof (this as any)[config.activationMethod] === 'function') {
      (this as any)[config.activationMethod]();
    }

    // Send confirmation response
    this.sendNullWebSocketMessage(messageText);
  }

  // ==================================================================================
  // NURSE UI CONTROL METHODS - Automatic UI changes based on doctor commands
  // ==================================================================================
  // Purpose: Automatically control nurse-side UI based on doctor's actions
  // Pattern: Doctor controls nurse dashboard remotely via nullwebsocket
  // Safety: Only works during video consultation, preserves local consultation flow
  // Methods: showParametersTab, hideParametersTab, activateStethoscope, startStethoscopeRecording
  // ==================================================================================


  private showParametersTab(): void {
    try {
      if (this.usertype !== 'Nurse') {
        console.log('⚠️ [NURSE] Cannot show parameters tab - user is not nurse');
        return;
      }

      console.log('🔧 [NURSE] Attempting to show parameters tab using multiple strategies...');

      // Use NgZone to ensure DOM manipulation works in Electron
      this.ngZone.runOutsideAngular(() => {
        // Strategy 1: Direct DOM button click (most reliable for Electron)
        setTimeout(() => {
          const parametersButton = document.querySelector('button[role="tab"]:nth-child(4)') as HTMLElement;
          if (parametersButton && parametersButton.textContent?.includes('Parameters')) {
            parametersButton.click();
            console.log('✅ [NURSE] Parameters tab activated via direct DOM click (Strategy 1)');
            return;
          }

          // Strategy 2: Find button by text content
          const buttons = document.querySelectorAll('button[role="tab"]');
          for (let i = 0; i < buttons.length; i++) {
            const button = buttons[i];
            if (button.textContent?.includes('Parameters')) {
              (button as HTMLElement).click();
              console.log('✅ [NURSE] Parameters tab activated via text search (Strategy 2)');
              return;
            }
          }

          // Strategy 3: Use tabs component if available
          if (this.tabsComponent) {
            this.tabsComponent.switchTab('parameters');
            console.log('✅ [NURSE] Parameters tab activated via tabs component (Strategy 3)');
            return;
          }

          // Strategy 4: Trigger click event programmatically
          const clickEvent = new MouseEvent('click', {
            view: window,
            bubbles: true,
            cancelable: true
          });

          const paramButton = document.querySelector('button[onclick*="parameters"]') as HTMLElement;
          if (paramButton) {
            paramButton.dispatchEvent(clickEvent);
            console.log('✅ [NURSE] Parameters tab activated via event dispatch (Strategy 4)');
            return;
          }

          console.error('❌ [NURSE] All strategies failed to open parameters tab');
        }, 100); // Small delay to ensure DOM is ready
      }); // Close NgZone.runOutsideAngular

    } catch (error) {
      console.error('❌ [NURSE] Error showing parameters tab:', error);
    }
  }

  /**
   * Hide parameters tab when doctor stops kit
   * Switches back to a default tab (patient history) using multiple strategies
   */
  private hideParametersTab(): void {
    try {
      if (this.usertype !== 'Nurse') {
        console.log('⚠️ [NURSE] Cannot hide parameters tab - user is not nurse');
        return;
      }

      console.log('🛑 [NURSE] Attempting to hide parameters tab and switch to patient history...');

      // Use NgZone to ensure DOM manipulation works in Electron
      this.ngZone.runOutsideAngular(() => {
        // Strategy 1: Direct DOM button click for Patient History (first button)
        setTimeout(() => {
          const patientHistoryButton = document.querySelector('button[role="tab"]:first-child') as HTMLElement;
          if (patientHistoryButton && patientHistoryButton.textContent?.includes('Patient')) {
            patientHistoryButton.click();
            console.log('✅ [NURSE] Switched to patient history via direct DOM click (Strategy 1)');
            return;
          }

          // Strategy 2: Find button by text content
          const buttons = document.querySelectorAll('button[role="tab"]');
          for (let i = 0; i < buttons.length; i++) {
            const button = buttons[i];
            if (button.textContent?.includes('Patient History')) {
              (button as HTMLElement).click();
              console.log('✅ [NURSE] Switched to patient history via text search (Strategy 2)');
              return;
            }
          }

          // Strategy 3: Use tabs component if available
          if (this.tabsComponent) {
            this.tabsComponent.switchTab('patientHistory');
            console.log('✅ [NURSE] Switched to patient history via tabs component (Strategy 3)');
            return;
          }

          // Strategy 4: Trigger click event programmatically
          const clickEvent = new MouseEvent('click', {
            view: window,
            bubbles: true,
            cancelable: true
          });

          const historyButton = document.querySelector('button[onclick*="patientHistory"]') as HTMLElement;
          if (historyButton) {
            historyButton.dispatchEvent(clickEvent);
            console.log('✅ [NURSE] Switched to patient history via event dispatch (Strategy 4)');
            return;
          }

          console.error('❌ [NURSE] All strategies failed to switch to patient history tab');
        }, 100); // Small delay to ensure DOM is ready
      }); // Close NgZone.runOutsideAngular

    } catch (error) {
      console.error('❌ [NURSE] Error hiding parameters tab:', error);
    }
  }




  /**
   * 🩺 REUSABLE BLE DEVICE OPENER - Works for all BLE medical devices
   * Handles BLE scanning, connection detection, and dialog opening
   */
  private async openBleDevicePage(deviceType: string, scanCode: string, connectionMessages: string[], sensorMessages: string[]): Promise<void> {
    console.log(`[NURSE] ${deviceType} device triggered!`);
    this.websocketsService.sendBleMessage(`startScanFromHtml~${scanCode}`);

    try {
      const deviceSubscription = this.websocketsService.bleValueObs$.subscribe((data) => {
        console.log(`[NURSE] Received ${deviceType} BLE data:`, data);

        if (data === "errorLableUpdate~start scan status : Success!") {
          console.log(`[NURSE] ${deviceType} scan started successfully`);
        } else if (connectionMessages.some(msg => data === msg || data.includes(msg))) {
          console.log(`[NURSE] ${deviceType} sensor connected`);
        } else if (sensorMessages.some(msg => data === msg || data.includes(msg))) {
          console.log(`[NURSE] Opening ${deviceType} dialog`);

          deviceSubscription.unsubscribe();

          const config = this.nurseDeviceConfig[deviceType.toLowerCase()];
          if (!config) {
            console.error(`[NURSE] No configuration found for ${deviceType}`);
            return;
          }

          const dialogRef = this.dialog.open(config.component, {
            ...config.dialogConfig,
            disableClose: true,
            data: { api: "withoutApiCalling" }
          });

          dialogRef.afterClosed().subscribe((result) => {
            console.log(`[NURSE] ${deviceType} dialog closed`);
            this.websocketsService.sendBleMessage("ble_close");
            if (result !== undefined) {
              console.log(`[NURSE] ${deviceType} result:`, result);
            }
          });
        }
      });
    } catch (error) {
      console.error(`[NURSE] Error in open${deviceType}DevicePage:`, error);
    }
  }

  /**
   * Open Fetal Doppler Device Page - Uses reusable BLE opener
   */
  async openFetalDopplerDevicePage() {
    // Send nullwebsocket messages for video consultation
    // if (!this.isLocalConsultation) {
    //   this.sendNullWebSocketMessage('connectedBle');
    //   this.sendNullWebSocketMessage('kitstatus_1001');
    // }

    await this.openBleDevicePage(
      'FetalDoppler',
      '70',
      ['errorLableUpdate~FETAL Doppler connected successfully.', 'errorLableUpdate~FETALDoppler connected successfully.'],
      ['SensorConnected~FETALDoppler~70', 'FetalDopplerConnected', 'SensorConnected~FetalDoppler~70']
    );
  }

  /**
   * Open Temperature Device Page - Uses reusable BLE opener
   */
  async openTemperatureDevicePage() {
    // Send nullwebsocket messages for video consultation
    // if (!this.isLocalConsultation) {
    //   this.sendNullWebSocketMessage('connectedBle');
    //   this.sendNullWebSocketMessage('kitstatus_1001');
    // }

    await this.openBleDevicePage(
      'Temperature',
      '40',
      ['errorLableUpdate~Temperature connected successfully.', 'TemperatureConnected'],
      ['SensorConnected~Temperature~71', 'SensorConnected~Temperature~40']
    );
  }

     async openECGDevicePage() {
     await this.openBleDevicePage(
      'Electrocardiogram',
      '10',
      ['errorLableUpdate~Electrocardiogram connected successfully.', 'ElectrocardiogramConnected'],
      ['SensorConnected~Electrocardiogram~10', 'SensorConnected~Electrocardiogram']
    );
  }

     async openMECGIPage() {
     await this.openBleDevicePage(
      'mecginterpretation',
      '102',
      ['errorLableUpdate~Electrocardiogram connected successfully.', 'ElectrocardiogramConnected'],
      ['SensorConnected~Electrocardiogram~102', 'SensorConnected~Electrocardiogram']
    );
  }

    async openPECGIPage() {
     await this.openBleDevicePage(
      'pecginterpretation',
      '102',
      ['errorLableUpdate~Electrocardiogram connected successfully.', 'ElectrocardiogramConnected'],
      ['SensorConnected~Electrocardiogram~102', 'SensorConnected~Electrocardiogram']
    );
  }

  /**
   * 🎵 REUSABLE DEVICE DIALOG OPENER - Works for all medical devices
   * Opens device-specific dialog on nurse side for doctor control
   */
  private openDeviceDialog(deviceType: string): void {
    try {
      if (this.usertype !== 'Nurse') {
        console.log(`⚠️ [NURSE] Cannot open ${deviceType} dialog - user is not nurse`);
        return;
      }

      if (this.deviceDialogRefs[deviceType]) {
        console.log(`⚠️ [NURSE] ${deviceType} dialog already open`);
        return;
      }

      const config = this.nurseDeviceConfig[deviceType];
      if (!config) {
        console.warn(`⚠️ [NURSE] No configuration found for device: ${deviceType}`);
        return;
      }

      console.log(`🎵 [NURSE] Opening ${deviceType} dialog for doctor control`);

      // Send nullwebsocket messages for video consultation
      // if (!this.isLocalConsultation) {
      //   this.sendNullWebSocketMessage('connectedBle');
      //   this.sendNullWebSocketMessage('kitstatus_1001');
      // }

      // Open device dialog
      this.deviceDialogRefs[deviceType] = this.dialog.open(config.component, {
        ...config.dialogConfig,
        disableClose: true,
        data: { api: "withoutApiCalling" }
      });

      // Handle dialog close
      this.deviceDialogRefs[deviceType]!.afterClosed().subscribe((result) => {
        console.log(`🔒 [NURSE] ${deviceType} dialog closed`);
        this.deviceDialogRefs[deviceType] = null;
        // Send close confirmation to doctor
        this.sendNullWebSocketMessage('ble_close');
      });

      console.log(`✅ [NURSE] ${deviceType} dialog opened successfully`);

    } catch (error) {
      console.error(`❌ [NURSE] Error opening ${deviceType} dialog:`, error);
    }
  }

  /**
   * 🔒 REUSABLE DEVICE DIALOG CLOSER - Works for all medical devices
   * Closes specific device dialog on nurse side
   */
  private closeDeviceDialog(deviceType: string): void {
    try {
      if (this.usertype !== 'Nurse') {
        console.log(`⚠️ [NURSE] Cannot close ${deviceType} dialog - user is not nurse`);
        return;
      }

      if (!this.deviceDialogRefs[deviceType]) {
        console.log(`⚠️ [NURSE] No ${deviceType} dialog to close`);
        return;
      }

      console.log(`🔒 [NURSE] Closing ${deviceType} dialog by doctor command`);

      // Close the dialog
      this.deviceDialogRefs[deviceType]!.close();
      this.deviceDialogRefs[deviceType] = null;

      console.log(`✅ [NURSE] ${deviceType} dialog closed successfully`);

    } catch (error) {
      console.error(`❌ [NURSE] Error closing ${deviceType} dialog:`, error);
    }
  }

  /**
   * 🔒 CLOSE ALL DEVICE DIALOGS - Called when doctor sends ble_close
   * Closes all open device dialogs on nurse side
   */
  private closeAllDeviceDialogs(): void {
    console.log('🔒 [NURSE] Closing all device dialogs by doctor command');

    Object.keys(this.deviceDialogRefs).forEach(deviceType => {
      if (this.deviceDialogRefs[deviceType]) {
        this.closeDeviceDialog(deviceType);
      }
    });
  }





  /**
   * Establish WebSocket connection for doctor side
   */
  private establishDoctorWebSocketConnection(): void {
    if (this.isLocalConsultation) {
      console.log('🔍 [DOCTOR] Skipping nullwebsocket connection for local consultation');
      return;
    }

    setTimeout(async () => {
      try {
        console.log(`🔌 [DOCTOR] Establishing nullwebsocket connection for consultation ${this.consultationId}`);
        const socketUrl = `wss://s3test2.remedi.co.in/RemediPRMS/consultationserverendpoint/room${this.consultationId}/null`;

        this.nullWebSocket$ = this.websocketsService['createSocket'](socketUrl, (msg: any) => {
          console.log('📨 [DOCTOR] Received nullwebsocket message:', msg);
        });

        console.log('✅ [DOCTOR] Nullwebsocket connection established successfully');
      } catch (error) {
        console.warn('⚠️ [DOCTOR] Nullwebsocket connection failed:', error);
      }
    }, 100);
  }

  /**
   * Disconnect nullwebsocket connection
   */
  private disconnectNurseWebSocket(): void {
    try {
      if (this.nullWebSocket$) {
        this.nullWebSocket$.complete();
        this.nullWebSocket$ = null;
        this.isVideoConsultationActive = false;
        this.isDoctorControllingNurse = false;
        console.log('🔌 Nurse nullwebsocket disconnected');
      }
    } catch (error) {
      console.error('❌ Error disconnecting nurse nullwebsocket:', error);
    }
  }

  /**
   * Show UI feedback when doctor connects
   */
  private showDoctorConnectedFeedback(): void {
    // Optional: Show snackbar or toast notification
    console.log('🎉 Doctor is now connected to the consultation');
    // You can add UI feedback here if needed
    // this.snackBar.open('Doctor connected successfully', 'Close', { duration: 3000 });
  }

  /**
   * Test method to validate nullwebsocket connection (for debugging)
   */
  testWebSocketConnection(): void {
    console.log('🧪 Testing nullwebsocket connection status:');

    console.log('NullWebSocket Instance:', this.nullWebSocket$ ? 'Connected' : 'Disconnected');
    console.log('Video Consultation Active:', this.isVideoConsultationActive);
    console.log('Doctor Controlling Nurse:', this.isDoctorControllingNurse);

  }

  /**
   * Disable tabs for nurse during parameters session
   */
  private disableTabsForNurse(): void {
    if (this.usertype === 'Nurse' && this.isVideoConsultationActive) {
      if (this.tabsComponent) {
        this.tabsComponent.disableTabs();
        console.log('🔒 [NURSE] Tabs disabled during parameters session');
      }
    }
  }

  /**
   * Enable tabs for nurse when parameters session ends
   */
  private enableTabsForNurse(): void {
    if (this.usertype === 'Nurse' && this.isVideoConsultationActive) {
      if (this.tabsComponent) {
        this.tabsComponent.enableTabs();
        console.log('✅ [NURSE] Tabs enabled after parameters session');
      }
    }
  }



  // Camera and Microphone selection methods
  toggleCameraDropdown(): void {
    this.showCameraDropdown = !this.showCameraDropdown;
    this.showMicDropdown = false; // Close mic dropdown if open
  }

  selectCamera(device: MediaDeviceInfo): void {
    this.selectedCameraId = device.deviceId;
    this.showCameraDropdown = false;
    console.log('Selected camera:', device.label);
  }

  toggleMicDropdown(): void {
    this.showMicDropdown = !this.showMicDropdown;
    this.showCameraDropdown = false; // Close camera dropdown if open
  }

  selectMic(device: MediaDeviceInfo): void {
    this.selectedMicId = device.deviceId;
    this.showMicDropdown = false;
    console.log('Selected microphone:', device.label);
  }

  //  ngOnDestroy lifecycle hook to clean up signaling subscription
  ngOnDestroy(): void {
    if (this.signalingSubscription) {
      this.signalingSubscription.unsubscribe();
      this.signalingSubscription = null;
    }
  }

  //  Toggle fullscreen for video containers
  toggleFullscreen(containerId: string): void {
    const container = document.getElementById(containerId);
    if (container) {
      if (document.fullscreenElement) {
        // Exit fullscreen
        document.exitFullscreen().catch(err => {
          console.error('Error exiting fullscreen:', err);
        });
      } else {
        // Enter fullscreen
        container.requestFullscreen().catch(err => {
          console.error('Error entering fullscreen:', err);
        });
      }
    }
  }

  viewPatReadings() {
     console.log('viewPatReadings report clicked');
  const consultationnId = localStorage.getItem('consultationId') || '';
  const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
  const patienttId = patientDetails.patientid || patientDetails.domainwisepid || '';

  console.log('Retrieved consultationId from localStorage:', consultationnId);
  console.log('Retrieved patientId from localStorage:', patienttId);

  if (!consultationnId) {
    console.error('No consultation ID found in localStorage');
    return;
  }

  if (!patienttId) {
    console.error('No patient ID found in localStorage');
    return;
  }

    const dialogRef = this.dialog.open(ViewPatientReadingsPage, {
      maxWidth: "1289px", // Adjusted to match the modal's max-width
      height: "auto",
      maxHeight: "90vh", // Prevent overflow on smaller screens
          data: {
      id: consultationnId,        // Pass consultation ID
      ptId: patienttId,          // Pass patient ID
      dt: new Date().toISOString() // Pass current datetime
    },
      panelClass: 'view-patient-readings-dialog',
      disableClose: true,
      autoFocus: false // Prevents automatic focus on first element
    });

    dialogRef.afterClosed();
  }

  /** Other existing methods like suspendConsultationConfirm, saveSuspendRequestToPouch, etc., remain unchanged */

  // Follow-up checkbox functionality
  onFollowUpChange(event: any): void {
    const isChecked = event.target.checked;
    
    if (isChecked) {
      // Show confirmation dialog
      this.showFollowUpConfirmation();
    } else {
      // If unchecked, just update the state
      this.isFollowUpChecked = false;
    }
  }

  private showFollowUpConfirmation(): void {
    const dialogRef = this.dialog.open(CommonDialogPage, {
      width: 'auto',
      height: 'auto',
      data: {
        data: 'follow-up-confirmation',
        message: 'Consultation marked as follow up.'
      },
      panelClass: 'follow-up-dialog',
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 'ok' || result === 'yes') {
        // User confirmed - call API and update checkbox
        this.callFollowUpAPI(true);
        this.isFollowUpChecked = true;
      } else {
        // User cancelled - uncheck the checkbox
        this.isFollowUpChecked = false;
      }
    });
  }

  private callFollowUpAPI(isFollowUp: boolean): void {
    const domainId = localStorage.getItem('domainId') || '1';
    const token = this.tokenRequest || localStorage.getItem('token') || '';
    const consultationId = this.consultationId || localStorage.getItem('consultationId') || '';
    
    const queryParams = `?action=checkoruncheckforfollowup&domain=${domainId}&token=${token}&check=${isFollowUp}&consultationId=${consultationId}`;
    
    this.apiSvc.postServiceByQueryBasic(this.constantSvc.APIConfig.GETCOMMONSERVICES, queryParams).subscribe({
      next: (response: any) => {
        console.log('Follow-up API response:', response);
        if (response.status === 'success') {
          console.log('Follow-up status updated successfully');
        } else {
          console.warn('Follow-up API returned non-success status:', response);
        }
      },
      error: (error) => {
        console.error('Error calling follow-up API:', error);
        // Reset checkbox on error
        this.isFollowUpChecked = false;
      }
    });
  }

}




































