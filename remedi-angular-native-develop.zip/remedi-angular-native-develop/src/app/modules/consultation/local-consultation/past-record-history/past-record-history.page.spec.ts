import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PastRecordHistoryPage } from './past-record-history.page';

describe('PastRecordHistoryPage', () => {
  let component: PastRecordHistoryPage;
  let fixture: ComponentFixture<PastRecordHistoryPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PastRecordHistoryPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
