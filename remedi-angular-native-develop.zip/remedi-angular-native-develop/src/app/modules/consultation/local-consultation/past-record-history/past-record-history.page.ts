import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  OnDestroy,
  AfterViewInit,
  Inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule, ModalController } from '@ionic/angular';
import { Subscription } from 'rxjs';
import * as Highcharts from 'highcharts/highstock';
import { WebsocketsService } from 'src/app/core/services/websocket.service';
import { MatTooltipModule } from '@angular/material/tooltip';
import { PouchdbService } from 'src/app/core/services/pouchdb.service';
import { SaveSpo2DataRequest, SaveSpo2FileDataRequest } from 'src/app/core/interfaces/prms/spo2-data.model';
import { ApiService } from 'src/app/core/services/api.service';
import { ConstantService } from 'src/app/core/services/constant.service';
import * as CryptoJS from 'crypto-js';
import { NetworkService } from 'src/app/core/services/network.service';
import { TranslateModule } from '@ngx-translate/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { Spo2DevicePage } from 'src/app/modules/prms/ble-device/spo2-device/spo2-device.page';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { EcgJettyDevicePage } from 'src/app/modules/prms/ble-device/ecg-jetty-device/ecg-jetty-device.page';
import { SpirometerJettyDevicePage } from 'src/app/modules/prms/ble-device/spirometer-jetty-device/spirometer-jetty-device.page';
interface VitalsResponse {
  status: string;
  consultationId: any;
  data: {
    spiro_filepath: any;
    ecg_filepath: any;
    stetho_filepath?: any[];
    fetal_filepath?: any[];
    temperature?: any[];
    bpSystolic?: any[];
    bpDiastolic?: any[];
    pulse?: any[];
    triglycerides?: any[];
    glucose?: any[];
    glucoseFasting?: any[];
    glucosePostprandial?: any[];
    glucoseRandom?: any[];
    hemoglobin?: any[];
    spo2?: any[];
    spo2_OxygenSaturation_Percentage?: Record<string, any>;
    // add other fields as needed
    rapidreader?: any[];
    testimage?: any[];
    GLU?: any[];
    BIL?: any[];
    KET?: any[];
    SG?: any[];
    BLO?: any[];
    pH?: any[];
    PRO?: any[];
    URO?: any[];
    NIT?: any[];
    LEU?: any[];

  };
  isUrineTestTaken?: number;
}

@Component({
  selector: 'app-past-record-history',
  templateUrl: './past-record-history.page.html',
  styleUrls: ['./past-record-history.page.scss'],
  standalone: true,
  imports: [CommonModule, IonicModule, FormsModule, TranslateModule,]
})
export class PastRecordHistoryPage implements OnInit {
   todayDate: string = '';

  bpIndex: any = 0;
  spo2Index: any = 0;
  getPatientData: any;
  currDomainId: any;
  tokenRequest: any = '';
  imageList: any;
  showReportDate: boolean | undefined;
  consulReportList: any = [];
  vitalsData: any;
  isUrineTest: any;

  tempMax: number | undefined;
  spiroMax: number | undefined;
  sysMax: number | undefined;
  diaMax: number | undefined;
  pulseMax: number | undefined;
  randomMax!: number;
  fastingMax!: number;
  postMax!: number;
  testResultData: any;
  username: any;
  usertype: any;
  bilMax!: number;
  triglyceridesMax: number | undefined;

  consultationList: any[] = [];
  selectedRecord: any = null;
  consultationId: any;
  patientId: any;
  language: any;
  ecgIndex: number | undefined;
  spiroIndex: any;
  // constructor(
  //   private modalCtrl: ModalController,
  //   private websocketsService: WebsocketsService,
  //   @Inject(MAT_DIALOG_DATA) public data: any,
  //   private pouchdbService: PouchdbService,
  //   private constantSvc: ConstantService,
  //   private apiSvc: ApiService,
  //     private dialog: MatDialog,
  //       private authService: AuthService,
  //   private networkService: NetworkService,
  //     // @Inject(MAT_DIALOG_DATA) public data: any,
  // // @Optional() private dialogRef: MatDialogRef<PastrecordsPage>
  //   private dialogRef: MatDialogRef<PastRecordHistoryPage>
  // ) { }
  glucoseIndex: any = 0;
  rapidIndex: any = 0;
  urineTestIndex: any = 0;
  // Rapid reader properties
  rapidImageData: any[] = [];

  // Urine test properties
  TestName = [
    {
      id: 1,
      name: "LEUKOCYTES",
      unit: "-Leu/µL",
      test: "LEU",
      value: "-Leu/µL",
    },
    {
      id: 2,
      name: "NITRITE",
      unit: "+",
      test: "NIT",
      value: "+",
    },
    {
      id: 3,
      name: "UROBILINOGEN",
      unit: "-mg/dL",
      test: "URO",
      value: "mg/dL",
    },
    {
      id: 4,
      name: "PROTEIN",
      unit: "6.5",
      test: "PRO",
      value: "6.5",
    },
    {
      id: 5,
      name: "pH",
      unit: "-Ery/µL",
      test: "pH",
      value: "-Ery/µL",
    },
    {
      id: 6,
      name: "BLOOD",
      unit: "1.030",
      test: "BLO",
      value: "1.030",
    },
    {
      id: 7,
      name: "SPECIFIC_GRAVITY",
      unit: "mg/dL",
      test: "SG",
      value: "mg/dL",
    },
    {
      id: 8,
      name: "KETONE",
      unit: "mg/dL",
      test: "KET",
      value: "mg/dL",
    },
    {
      id: 9,
      name: "BILIRUBIN",
      unit: "100+-",
      test: "BIL",
      value: "100+-",
    },
    {
      id: 10,
      name: "GLUCOSE",
      unit: "mg/dL",
      test: "GLU",
      value: "mg/dL",
    },
  ];

  urineTestData: any[] = [];
  urineTestFullData: any[] = [];
  selectedSpiroIndex: number | undefined;
  showSpo2UI: boolean = false; // default hidden
  LipidIndex=0;
   pastHbA1cRecords: any[] = [];
  selectedHbA1cRecord: any = null;
  loadingPastRecords = false
  cdr: any;
    readings: any[] = [];

    todayFormatted: string = '';
  HbA1cIndex=0;
  constructor(
    private modalCtrl: ModalController,
    private _http: HttpClient,
    private websocketsService: WebsocketsService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private pouchdbService: PouchdbService,
    private constantSvc: ConstantService,
    private apiSvc: ApiService,
    private dialog: MatDialog,
    private authService: AuthService,
    private networkService: NetworkService,
    public dialogRef: MatDialogRef<PastRecordHistoryPage>
  ) { }


  ngOnInit() {
        this.readings = this.data.readings || [];
 this.todayFormatted = this.getFormattedDate(new Date());
    const loginResponseStr = localStorage.getItem('LOGIN_RESPONSE');

    const currentSession = this.authService.getCurrentSession();

    this.tokenRequest = this.authService.getToken() || '';
    this.username = currentSession?.username || '';
    this.currDomainId = currentSession?.domainId || '';
    this.language = currentSession?.language || '';

    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    this.patientId = patientDetails.patientid || '';
    this.consultationId = localStorage.getItem('consultationId') || '';
    // const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    // this.tokenRequest = loginResponse.token ?? localStorage.getItem('token') ?? '';
    // this.currDomainId = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
    // this.username = loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? '';
    // this.usertype = loginResponse.commondetail?.usertype ?? localStorage.getItem('usertype') ?? '';
    console.log('Token:', this.tokenRequest);

    this.getVitals()

  }

  getFormattedDate(date: Date): string {
    const day = date.getDate();
    const month = date.toLocaleString('default', { month: 'long' }); // Full month name
    const year = date.getFullYear();

    // Add ordinal suffix
    const ordinal = this.getOrdinalSuffix(day);

    // Add leading zero for day
    const dayWithZero = day < 10 ? '0' + day : day;

    return `${dayWithZero}${ordinal} ${month}, ${year}`;
  }

  getOrdinalSuffix(day: number): string {
    if (day > 3 && day < 21) return 'th'; // 4-20 is 'th'
    switch (day % 10) {
      case 1: return 'st';
      case 2: return 'nd';
      case 3: return 'rd';
      default: return 'th';
    }
  }


onReadingClick(index: number) {
  const selectedReading = this.readings[index]; // <-- use 'readings'
  console.log('Selected Reading:', selectedReading);

  // You can open a popup, show details, or highlight the reading
}

  spo2ReadingChange(event: Event) {
    const value = (event.target as HTMLSelectElement).value;
    console.log(value);
  }


  changeGlucoseReading(event: Event) {
    const selectElement = event.target as HTMLSelectElement | null;
    if (selectElement) {
      this.glucoseIndex = +selectElement.value;
    }
  }

changeLipidProfile(event: Event) {
   const value = +(event.target as HTMLSelectElement).value;
  if (this.vitalsData?.lipid?.[value]) {
    this.LipidIndex = value;
  }
}
changeHbA1cProfile(event: any) {
  this.HbA1cIndex = event.target.value;
}
  loadPastHbA1cRecords() {
    this.pouchdbService.getAllRecords().subscribe({
      next: (records: any[]) => {
        // Sort records by date descending
        this.pastHbA1cRecords = records.sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );

        // Default selection
        this.selectedHbA1cRecord = this.pastHbA1cRecords[0] || null;

        this.cdr.detectChanges();
      },
      error: (err) => console.error('Failed to load HbA1c records:', err)
    });
  }

  rapidReader(event: Event) {
    const selectElement = event.target as HTMLSelectElement | null;
    if (selectElement) {
      this.rapidIndex = +selectElement.value;
    }
  }


  changeUrineTestProfile(event: Event) {
    const selectElement = event.target as HTMLSelectElement | null;
    if (selectElement) {
      this.urineTestIndex = +selectElement.value;
      if (this.urineTestFullData && this.urineTestFullData[+selectElement.value]) {
        Object.keys(this.urineTestFullData[+selectElement.value]).forEach((key) => {
          this.TestName.forEach((urineResultTest) => {
            if (urineResultTest.test === key) {
              urineResultTest.value = this.urineTestFullData[+selectElement.value][key];
            }
          });
        });
      }
    }
  }

  onDialogClose() {

    this.dialogRef.close();
  }
  
  bpReadingChange(event: Event) {
    const selectElement = event.target as HTMLSelectElement | null;

    if (selectElement) {
      this.bpIndex = +selectElement.value; // convert string to number
    }
  }
  ecgPathPathReadingChange(parameter: string, data: any, event: Event) {
    const index = (event.target as HTMLSelectElement)?.value; // cast to get .value
    this.data = { api: 'apiCalling', parameter, data, index };
  }


  spiroFilePathReadingChange(event: Event) {
  const selectElement = event.target as HTMLSelectElement;
  const value = selectElement.value;
   const target = event.target as HTMLSelectElement | null;

  if (target) {
    this.selectedSpiroIndex = +target.value;
  }
  console.log('Selected value:', value);
}




  getVitals() {
    const offset = localStorage.getItem('offset'); // returns string, e.g. "5:30"

    // if (offset) {
    //   console.log("Offset from localStorage:", offset);
    //   // If you want to split hours and minutes
    //   const [hours, minutes] = offset.split(':').map(Number);
    //   console.log("Hours:", hours, "Minutes:", minutes);
    // }

    const currentToken = this.authService.getToken() || this.tokenRequest;
    const currentSession = this.authService.getCurrentSession();
    const userName = currentSession?.username || '';
    const domain = currentSession?.domainId || '';
    const language = currentSession?.language || '';
    this.consultationId = localStorage.getItem('consultationId') || '';

    // const hardcodedTimeOffset = "5:30";
    const data =
      "?action=getfromserver&domain=" +
      domain +
      "&username=" +
      userName +
      "&localeFile=English&consultationId=" +
      this.consultationId +
      "&usertype=" +
      this.usertype +
      "&tblname=vitals" +
      "&timeOffset=" + offset +
      "&token=" +
      this.tokenRequest;

    this.apiSvc
      .postServiceByQueryBasic<VitalsResponse>(
        this.constantSvc.APIConfig.GETCOMMONSERVICES,
        data
      )
      .subscribe((res) => {
        console.log("vitalsData res", res);

        if (res.status === "OK") {
          this.vitalsData = res.data;

          if (res.isUrineTestTaken) {
            this.isUrineTest = res.isUrineTestTaken;
          } else {
            this.isUrineTest = 0;
          }

          const data = res.data;

          // Your existing processing code...
          if (res.data.temperature) {
            this.vitalsData.temperature = this.vitalsData.temperature.reverse();
          }
          if (data.bpSystolic) {
            this.sysMax = data.bpSystolic.length - 1;
            this.diaMax = data.bpDiastolic?.length ? data.bpDiastolic.length - 1 : 0;
            this.pulseMax = data.pulse?.length ? data.pulse.length - 1 : 0;
          }

          this.triglyceridesMax = data.triglycerides ? data.triglycerides.length - 1 : 0;

          if (data.glucose) {
            this.randomMax = data.glucose.length - 1;
          }
          if (data.glucoseFasting) {
            this.fastingMax = data.glucoseFasting.length - 1;
          }
          if (data.glucosePostprandial) {
            this.postMax = data.glucosePostprandial.length - 1;
          }
          if (data.glucoseRandom) {
            console.log("glucose index", this.glucoseIndex);

          }
          if (data.glucoseFasting) {
            console.log("glucose index", this.glucoseIndex);

          }
          if (data.glucosePostprandial) {
            console.log("glucose index", this.glucoseIndex);

          }
          if (data.bpSystolic) {
            this.vitalsData.bpSystolic = this.vitalsData.bpSystolic.reverse();
          }
          if (data.bpDiastolic) {
            this.vitalsData.bpDiastolic = this.vitalsData.bpDiastolic.reverse();
          }
          if (data.pulse) {
            this.vitalsData.pulse = this.vitalsData.pulse.reverse();
          }
          if (data.temperature) {
            this.vitalsData.temperature = this.vitalsData.temperature.reverse();
          }
          if (data.hemoglobin) {
            this.vitalsData.hemoglobin = this.vitalsData.hemoglobin.reverse();
          }
          if (data.spo2) {
            this.vitalsData.spo2 = this.vitalsData.spo2.reverse();
          }



          //           if (data.spo2_OxygenSaturation_Percentage) {
          //   let globalspO2list = "";
          //   const deviceName = "spo2_OxygenSaturation_Percentage";

          //   Object.keys(data.spo2_OxygenSaturation_Percentage).forEach((value) => {
          //     console.log("SANGEETA", value);
          //     const fname = value.split("~")[1];
          //     if (fname && fname !== "manualentry") {
          //       globalspO2list += fname + ",";
          //     }
          //   });

          //   console.log("checking data for globalspO2list", globalspO2list);
          //   this.downloadFileFroms3(globalspO2list, deviceName);
          // }

          if (data.spo2_OxygenSaturation_Percentage) {
            let globalspO2list = "";
            const deviceName = "spo2_OxygenSaturation_Percentage";
            let hasValidSpo2 = false;

            Object.keys(data.spo2_OxygenSaturation_Percentage).forEach((value) => {
              const fname = value.split("~")[1];
              if (fname && fname.trim() !== "" && fname !== "manualentry") {
                globalspO2list += fname + ",";
                hasValidSpo2 = true;
              }
            });

            this.showSpo2UI = hasValidSpo2;

            if (hasValidSpo2) {
              this.downloadFileFroms3(globalspO2list, deviceName);
            }
          }


          // ADD NEW PROCESSING FOR GLUCOSE, RAPID READER, AND URINE TEST

          // Process rapid reader data
          if (data.rapidreader) {
            data.rapidreader.forEach((element: any) => {
              element.isValidRapiImage = true;
              if (element.testImage && element.testImage.match(/manualentry/g)) {
                element.isValidRapiImage = false;
              }
            });
          }

          // Process test images for rapid reader
          if (data.testimage) {
            this.rapidImageData = data.testimage;
          }

          // Process urine test data
          this.processUrineTestData(data);



          if (data.ecg_filepath) {
            this.vitalsData.ecg_filepath = this.vitalsData.ecg_filepath;
            console.log("ecg_filepath", this.vitalsData);
          }



          if (data.spiro_filepath) {
            console.log("spiro_filepath", data.spiro_filepath);

            let deviceNamesetho = "spiro_filepath";
            Object.keys(data.spiro_filepath).forEach((value) => {
              console.log("SANGEETAspiro_filepath", value);
            });
            console.log(
              "checking data for spiro_filepath",
              data.spiro_filepath
            );
            this.downloadFileFroms3spirofilepath(
              data.spiro_filepath,
              deviceNamesetho
            );
          }

          // Process stethoscope data
          if (data.stetho_filepath) {
            this.vitalsData.stetho_filepath = this.vitalsData.stetho_filepath.reverse();
            console.log("stetho_filepath", this.vitalsData);
            
            let deviceNamestetho = "stetho_filepath";
            Object.keys(data.stetho_filepath).forEach((value) => {
              console.log("SANGEETAstetho", value);
            });
            console.log("checking data for globalstetholist", data.stetho_filepath);
            this.downloadFileFroms3stetho(data.stetho_filepath, deviceNamestetho);
          }

          // Process fetal doppler data
          if (data.fetal_filepath) {
            this.vitalsData.fetal_filepath = this.vitalsData.fetal_filepath.reverse();
            console.log("fetal_filepath", this.vitalsData);
            
            let deviceNamefetal = "fetal_filepath";
            Object.keys(data.fetal_filepath).forEach((value) => {
              console.log("SANGEETAfetal_filepath", value);
            });
            console.log("checking data for globalfetalfilepath", data.fetal_filepath);
            this.downloadFileFroms3fetal(data.fetal_filepath, deviceNamefetal);
          }
        }
      });
  }


  downloadFileFroms3(downloadfilelist: string, devicename: string) {
    let data =
      "?action=downloadfilefroms3&downloadfilelist=" +
      downloadfilelist +
      "&devicename=" +
      devicename +
      "&conId=" +
      this.consultationId +
      "&patientId=" +
      this.patientId +
      "&token=" +
      this.tokenRequest;

    this.apiSvc
      .postServiceByQueryBasic(
        this.constantSvc.APIConfig.GETCOMMONSERVICES,
        data
      )
      .subscribe((res) => {
        console.log("downloadFileFroms3", res);
      });
  }

  
 downloadFileFroms3spirofilepath(spiro_filepaths: string[], deviceNamefetal: string) {
  spiro_filepaths.forEach(file => {
    const data = `?action=downloadfilefroms3&downloadfilelist=${file}`
      + `&devicename=${deviceNamefetal}`
      + `&conId=${this.consultationId}`
      + `&patientId=${this.patientId}`
      + `&token=${this.tokenRequest}`;

    this.apiSvc.postServiceByQueryBasicText(
  this.constantSvc.APIConfig.GETCOMMONSERVICES,
  data
).subscribe((res: any) => {
  const textResponse = res as string;
  console.log("downloadFileFroms3spirofilepath", textResponse);
});

  });
}

  // pop -up model for Spo2DeviceComponent
  // pastRecordSpo2Value(parameter: any) {
  //   console.log("parameter",parameter);

  //   const dialogRef = this.dialog.open(Spo2DevicePage, {
  //     data: {
  //       api: "apiCalling",
  //       parameter: parameter,
  //       data: this.vitalsData,
  //       index: this.spo2Index,
  //     },
  //     width: "711px",
  //     height: "auto",
  //     disableClose: true,
  //   });

  //   dialogRef.afterClosed().subscribe((result) => {
  //     if (result != undefined) {
  //     }
  //   });
  // }
  openSpo2Dialog() {
    this.dialog.open(Spo2DevicePage, {
      data: {
        api: "apiCalling",
        parameter: "spo2",
        data: this.vitalsData,
        index: this.spo2Index ?? 0,
        // showBatteryIcon: false,
        // showConnectionButton: false,
        // showTotalTime: false,
      },
      width: 'auto',
      height: 'auto',
      disableClose: true,
    });
  }


  getPastRecordEcg(parameter: any) {
    console.log("INSIDE getPastRecordEcg");
    const dialogRef = this.dialog.open(EcgJettyDevicePage, {
      data: {
        api: "apiCalling",
        parameter: parameter,
        data: this.vitalsData,
        index: '1',
      },
      width: "800px",
      height: "auto",
      disableClose: true,

      panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result != undefined) {
      }
    });
  }
  spiroSeriesData = [];
  spiroCount = 0;
  getPastRecordSpiroDevice(parameter: any, index?:number) {
     if (index === undefined) {
    console.warn("Index not selected, using default 0");
    index = 0;
  }
  //   if (this.vitalsData.spiro_filepath[0] == "manualentry") {
  //     // if (this.vitalsData.spiro_filepath[Number(this.spiroIndex)] == "manualentry") {
  //     const dialogRef = this.dialog.open(SpiroMeterPastRecordDataComponent, {
  //       data: {
  //         api: "apiCalling",
  //         parameter: parameter,
  //         index: this.spiroIndex,
  //         conId: this.getPatientData.consultationId,
  //         patientId: +this.getPatientData.domainwiseid,
  //         // token: + this.tokenRequest,
  //         // spiroSeriesData: this.spiroSeriesData,
  //         // spiroCount: this.spiroCount
  //       },
  //       width: "700px",
  //       height: "auto",
  //       disableClose: true,
  //       // panelClass: 'slot-dialog'
  //     });

  //     dialogRef.afterClosed().subscribe((result) => {
  //       if (result != undefined) {
  //       }
  //     });
  //   } else {
     const dialogRef = this.dialog.open(SpirometerJettyDevicePage, {
        data: {
          api: "apiCalling",
          parameter: parameter,
          data: this.vitalsData,
          index:index ,
        },
        width: "753px",
        height: "auto",
        disableClose: true,
       });

       dialogRef.afterClosed().subscribe((result) => {
         if (result != undefined) {
            }
       });
    // }
  // }
}

  private processUrineTestData(data: any) {
    let urineTestFlag = true;
    const urineTest = { BIL: "-" };

    // Process each urine test parameter
    const urineParams = ['BIL', 'GLU', 'KET', 'SG', 'BLO', 'pH', 'PRO', 'URO', 'NIT', 'LEU'];

    urineParams.forEach(param => {
      if (data[param]) {
        if (urineTestFlag) {
          // Initialize arrays for first parameter
          for (let i = 0; i < data[param].length; i++) {
            this.urineTestData.push(JSON.parse(JSON.stringify(urineTest)));
            this.urineTestFullData.push(JSON.parse(JSON.stringify(urineTest)));
          }
          urineTestFlag = false;
        }

        // Process parameter data
        data[param].forEach((element: string, i: number) => {
          if (this.urineTestFullData[i]) {
            this.urineTestFullData[i][param] = JSON.parse(JSON.stringify(element));

            // Clean up the display value
            let cleanElement = element;
            if (param === 'BIL' || param === 'GLU' || param === 'KET' || param === 'PRO' || param === 'URO') {
              cleanElement = element.replace("mg/dL", "");
            } else if (param === 'BLO' || param === 'pH') {
              cleanElement = element.replace("Ery/µL", "");
            } else if (param === 'LEU') {
              cleanElement = element.replace("Leu/µL", "");
            }

            this.urineTestData[i][param] = cleanElement;
          }
        });
      }
    });

    // Update TestName values with first reading
    if (this.urineTestFullData.length > 0) {
      Object.keys(this.urineTestFullData[0]).forEach((key) => {
        this.TestName.forEach((urineResultTest) => {
          if (urineResultTest.test === key) {
            urineResultTest.value = this.urineTestFullData[0][key];
          }
        });
      });
    }
  }



  // Download methods for stethoscope and fetal doppler devices
  downloadFileFroms3stetho(stetho_filepaths: string[], deviceName: string) {
    stetho_filepaths.forEach(file => {
      const data = `?action=downloadfilefroms3&downloadfilelist=${file}`
        + `&devicename=${deviceName}`
        + `&conId=${this.consultationId}`
        + `&patientId=${this.patientId}`
        + `&token=${this.tokenRequest}`;

      this.apiSvc.postServiceByQueryBasicText(
        this.constantSvc.APIConfig.GETCOMMONSERVICES,
        data
      ).subscribe((res: any) => {
        const textResponse = res as string;
        console.log("downloadFileFroms3stetho", textResponse);
      });
    });
  }

  downloadFileFroms3fetal(fetal_filepaths: string[], deviceName: string) {
    fetal_filepaths.forEach(file => {
      const data = `?action=downloadfilefroms3&downloadfilelist=${file}`
        + `&devicename=${deviceName}`
        + `&conId=${this.consultationId}`
        + `&patientId=${this.patientId}`
        + `&token=${this.tokenRequest}`;

      this.apiSvc.postServiceByQueryBasicText(
        this.constantSvc.APIConfig.GETCOMMONSERVICES,
        data
      ).subscribe((res: any) => {
        const textResponse = res as string;
        console.log("downloadFileFroms3fetal", textResponse);
      });
    });
  }
}




