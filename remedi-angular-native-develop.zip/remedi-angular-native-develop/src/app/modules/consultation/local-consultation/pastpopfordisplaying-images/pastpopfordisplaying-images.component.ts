import { Component, OnInit, Inject, Optional } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

interface RapidTestData {
  patientName: string;
  age: string;
  gender: string;
  dateOfBirth: string;
  testResult: string;
  testImage: string | null;
  testName?: string;
}

interface UrineTestData {
  patientName: string;
  age: string;
  appointmentDate: string;
  BLO: string[];
  GLU: string[];
  PRO: string[];
  URO: string[];
  SG: string[];
  pH: string[];
  BIL: string[];
  NIT: string[];
  KET: string[];
  LEU: string[];
  testimage: string[];
  stripType: string;
}

@Component({
  selector: 'app-pastpopfordisplaying-images',
  templateUrl: './pastpopfordisplaying-images.component.html',
  styleUrls: ['./pastpopfordisplaying-images.component.scss'],
  standalone: true,
  imports: [CommonModule]
})
export class PastpopfordisplayingImagesComponent implements OnInit {
  
  selectedRapidTestData: RapidTestData | null = null;
  selectedUrineTestData: UrineTestData | null = null;
  testType: 'rapid' | 'urine' = 'rapid';
  combinedUrineArray: { key: string, value: string }[] = [];

  constructor(
    @Optional() public dialogRef: MatDialogRef<PastpopfordisplayingImagesComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    console.log('PastpopfordisplayingImagesComponent initialized with data:', this.data);
    
    if (this.data) {
      this.testType = this.data.testType || 'rapid';
      
      if (this.testType === 'rapid') {
        this.initializeRapidTestData();
      } else if (this.testType === 'urine') {
        this.initializeUrineTestData();
      }
    }
  }

  initializeRapidTestData(): void {
    const { reading, record } = this.data;
    
    this.selectedRapidTestData = {
      patientName: record?.patientName || 'N/A',
      age: record?.age || 'N/A',
      gender: reading?.gender || 'N/A',
      dateOfBirth: reading?.dateOfBirth || 'N/A',
      testResult: reading?.testResult || 'N/A',
      testImage: reading?.testImage || null,
      testName: reading?.testName || 'Rapid Test'
    };
  }

initializeUrineTestData(): void {
  const { reading, record } = this.data;
  
  const urineData = reading || {};
  
  console.log('Raw reading data:', reading);
  
  // Helper function to ensure array format
  const ensureArray = (value: any): string[] => {
    if (Array.isArray(value)) return value;
    if (value && typeof value === 'string') return [value];
    return [];
  };
  
  this.selectedUrineTestData = {
    patientName: record?.patientName || 'N/A',
    age: record?.age || 'N/A',
    appointmentDate: record?.appointmentDate || 'N/A',
    BLO: ensureArray(urineData?.BLO),
    GLU: ensureArray(urineData?.GLU),
    PRO: ensureArray(urineData?.PRO),
    URO: ensureArray(urineData?.URO),
    SG: ensureArray(urineData?.SG),
    pH: ensureArray(urineData?.pH),
    BIL: ensureArray(urineData?.BIL),
    NIT: ensureArray(urineData?.NIT),
    KET: ensureArray(urineData?.KET),
    LEU: ensureArray(urineData?.LEU),
    testimage: ensureArray(urineData?.testimage),
    stripType: urineData?.stripType || '1'
  };
  
  console.log('Processed selectedUrineTestData:', this.selectedUrineTestData);
  
  this.processUrineResults();
}

processUrineResults(): void {
  if (!this.selectedUrineTestData) return;
  
  // Define the proper order of tests
  const testOrder = ['LEU', 'NIT', 'URO', 'PRO', 'pH', 'BLO', 'SG', 'KET', 'BIL', 'GLU'];
  
  const testMap: { [key: string]: string[] } = {
    'LEU': this.selectedUrineTestData.LEU,
    'NIT': this.selectedUrineTestData.NIT,
    'URO': this.selectedUrineTestData.URO,
    'PRO': this.selectedUrineTestData.PRO,
    'pH': this.selectedUrineTestData.pH,
    'BLO': this.selectedUrineTestData.BLO,
    'SG': this.selectedUrineTestData.SG,
    'KET': this.selectedUrineTestData.KET,
    'BIL': this.selectedUrineTestData.BIL,
    'GLU': this.selectedUrineTestData.GLU
  };
  
  // Process in the correct order
  this.combinedUrineArray = testOrder
    .filter(key => testMap[key] && testMap[key].length > 0)
    .map(key => ({
      key: key,
      value: testMap[key][0] || 'N/A'
    }));
}

  getReferenceStripImage(): string {
    if (this.selectedUrineTestData?.stripType === '1') {
      return "assets/images/UrineStrip.PNG";
    } else if (this.selectedUrineTestData?.stripType === '2') {
      return "assets/images/UrineRefType-II.jpeg";
    }
    return "assets/images/UrineStrip.PNG";
  }

  closeRapidTestPopup(): void {
    if (this.dialogRef) {
      this.dialogRef.close();
    }
  }

/**
 * Get display name for test parameters (converts abbreviations to full names)
 */
getTestDisplayName(key: string): string {
  const testNames: { [key: string]: string } = {
    'LEU': 'Leukocytes(LEU)',
    'NIT': 'Nitrite(NIT)',
    'URO': 'Urobilinogen(URO)',
    'PRO': 'Protein(PRO)',
    'pH': 'pH',
    'BLO': 'Blood(BLO)',
    'SG': 'Specific Gravity(SG)',
    'KET': 'Ketone(KET)',
    'BIL': 'Bilirubin(BIL)',
    'GLU': 'Glucose(GLU)'
  };
  
  return testNames[key] || key;
}

/**
 * Check if test image exists
 */
hasTestImage(): boolean {
  return !!(this.selectedUrineTestData?.testimage && 
            this.selectedUrineTestData?.testimage.length > 0 && 
            this.selectedUrineTestData?.testimage[0]);
}
}