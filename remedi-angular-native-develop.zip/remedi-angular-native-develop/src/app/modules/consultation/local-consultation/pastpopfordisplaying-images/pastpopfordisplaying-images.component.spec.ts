import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { PastpopfordisplayingImagesComponent } from './pastpopfordisplaying-images.component';

describe('PastpopfordisplayingImagesComponent', () => {
  let component: PastpopfordisplayingImagesComponent;
  let fixture: ComponentFixture<PastpopfordisplayingImagesComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [PastpopfordisplayingImagesComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(PastpopfordisplayingImagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
