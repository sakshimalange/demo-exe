import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PrintPatientIdPage } from './print-patient-id.page';

describe('PrintPatientIdPage', () => {
  let component: PrintPatientIdPage;
  let fixture: ComponentFixture<PrintPatientIdPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintPatientIdPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
