import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ConstantService } from 'src/app/core/services/constant.service';
import { ApiService } from 'src/app/core/services/api.service';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { AuthService } from 'src/app/core/services/auth.service';
import { DOCUMENT } from '@angular/common';
import { Inject } from '@angular/core';

@Component({
  selector: 'app-print-patient-id',
  templateUrl: './print-patient-id.page.html',
  styleUrls: ['./print-patient-id.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule],
})
export class PrintPatientIdPage implements OnInit {
  currDocId: any;
  currDomainName: any;
  currUserType: any;
  username: any;
  loginTime: any;
  currDomainId: any;
  currentUserName: any;
  honorific: any;
  consultationId: any;
  invoiceData: any;
  imageLogo: any;
  hospitalLogo: any;
  today = new Date();
  reportData: any;
  curUser: any;
  patientId: any;
  patientData: any;
  tokenRequest: string = '';
  language: string = '';
  domainwisepid: any;

  constructor(
    private constantSvc: ConstantService,
    private apiSvc: ApiService,
    public dialog: MatDialog,
    private authService: AuthService,
    private dialogRef: MatDialogRef<PrintPatientIdPage>,
    @Inject(DOCUMENT) private document: Document
  ) {}

  ngOnInit() {
    // this.consultationId = localStorage.getItem('consultationId') || '';
    const currentSession = this.authService.getCurrentSession();
    this.tokenRequest = this.authService.getToken() || '';
    // console.log("tokenRequest", this.tokenRequest);
    this.username = currentSession?.username || '';
    this.currDomainId = currentSession?.domainId || '';
    this.language = currentSession?.language || '';

    // Patient & consultation info
    const patientDetails = JSON.parse(
      sessionStorage.getItem('patientDetails') || '{}'
    );
    console.log('patientDetails', patientDetails);
    this.patientId = patientDetails.domainwisepid || '';
    this.consultationId = localStorage.getItem('consultationId') || '';

    // Get login/session info
    const loginResponse = JSON.parse(
      localStorage.getItem('LOGIN_RESPONSE') || '{}'
    );
    console.log('loginResponse', loginResponse);
    this.tokenRequest =
      loginResponse.token ?? localStorage.getItem('token') ?? '';
    this.currDomainId =
      loginResponse.profiledetail?.domainId ??
      localStorage.getItem('domainId') ??
      '0';
    console.log('this.currDomainId', this.currDomainId);
    this.username =
      loginResponse.profiledetail?.userName ??
      localStorage.getItem('userName') ??
      '';
    this.currDomainName =
      loginResponse.commondetail?.domainName ??
      loginResponse.domainName ??
      localStorage.getItem('domainName') ??
      '';
    console.log('this.currDomainName', this.currDomainName);
    //this.usertype = loginResponse.commondetail?.usertype ?? localStorage.getItem('usertype') ?? '';
    this.getLogo();
    this.searchPatient(this.patientId);
    this.getHospLogo();
  }
  getLogo() {
    // https://s3test2.remedi.co.in/RemediPRMS/RemediNovaDoctorAPI.do?action=domainLogo&username=kmcdoctor1&domain=21
    let data =
      '?action=domainLogo&username=' +
      this.username +
      '&domain=' +
      this.currDomainId;
    this.apiSvc
      .postServiceByQueryBasicLogo(
        this.constantSvc.APIConfig.GETCOMMONSERVICES,
        data
      )
      .subscribe((res) => {
        console.log('res', res);
        if (res.status == 'success') {
          this.imageLogo = res.domainLogo;
          console.log('this.imageLogo', this.imageLogo);
          // this.router.navigate(['/dashboard']);
        } else {
        }
      });
  }
  getHospLogo() {
    let data =
      '?action=getHospitalImage' + '&domainName=' + this.currDomainName;
    this.apiSvc
      .postServiceByQueryBasicLogo(
        this.constantSvc.APIConfig.GETCOMMONSERVICES,
        data
      )
      .subscribe((res) => {
        console.log('res', res);
        if (res.status == 'success') {
          this.hospitalLogo = res.HospitalImage;
          console.log('this.hospitalLogo', this.hospitalLogo);
          // this.router.navigate(['/dashboard']);
        } else {
        }
      });
  }
  //SEARCH PATIENT BY ID
  searchPatient(ptid: string) {
    //https://s3test2.remedi.co.in/RemediPRMS/RemediNovaDoctorAPI.do?action=search&patientid=1541&domain=21&username=demo143&iswithdash=0&token=
    let data =
      '?action=search&patientid=' +
      this.patientId +
      '&domain=' +
      this.currDomainId +
      '&username=' +
      this.username +
      '&iswithdash=0&token=' +
      this.tokenRequest;
    this.apiSvc
      .postServiceByQueryBasic(
        this.constantSvc.APIConfig.GETCOMMONSERVICES,
        data
      )
      .subscribe((res: any) => {
        if (res.status == 'success') {
          this.patientData = res.data[0];
          // this.router.navigate(['/diagnostics']);
        } else if (res.status == 'failure') {
        }
      });
  }
  closeDialog(): void {
    this.dialogRef.close();
  }
  // print-patient-id.page.ts
  printIdCard(): void {
    window.print();
  }

  printById(elementId: string) {
    const el = this.document.getElementById(elementId);
    if (!el) {
      console.error('Element not found', elementId);
      return;
    }

    // Clone the element
    const content = el.cloneNode(true) as HTMLElement;

    // Create a temporary container
    const printContainer = this.document.createElement('div');
    printContainer.id = elementId; //'print-container';
    printContainer.style.position = 'fixed';
    printContainer.style.top = '0';
    printContainer.style.left = '0';
    printContainer.style.width = '100%';
    printContainer.style.height = '100%';
    printContainer.style.zIndex = '9999';
    printContainer.style.background = 'white';
    printContainer.style.display = 'flex';
    printContainer.style.justifyContent = 'center';
    printContainer.style.alignItems = 'center';

    printContainer.appendChild(content);
    this.document.body.appendChild(printContainer);
    if (!this.document.getElementById('custom-print-style')) {
      const styleEl = this.document.createElement('style');
      styleEl.id = 'custom-print-style';
      styleEl.innerHTML = `
        ${`@media print {
          #print-root {
            transform: scale(0.55);
            transform-origin: center; /* or center, depending on alignment you want */
            width: 100%;
            height: 100%;
          }
        
          body, html {
            overflow: hidden;
          }
        }`}
      `;
      this.document.head.appendChild(styleEl);
    }

    // Trigger print
    window.print();

    // Remove after printing
    this.document.body.removeChild(printContainer);
  }

  // Alternative simple print method that uses browser's native print
  printIdCardSimple(): void {
    // Add print class to body temporarily
    this.document.body.classList.add('print-mode');

    setTimeout(() => {
      window.print();
      // Remove print class after printing
      this.document.body.classList.remove('print-mode');
    }, 100);
  }
}
