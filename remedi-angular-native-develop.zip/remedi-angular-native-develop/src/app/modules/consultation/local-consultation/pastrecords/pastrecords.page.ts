
import { IonicModule, ModalController } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component, OnInit, ChangeDetectorRef, NgZone, Optional, HostListener } from '@angular/core';
import { NavController } from '@ionic/angular';
import { UploadDocumentsPage } from '../upload-documents/upload-documents.page';


import {
  ElementRef,
  ViewChild,
  OnDestroy,
  AfterViewInit,
  Inject,
} from '@angular/core';
import { Subscription } from 'rxjs';
import * as Highcharts from 'highcharts/highstock';
import { WebsocketsService } from 'src/app/core/services/websocket.service';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { PouchdbService } from 'src/app/core/services/pouchdb.service';
import { SaveSpo2DataRequest, SaveSpo2FileDataRequest } from 'src/app/core/interfaces/prms/spo2-data.model';
import { ApiService } from 'src/app/core/services/api.service';
import { ConstantService } from 'src/app/core/services/constant.service';
import * as CryptoJS from 'crypto-js';
import { NetworkService } from 'src/app/core/services/network.service';
import { SidebarPage } from '../sidebar/sidebar.page';
import { TabsPage } from '../tabs/tabs.page';
import { Consultation, MedicalImage } from 'src/app/core/interfaces/pouchdb.model';
import { environment } from 'src/environments/environment';
import { IcareThermometerPage } from 'src/app/modules/prms/ble-device/icare-thermometer/icare-thermometer.page';
import { TranslateModule } from '@ngx-translate/core';
import { PastRecordHistoryPage } from '../past-record-history/past-record-history.page';
import { AuthService } from 'src/app/core/services/auth.service';
import { Spo2DevicePage } from 'src/app/modules/prms/ble-device/spo2-device/spo2-device.page';
import { UDocumentsPage } from '../u-documents/u-documents.page';
import { ArrayifyPipe } from 'src/app/core/services/arrayify.pipe';
import { EcgJettyDevicePage } from 'src/app/modules/prms/ble-device/ecg-jetty-device/ecg-jetty-device.page';
import { PastRecordCalendarComponent } from "../past-record-calendar/past-record-calendar.component";
import { PastConsultationPage } from '../past-consultation/past-consultation.page';
import { SpirometerJettyDevicePage } from 'src/app/modules/prms/ble-device/spirometer-jetty-device/spirometer-jetty-device.page';
import { PastpopfordisplayingImagesComponent } from '../pastpopfordisplaying-images/pastpopfordisplaying-images.component';
import { StethoscopeDevicePage } from 'src/app/modules/prms/ble-device/stethoscope-device/stethoscope-device.page';
import { FetalDopplerDevicePage } from 'src/app/modules/prms/ble-device/fetal-doppler-device/fetal-doppler-device.page';
import { EcgInterpretationJettyDeviceComponent } from 'src/app/modules/prms/ble-device/ecg-interpretation-jetty-device/ecg-interpretation-jetty-device.component';
import { EcgInterpretationManualJettyComponent } from 'src/app/modules/prms/manual_entry/ecg-interpretation-manual-jetty/ecg-interpretation-manual-jetty.component';
import { PastImagesPreviewPage } from '../past-images-preview/past-images-preview.page';

interface HbA1cReading {
  HbA1c_per?: string;
  HbA1c_eAG?: string;
  HbA1c_mmol?: string;
  reading_number?: number;
}
@Component({
  selector: 'app-pastrecords',
  templateUrl: './pastrecords.page.html',
  styleUrls: ['./pastrecords.page.scss', '../tabs/tabs.page.scss'],
  standalone: true,
  imports: [
    IonicModule,
    CommonModule,
    TranslateModule,
    ReactiveFormsModule, // <-- Add this
    ArrayifyPipe,
    FormsModule,
    PastRecordCalendarComponent
]
})
export class PastrecordsPage implements OnInit {

  paginationForm: FormGroup;
  getPatientData: any;
  currDomainId: any;
  tokenRequest: string = '';
  spo2Index: any = 0;
  imageList: any;
  showReportDate: boolean | undefined;
  consulReportList: any = [];
  vitalsData: any;
  isUrineTest: any;
  filteredConsultations: any[] = [];
  tempMax: number | undefined;
  spiroMax: number | undefined;
  sysMax: number | undefined;
  diaMax: number | undefined;
  pulseMax: number | undefined;
  randomMax!: number;
  fastingMax!: number;
  postMax!: number;
  testResultData: any;
  username: any;
  usertype: any;
  domainName: any;
  bpIndex: any = 0;
  bilMax!: number;
  triglyceridesMax: number | undefined;
  glucoseIndex: any;
  consultationList: any[] = [];
  selectedRecord: any = null;
  isTemperaturePopupOpen = false;
  patientId: any;
  consultationId: any;
  language: any;
  db: any;
filterData: any[] = []; // Dynamic filters
  isLocalConsultation: boolean = false;
  isOpen = false;
  isOpenAtten = false;
  isOpenCurrCons = false;
  readings: any[] = [];
  appointmentForm!: FormGroup;
  showCalendar: boolean=false;
  selectedDateRange: {start: Date, end: Date} | null = null;
  calendarPosition = { top: 0, right: 0 };
selectedAttendedBy = new Set<string>();
attendedByList: string[] = [];
  spiroIndex: any;
selectedSort: string | null = 'Newest First';
selectedFilters: string[] = [];
  constructor(
    private formBuilder: FormBuilder,
    private modalCtrl: ModalController,
    private websocketsService: WebsocketsService,
    private pouchdbService: PouchdbService,
    private constantSvc: ConstantService,
    private dialog: MatDialog,
    private apiSvc: ApiService,
    private authService: AuthService,
    // private translate: TranslateService,
    private networkService: NetworkService,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any,
    @Optional() private dialogRef: MatDialogRef<PastrecordsPage>,
    private navCtrl: NavController,
    private eRef: ElementRef,
  ) {
    this.paginationForm = this.formBuilder.group({
      pageSize: [5]
    });

    // Subscribe to page size changes
    this.paginationForm.get('pageSize')?.valueChanges.subscribe(() => {
      this.onPageSizeChange();
    });

    // Initialize readings from injected data
    this.readings = data?.readings || []; // <-- Add this line here
  }


  ngOnInit() {
    console.log('ngOnInit started');
    const flag = localStorage.getItem('isLocalConsultation') === 'true';
    console.log('Flag from storage:', flag);
    this.isLocalConsultation = flag;
    // this.pouchdbService.initDB('medicalimagecategory_db');
    // this.pouchdbService.initDB('consultationlist_db');

    this.consultationId = localStorage.getItem('consultationId') || '';
    console.log('Consultation ID:', this.consultationId);
    const currentSession = this.authService.getCurrentSession();

    this.tokenRequest = this.authService.getToken() || '';
    this.username = currentSession?.username || '';
    this.currDomainId = currentSession?.domainId || '';
    this.language = currentSession?.language || '';

    // Patient & consultation info
    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    this.patientId = patientDetails.patientid || '';
    this.consultationId = localStorage.getItem('consultationId') || '';
    // Get login/session info
// First, try sessionStorage — if not found, fallback to localStorage
let rawLoginResponse: any = sessionStorage.getItem('LOGIN_RESPONSE') || localStorage.getItem('LOGIN_RESPONSE') || '{}';
let loginResponse: any = {};

try {
  loginResponse = JSON.parse(rawLoginResponse);
  // if it’s still a string, parse again
  if (typeof loginResponse === 'string') {
    loginResponse = JSON.parse(loginResponse);
  }
} catch (e) {
  console.error('Error parsing LOGIN_RESPONSE:', e);
}

this.tokenRequest = loginResponse.token ?? '';
this.currDomainId = loginResponse.profiledetail?.domainId ?? '0';
this.username = loginResponse.profiledetail?.userName ?? '';
this.usertype = loginResponse.commondetail?.usertype ?? '';
this.domainName = loginResponse.commondetail?.domainName ?? '';

console.log('✅ Domain Name:', this.domainName);


    this.getMedicalImages();
    // this.getConsultationList();
    this.getAllConsultationListForToday();
    // this.getVitals();
  }

  toggleDropdown() {
    this.isOpen = !this.isOpen;
  }
  toggleAttendedBy() {
    this.isOpenAtten = !this.isOpenAtten;
  }
  toggleCurrCons() {
    this.isOpenCurrCons = !this.isOpenCurrCons;
  }
  @HostListener('document:click', ['$event'])
  clickOutside(event: Event) {
    // Close the dropdown only if click is outside this section
    const filterButton = this.eRef.nativeElement.querySelector('#button-ic');
    if (this.isOpen && filterButton && !filterButton.contains(event.target)) {
      this.isOpen = false;
    }
  }




  pageSizes = [5, 10, 25];

  currentPage = 1;
  allConsultationList: any[] = []; // Store all records
  paginatedConsultationList: any[] = []; // Store paginated records

get pageSize() {
  return this.paginationForm.get('pageSize')?.value || 5;
}

set pageSize(value: number) {
  this.paginationForm.get('pageSize')?.setValue(value);
  this.onPageSizeChange();
}

  get totalItems() {
    return this.allConsultationList.length;
  }

  get currentPageRange() {
    const start = (this.currentPage - 1) * this.pageSize + 1;
    const end = Math.min(this.currentPage * this.pageSize, this.totalItems);
    return `${start.toString().padStart(2, '0')}-${end.toString().padStart(2, '0')}`;
  }

  get totalPages() {
    return Math.ceil(this.totalItems / this.pageSize);
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePaginatedData();
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updatePaginatedData();
    }
  }

  onPageSizeChange() {
    this.currentPage = 1; // Reset to first page when page size changes
    this.updatePaginatedData();
  }

  updatePaginatedData() {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    this.paginatedConsultationList = this.allConsultationList.slice(startIndex, endIndex);
    // this.consultationList = this.paginatedConsultationList; // Update the display list
  }

removeFilter(filter: string) {
  this.selectedFilters = this.selectedFilters.filter(f => f !== filter);
}

  deleteRecord(record: any) {
    console.log('Delete record:', record);
  }

  // removeFilter(type: string) {
  //   console.log(`Removing filter of type: ${type}`);
  // }

  getMedicalImages() {
    const data = `?action=medicalimagecategory` +
      `&consultationId=${this.consultationId}` +
      `&patientId=${this.patientId}` +
      `&domain=${this.currDomainId}` +
      `&tblname=prms_complaint` +
      `&imagetype=` +
      `&token=${this.tokenRequest}`;

    this.apiSvc
      .postServiceByQuery(this.constantSvc.APIConfig.GETCOMMONSERVICES, data)
      .subscribe((res: any) => {
        if (res.status === 'success') {
          console.log('API Data:', res.data);

          const pouchDoc = {
            _id: `medical_images_${1}_${1}`,
            type: 'medical_images',
            consultationId: 1,
            patientId: 1,
            data: res.data
          };

          // Save into PouchDB
          this.pouchdbService.addRecord(pouchDoc).subscribe({
            next: () => {
              console.log('Saved medical images into PouchDB.');

              // Fetch from PouchDB to display
              this.pouchdbService.getRecordById(`medical_images_${89532}_${6923}`).subscribe({
                next: (doc: any) => {
                  this.imageList = doc.data;
                  console.log('Loaded medical images from PouchDB for UI display.');
                },
                error: (err) => {
                  console.error('Error loading from PouchDB:', err);
                }
              });
            },
            error: (err) => {
              console.error('Error saving images offline:', err);
            }
          });
        }
      });
  }
  // bpReadingChange(event: Event) {
  //   const selectElement = event.target as HTMLSelectElement | null;

  //   if (selectElement) {
  //     this.bpIndex = +selectElement.value; // convert string to number
  //   }
  // }
  // ✅ Save Lipid Record
  async saveLipidRecord(lipidData: any): Promise<any> {
    const record = {
      _id: new Date().toISOString(),
      type: 'lipid',
      data: lipidData,
      createdAt: new Date().toISOString()
    };

    try {
      const response = await this.db.put(record);
      console.log('Lipid record saved:', response);
      return response;
    } catch (err) {
      console.error('Error saving lipid record:', err);
    }
  }
  // ✅ Fetch Lipid Records
  async getLipidRecords(): Promise<any[]> {
    try {
      const result = await this.db.find({
        selector: { type: 'lipid' },
        sort: [{ createdAt: 'desc' }]
      });

      return result.docs.map((doc: any) => doc.data);
    } catch (err) {
      console.error('Error fetching lipid records:', err);
      return [];
    }
  }




  applyFilters() {
    // You can implement your filter logic here.
    // For now, even an empty method will prevent the error.
    console.log('Filter applied');
  }
  
  clearFilters() {
    // You can reset your filtered list to show all consultations
    console.log('Filters cleared');

    // Example: reset the displayed consultations
    // If you have a filtered array, reset it to the original list
    this.filteredConsultations = [...this.allConsultationList];

    // Or if you are using pagination, refresh the table
    this.currentPage = 1;
    this.updatePaginatedData();
  }

toggleCheckbox(name: string) {
  if (this.selectedAttendedBy.has(name)) {
    this.selectedAttendedBy.delete(name);
  } else {
    this.selectedAttendedBy.add(name);
  }
}



  itemsPerPage: number = 5;
  private _totalItems: number = 0;   // internal tracker

  startIndex: number = 0;
  endIndex: number = 0;

getAllConsultationListForToday(fromDate?: string, toDate?: string) {
  const currentSession = this.authService.getCurrentSession();
  const userName = currentSession?.username || '';
  const domain = currentSession?.domainId || '';

  const today = new Date();
  const dd = String(today.getDate()).padStart(2, '0');
  const mm = String(today.getMonth() + 1).padStart(2, '0');
  const yyyy = today.getFullYear();

  const startDate = fromDate || `${mm}/${dd}/${yyyy}`;
  const endDate = toDate || `${mm}/${dd}/${yyyy}`;

  const query =
    `?action=allconsultationlistforangular` +
    `&patientId=${this.patientId}` +
    `&domainid=${domain}` +
    `&username=${userName}` +
    `&timeOffset=${environment.getTimeOffSet()}` +
    `&fromDate=${startDate}` +
    `&toDate=${endDate}` +
    `&userLang=English` +
    `&domain=${this.domainName }` +
    `&token=${this.tokenRequest}`;

  this.apiSvc.postServiceByQueryBasic(this.constantSvc.APIConfig.GETCOMMONSERVICES, query)
    .subscribe({
      next: (res: any) => {
        if (res.status === 'success' && res.data) {
          console.log("Raw API Data:", res.data);

          this.allConsultationList = res.data.flatMap((item: any) => {
            const rawDate = item.prmsParameters?.consultationDetails?.appointmentDate || item.appointmentDate;
            const formattedDate = rawDate || null;
            const allRecords: any[] = [];

            // ---------------- Generic / No Parameters ----------------
            if (!item.prmsParameters || item.prmsParameters?.prmsStatus === "no_parameters") {
              allRecords.push({
                appointmentDate: formattedDate,
                pastRecords: 'No Parameters',
                reading: null,
                documentType: item.documentType === 'recorded_reading' ? 'Recorded Readings' : 'Past Consultation',
                attendedBy: item.prmsParameters?.consultationDetails?.attendedBy || item.attendedBy || 'Unknown',
                consultationId: item.consultationId,
                patientName: item.prmsParameters?.patientInfo
                  ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
                  : null,
                age: item.prmsParameters?.patientInfo?.age || null,
              });
            }

            // ---------------- Temperature ----------------
            const tempArr = item.prmsParameters?.data?.temperature || [];
            if (Array.isArray(tempArr) && tempArr.length > 0) {
              const temperatureReadings = tempArr.map((t: string, idx: number) => {
                const [fahrenheit, celsius] = t.split(',').map(v => v.trim());
                return { fahrenheit, celsius, readingNumber: idx + 1 };
              });

              allRecords.push({
                appointmentDate: formattedDate,
                pastRecords: 'Temperature',
                reading: {
                  type: 'temperature',
                  fahrenheit: temperatureReadings[0].fahrenheit,
                  celsius: temperatureReadings[0].celsius,
                  extra: temperatureReadings.length > 1 ? `+${temperatureReadings.length - 1}` : '',
                  allReadings: temperatureReadings,
                },
                documentType: item.documentType === 'recorded_reading' ? 'Recorded Readings' : 'Past Consultation',
                attendedBy: item.prmsParameters?.consultationDetails?.attendedBy || item.attendedBy || 'Unknown',
                consultationId: item.consultationId,
                patientName: item.prmsParameters?.patientInfo
                  ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
                  : null,
                age: item.prmsParameters?.patientInfo?.age || null,
              });
            }

            // ---------------- SPO2 ----------------
            const spo2Readings = item.prmsParameters?.data?.spo2 || [];
            const fileSpo2Records = item.prmsParameters?.data?.spo2_OxygenSaturation_Percentage;

            if (spo2Readings.length > 0) {
              allRecords.push({
                appointmentDate: formattedDate,
                pastRecords: 'SPO2',
                reading: {
                  type: 'spo2',
                  percentage: spo2Readings[0].percentage,
                  pulse: spo2Readings[0].pulse,
                  extra: spo2Readings.length > 1 ? `+${spo2Readings.length - 1}` : '',
                  allReadings: spo2Readings,
                  spo2_OxygenSaturation_Percentage: fileSpo2Records,
                },
                documentType: item.documentType === 'recorded_reading' ? 'Recorded Readings' : 'Past Consultation',
                attendedBy: item.prmsParameters?.consultationDetails?.attendedBy || item.attendedBy || 'Unknown',
                consultationId: item.consultationId,
                patientName: item.prmsParameters?.patientInfo
                  ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
                  : null,
                age: item.prmsParameters?.patientInfo?.age || null,
              });

              // Download SPO2 files if present
              if (fileSpo2Records) {
                let globalspO2list = "";
                Object.keys(fileSpo2Records).forEach(key => {
                  const fname = key.split("~")[1];
                  if (fname && fname.trim() !== "" && fname !== "manualentry") {
                    globalspO2list += fname + ",";
                  }
                });
                if (globalspO2list) {
                  this.downloadFileFroms3(globalspO2list, "spo2_OxygenSaturation_Percentage");
                }
              }
            }

            // ---------------- BP ----------------
            const systolicArr = item.prmsParameters?.data?.bpSystolic || [];
            const diastolicArr = item.prmsParameters?.data?.bpDiastolic || [];
            const pulseArr = item.prmsParameters?.data?.pulse || [];

            if (systolicArr.length > 0 && diastolicArr.length > 0) {
              const bpReadings = systolicArr.map((systolic: string, idx: number) => ({
                systolic,
                diastolic: diastolicArr[idx] || '',
                pulse: pulseArr[idx] || '',
              }));

              allRecords.push({
                appointmentDate: formattedDate,
                pastRecords: 'BP',
                reading: {
                  type: 'bp',
                  systolic: bpReadings[0].systolic,
                  diastolic: bpReadings[0].diastolic,
                  pulse: bpReadings[0].pulse,
                  extra: bpReadings.length > 1 ? `+${bpReadings.length - 1}` : '',
                  allReadings: bpReadings,
                },
                documentType: item.documentType === 'recorded_reading' ? 'Recorded Readings' : 'Past Consultation',
                attendedBy: item.prmsParameters?.consultationDetails?.attendedBy || item.attendedBy || 'Unknown',
                consultationId: item.consultationId,
                patientName: item.prmsParameters?.patientInfo
                  ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
                  : null,
                age: item.prmsParameters?.patientInfo?.age || null,
              });
            }

            // ---------------- Continue for ECG, Lipid, HbA1c, Hemoglobin, Glucose, EyeInocce, Spirometer ----------------
            // ... (copy the rest of your code here exactly as in your snippet) ...
            // ---------------- ECG ----------------
            const ecgFilepath = item.prmsParameters?.data?.ecg_filepath || {};
            const s3EcgFilepath = item.prmsParameters?.data?.s3_ecg_filepath || {};
            // Sort filenames numerically by the sequence number (e.g., 1, 2, 3 from "ble_ecg_97776_X.txt")
            const sortedEcgFilenames = Object.keys(ecgFilepath).sort((a, b) => {
            // Extract the number before ".txt" (e.g., "1" from "ble_ecg_97776_1.txt")
            const numA = parseInt(a.match(/ble_ecg_\d+_(\d+)\.txt/)?.[1] || '0', 10);
            const numB = parseInt(b.match(/ble_ecg_\d+_(\d+)\.txt/)?.[1] || '0', 10);
            return numA - numB;  // Ascending order
            });
            const ecgReadings = sortedEcgFilenames.map(filename => ({
              reportName: filename || 'ECG Report',
              pulseRate: ecgFilepath[filename],
              s3Url: s3EcgFilepath ? Object.keys(s3EcgFilepath).find(url => url.includes(filename)) : null
            })).filter(r => r.reportName && r.reportName.trim() !== "");

            if (ecgReadings.length > 0) {
              allRecords.push({
                appointmentDate: formattedDate,
                pastRecords: 'ECG',
                reading: {
                  type: 'ecg',
                  reportName: ecgReadings[0].reportName,
                  pulseRate: ecgReadings[0].pulseRate,
                  extra: ecgReadings.length > 1 ? `+${ecgReadings.length - 1}` : '',
                  allReadings: ecgReadings,
                },
                documentType: item.documentType === 'recorded_reading' ? 'Recorded Readings' : 'Past Consultation',
                attendedBy: item.prmsParameters?.consultationDetails?.attendedBy || item.attendedBy || 'Unknown',
                consultationId: item.consultationId,
                patientName: item.prmsParameters?.patientInfo
                  ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
                  : null,
                age: item.prmsParameters?.patientInfo?.age || null,
              });

              // Download ECG files if needed
              const globalEcgList = ecgReadings.map(r => r.reportName).filter(n => n).join(',');
              if (globalEcgList) this.downloadFileFroms3(globalEcgList, "ecg");
            }

            // ---------------- Lipid Profile ----------------
            const lipidArr = item.prmsParameters?.data?.lipid || [];
            if (lipidArr.length > 0) {
              const lipidReadings = lipidArr.map((lipid: any) => ({
                tc: lipid.total_cholesterol ?? '-',
                hdl: lipid.hdl_cholesterol ?? '-',
                ldl: lipid.ldl_friedewald ?? lipid.ldl_iranian ?? '-',
                tg: lipid.triglycerides ?? '-',
                readingNumber: lipid.reading_number ?? '-'
              }));

              allRecords.push({
                appointmentDate: formattedDate,
                pastRecords: 'Lipid Profile',
                reading: {
                  type: 'lipid',
                  tc: lipidReadings[0].tc,
                  hdl: lipidReadings[0].hdl,
                  ldl: lipidReadings[0].ldl,
                  tg: lipidReadings[0].tg,
                  extra: lipidReadings.length > 1 ? `+${lipidReadings.length - 1}` : '',
                  allReadings: lipidReadings,
                },
                documentType: item.documentType === 'recorded_reading' ? 'Recorded Readings' : 'Past Consultation',
                attendedBy: item.prmsParameters?.consultationDetails?.attendedBy || item.attendedBy || 'Unknown',
                consultationId: item.consultationId,
                patientName: item.prmsParameters?.patientInfo
                  ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
                  : null,
                age: item.prmsParameters?.patientInfo?.age || null,
              });
            }

            // ---------------- HbA1c ----------------
       const hbA1cArr: HbA1cReading[] = item.prmsParameters?.data?.hbA1cBean || [];

if (Array.isArray(hbA1cArr) && hbA1cArr.length > 0) {
  // Filter valid readings
  const validHbA1cReadings: HbA1cReading[] = hbA1cArr.filter(
    (r: HbA1cReading) => r.HbA1c_per || r.HbA1c_eAG || r.HbA1c_mmol
  );

  if (validHbA1cReadings.length > 0) {
    // Map readings (use different variable name to avoid duplicates)
    const mappedHbA1cReadings = validHbA1cReadings.map((r: HbA1cReading) => ({
      per: r.HbA1c_per ?? '-',
      eAG: r.HbA1c_eAG ?? '-',
      mmol: r.HbA1c_mmol ?? '-',
      readingNumber: r.reading_number ?? '-'
    }));

    allRecords.push({
      appointmentDate: formattedDate,
      pastRecords: 'HbA1c',
      reading: {
        type: 'hbA1c',
        per: mappedHbA1cReadings[0].per,
        eAG: mappedHbA1cReadings[0].eAG,
        mmol: mappedHbA1cReadings[0].mmol,
        extra: mappedHbA1cReadings.length > 1 ? `+${mappedHbA1cReadings.length - 1}` : '',
        allReadings: mappedHbA1cReadings,
        normalRanges: {
          per: item.prmsParameters?.data?.hbA1cHemoglobinPerNormalRange,
          mmol: item.prmsParameters?.data?.hbA1cHemoglobinNormalRange,
          eAG: item.prmsParameters?.data?.hbA1cEagNormalRange
        }
      },
      documentType:
        item.documentType === 'recorded_reading'
          ? 'Recorded Readings'
          : 'Past Consultation',
      attendedBy:
        item.prmsParameters?.consultationDetails?.attendedBy ||
        item.attendedBy ||
        'Unknown',
      consultationId: item.consultationId,
      patientName: item.prmsParameters?.patientInfo
        ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
        : null,
      age: item.prmsParameters?.patientInfo?.age || null,
    });
  }
}
            // ---------------- Hemoglobin ----------------
            const hemoglobinArr = item.prmsParameters?.data?.hemoglobin || item.hemoglobin || [];
            if (hemoglobinArr.length > 0) {
              allRecords.push({
                appointmentDate: formattedDate,
                pastRecords: 'Hemoglobin',
                reading: {
                  type: 'hemoglobin',
                  value: hemoglobinArr[0],
                  extra: hemoglobinArr.length > 1 ? `+${hemoglobinArr.length - 1}` : '',
                  allReadings: hemoglobinArr.map((val: string, idx: number) => ({
                    value: val,
                    readingNumber: idx + 1
                  }))
                },
                documentType: item.documentType === 'recorded_reading' ? 'Recorded Readings' : 'Past Consultation',
                attendedBy: item.prmsParameters?.consultationDetails?.attendedBy || item.attendedBy || 'Unknown',
                consultationId: item.consultationId,
                patientName: item.prmsParameters?.patientInfo
                  ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
                  : null,
                age: item.prmsParameters?.patientInfo?.age || null,
              });
            }

            // ---------------- Glucose ----------------
            const glucoseFastingArr = item.prmsParameters?.data?.glucoseFasting || [];
            const glucoseRandomArr = item.prmsParameters?.data?.glucoseRandom || [];
            const glucosePostprandialArr = item.prmsParameters?.data?.glucosePostprandial || [];

            const allGlucoseReadings: any[] = [];
            const maxLength = Math.max(glucoseFastingArr.length, glucoseRandomArr.length, glucosePostprandialArr.length);

            for (let i = 0; i < maxLength; i++) {
              if (i < glucoseFastingArr.length && glucoseFastingArr[i]?.trim() !== '') {
                allGlucoseReadings.push({ value: glucoseFastingArr[i].trim(), type: 'Fasting', readingNumber: i + 1, sequenceIndex: i, category: 'fasting' });
              }
              if (i < glucoseRandomArr.length && glucoseRandomArr[i]?.trim() !== '') {
                allGlucoseReadings.push({ value: glucoseRandomArr[i].trim(), type: 'Random', readingNumber: i + 1, sequenceIndex: i, category: 'random' });
              }
              if (i < glucosePostprandialArr.length && glucosePostprandialArr[i]?.trim() !== '') {
                allGlucoseReadings.push({ value: glucosePostprandialArr[i].trim(), type: 'Post-Prandial', readingNumber: i + 1, sequenceIndex: i, category: 'postprandial' });
              }
            }

            if (allGlucoseReadings.length > 0) {
              const latestReading = allGlucoseReadings.reduce((latest, current) => current.sequenceIndex > latest.sequenceIndex ? current : latest);
              const chronologicalReadings = allGlucoseReadings.sort((a, b) => a.sequenceIndex - b.sequenceIndex);

              allRecords.push({
                appointmentDate: formattedDate,
                pastRecords: `Glucose (${latestReading.type} Blood Sugar)`,
                reading: {
                  type: 'glucose',
                  subType: latestReading.category,
                  value: latestReading.value,
                  unit: 'Mg/Dl',
                  displayType: latestReading.type,
                  extra: allGlucoseReadings.length > 1 ? `+${allGlucoseReadings.length - 1}` : '',
                  allReadings: chronologicalReadings,
                  hasMultipleReadings: allGlucoseReadings.length > 1
                },
                documentType: item.documentType === 'recorded_reading' ? 'Recorded Readings' : 'Past Consultation',
                attendedBy: item.prmsParameters?.consultationDetails?.attendedBy || item.attendedBy || 'Unknown',
                consultationId: item.consultationId,
                patientName: item.prmsParameters?.patientInfo
                  ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
                  : null,
                age: item.prmsParameters?.patientInfo?.age || null,
              });
            }


            // ---------------- Rapid Test ---------------- 
const rapidReaderArr = item.prmsParameters?.data?.rapidreader || [];
if (Array.isArray(rapidReaderArr) && rapidReaderArr.length > 0) {
  const rapidReadings = rapidReaderArr.map((test: any, idx: number) => ({
    testName: test.testName || 'Rapid Test',
    testResult: test.testResult || 'N/A',
    testImage: test.testImage || null,
    patientId: test.patientid || this.patientId,
    consultationId: test.consultationid || item.consultationId,
    readingNumber: idx + 1
  }));

  allRecords.push({
    appointmentDate: formattedDate,
    pastRecords: 'Rapid Test',
    reading: {
      type: 'rapidtest',
      testName: rapidReadings[0].testName,
      testResult: rapidReadings[0].testResult,
      testImage: rapidReadings[0].testImage,
      extra: rapidReadings.length > 1 ? `+${rapidReadings.length - 1}` : '',
      allReadings: rapidReadings,
      hasMultipleReadings: rapidReadings.length > 1,
      gender: item.prmsParameters?.patientInfo?.gender || 'N/A',
      dateOfBirth: item.prmsParameters?.patientInfo?.dateOfBirth || 'N/A'
    },
    documentType:
      item.documentType === 'recorded_reading'
        ? 'Recorded Readings'
        : 'Past Consultation',
    attendedBy:
      item.prmsParameters?.consultationDetails?.attendedBy ||
      item.attendedBy ||
      'Unknown',
    consultationId: item.consultationId,
    patientName: item.prmsParameters?.patientInfo
      ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
      : null,
    age: item.prmsParameters?.patientInfo?.age || null,
  });
}
// ---------------- ECG Interpretation (AI + Manual Combined) ----------------
const ecgiFilepath = item.prmsParameters?.data?.ecgi_filepath || {};
const s3EcgiFilepath = item.prmsParameters?.data?.s3_ecgi_filepath || {};

console.log('ECG Interpretation Data:', { ecgiFilepath, s3EcgiFilepath });

const allEcgReadings: any[] = [];
// Sort filenames numerically by the sequence number (e.g., 1, 2, 3 from "ble_ecgi_97776_X.txt")
const sortedFilenames = Object.keys(ecgiFilepath).sort((a, b) => {
  // Extract the number before ".txt" (e.g., "1" from "ble_ecgi_97776_1.txt")
  const numA = parseInt(a.match(/ble_ecgi_\d+_(\d+)\.txt/)?.[1] || '0', 10);
  const numB = parseInt(b.match(/ble_ecgi_\d+_(\d+)\.txt/)?.[1] || '0', 10);
  return numA - numB;  // Ascending order
});

sortedFilenames.forEach((filename) => {
  const details = ecgiFilepath[filename];
  const parts = details ? details.split(',') : [];
  const pulseRate = parts[0] ? parseFloat(parts[0]) : undefined;
  const isManual = parts[1] === '1';
  const hasAIReport = parts.length > 2 && parts[parts.length - 1] === '1'; 
  const reading = {
    reportName: filename || 'ECG Interpretation Report',
    pulseRate,
    details,
    isManual,
     hasAIReport,
    s3Url: s3EcgiFilepath
      ? Object.keys(s3EcgiFilepath).find((url) => url.includes(filename))
      : null,
    consultationId: item.consultationId,
    patientId: this.patientId,
  };

  allEcgReadings.push(reading);
});

console.log('All ECG Readings:', allEcgReadings);

// Add Unified ECG Interpretation Record
if (allEcgReadings.length > 0) {
  const ecgRecord = {
    appointmentDate: formattedDate,
    pastRecords: 'ECG Interpretation',
    reading: {
      type: 'ecg-interpretation',
      reportName: allEcgReadings[0].reportName,
      pulseRate: allEcgReadings[0].pulseRate,
      extra: allEcgReadings.length > 1 ? `+${allEcgReadings.length - 1}` : '',
      allReadings: allEcgReadings,
    },
    documentType:
      item.documentType === 'recorded_reading'
        ? 'Recorded Readings'
        : 'Past Consultation',
    attendedBy:
      item.prmsParameters?.consultationDetails?.attendedBy ||
      item.attendedBy ||
      'Unknown',
    consultationId: item.consultationId,
    patientName: item.prmsParameters?.patientInfo
      ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
      : null,
    age: item.prmsParameters?.patientInfo?.age || null,
  };

  console.log('Adding ECG Interpretation Record:', ecgRecord);
  allRecords.push(ecgRecord);

  // Download all ECG files
  const allFileList = allEcgReadings.map((r) => r.reportName).filter((n) => n).join(',');
  if (allFileList) this.downloadFileFroms3(allFileList, 'ecgi_filepath');
}

// ---------------- Urine Test ----------------
const urineTestData = item.prmsParameters?.data;
const hasUrineTestData = urineTestData && (
  urineTestData.BLO || urineTestData.GLU || urineTestData.PRO ||
  urineTestData.URO || urineTestData.SG || urineTestData.pH ||
  urineTestData.BIL || urineTestData.NIT || urineTestData.KET || urineTestData.LEU
);

if (hasUrineTestData) {
  const urineTestResults = [];
  
  const maxUrineReadings = Math.max(
    (urineTestData.BLO || []).length,
    (urineTestData.GLU || []).length,
    (urineTestData.PRO || []).length,
    (urineTestData.URO || []).length,
    (urineTestData.SG || []).length,
    (urineTestData.pH || []).length,
    (urineTestData.BIL || []).length,
    (urineTestData.NIT || []).length,
    (urineTestData.KET || []).length,
    (urineTestData.LEU || []).length
  );

  for (let i = 0; i < maxUrineReadings; i++) {
    urineTestResults.push({
      BLO: urineTestData.BLO?.[i] || [],
      GLU: urineTestData.GLU?.[i] || [],
      PRO: urineTestData.PRO?.[i] || [],
      URO: urineTestData.URO?.[i] || [],
      SG: urineTestData.SG?.[i] || [],
      pH: urineTestData.pH?.[i] || [],
      BIL: urineTestData.BIL?.[i] || [],
      NIT: urineTestData.NIT?.[i] || [],
      KET: urineTestData.KET?.[i] || [],
      LEU: urineTestData.LEU?.[i] || [],
      testimage: urineTestData.testimage?.[i] ? [urineTestData.testimage[i]] : [],
      stripType: urineTestData.urineTestStripType?.[0] || '1',
      patientId: this.patientId,
      consultationId: item.consultationId,
      readingNumber: i + 1
    });
  }

  allRecords.push({
    appointmentDate: formattedDate,
    pastRecords: 'Urine Test',
    reading: {
      type: 'urinetest',
      summary: 'Test Results Available',
      extra: urineTestResults.length > 1 ? `+${urineTestResults.length - 1}` : '',
      allReadings: urineTestResults,
      hasMultipleReadings: urineTestResults.length > 1
    },
    documentType:
      item.documentType === 'recorded_reading'
        ? 'Recorded Readings'
        : 'Past Consultation',
    attendedBy:
      item.prmsParameters?.consultationDetails?.attendedBy ||
      item.attendedBy ||
      'Unknown',
    consultationId: item.consultationId,
    patientName: item.prmsParameters?.patientInfo
      ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
      : null,
    age: item.prmsParameters?.patientInfo?.age || null,
  });
}

            // ---------------- EyeInocce ----------------
            const eyeInocceArr = item.prmsParameters?.data?.eyeInocce || [];
            if (eyeInocceArr.length > 0) {
              allRecords.push({
                appointmentDate: formattedDate,
                pastRecords: 'EyeInocce',
                reading: { type: 'eyeInocce', value: eyeInocceArr[0], extra: eyeInocceArr.length > 1 ? `+${eyeInocceArr.length - 1}` : '', allReadings: eyeInocceArr },
                documentType: item.documentType === 'recorded_reading' ? 'Recorded Readings' : 'Past Consultation',
                attendedBy: item.prmsParameters?.consultationDetails?.attendedBy || item.attendedBy || 'Unknown',
                consultationId: item.consultationId,
                patientName: item.prmsParameters?.patientInfo ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}` : null,
                age: item.prmsParameters?.patientInfo?.age || null,
              });
            }
            

            // ---------------- Spirometer ----------------
            const spiroFilepathArr = item.prmsParameters?.data?.spiro_filepath || [];
            const s3SpiroFilepathArr = item.prmsParameters?.data?.s3_spiro_filepath || [];
            if (spiroFilepathArr.length > 0) {
              const spiroReadings = spiroFilepathArr.map((filename: string, idx: number) => ({
                reportName: filename || `Spirometer Report ${idx + 1}`,
                s3Url: s3SpiroFilepathArr[idx] || null,
                values: {
                  fvc: item.prmsParameters?.data?.fvc?.[idx] || null,
                  fev1: item.prmsParameters?.data?.fev1?.[idx] || null,
                  fev1_fvc: item.prmsParameters?.data?.fev1_fvc?.[idx] || null,
                  pef: item.prmsParameters?.data?.pef?.[idx] || null,
                  fef25: item.prmsParameters?.data?.fef25?.[idx] || null,
                  fef50: item.prmsParameters?.data?.fef50?.[idx] || null,
                  fef75: item.prmsParameters?.data?.fef75?.[idx] || null,
                  fef25_75: item.prmsParameters?.data?.fef25_75?.[idx] || null,
                  pif: item.prmsParameters?.data?.pif?.[idx] || null
                }
              }));

     

if (Array.isArray(spiroFilepathArr) && spiroFilepathArr.length > 0) {
  const spiroReadings = spiroFilepathArr.map((filename: string, idx: number) => ({
    reportName: filename || `Spirometer Report ${idx + 1}`,
    s3Url: s3SpiroFilepathArr[idx] || null,
    values: {
      fvc: item.prmsParameters?.data?.fvc?.[idx] || null,
      fev1: item.prmsParameters?.data?.fev1?.[idx] || null,
      fev1_fvc: item.prmsParameters?.data?.fev1_fvc?.[idx] || null,
      pef: item.prmsParameters?.data?.pef?.[idx] || null,
      fef25: item.prmsParameters?.data?.fef25?.[idx] || null,
      fef50: item.prmsParameters?.data?.fef50?.[idx] || null,
      fef75: item.prmsParameters?.data?.fef75?.[idx] || null,
      fef25_75: item.prmsParameters?.data?.fef25_75?.[idx] || null,
      pif: item.prmsParameters?.data?.pif?.[idx] || null,
      tv: item.prmsParameters?.data?.tv?.[idx] || null,
      tlc: item.prmsParameters?.data?.tlc?.[idx] || null,
      fet: item.prmsParameters?.data?.fet?.[idx] || null,
      fivc: item.prmsParameters?.data?.fivc?.[idx] || null,
      fev1percent: item.prmsParameters?.data?.fev1percent?.[idx] || null
    }
  }));

  const validSpiroReadings = spiroReadings.filter(r => r.reportName && r.reportName.trim() !== "");

  if (validSpiroReadings.length > 0) {
    allRecords.push({
      appointmentDate: formattedDate,
      pastRecords: 'SpiroMeter',
      reading: {
        type: 'spirometer',
        reportName: validSpiroReadings[0].reportName,
        extra: validSpiroReadings.length > 1 ? `+${validSpiroReadings.length - 1}` : '',
        allReadings: validSpiroReadings,
      },
      documentType:
        item.documentType === 'recorded_reading'
          ? 'Recorded Readings'
          : 'Past Consultation',
      attendedBy:
        item.prmsParameters?.consultationDetails?.attendedBy ||
        item.attendedBy ||
        'Unknown',
      consultationId: item.consultationId,
      patientName: item.prmsParameters?.patientInfo
        ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
        : null,
      age: item.prmsParameters?.patientInfo?.age || null,
    });
    // Download Spirometer files if needed
let globalSpiroList: string[] = [];
const deviceName = "spiro_filepath";

validSpiroReadings.forEach((reading) => {
  if (reading.reportName && reading.reportName.trim() !== "") {
    globalSpiroList.push(reading.reportName);
  }
});

if (globalSpiroList.length > 0) {
  this.downloadFileFroms3spirofilepath(globalSpiroList, deviceName);
}
  }
}

          
          }
  // ✅ NEW: Process Images (for current consultation or all)
            const imageGroups = item.prmsParameters?.consultationImages?.imageGroups || [];
            if (imageGroups.length > 0) {
              const isCurrentConsultation = this.isToday(rawDate);  // Implement helper below
              console.log('Processing Images for Consultation:', isCurrentConsultation);
              if (isCurrentConsultation) {  // Or remove this if you want all images
                imageGroups.forEach((group: any) => {
                  allRecords.push({
                    appointmentDate: formattedDate,
                          pastRecords: `${group.imageType} (${group.imageCount} images)`,  // e.g., "ECG (2 images)"
                    reading: {
                      type: 'images',  // Custom type for images
                      imageGroup: group,
                      allImages: group.images,  // Array of images with S3URL, addedAt, imageType, etc.
                      totalImageCount: group.imageCount,
                      imageType: group.imageType,
                      patientId: this.patientId,
                      consultationId: item.consultationId
                    },
                    documentType: 'Manually Uploaded',  // Hardcoded as requested
                    attendedBy: item.prmsParameters?.consultationDetails?.attendedBy || item.attendedBy || 'Unknown',
                    consultationId: item.consultationId,
                    patientName: item.prmsParameters?.patientInfo
                      ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
                      : null,
                    age: item.prmsParameters?.patientInfo?.age || null,
                    showDetails: false  // No expand needed, but optional
                  });
                });
              }
            }

            // ---------------- Stethoscope ----------------
            const stethoFilepathArr = item.prmsParameters?.data?.stetho_filepath || [];
            const s3StethoFilepathArr = item.prmsParameters?.data?.s3_stetho_filepath || [];
            console.log('Stethoscope data found:', stethoFilepathArr, s3StethoFilepathArr);
            if (stethoFilepathArr.length > 0) {
              const stethoReadings = stethoFilepathArr.map((filename: string, idx: number) => ({
                reportName: filename || `Stethoscope Report ${idx + 1}`,
                s3Url: s3StethoFilepathArr[idx] || null,
                filePath: filename
              }));

              const validStethoReadings = stethoReadings.filter((r: any) => r.reportName && r.reportName.trim() !== "");

              if (validStethoReadings.length > 0) {
                allRecords.push({
                  appointmentDate: formattedDate,
                  pastRecords: 'Stethoscope',
                  reading: {
                    type: 'stethoscope',
                    reportName: validStethoReadings[0].reportName,
                    extra: validStethoReadings.length > 1 ? `+${validStethoReadings.length - 1}` : '',
                    allReadings: validStethoReadings,
                  },
                  documentType: item.documentType === 'recorded_reading' ? 'Recorded Readings' : 'Past Consultation',
                  attendedBy: item.prmsParameters?.consultationDetails?.attendedBy || item.attendedBy || 'Unknown',
                  consultationId: item.consultationId,
                  patientName: item.prmsParameters?.patientInfo
                    ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
                    : null,
                  age: item.prmsParameters?.patientInfo?.age || null,
                });

                // Download Stethoscope files
                const globalStethoList = validStethoReadings.map((r: any) => r.reportName).filter((n: any) => n);
                if (globalStethoList.length > 0) {
                  console.log('this method called this.downloadFileFroms3stetho(globalStethoList, "stetho_filepath");')
                  this.downloadFileFroms3stetho(globalStethoList, "stetho_filepath");
                }
              }
            }

            // ---------------- Fetal Doppler ----------------
            const fetalFilepathArr = item.prmsParameters?.data?.fetal_filepath || [];
            const s3FetalFilepathArr = item.prmsParameters?.data?.s3_fetal_filepath || [];
            console.log('Fetal Doppler data found:', fetalFilepathArr, s3FetalFilepathArr);
            if (fetalFilepathArr.length > 0) {
              const fetalReadings = fetalFilepathArr.map((filename: string, idx: number) => ({
                reportName: filename || `Fetal Doppler Report ${idx + 1}`,
                s3Url: s3FetalFilepathArr[idx] || null,
                filePath: filename
              }));

              const validFetalReadings = fetalReadings.filter((r: any) => r.reportName && r.reportName.trim() !== "");

              if (validFetalReadings.length > 0) {
                allRecords.push({
                  appointmentDate: formattedDate,
                  pastRecords: 'Fetal Doppler',
                  reading: {
                    type: 'fetal',
                    reportName: validFetalReadings[0].reportName,
                    extra: validFetalReadings.length > 1 ? `+${validFetalReadings.length - 1}` : '',
                    allReadings: validFetalReadings,
                  },
                  documentType: item.documentType === 'recorded_reading' ? 'Recorded Readings' : 'Past Consultation',
                  attendedBy: item.prmsParameters?.consultationDetails?.attendedBy || item.attendedBy || 'Unknown',
                  consultationId: item.consultationId,
                  patientName: item.prmsParameters?.patientInfo
                    ? `${item.prmsParameters.patientInfo.firstName} ${item.prmsParameters.patientInfo.lastName}`
                    : null,
                  age: item.prmsParameters?.patientInfo?.age || null,
                });

                // Download Fetal Doppler files
                const globalFetalList = validFetalReadings.map((r: any) => r.reportName).filter((n: any) => n);
                if (globalFetalList.length > 0) {
                  console.log('this method called this.downloadFileFroms3stetho(globalStethoList, "stetho_filepath");')
                  this.downloadFileFroms3fetal(globalFetalList, "fetal_filepath");
                }
              }
            }
            return allRecords;
          });

          console.log("Mapped Consultation Data:", this.allConsultationList);
          
          // Debug: Check for stethoscope and fetal records
          const stethoRecords = this.allConsultationList.filter(record => record.reading?.type === 'stethoscope');
          const fetalRecords = this.allConsultationList.filter(record => record.reading?.type === 'fetal');
          console.log('Stethoscope records found:', stethoRecords.length, stethoRecords);
          console.log('Fetal Doppler records found:', fetalRecords.length, fetalRecords);

          // ---------------- Generate Dynamic Filters ----------------
          const attendedBySet = new Set<string>();
          (this.allConsultationList || []).forEach(item => {
            if (item && item.attendedBy) {
              attendedBySet.add(item.attendedBy);
            }
          });

          this.filterData = [
            {
              title: 'Past Consultations',
              type: 'past_consultation',
              items: this.allConsultationList.filter(
                i => i.documentType === 'Past Consultation'
              ),
            },
            {
              title: 'Current Consultation',
              type: 'current_consultation',
              items: this.allConsultationList.filter(
                i => i.documentType === 'Recorded Readings'
              ),
            },
            {
              title: 'Attended By',
              type: 'attended_by',
              items: Array.from(attendedBySet),
            },
          ];

          this.attendedByList = this.filterData.find(f => f.type === 'attended_by')?.items || [];

          this.currentPage = 1;
          this.updatePaginatedData();

        } else {
          this.allConsultationList = [];
          this.filterData = [];
          this.attendedByList = [];
        }
      },
      error: (err) => {
        console.error('Error fetching consultation list:', err);
        this.allConsultationList = [];
        this.filterData = [];
        this.attendedByList = [];
      }
    });
}
 private isToday(dateString: string): boolean {
    if (!dateString) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);  // Normalize to start of day
    const inputDate = new Date(dateString);
    inputDate.setHours(0, 0, 0, 0);  // Normalize input date
    return inputDate.getTime() === today.getTime();
  }
openPastConsultationPage(consultationId: string, documentType: string) {
  // ✅ Check document type before making API call
  if (documentType === 'Recorded Readings') {
    console.log('Skipping popup for Recorded Readings');
    return; // stop here, don’t open popup
  }

  const data = `?action=consultationdetailsforangular&consultationId=${consultationId}&patientId=${this.patientId}&domain=${this.currDomainId}&timeOffset=${environment.getTimeOffSet()}&domainid=${this.currDomainId}&userLang=English&token=${this.tokenRequest}`;

  this.apiSvc.postServiceByQueryBasic(this.constantSvc.APIConfig.GETCOMMONSERVICES, data)
    .subscribe({
      next: (res: any) => {
        console.log('API Response:', res); // Debug
         // ✅ Extract counts safely
        const imageTypeCount = res?.consultationImages?.imageTypeCount || 0;
        const totalImageCount = res?.consultationImages?.totalImageCount || 0;

         if (
          (res.status === 'success' || res.status === 'OK') ||
          (res.status === 'error' && imageTypeCount > 0)
        ) {
          this.dialog.open(PastConsultationPage, {
              data: { 
              apiResponse: res,
              consultationId: consultationId,  
              patientId: this.patientId        
            },
            width: '1000px',
            height: '720px',
            disableClose: true,
          });
        } else {
          console.warn('No data available to show in popup');
        }
      },
      error: (err) => {
        console.error('Error fetching consultation details:', err);
      }
    });
}


  // Helper for document type
  getDocumentTypeLabel(docType: string): string {
    switch (docType) {
      case 'recorded_reading': return 'Recorded Readings';
      case 'manual_upload': return 'Manually Uploaded';
      case 'past_consultation': return 'Past Consultation';
      default: return 'Consultation';
    }
  }

  getMonthNumber(mon: string): string {
    const months: any = {
      Jan: "01", Feb: "02", Mar: "03", Apr: "04",
      May: "05", Jun: "06", Jul: "07", Aug: "08",
      Sep: "09", Oct: "10", Nov: "11", Dec: "12"
    };
    return months[mon] || "01";
  }


  async openPastRecordHistoryPage(readings: any[]) {
    const dialogRef = this.dialog.open(PastRecordHistoryPage, {
      // width: "600px",
      height: "auto",
      minWidth: '250px',
      maxWidth: '1000px',
      disableClose: true,
      data: { readings }  // <-- Pass readings here
      // panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result) => {

    });
  }

  openSpo2Dialog(allReadings: any[]) {
    console.log("All SPO2 Readings for Graph:", allReadings);
    this.dialog.open(Spo2DevicePage, {
      data: {
        api: "apiCalling",
        parameter: "spo2",
        data: { readings: allReadings },
        index: this.spo2Index ?? 0,
      },
      width: 'auto',
      height: 'auto',
      disableClose: true,
    });
  }

  uploadDocuments() {
    const dialogRef = this.dialog.open(UDocumentsPage, {
      width: "800px",
      height: "auto",
      panelClass: 'UploadImagePage-dialog',
      disableClose: true,
      // panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result) => {

    });

  }

  // uploadDocuments()  {
  //   const dialogRef = this.dialog.open(UploadDocumentsPage, {
  //     width: "600px",
  //     height: "auto",
  //     //panelClass: 'UploadImagePage-dialog',
  //     disableClose: true,
  //     // panelClass: 'slot-dialog'
  //   });

  //   dialogRef.afterClosed().subscribe((result) => {

  //   });

  // }


  downloadFileFroms3(downloadfilelist: string, devicename: string) {
    let data =
      "?action=downloadfilefroms3&downloadfilelist=" +
      downloadfilelist +
      "&devicename=" +
      devicename +
      "&conId=" +
      this.consultationId +
      "&patientId=" +
      this.patientId +
      "&token=" +
      this.tokenRequest;

    this.apiSvc
      .postServiceByQueryBasic(
        this.constantSvc.APIConfig.GETCOMMONSERVICES,
        data
      )
      .subscribe((res) => {
        console.log("downloadFileFroms3", res);
      });
  }

  closePopup() {
    this.isTemperaturePopupOpen = false;
  }
  prepareEcgPayload(r: any, record: any) {
  return {
    ...r,
    consultationId: record.consultationId,
    patientId: this.patientId
  };
}

getPastRecordEcg(reading: any) {
  console.log("INSIDE getPastRecordEcg:", reading);

  const dialogRef = this.dialog.open(EcgJettyDevicePage, {
    data: {
      api: "apiCalling",
      data: { readings: reading },
      index: '1',
    },
    width: "1000px",
    height: "auto",
    disableClose: true,
    panelClass: 'slot-dialog'
  });

  dialogRef.afterClosed().subscribe((result) => {
    if (result !== undefined) {
      console.log("Dialog closed with:", result);
    }
  });
}
  onDateRangeSelected(dateRange: { start: Date; end: Date }): void {
    this.selectedDateRange = dateRange;

    const startStr = `${dateRange.start.getMonth() + 1}/${dateRange.start.getDate()}/${dateRange.start.getFullYear()}`;
    const endStr = `${dateRange.end.getMonth() + 1}/${dateRange.end.getDate()}/${dateRange.end.getFullYear()}`;

    this.getAllConsultationListForToday(startStr, endStr);
  }


onCalendarClosed(): void {
  this.showCalendar = false;
}

clearDateRange() {
  this.selectedDateRange = null;
}

clearSort() {
  this.selectedSort = null;
}
  
 downloadFileFroms3spirofilepath(spiro_filepaths: string[], deviceNamefetal: string) {
  spiro_filepaths.forEach(file => {
    const data = `?action=downloadfilefroms3&downloadfilelist=${file}`
      + `&devicename=${deviceNamefetal}`
      + `&conId=${this.consultationId}`
      + `&patientId=${this.patientId}`
      + `&token=${this.tokenRequest}`;

    this.apiSvc.postServiceByQueryBasicText(
  this.constantSvc.APIConfig.GETCOMMONSERVICES,
  data
).subscribe((res: any) => {
  const textResponse = res as string;
  console.log("downloadFileFroms3spirofilepath", textResponse);
});

  });
}

downloadFileFroms3stetho(stetho_filepaths: string[], deviceName: string) {
  stetho_filepaths.forEach(file => {
    const data = `?action=downloadfilefroms3&downloadfilelist=${file}`
      + `&devicename=${deviceName}`
      + `&conId=${this.consultationId}`
      + `&patientId=${this.patientId}`
      + `&token=${this.tokenRequest}`;

    this.apiSvc.postServiceByQueryBasicText(
      this.constantSvc.APIConfig.GETCOMMONSERVICES,
      data
    ).subscribe((res: any) => {
      console.log("Downloaded stethoscope file:", res);
    });
  });
}

downloadFileFroms3fetal(fetal_filepaths: string[], deviceName: string) {
  fetal_filepaths.forEach(file => {
    const data = `?action=downloadfilefroms3&downloadfilelist=${file}`
      + `&devicename=${deviceName}`
      + `&conId=${this.consultationId}`
      + `&patientId=${this.patientId}`
      + `&token=${this.tokenRequest}`;

    this.apiSvc.postServiceByQueryBasicText(
      this.constantSvc.APIConfig.GETCOMMONSERVICES,
      data
    ).subscribe((res: any) => {
      console.log("Downloaded fetal doppler file:", res);
    });
  });
}


spiroSeriesData = [];
  spiroCount = 0;
  getPastRecordSpiroDevice(allReadings: any[]) {
 
      const dialogRef = this.dialog.open(SpirometerJettyDevicePage, {
        data: {
          api: "apiCalling",
          data: allReadings,
        },
        disableClose: true,
         width: '1000px',
         maxWidth: '1000px',
         panelClass: 'custom-spiro-dialog',
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result != undefined) {
        }
      });
    //}
  }

viewImages(images: any[], patientId: string, consultationId: string, event?: Event) {
  event?.stopPropagation(); // Prevent row click duplication

  console.log('Viewing images:', images);
  console.log('Patient ID:', patientId);
  console.log('Consultation ID:', consultationId);

  const dialogRef = this.dialog.open(PastImagesPreviewPage, {
    data: { 
      images, 
      patientId, 
      consultationId 
    },  // ✅ pass all three
    width: '1000px',
    height: '600px',
    disableClose: true,
    panelClass: 'image-viewer-dialog'
  });

  dialogRef.afterClosed().subscribe((result) => {
    if (result) {
      console.log('Image action:', result);  // e.g., download or zoom
    }
  });
}

  openRapidTestPopup(individualReading: any, parentReading: any, record: any) {
  console.log("Opening Rapid Test Popup:", individualReading, parentReading, record);

  const dialogRef = this.dialog.open(PastpopfordisplayingImagesComponent, {
    data: {
      reading: {
        testName: individualReading.testName || parentReading.testName || 'Rapid Test',
        testResult: individualReading.testResult || parentReading.testResult || 'N/A',
        testImage: individualReading.testImage || parentReading.testImage || null,
        gender: parentReading.gender || 'N/A',
        dateOfBirth: parentReading.dateOfBirth || 'N/A'
      },
      record: {
        patientName: record.patientName || 'N/A',
        age: record.age || 'N/A'
      }
    },
    width: '1289px',
    maxWidth: '90vw',
    height: 'auto',
    maxHeight: '90vh',
    disableClose: true,
    panelClass: 'rapid-test-dialog'
  });

  dialogRef.afterClosed().subscribe((result) => {
    if (result !== undefined) {
      console.log("Rapid Test Dialog closed with:", result);
    }
  });
}

/**
 * Opens Urine Test popup dialog
 */
openUrineTestPopup(urineReading: any, parentReading: any, record: any) {
  console.log("Opening Urine Test Popup:", urineReading, parentReading, record);
  
  const dialogRef = this.dialog.open(PastpopfordisplayingImagesComponent, {
    data: {
      testType: 'urine',
      reading: {
        BLO: urineReading.BLO || [],
        GLU: urineReading.GLU || [],
        PRO: urineReading.PRO || [],
        URO: urineReading.URO || [],
        SG: urineReading.SG || [],
        pH: urineReading.pH || [],
        BIL: urineReading.BIL || [],
        NIT: urineReading.NIT || [],
        KET: urineReading.KET || [],
        LEU: urineReading.LEU || [],
        testimage: urineReading.testimage || [],
        stripType: urineReading.stripType || '1',
        patientId: urineReading.patientId || this.patientId,
        consultationId: urineReading.consultationId || record.consultationId
      },
      record: {
        patientName: record.patientName || 'N/A',
        age: record.age || 'N/A',
        appointmentDate: record.appointmentDate || 'N/A'
      }
    },
    width: '1289px',
    maxWidth: '95vw',
    height: 'auto',
    maxHeight: '90vh',
    disableClose: true,
    panelClass: ['urine-test-dialog', 'full-width-dialog'],
    hasBackdrop: true,
    backdropClass: 'urine-transparent-backdrop',
  });

  dialogRef.afterClosed().subscribe((result) => {
    if (result !== undefined) {
      console.log("Urine Test Dialog closed with:", result);
    }
  });
}/**
 * Opens ECG Interpretation dialog (AI or Manual based on reading type)
 */openEcgInterpretation(reading: any): void {
  console.log("Opening ECG Interpretation:", reading);

  const isManual = reading.isManual === true;

  if (isManual) {
     const panelClassName =
  this.usertype === 'Doctor'
    ? 'ecgi-manual-dialog-panel'
    : 'ecgi-manual-dialog-panel';

            const dialogRef = this.dialog.open(EcgInterpretationManualJettyComponent, {
             
      data: {
        api: "apiCalling",
        data: { readings: reading },
        index: '1',
      },
      width: "1000px",
      height: "auto",
       position: { left: '3%' } ,
      disableClose: true,
        panelClass: panelClassName,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result !== undefined) {
        console.log("Manual ECG Dialog closed with:", result);
      }
    });
  } else {
    // AI ECG Interpretation
    const dialogRef = this.dialog.open(EcgInterpretationJettyDeviceComponent, {
      data: {
        api: "apiCalling",
        data: { readings: reading },
        index: '1',
      },
      width: "1000px",
      height: "auto",
      disableClose: true,
      panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result !== undefined) {
        console.log("AI ECG Dialog closed with:", result);
      }
    });
  }
}


// Add this method to the PastrecordsPage component
downloadReport(reading: any) {
  const params = {
    action: 'downloadInterpretationReport',
    username: this.username,
    conId: this.consultationId,
    domain: this.currDomainId,
    filepath: reading.reportName,  // Assuming reportName is the filepath, e.g., 'ble_ecgi_96314_1.txt'
    patientId: this.patientId,
    token: this.tokenRequest
  };

  const queryString = new URLSearchParams(params).toString();  // Assuming BASE_URL is defined in constantSvc

  this.apiSvc.postServiceByQueryBasic(this.constantSvc.APIConfig.GETCOMMONSERVICES, `?${queryString}`)
    .subscribe({
      next: (res: any) => {
        if (res.status === 'ok' && res.S3FileName_URL) {
          // Extract the URL and trigger download
          const downloadUrl = res.S3FileName_URL;
          window.open(downloadUrl, '_blank');  // Opens the PDF in a new tab/window for download
        } else {
          console.error('Failed to download report:', res.message);
          // Optionally show a user-friendly error message
        }
      },
      error: (err) => {
        console.error('Error downloading report:', err);
        // Optionally show a user-friendly error message
      }
    });
}
getPastRecordStetho(reading: any) {
  console.log("INSIDE getPastRecordStetho:", reading);

  const dialogRef = this.dialog.open(StethoscopeDevicePage, {
    data: {
      api: "apiCalling",
      data: { readings: reading },
      index: '1',
    },
    width: "800px",
    height: "auto",
    disableClose: true,
    panelClass: 'slot-dialog'
  });

  dialogRef.afterClosed().subscribe((result) => {
    if (result !== undefined) {
      console.log("Stethoscope Dialog closed with:", result);
    }
  });
}

getPastRecordFetal(reading: any) {
  console.log("INSIDE getPastRecordFetal:", reading);

  // Enhanced data structure for fetal doppler past records with proper file handling
  const dialogRef = this.dialog.open(FetalDopplerDevicePage, {
    data: {
      api: "apiCalling",
      parameter: "fetal",
      data: { 
        readings: Array.isArray(reading) ? reading : [reading],
        consultationId: this.consultationId,
        patientId: this.patientId,
        // Extract filename with heart rate for proper file reading
        selectedFileName: reading.fullFileName || reading.reportName || reading.filePath
      },
      index: 0,
      // Enhanced flags for past record functionality
      enableFileReading: true,
      enableGraphPlotting: true,
      enableAudioPlayback: true
    },
    width: "1000px",
    height: "650px", // Slightly taller for enhanced controls
    disableClose: true,
    panelClass: 'fetal-doppler-enhanced-dialog'
  });

  dialogRef.afterClosed().subscribe((result) => {
    if (result !== undefined) {
      console.log("Enhanced Fetal Doppler Dialog closed with:", result);
    }
  });
}

}