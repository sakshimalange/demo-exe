import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PastrecordsPage } from './pastrecords.page';

describe('PastrecordsPage', () => {
  let component: PastrecordsPage;
  let fixture: ComponentFixture<PastrecordsPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PastrecordsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
