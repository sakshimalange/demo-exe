import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { lastValueFrom } from 'rxjs';
import { PouchdbService } from '../../../../core/services/pouchdb.service';
import { Investigation } from '../../../../core/interfaces/localconsultation.model';
import { ApiService } from '../../../../core/services/api.service';
import { ConstantService } from '../../../../core/services/constant.service';
import { DialogService } from 'src/app/core/services/dialog.service';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

@Component({
  selector: 'app-investigations',
  templateUrl: './investigations.page.html',
  styleUrls: ['./investigations.page.scss', '../tabs/tabs.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule, HttpClientModule, MatSnackBarModule],
})
export class InvestigationsPage implements OnInit {
  masterData: any = {};
  labCategories: any[] = [];
  labTests: any[] = [];
  filteredLabList: any[] = [];
  filteredTestList: any[] = [];
  investigationForm: FormGroup;
  investigations: Investigation[] = [];

  saving = false;
  message = '';
  error = '';
  editingInvestigation: Investigation | null = null;
  isLocalConsultation: boolean = false;
  isMobile = false;
  isModalOpen = false;
  showLabDropdown = false;
  showTestDropdown = false;

  constructor(
    private pouchdbService: PouchdbService,
    private pouch: PouchdbService,
    private http: HttpClient,
    private pouchdb: PouchdbService,
    private fb: FormBuilder,
    private apiService: ApiService,
    private constantService: ConstantService,
    private dialogService: DialogService,
    private snackBar: MatSnackBar
  ) {
    this.investigationForm = this.fb.group({
      investigationMode: ['select'],
      selectedTest: [''],
      selectedLab: [''],
      selectedLabId: [''],
      selectedLabName: [''],
      isProvisional: [false],
    });
  }

  async ngOnInit() {

    const flag = localStorage.getItem('isLocalConsultation') === 'true';
    this.isLocalConsultation = flag;

    this.pouch.initDB('prms_investigation');

    this.checkScreenSize();
    window.addEventListener('resize', () => this.checkScreenSize());

    this.loadSavedInvestigations(); // Now calls sync after loading
    this.checkNetworkAndSync();


    this.labCategories = await this.pouchdbService.getTable('tbllabcategory');
    console.log('Patient labCategories:', this.labCategories);

    this.labTests = await this.pouchdbService.getTable('tbllabsubtest');
    console.log('Patient labTests:', this.labTests);

    // Initialize filtered lists with ascending order sorting
    this.filteredLabList = [...this.labCategories].sort((a, b) => (a.LabName || '').localeCompare(b.LabName || ''));
    this.filteredTestList = [...this.labTests].sort((a, b) => (a.TestName || '').localeCompare(b.TestName || ''));

  }

  investigationLabelMap: any = {
    select: 'Test',
    chapter: 'Lab & Test',
    manual: 'Manual Test Entry'
  };

  onLabSelected(event: any) {
    const value = event.target.value;
    let selectedLab;
    if (this.investigationForm.get('investigationMode')?.value === 'manual') {
      selectedLab = this.labCategories.find(lab => lab.Id == value);
    } else {
      selectedLab = this.labCategories.find(lab => lab.LabName === value);
    }
    if (selectedLab) {
      this.investigationForm.patchValue({
        selectedLab: selectedLab.LabName,
        selectedLabId: selectedLab.Id,
        selectedLabName: selectedLab.LabName
      });
    } else {
      this.investigationForm.patchValue({
        selectedLab: '',
        selectedLabId: '',
        selectedLabName: ''
      });
    }
  }

  checkScreenSize() {
    this.isMobile = window.innerWidth <= 500;
  }
  openModal() {
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
    this.editingInvestigation = null;
    this. investigationForm.reset({ days: 0 });
  }


  private checkNetworkAndSync() {
    if (navigator.onLine) {
      console.log(' Online - Starting investigation sync...');
      this.syncAllUnsyncedInvestigation();
    }
    window.addEventListener('online', () => {
      console.log(' Back online - Syncing investigations...');
      this.syncAllUnsyncedInvestigation();
    });
  }


  /**  Add or  Update Investigation */
  saveInvestigation() {
    const formValue = this.investigationForm.value;

    // Validation with warning dialog
    if (!formValue.selectedTest?.trim()) {
      this.dialogService.warning('Please enter or select a test.');
      return;
    }

    if (formValue.investigationMode === 'chapter' || formValue.investigationMode === 'manual') {
      if (!formValue.selectedLab?.trim()) {
        this.dialogService.warning('Please select a lab.');
        return;
      }
    }

    if (this.saving) return;

    this.saving = true;
    this.message = '';
    this.error = '';

    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const consultationId = localStorage.getItem('consultationId') || '1';
    const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
    const domain = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
    const username = loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? '';
    const patientId = patientDetails.patientid || '';

    const data: Investigation = {
      test: formValue.selectedTest,
      lab: formValue.selectedLab || '',
      labId: formValue.selectedLabId || '',
      isMandatory: formValue.isProvisional,
      investigationMode: formValue.investigationMode,
      mandatory: true,
      createdAt: new Date().toISOString(),
      type: 'investigation',
      synced: false,
      domain: domain,
      action: 'savetoserver',
      patientId: patientId,
      consultationId: consultationId,
      username: username,
      paramName: 'investigation',
      tblname: 'prms_investigation',
      token: token,
      forwardto: 'AndroidRemoteConsultaionSevices.do',
    };

    if (this.editingInvestigation && this.editingInvestigation._id && this.editingInvestigation._rev) {
      const updatedDoc = { ...this.editingInvestigation, ...data };
      this.pouchdb.updateRecord(updatedDoc).subscribe({
        next: () => {
          this.finishAction(' Investigation updated!');
          this.snackBar.open('Investigation updated successfully.', 'Close', { duration: 3000 });
        },
        error: (err) => this.finishAction(' Failed to update investigation: ' + err.message, true),
      });
    } else {
      this.pouchdb.addRecord(data).subscribe({
        next: () => {
          this.finishAction(' Investigation added!');
          this.snackBar.open('Investigation saved successfully.', 'Close', { duration: 3000 });
        },
        error: (err) => this.finishAction(' Failed to add investigation: ' + err.message, true),
      });
    }

     if (this.isMobile) this.closeModal();
  }

  addInvestigation() {
    this.saveInvestigation();
  }

  /** 📥 Load all saved investigations */
  loadSavedInvestigations() {
     const consultationId = localStorage.getItem('consultationId') || '';
    console.log('consultationId', consultationId);

    this.pouchdb.getRecordsByType<Investigation>('investigation').subscribe({
      next: (docs) => {
        this.investigations = docs.filter(investigations => investigations.consultationId === consultationId);
        this.investigations = docs;
        console.log(' Investigations Loaded:', this.investigations);
        //  Call sync AFTER data is loaded
        this.syncAllUnsyncedInvestigation();
      },
      error: (err) => {
        console.error(' Error loading investigations:', err);
        this.error = 'Failed to load investigations.';
      },
    });
  }

  editInvestigation(item: Investigation) {
    this.editingInvestigation = { ...item };
    this.investigationForm.patchValue({
      selectedTest: item.test,
      selectedLab: item.lab || '',
      selectedLabId: item.labId || '',
      selectedLabName: item.lab || '',
      isProvisional: item.isMandatory || false,
      investigationMode: item.investigationMode || 'select',
    });
  }

  async deleteInvestigation(item: Investigation) {
    if (!item._id) return;

    try {
      // ✅ Fetch the latest document to get the current _rev before deleting
      const latestItem = await lastValueFrom(this.pouchdbService.getRecordById<Investigation>(item._id));
      this.pouchdb.deleteRecord(latestItem).subscribe({
        next: () => {
          this.finishAction(' Investigation deleted!');
          this.snackBar.open('Investigation deleted successfully.', 'Close', { duration: 3000 });
        },
        error: (err) => this.finishAction(' Failed to delete investigation: ' + (err instanceof Error ? err.message : String(err)), true),
      });
    } catch (err) {
      this.finishAction(' Failed to delete investigation: ' + (err instanceof Error ? err.message : String(err)), true);
    }
  }

  /**  Sync all unsynced investigations */
  private async syncAllUnsyncedInvestigation() {
    this.pouch.initDB('prms_investigation');

    const unsyncedInvestigations = this.investigations.filter((inv) => !inv.synced);
    for (const investigation of unsyncedInvestigations) {
      await this.syncWithBackend(investigation);
    }
  }

  /**  API sync */

  private async syncWithBackend(investigation: Investigation) {
    this.pouch.getAllRecords<Investigation>().subscribe((records) => {
      const unsynced = records.filter((r) => !r.synced && r.consultationId === localStorage.getItem('consultationId'));
      console.log('unsynced', unsynced);

      unsynced.forEach((record) => {

        const token = localStorage.getItem('token') || '';

        const query =
          `?forwardto=${investigation.forwardto}` +
          `&action=${investigation.action}` +
          `&domain=${investigation.domain}` +
          `&username=${investigation.username}` +
          `&patientId=${investigation.patientId}` +
          `&consultationId=${investigation.consultationId}` +
          `&tblname=${investigation.tblname}` +
          `&test=${encodeURIComponent(investigation.test || '')}` +
          `&lab=${encodeURIComponent(investigation.lab || '')}` +
          `&diagnosisList: ${investigation.test || ''}~${investigation.labId || ''}` +
          `&labId=${encodeURIComponent(investigation.labId || '0')}` +
          `&isMandatory=${investigation.isMandatory ? '1' : '0'}` +
          `&investigationMode=${investigation.investigationMode}` +

          `&token=${token}`;
        this.apiService.postServiceByQueryBasic(this.constantService.APIConfig.GETCOMMONSERVICES, query)
          .subscribe({
            next: (res: any) => {
              if (res.status === 'success') {
                console.log('Synced Investigation record:', record);
                record.synced = true;
                this.pouch.updateRecord(record).subscribe();
              } else {
                console.warn('Sync failed:', res);
              }
            },
            error: (err) => {
              console.error('Error syncing Investigation record:', err);
            },

          });
      });
    });
  }


  private finishAction(msg: string, isError = false) {
    this.saving = false;
    if (isError) this.error = msg;
    else this.message = msg;

    this.resetForm();
    this.loadSavedInvestigations();
  }

  private resetForm() {
    this.investigationForm.reset({
      investigationMode: 'select',
      selectedTest: '',
      selectedLab: '',
      selectedLabId: '',
      selectedLabName: '',
      isProvisional: false,
    });
    this.editingInvestigation = null;
  }

  // Filter and Search Methods
  filterLabList() {
    const input = this.investigationForm.get('selectedLab')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredLabList = [...this.labCategories].sort((a, b) => (a.LabName || '').localeCompare(b.LabName || ''));
      return;
    }
    this.filteredLabList = this.labCategories.filter(lab =>
      lab.LabName?.toLowerCase().includes(input)
    ).sort((a, b) => (a.LabName || '').localeCompare(b.LabName || ''));
  }

  selectLab(lab: any) {
    this.investigationForm.get('selectedLab')?.setValue(lab.LabName);
    this.showLabDropdown = false;
  }

  hideLabDropdown() {
    setTimeout(() => this.showLabDropdown = false, 200);
  }

  filterTestList() {
    const input = this.investigationForm.get('selectedTest')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredTestList = [...this.labTests].sort((a, b) => (a.TestName || '').localeCompare(b.TestName || ''));
      return;
    }
    this.filteredTestList = this.labTests.filter(test =>
      test.TestName?.toLowerCase().includes(input)
    ).sort((a, b) => (a.TestName || '').localeCompare(b.TestName || ''));
  }

  selectTest(test: any) {
    this.investigationForm.get('selectedTest')?.setValue(test.TestName);
    this.showTestDropdown = false;
  }

  hideTestDropdown() {
    setTimeout(() => this.showTestDropdown = false, 200);
  }
}
