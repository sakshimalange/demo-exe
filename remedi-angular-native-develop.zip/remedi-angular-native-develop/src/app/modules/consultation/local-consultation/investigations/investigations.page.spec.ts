import { ComponentFixture, TestBed } from '@angular/core/testing';
import { InvestigationsPage } from './investigations.page';

describe('InvestigationsPage', () => {
  let component: InvestigationsPage;
  let fixture: ComponentFixture<InvestigationsPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(InvestigationsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
