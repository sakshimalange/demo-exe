import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators,
  FormsModule
} from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { catchError, of, lastValueFrom } from 'rxjs';
import { PouchdbService } from '../../../../core/services/pouchdb.service';
import { Complaint } from '../../../../core/interfaces/localconsultation.model';
import { ApiService } from '../../../../core/services/api.service';
import { ConstantService } from '../../../../core/services/constant.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { DialogService } from 'src/app/core/services/dialog.service';
import { Router, RouterModule } from '@angular/router';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-complaints',
  templateUrl: './complaints.page.html',
  styleUrls: ['./complaints.page.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule,FormsModule, HttpClientModule, MatSnackBarModule],
})
export class ComplaintsPage implements OnInit {
  masterData: any = {};
  complaintList: any[] = [];
  filteredComplaintList: any[] = [];
  complaintForm: FormGroup;
  complaint: Complaint[] = [];

  savedComplaints: Complaint[] = [];
  editingComplaint: Complaint | null = null;
  message = '';
  error = '';
  saving = false;
  isLocalConsultation: boolean = false;
  isMobile = false;
  isModalOpen = false;
  selectedComplaint: 'chief' | 'associated' = 'chief';
  showAssociatedDropdown = false;
  showDropdown = false;
  timePeriods: string[] = ['minutes', 'hours', 'days', 'weeks'];
  showChiefTimeDropdown = false;
  showAssociatedTimeDropdown = false;
  showChiefTimePeriodDropdown = false;
  showAssociatedTimePeriodDropdown = false;


  constructor(
      private router: Router,
    private pouchdbService: PouchdbService,
    private http: HttpClient,
    private formBuilder: FormBuilder,
    private apiService: ApiService,
    private constantService: ConstantService,
    private toastService: ToastService,
    private snackBar: MatSnackBar,
  ) {
    //  Updated Form Group with separate controls for each complaint type
    this.complaintForm = this.formBuilder.group({
      complaintType: ['chief'],
      chiefComplaint: [''],
      chiefSince: [''],
      chiefTimePeriod: ['hours'],
      associatedComplaint: [''],
      associatedSince: [''],
      associatedTimePeriod: ['hours'],
    });
  }

  async ngOnInit() {
    this.pouchdbService.initDB('prms_complaint');

      this.checkScreenSize();
    window.addEventListener('resize', () => this.checkScreenSize());

    this.loadSavedComplaints();
    this.checkNetworkAndSync();
    
    // Fetch complaint data from server and store in PouchDB
    await this.fetchAndStoreComplaintData();

    this.complaintList = await this.pouchdbService.getTable('tblpatientcomplaints');
    // Sort complaints ascending by ComplaintName
 this.filteredComplaintList = this.complaintList;
    this.complaintList.sort((a, b) => a.ComplaintName.localeCompare(b.ComplaintName));

    const flag = localStorage.getItem('isLocalConsultation') === 'true';
    console.log('Flag from storage:', flag);
    this.isLocalConsultation = flag;
  }

  private checkNetworkAndSync() {
    if (navigator.onLine) {
      console.log('Online - Starting complaint sync...');
      this.syncAllUnsyncedComplaints();
    }

    window.addEventListener('online', () => {
      console.log('Back online - Syncing complaints...');
      this.syncAllUnsyncedComplaints();
    });
  }


  checkScreenSize() {
    this.isMobile = window.innerWidth <= 500;
  }
  openModal() {
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
    this.editingComplaint = null;
    this.complaintForm.reset({ days: 0 });
  }



  goToDoctorDashboard() {
    this.router.navigate(['/dashboard']);
  }

selectComplaint(name: string) {
  this.complaintForm.get('associatedComplaint')?.setValue(name);
  this.showDropdown = false;
  this.showChiefTimePeriodDropdown = false;
  this.showAssociatedTimePeriodDropdown = false;
}

hideDropdown() {
  // Use timeout so click event registers before blur hides it
  setTimeout(() => this.showDropdown = false, 200);
}

  filterComplaints() {
    const input = this.complaintForm.get('associatedComplaint')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredComplaintList = this.complaintList;
      return;
    }
    this.filteredComplaintList = this.complaintList.filter(c =>
      c.ComplaintName.toLowerCase().includes(input)
    );
    this.showChiefTimePeriodDropdown = false;
    this.showAssociatedTimePeriodDropdown = false;
  }


  getAssociatedComplaintName(value: string): string {
    if (!value) return 'Unknown Complaint';
    const complaint = this.complaintList.find((c) => c.Id === value || c.ComplaintName === value);
    return complaint ? complaint.ComplaintName : 'Unknown Complaint';
  }

  addComplaint() {
    const formValue = this.complaintForm.value;
    const complaintType = formValue.complaintType;

    // Validation based on selected complaint type
    if (complaintType === 'chief') {
      if (!formValue.chiefComplaint?.trim()) {
        this.snackBar.open('Please enter chief complaint.', 'Close', { duration: 3000 });
        return;
      }
      if (!formValue.chiefSince || formValue.chiefSince === '') {
         this.snackBar.open('Please enter duration for chief complaint.', 'Close', { duration: 3000 });

        return;
      }
      if (!formValue.chiefTimePeriod?.trim()) {
         this.snackBar.open('Please select time period for chief complaint.', 'Close', { duration: 3000 });

        return;
      }
    } else if (complaintType === 'associated') {
      if (!formValue.associatedComplaint?.trim()) {
         this.snackBar.open('Please select associated complaint.', 'Close', { duration: 3000 });

        return;
      }
      if (!formValue.associatedSince || formValue.associatedSince === '') {
         this.snackBar.open('Please enter duration for associated complaint.', 'Close', { duration: 3000 });

        return;
      }
      if (!formValue.associatedTimePeriod?.trim()) {
         this.snackBar.open('Please select time period for associated complaint.', 'Close', { duration: 3000 });

        return;
      }
    }

    // Check if a chief complaint already exists for this consultation ID
    if (formValue.chiefComplaint?.trim()) {
      const consultationId = localStorage.getItem('consultationId') || '1';
      const existingChiefComplaint = this.savedComplaints.find(
        complaint => complaint.ChiefComplaint && complaint.consultationId === consultationId
      );
      if (existingChiefComplaint) {
        this.error = 'Only one chief complaint can be added per consultation. Please delete the existing chief complaint to add a new one.';
        return;
      }
    }

    this.saving = true;
    this.error = '';
    this.message = '';

    const patientDetails = JSON.parse(
      localStorage.getItem('patientDetails') || '{}'
    );
    const consultationId = localStorage.getItem('consultationId') || '1';
     const localConsultationId = localStorage.getItem('localConsultationId') || '1';
    const loginResponse = JSON.parse(
      localStorage.getItem('LOGIN_RESPONSE') || '{}'
    );

    const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
    const domain = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
    const patientId = patientDetails.patientid || '';

    //  Create an array to hold the complaint objects to be saved
    const complaintsToSave: Complaint[] = [];

    // Add Chief Complaint data if it exists
    if (formValue.chiefComplaint?.trim()) {
      complaintsToSave.push({
        ChiefComplaint: formValue.chiefComplaint,
        complaint: '', // Not applicable for chief complaint
        duration: formValue.chiefSince || '',
        spec: formValue.chiefTimePeriod || 'hours',
        createdAt: new Date().toISOString(),
        type: 'complaint',
        synced: false,
        domain: domain,
        action: 'savetoserver',
        patientId: patientId,
        consultationId: consultationId,
        localConsultationId:localConsultationId,
        paramName: 'complaint',
        tblname: 'prms_complaint',
        token: token,
        forwardto: 'AndroidRemoteConsultaionWPSevices.do',
      });
    }

    // Add Associated Complaint data if it exists
    if (formValue.associatedComplaint) {
      const associatedComplaintText = this.getAssociatedComplaintName(formValue.associatedComplaint);
      complaintsToSave.push({
        ChiefComplaint: '', // Not applicable for associated complaint
        complaint: associatedComplaintText,
        duration: formValue.associatedSince || '',
        spec: formValue.associatedTimePeriod || 'hours',
        createdAt: new Date().toISOString(),
        type: 'complaint',
        synced: false,
        domain: domain,
        action: 'savetoserver',
        patientId: patientId,
        consultationId: consultationId,
        localConsultationId:localConsultationId,
        paramName: 'complaint',
        tblname: 'prms_complaint',
        token: token,
        forwardto: 'AndroidRemoteConsultaionWPSevices.do',
      });
    }

    // Handle editing and saving/updating for each complaint record
    const saveActions = complaintsToSave.map(data => {
      if (this.editingComplaint && this.editingComplaint._id && this.editingComplaint._rev) {
        // This part needs more complex logic to determine which of the two complaints is being edited.
        // For a simple UI, a better approach might be to save a single record with both fields.
        // The current implementation will save new records.
        console.log('edit logic not fully implemented for multiple records');
        const updatedDoc = { ...this.editingComplaint, ...data };
        return lastValueFrom(this.pouchdbService.updateRecord(updatedDoc));
      } else {
        console.log('save');
        return lastValueFrom(this.pouchdbService.addRecord(data));
      }
    });

    Promise.all(saveActions)
      .then(() => {
        this.finishAction('Complaints saved successfully!');
         this.snackBar.open('Complaint(s) saved successfully.', 'Close', { duration: 3000 });

      })
      .catch(() => {
         this.snackBar.open('Please enter chief complaint.', 'Close', { duration: 3000 });
        this.finishAction('Failed to save complaint(s)', true);
      });

       if (this.isMobile) this.closeModal();
  }

  editComplaint(item: Complaint) {
    this.editingComplaint = { ...item };

    // Determine complaint type based on which field has data
    const isChiefComplaint = !!item.ChiefComplaint && item.ChiefComplaint.trim() !== '';
    const isAssociatedComplaint = !!item.complaint && item.complaint.trim() !== '';

    // Set the appropriate complaint type in the form
    const complaintType = isChiefComplaint ? 'chief' : 'associated';

    this.complaintForm.patchValue({
      complaintType: complaintType,
      chiefComplaint: item.ChiefComplaint || '',
      associatedComplaint: item.complaint || '',
      chiefSince: isChiefComplaint ? item.duration : '',
      chiefTimePeriod: isChiefComplaint ? item.spec : 'hours',
      associatedSince: isAssociatedComplaint ? item.duration : '',
      associatedTimePeriod: isAssociatedComplaint ? item.spec : 'hours',
    });
  }


  loadSavedComplaints() {
    const consultationId = localStorage.getItem('consultationId') || '';
    console.log('consultationId', consultationId);
    this.pouchdbService.getRecordsByType<Complaint>('complaint').subscribe({
      next: (docs) => {
        this.savedComplaints = docs.filter(complaint => complaint.consultationId === consultationId);
        console.log('Loaded complaints:', this.savedComplaints);
        this.syncAllUnsyncedComplaints();
      },
      error: (err) => console.error(' Failed to load complaints', err),
    });
  }

  private async syncAllUnsyncedComplaints() {
    this.pouchdbService.initDB('prms_complaint');
    for (const complaint of this.savedComplaints) {
      if (!complaint.synced) {
        await this.syncWithBackend(complaint);
      }
    }
  }
  async deleteComplaint(item: Complaint) {
    if (!item._id) return;

    try {
      //  Fetch the latest document to get the current _rev before deleting
      const latestItem = await lastValueFrom(this.pouchdbService.getRecordById<Complaint>(item._id));
      this.pouchdbService.deleteRecord(latestItem).subscribe({
        next: () => {
          this.finishAction(' Complaint deleted!');
           this.snackBar.open('Complaint Data Deleted successfully.', 'Close', { duration: 3000 });

        },
        error: () => this.finishAction(' Failed to delete complaint', true),
      });
    } catch (err) {
      this.finishAction(' Failed to delete complaint', true);
    }
  }

  private async syncWithBackend(complaint: Complaint) {
    this.pouchdbService.getAllRecords<Complaint>().subscribe((records) => {
      const unsynced = records.filter((r) => r.synced == false && r.consultationId === localStorage.getItem('consultationId'));
      console.log('unsynced', unsynced);

      unsynced.forEach((record) => {
        const token = localStorage.getItem('token') || '';
        const query =
          `?forwardto=${record.forwardto}` +
          `&action=${record.action}` +
          `&domain=${record.domain}` +
          `&patientId=${record.patientId}` +
          `&consultationId=${record.consultationId}` +
          `&paramName=${record.paramName}` +
          `&tblname=${record.tblname}` +
          `&complaint=${encodeURIComponent(record.complaint)}` +
          `&ChiefComplaint=${encodeURIComponent(record.ChiefComplaint)}` +
          `&duration=${encodeURIComponent(record.duration)}` +
          `&spec=${encodeURIComponent(record.spec)}` +
          `&token=${encodeURIComponent(token)}`;

        this.apiService.postServiceByQueryBasic(this.constantService.APIConfig.GETCOMMONSERVICES, query).subscribe({
          next: (res: any) => {
            if (res.status === 'success') {
              console.log('Synced Complaint record:', record);
              record.synced = true;
              this.pouchdbService.updateRecord(record).subscribe();
            } else {
              console.warn('Sync failed:', res);
            }
          },
          error: (err) => {
            console.error(' Error syncing Complaint record:', err);
          },
        });
      });
    });
  }

  private async fetchAndStoreComplaintData() {
    try {
      const consultationId = localStorage.getItem('consultationId') || '';
      const patientId = localStorage.getItem('patientDetails') ? JSON.parse(localStorage.getItem('patientDetails') || '{}').patientid : '';
      const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
      const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
      const domain = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
      const username = loginResponse.profiledetail?.username ?? localStorage.getItem('username') ?? '';
      
      if (!consultationId || !patientId || !token) {
        console.warn('Missing required parameters for complaint data fetch');
        return;
      }

      const baseUrl = this.constantService.APIConfig.GETCOMMONSERVICES;
      const queryParams = `?action=getfromserver&domain=${domain}&username=${username}&consultationId=${consultationId}&usertype=Doctor&localeFile=English&paramName=complaintList&tblname=prms_complaint&patientId=${patientId}&token=${token}`;
      
      this.apiService.postServiceByQueryBasic(baseUrl, queryParams).subscribe({
        next: async (response: any) => {
          if (response && response.status === 'success' && response.data) {
            // Store each complaint in PouchDB
            for (const complaintData of response.data) {
              const complaintRecord: Complaint = {
                complaint: complaintData.complaint || '',
                duration: complaintData.duration || 4,
                spec: complaintData.spec || 'hours',
                ChiefComplaint: '',
                createdAt: new Date().toISOString(),
                type: 'complaint',
                synced: true,
                domain: domain,
                action: 'getfromserver',
                patientId: patientId,
                consultationId: consultationId,
                localConsultationId: localStorage.getItem('localConsultationId') || '',
                paramName: 'complaintList',
                tblname: 'prms_complaint',
                token: token,
                forwardto: 'AndroidRemoteConsultaionWPSevices.do'
              };
              
              await lastValueFrom(this.pouchdbService.addRecord(complaintRecord));
            }
            console.log('Complaint data fetched and stored successfully');
          }
        },
        error: (error) => {
          console.error('Error fetching complaint data:', error);
        }
      });
    } catch (error) {
      console.error('Error in fetchAndStoreComplaintData:', error);
    }
  }

  private finishAction(msg: string, isError = false) {
    this.saving = false;
    if (isError) this.error = msg;
    else this.message = msg;

    this.resetForm();
    this.loadSavedComplaints();
  }



  selectAssociatedComplaint(complaint: any) {
    this.complaintForm.patchValue({ associatedComplaint: complaint.ComplaintName });
    this.showAssociatedDropdown = false;
  }

  hideAssociatedDropdown() {
    setTimeout(() => {
      this.showAssociatedDropdown = false;
    }, 200);
  }



  hideChiefTimeDropdown() {
    setTimeout(() => this.showChiefTimeDropdown = false, 200);
  }

  hideAssociatedTimeDropdown() {
    setTimeout(() => this.showAssociatedTimeDropdown = false, 200);
  }

  toggleChiefTimePeriodDropdown() {
    this.showChiefTimePeriodDropdown = !this.showChiefTimePeriodDropdown;
    this.showAssociatedTimePeriodDropdown = false;
    this.showDropdown = false;
  }

  toggleAssociatedTimePeriodDropdown() {
    this.showAssociatedTimePeriodDropdown = !this.showAssociatedTimePeriodDropdown;
    this.showChiefTimePeriodDropdown = false;
    this.showDropdown = false;
  }

  selectChiefTimePeriod(value: string) {
    this.complaintForm.get('chiefTimePeriod')?.setValue(value);
    this.showChiefTimePeriodDropdown = false;
  }

  selectAssociatedTimePeriod(value: string) {
    this.complaintForm.get('associatedTimePeriod')?.setValue(value);
    this.showAssociatedTimePeriodDropdown = false;
  }

  getTimePeriodDisplay(value: string): string {
    if (!value) return '';
    return value.charAt(0).toUpperCase() + value.slice(1);
  }

  private resetForm() {
    this.complaintForm.reset({
      complaintType: 'chief', // Default to chief complaint
      chiefComplaint: '',
      chiefSince: '',
      chiefTimePeriod: 'hours',
      associatedComplaint: '',
      associatedSince: '',
      associatedTimePeriod: 'hours',
    });
    this.editingComplaint = null;
  }
}
