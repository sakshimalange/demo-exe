import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar } from '@ionic/angular/standalone';
import { IonicModule } from '@ionic/angular';
import { WebsocketsService } from 'src/app/core/services/websocket.service';
import { filter, Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { MedicalDeviceCommunicationPlugin } from 'src/app/core/plugins/medical-device-communication.plugin';
import { PouchdbService } from 'src/app/core/services/pouchdb.service';
import { Spo2DevicePage } from 'src/app/modules/prms/ble-device/spo2-device/spo2-device.page';
import { ThermometerPage } from 'src/app/modules/prms/ble-device/thermometer/thermometer.page';
import { HemoglobinPage } from 'src/app/modules/prms/usb-device/hemoglobin/hemoglobin.page';
import { BloodPressureJettyPage } from 'src/app/modules/prms/ble-device/blood-pressure-jetty/blood-pressure-jetty.page';
import { HemoglobinJettyPage } from 'src/app/modules/prms/usb-device/hemoglobin-jetty/hemoglobin-jetty.page';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/core/services/api.service';
import { ConstantService } from 'src/app/core/services/constant.service';
import { IcareSpo2Page } from 'src/app/modules/prms/ble-device/icare-spo2/icare-spo2.page';
import { IcareThermometerPage } from 'src/app/modules/prms/ble-device/icare-thermometer/icare-thermometer.page';
import { BloodPressureIcarePage } from 'src/app/modules/prms/ble-device/blood-pressure-icare/blood-pressure-icare.page';

import { SharedDataService } from 'src/app/core/services/share-api-responses';
import { EcgJettyDevicePage } from 'src/app/modules/prms/ble-device/ecg-jetty-device/ecg-jetty-device.page';
import { SpirometerJettyDevicePage } from 'src/app/modules/prms/ble-device/spirometer-jetty-device/spirometer-jetty-device.page';
import { HbA1cBleDevicePage } from 'src/app/modules/prms/ble-device/hb-a1c-ble-device/hb-a1c-ble-device.page';
import { LipidProfilePage } from 'src/app/modules/prms/usb-device/lipid-profile/lipid-profile.page';
import { AuthService } from 'src/app/core/services/auth.service';

import { NullWebsocketService } from 'src/app/core/services/null-websocket.service';
import { GlucosePage } from 'src/app/modules/prms/usb-device/glucose/glucose.page';
import { GlucoseBlePage } from 'src/app/modules/prms/ble-device/glucose-ble/glucose-ble.page';
import { UrineTestPage } from 'src/app/modules/prms/usb-device/urine-test/urine-test.page';
import { RapidTestPage } from 'src/app/modules/prms/usb-device/rapid-test/rapid-test.page';
import { FetalDopplerDevicePage } from 'src/app/modules/prms/ble-device/fetal-doppler-device/fetal-doppler-device.page';
import { StethoscopeDevicePage } from 'src/app/modules/prms/ble-device/stethoscope-device/stethoscope-device.page';

import { TestSelectionDialogPage } from 'src/app/modules/prms/usb-device/test-selection-dialog/test-selection-dialog.page';
import { PulseOximeterManualComponent } from 'src/app/modules/prms/manual_entry/spo2-manual/spo2-manual.component';
import { TemperatureManualComponent } from 'src/app/modules/prms/manual_entry/temperature-manual/temperature-manual.component';
import { BloodPressureComponent } from 'src/app/modules/prms/manual_entry/blood-pressure/blood-pressure.component';
import { HemoglobinManualComponent } from 'src/app/modules/prms/manual_entry/hemoglobin-manual/hemoglobin-manual.component';
import { SpirometerManualComponent } from 'src/app/modules/prms/manual_entry/spirometer-manual/spirometer-manual.component';
import { GlucoseManualEntryComponent } from 'src/app/modules/prms/manual_entry/glucose-manual/glucose-manual.component';
import { UrineManualComponent } from 'src/app/modules/prms/manual_entry/urine-manual/urine-manual.component';
import { RapidManualComponent } from 'src/app/modules/prms/manual_entry/rapid-manual/rapid-manual.component';
import { Hba1cManualComponent } from 'src/app/modules/prms/manual_entry/hba1c-manual/hba1c-manual.component';
import { LipidTestSelectionComponent } from 'src/app/modules/prms/usb-device/lipid-test-selection/lipid-test-selection.component';
import { LipidManualEntryComponent } from 'src/app/modules/prms/manual_entry/lipid_profile_manual/lipid-manual-entry/lipid-manual-entry.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Snackbar } from 'src/app/core/services/snackbar';
import { EcgInterpretationJettyDeviceComponent } from 'src/app/modules/prms/ble-device/ecg-interpretation-jetty-device/ecg-interpretation-jetty-device.component';
import { EcgInterpretationManualJettyComponent } from 'src/app/modules/prms/manual_entry/ecg-interpretation-manual-jetty/ecg-interpretation-manual-jetty.component';
import { OtoscopePage } from 'src/app/modules/prms/usb-device/otoscope/otoscope.page';



interface EnabledParameterResponse {
  Result: string;
  data: string[];
}
interface EnabledParameter {
  name: string;
  disable: boolean;
  src: string;
  manual: boolean;
  isRipple: boolean;
  isActive: boolean;
}

interface ManualEntryResponse {
  Result: string;
  Records: string[]; // Assuming API returns an array of parameter names
}

interface ParameterConfResponse {
  status: string;
  data: {
    ParameterListWithManual: { [key: string]: number };
  };
}

// Interface for parameter buttons
interface ParameterButton {
  name: string;
  manual: boolean;
}



@Component({
  selector: 'app-parameters',
  templateUrl: './parameters.page.html',
  styleUrls: ['./parameters.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class ParametersPage implements OnInit {
  isSpo2DialogOpen = false;
  isBpDialogOpen = false;
  valSubscription!: Subscription | null;
  valSubscription1!: Subscription;
  valSubscription2!: Subscription;
  valSubscription3!: Subscription;
  valSubscription4!: Subscription;
  valSubscription5!: Subscription;
  valSubscription6: Subscription | null = null;
  valSubscription7!: Subscription;
  valSubscription8!: Subscription;
  valSubscriptiongble!: Subscription;
  subscriptionspo2!: Subscription;
  isRapidTestKitReady = false;
  paramValueSubscription!: Subscription;
  private isThermometerDialogOpen = false; // Add this property to your class

  issdkjarReady = false;
  private rapidTestDialogOpen = false;
  private urinetestdialogopen = false;
  private glucosetestdialogopen = false;
  jettyMessage: string | null = null;
  loginTime: any;
  username: any;
  currentUser: any;
  patientData: any;
  subscription5!: Subscription;
  showHbA1cModal: boolean = false;
  hbA1cDataFetched: boolean = false;
  currentVal = 0;
  hba1cValue: string = '';
  hba1cMmol: string = '';
  eagValue: string = '';
  tokenRequest: any;
  currDomainId: any;
  usertype: any;
  currDomainName: any;
  enabledParameterBtn: EnabledParameter[] = [];
  temperatureFVal: string | null = null;
  manualEntryParameterBtn: any[] = [];
  parameterConf: any = null; // null indicates API not loaded yet or failed
  consultationId: any;
  patientId: any;
  language: any;
  isLocalConsultation: boolean = false;
  dataspo2: any[] = [];
  bleConnectionStatus: 'connected' | 'not-connected' = 'not-connected';
  bleConnectionMessage: string = 'BLE Dongle Not Connected';
  private reconnectInterval: any;
  private bleStatusSubscription: Subscription | null = null
  snackbarInterval: any;
  activeSnackbarDevice: string | null = null; // Track which device is showing snackbar
  wasMeasurementTaken: any;



  closeHbA1cModal() {
    this.showHbA1cModal = false;
  }
  bleSub: Subscription | null = null;
  paramSub: Subscription | null = null;
  errorStart!: boolean;
  status: boolean | undefined;
  errorMsgLocal: boolean | undefined;

  private subscription: Subscription | undefined;


  // ==================================================================================
  // CENTRALIZED DOCTOR CONTROL SYSTEM - PARAMETERS PAGE
  // ==================================================================================
  // Purpose: Use centralized nullwebsocket service for dongle connection messages
  // Benefits: Single connection shared across all pages, no duplicate connections
  // Pattern: When dongle connects and user is Doctor → send messages to nurse
  // Messages: ble_msgFromBLEApplet_true_Dongle connected successfully + ble_enablestethoble_2
  // ==================================================================================

  private isVideoConsultationActive: boolean = false;     // Flag to enable doctor control
  private isDongleConnected: boolean = false;             // Track dongle connection status
  private dongleMessagesAlreadySent: boolean = false;     // Prevent duplicate message sending
  private stethoscopeStartSent: boolean = false;          // Prevent duplicate ble_stetho_start messages

  // ==================================================================================
  // NURSE-SIDE STETHOSCOPE READING FUNCTIONALITY
  // ==================================================================================
  // Purpose: Handle doctor's stethoscope reading requests and send data back
  // Message: {"message":"stethopos_true_1_1_null"} → Start reading → Send data to doctor
  // ==================================================================================
  private currentUserType: string = '';                   // Track if user is Nurse or Doctor
  private stethoscopeReadingActive: boolean = false;      // Track if reading is in progress
  private stethoscopeReadingData: any[] = [];            // Store reading data
  private stethoscopeReadingInterval: any = null;        // Interval for continuous reading

  // ✅ New properties for device activation signaling
  private signalingSubscription: Subscription | null = null;
  kitActivated = false; // Tracks if the medical device kit has been activated
  activeDevices: Set<string> = new Set(); // Tracks which specific devices are currently active
  manualEcgInterpretationOpen = false;

private isEcgDialogOpen = false;
private isSubscribedToBle = false;

  constructor(
    private WebsocketsService: WebsocketsService,
    private dialog: MatDialog,
    private router: Router,
    private apiSvc: ApiService,
    private constantSvc: ConstantService,
    private pouchdbService: PouchdbService,
    private authService: AuthService,
    private sharedDataService: SharedDataService<any>,

    private snackBar: MatSnackBar,

    private nullWebsocketService: NullWebsocketService


  ) { }




  ngOnInit() {
    // First, initialize the DB
    // this.pouchdbService.initDB('spo2_data'); // or 'bp_localdb', etc.

    this.initBleStatusMonitoring(); 
    //this.WebsocketsService.sendBleMessage("BleAppletInit"); this line moved  to fix finish status issue 

    const currentSession = this.authService.getCurrentSession();
    const flag = localStorage.getItem('isLocalConsultation') === 'true';
    this.isLocalConsultation = flag;
    this.tokenRequest = this.authService.getToken() || '';
    this.username = currentSession?.username || '';
    this.currDomainId = currentSession?.domainId || '';
    this.language = currentSession?.language || '';
    this.temperatureFVal = sessionStorage.getItem("temperatureFVal");
    // Patient & consultation info
    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    this.patientId = patientDetails.patientid || '';
    this.consultationId = localStorage.getItem('consultationId') || '';
    // Get login/session info
    const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    this.tokenRequest = loginResponse.token ?? localStorage.getItem('token') ?? '';
    this.currDomainId = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
    this.username = loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? '';
    this.usertype = loginResponse.commondetail?.usertype ?? localStorage.getItem('usertype') ?? '';
    this.currentUserType= loginResponse.commondetail?.usertype ?? localStorage.getItem('usertype') ?? '';
    console.log('🔧 Parameters Page - User Type:', this.usertype);
    console.log('Token:', this.tokenRequest);

    // 🔧 Initialize video consultation status for both doctor and nurse
    this.initializeVideoConsultationStatus();

    // Initialize centralized doctor control system for parameters page
    this.initializeDoctorControlSystem();


    // ✅ Initialize nurse-side functionality for stethoscope readings
    this.initializeNurseSideStethoscopeHandling();

    const data = this.pouchdbService.getAllRecords<any>().subscribe({
      next: (records: any) => {
        console.log('All Records:', records);
      },
      error: (err: any) => {
        console.error('Error fetching all records:', err);
      }
    });
    console.log("pouchbd", data);
//pleae dont changes  this code is working on local consultation if you wnat to change let me know sangeets
 this.WebsocketsService.connectBleSocket();
    this.WebsocketsService.connectParamSocket();

    setTimeout(() => {
      //this.WebsocketsService.sendBleMessage("BleAppletInit"); this line moved  to fix finish status issue 
      // Ensure WebSocket is connected before sending BleAppletInit
      this.ensureBleConnectionAndInit();

      // Only subscribe once
      this.bleSub = this.WebsocketsService.bleValueObs$
        .pipe(
          filter(data =>
            data?.includes("msgFromBLEApplet") || data === "error"
          )
        )
        .subscribe((data) => {
          console.log("BLE Message:", data);


          if (data === "msgFromBLEApplet~false~Dongle not connected.") {
            console.warn("Dongle is not connected.");
          } else if (data === "msgFromBLEApplet~true~Dongle connected successfully.~1") {
            console.log("Dongle connected successfully.");
          } else if (data === "error") {
            console.error("BLE connection error.");
          }
        });
      this.WebsocketsService.sendParamMessage("connectKitFirstTime");

      this.paramSub = this.WebsocketsService.paramValueObs$.subscribe((data) => {
        console.log("param data", data);

        if (data == null || data == "null") {
          console.log("usb Test not available - Please start the SDK");
          this.issdkjarReady = false;
        } else if (data === "kitStatusCheck~1001") {
          console.log("usb Test ready!");
          this.issdkjarReady = true;
        } else if (data == "error") {
          console.log("usb Test has error!");
          this.issdkjarReady = false;
        }
      });
    }, 1000)
    
    this.WebsocketsService.jettyConnection$.subscribe((isConnected: boolean) => {
      this.issdkjarReady = isConnected;
    });
    //end of please dont changes the this code is working on local consultation if you wnat to change let me know sangeets


    // setTimeout(() => {
    //   // Connect BLE socket for local consultation
    //   if (!this.WebsocketsService.getBleSocketInstance()) {
    //     this.WebsocketsService.connectBleSocket();
    //   }

    //   this.WebsocketsService.sendBleMessage("BleAppletInit");

    //   // Only subscribe once
    //   this.bleSub = this.WebsocketsService.bleValueObs$
    //     .pipe(
    //       filter((data: string | string[]) =>
    //         data?.includes("msgFromBLEApplet") || data === "error"
    //       )
    //     )
    //     .subscribe((data: string | string[]) => {
    //       console.log("BLE Message:", data);


    //       if (data === "msgFromBLEApplet~false~Dongle not connected.") {
    //         console.warn("Dongle is not connected.");

    //         this.isDongleConnected = false;
    //         this.dongleMessagesAlreadySent = false; // Reset flag on disconnection

    //       } else if (data === "msgFromBLEApplet~true~Dongle connected successfully.~1 ") {
    //         console.log("Dongle connected successfully.");

    //         this.isDongleConnected = true;
    //         this.handleDongleConnection();

    //       } else if (data === "error") {
    //         console.error("BLE connection error.");

    //         this.isDongleConnected = false;
    //         this.dongleMessagesAlreadySent = false; // Reset flag on error

    //       }
    //     });
    //   // Connect param socket for local consultation
    //   if (!this.WebsocketsService.getParamSocketInstance()) {
    //     this.WebsocketsService.connectParamSocket();
    //   }

    //   this.WebsocketsService.sendParamMessage("connectKitFirstTime");

    //   this.paramSub = this.WebsocketsService.paramValueObs$.subscribe((data: string | null) => {
    //     console.log("param data", data);

    //     if (data == null || data == "null") {
    //       console.log("usb Test not available - Please start the SDK");
    //       this.issdkjarReady = false;
    //     } else if (data === "kitStatusCheck~1001") {
    //       console.log("usb Test ready!");
    //       this.issdkjarReady = true;
    //     } else if (data == "error") {
    //       console.log("usb Test has error!");
    //       this.issdkjarReady = false;
    //     }
    //   });
    // }, 1000);

    this.getEnabledParameterList();



    this.subscription = this.sharedDataService.getData().subscribe((apiResponse: { temp: number | null | undefined; }) => {
      if (apiResponse && apiResponse.temp !== undefined && apiResponse.temp !== null) {
        this.currentVal = apiResponse.temp;
      }
    })
  }





  ngOnDestroy() {
    this.stopSnackbarReminder(this.activeSnackbarDevice);
     if (this.valSubscription) {
    this.valSubscription.unsubscribe();
  }
  this.isSubscribedToBle = false;
  this.isEcgDialogOpen = false;
    this.bleSub?.unsubscribe();
    this.paramSub?.unsubscribe();
    if (this.paramValueSubscription) {
      this.paramValueSubscription.unsubscribe();
    }
    this.cleanupBleStatusMonitoring();


    // Clean up doctor control system
    this.disconnectDoctorWebSocket();


    // ✅ Clean up nurse-side stethoscope functionality
    // this.cleanupNurseSideStethoscope(); // COMMENTED - Use real stethoscope-device component


  }

  handleJettyClick(deviceName: string, methodName: string | null) {
    this.jettyMessage = `Please Switch On ${deviceName} Device`;

    if (methodName && typeof (this as any)[methodName] === 'function') {
      (this as any)[methodName]();
    }

    setTimeout(() => {
      this.jettyMessage = null;
    }, 3000);
  }


  async openPulseOximeterManual() {
    console.log("Opening SPO2 Component Device...");
    const dialogRef = this.dialog.open(PulseOximeterManualComponent, {
      panelClass: 'spo2-dialog-panel',
      height: "auto",
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        console.log("Manual SpO2 saved:", result);
        // 🔹 Handle manual result (save to DB, sync, etc.)
      } else {
        console.log("Manual SpO2 entry closed without saving");
      }
    });

    return; // stop here, don’t go to device
  }

  // async openSpo2ComponentDeviceold(key: any) {
  //   // 1️⃣ Check device status first
  //   const status = this.getCardClass(key);

  //   // Stop any previous device reminder immediately
  //   if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
  //     this.stopSnackbarReminder(this.activeSnackbarDevice);
  //   }

  //   if (status === 'disconnected' || status === 'completed') {
  //     this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
  //   }

  //   let manual = this.manualEntryParameterBtn.find(res => { return res === key });
  //   if (manual) {
  //     // Manual entry flow
  //     if (!this.isLocalConsultation && this.usertype === 'Doctor') {
  //       this.nullWebsocketService.sendMessage("open_spo2_manual");
  //     }
  //     console.log("Opening manual SPO2 entry", manual);
  //     this.openPulseOximeterManual();
  //   } else {
  //     // Device flow
  //     console.log("Opening SPO2 Component Device...");

  //     if (!this.isLocalConsultation && this.usertype === 'Doctor') {
  //       // Remote consultation - send device start message to nurse

  //     this.sendNullWebSocketMessage("ble_spo2_start");
  // console.log('📱 [PARAMETERS] Doctor clicked SPO2 device - sent ble_spo2_start to nurse');

  // this.subscriptionspo2 = this.WebsocketsService.bleValueObs$.subscribe((data) => {
  //   console.log('📱 [data]', data);

  //   try {
  //     var jsondata = JSON.parse(data);

  //     if (jsondata?.message == "loggedinsuccess") {
  //       // this.connectedConsultaionDoctor1();
  //     } else if (jsondata?.message == "error_start scan status : Success!") {
  //       // handle if needed
  //     } else if (jsondata?.message == "error_SPO2Sensor connected successfully.") {
  //       const dialogRef = this.dialog.open(Spo2DevicePage, {
  //         data: { api: "withoutApiCalling" },
  //         width: "701px",
  //         height: "auto",
  //       });

  //       dialogRef.afterClosed().subscribe((result) => {
  //         this.subscriptionspo2.unsubscribe();
  //         if (result != undefined) {}
  //       });

  //       this.status = false;
  //     }

  //     // ✅ NEW: Update dataspo2 whenever plot data arrives in remote flow
  //     if (data.startsWith("data_blespo2_plot_")) {
  //       const start = data.indexOf("[");
  //       const end = data.lastIndexOf("]") + 1;
  //       if (start > -1 && end > -1) {
  //         this.dataspo2 = JSON.parse(data.substring(start, end));
  //         console.log("📊 dataspo2 updated (remote):", this.dataspo2);
  //       }
  //     }

  //   } catch (e) {``
  //     console.warn("Failed to parse remote SPO2 data:", e);
  //   }

  // });
  //       return; // ✅ STOP HERE - Don't proceed with local device handling
  //     } else {
  //       // Local consultation - handle device directly
  //       console.log("Starting local SPO2 device scan");

  //       this.WebsocketsService.sendBleMessage("startScanFromHtml~50");
  //       // Prevent multiple subscriptions
  //       if (this.valSubscription6) {
  //         this.valSubscription6.unsubscribe();
  //       }

  //       this.valSubscription6 = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {
  //         if (data === "errorLableUpdate~start scan status : Success!") {
  //           // handle
  //         } else if (data === "errorLableUpdate~SPO2Sensor connected successfully.") {
  //           // handle
  //         } else if (data === "SensorConnected~SPO2Sensor~50") {

  //           // Stop if already open
  //           if (this.isSpo2DialogOpen) {
  //             return;
  //           }
  //           this.isSpo2DialogOpen = true;
  //           const device = this.enabledParameterBtn.find(
  //             d => d.name.toLowerCase() === key.toLowerCase()
  //           );
  //           if (device) {
  //             device.isActive = true;  // mark as active
  //             device.manual = false;   // ensure it's not treated as manual
  //           }

  //           this.stopSnackbarReminder(key);
  //           this.deviceConnectionState['PulseOximeter'] = "connected";
  //           const dialogRef = this.dialog.open(Spo2DevicePage, {
  //             panelClass: 'spo2-dialog-panel',
  //             width: 'auto',
  //             height: 'auto',
  //             disableClose: true,
  //             data: { api: 'withoutApiCalling' }
  //           });

  //           dialogRef.afterClosed().subscribe((result: undefined) => {
  //             this.isSpo2DialogOpen = false; // Reset flag
  //             this.WebsocketsService.sendBleMessage("ble_close");

  //             // Unsubscribe when dialog closes
  //             if (this.valSubscription6) {
  //               this.valSubscription6.unsubscribe();
  //               this.valSubscription6 = null;
  //             }

  //             if (result != undefined) {
  //               this.deviceConnectionState['PulseOximeter'] = 'completed';
  //             } else {
  //               if (this.issdkjarReady) {
  //                 this.deviceConnectionState['PulseOximeter'] = 'disconnected';
  //               } else {
  //                 // Jetty not running → disabled
  //                 this.deviceConnectionState['PulseOximeter'] = 'disabled';
  //               }
  //             }
  //           });
  //         }
  //       });
  //     }

  //   }
  // }

  async openSpo2ComponentDevice(key: any) {
    // 1️⃣ Check device status first
    const status = this.getCardClass(key);
    if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
      this.stopSnackbarReminder(this.activeSnackbarDevice);
    }

    if (status === 'disconnected' || status === 'completed' || status === 'connected') {
      this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
      // 👉 still continue, because once the sensor turns on, Jetty will connect
    }

    // 🔧 DEBUG: Log current state
    console.log('🔧 [DEBUG] SPO2 Device - isLocalConsultation:', this.isLocalConsultation, 'usertype:', this.usertype);

    // Optional: stop previous snackbar reminders if needed
    // if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
    //   this.stopSnackbarReminder(this.activeSnackbarDevice);
    // }

    // 2️⃣ Check if this is a manual entry (✅ FIXED)
    const manual = this.manualEntryParameterBtn.includes(key); // returns true/false

    if (manual === true) {
      // 🔹 Manual entry flow
      console.log('Opening manual SPO2 entry for', key);

      if (!this.isLocalConsultation && this.usertype === 'Doctor') {
        this.nullWebsocketService.sendMessage('open_spo2_manual');
      }

      this.openPulseOximeterManual();
    } else {
      // 🔹 Device flow
      console.log('Opening SPO2 Component Device...');

      // Video consultation - Doctor: send message only, no physical device
      if (!this.isLocalConsultation && this.usertype === 'Doctor') {
        this.sendNullWebSocketMessage('ble_spo2_start');
        console.log('📱 [DOCTOR] Video consultation - sending SPO2 request to nurse');
                this.nullWebsocketService.messages$.subscribe((message) => {
          console.log('Null WebSocket Message Received: doctor', message);
          if (message?.message === "ble_sensorconnected_SPO2Sensor_50") {
            this.stopSnackbarReminder(key);

        if (!this.isSpo2DialogOpen) {
          this.isSpo2DialogOpen = true;
          const dialogRef = this.dialog.open(Spo2DevicePage, {
            data: { api: "withoutApiCalling" },
            width: "701px",
            height: "auto",
          });

          dialogRef.afterClosed().subscribe(() => {
            this.isSpo2DialogOpen = false;
          });
        }
           }
        })
        return;
      }

      // Local consultation OR Video consultation Nurse: handle physical device
      console.log('📱 [NURSE/LOCAL] Starting physical SPO2 device for:', this.isLocalConsultation ? 'Local' : 'Video', 'consultation');
      console.log('📱 [NURSE/LOCAL] About to send startScanFromHtml~50');

      this.WebsocketsService.sendBleMessage('startScanFromHtml~50');

      // Prevent multiple subscriptions
      if (this.valSubscription6) {
        this.valSubscription6.unsubscribe();
      }

      this.valSubscription6 = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {

        if (data === 'errorLableUpdate~start scan status : Success!') {

        } else if (data === 'errorLableUpdate~SPO2Sensor connected successfully.') {

        } else if (data === 'SensorConnected~SPO2Sensor~50') {

          // Avoid reopening if already open
          if (this.isSpo2DialogOpen || this.dialog.openDialogs.length > 0) return;

          this.isSpo2DialogOpen = true;

          const device = this.enabledParameterBtn.find(
            d => d.name.toLowerCase() === key.toLowerCase()
          );

          if (device) {
            device.isActive = true;
            device.manual = false;
          }

          this.stopSnackbarReminder(key);
          this.deviceConnectionState['PulseOximeter'] = 'connected';

          const dialogRef = this.dialog.open(Spo2DevicePage, {
            panelClass: 'spo2-dialog-panel',
            width: 'auto',
            height: 'auto',
            disableClose: true,
            data: { api: 'withoutApiCalling' },
          });

          dialogRef.afterClosed().subscribe((result: undefined) => {
            this.isSpo2DialogOpen = false;
            this.WebsocketsService.sendBleMessage('ble_close');

            // Clean up subscription
            if (this.valSubscription6) {
              this.valSubscription6.unsubscribe();
              this.valSubscription6 = null;
            }

            // Update device connection state
            if (result !== undefined) {
              this.deviceConnectionState['PulseOximeter'] = 'completed';
            } else {
              if (this.issdkjarReady) {
                this.deviceConnectionState['PulseOximeter'] = 'disconnected';
              } else {
                this.deviceConnectionState['PulseOximeter'] = 'disabled';
              }
            }
          });
        }
      });
    }
  }


  async openBloodPressureJettyPage(key: any) {
    // 1️⃣ Check device status first
    const status = this.getCardClass(key);

    // Stop any previous device reminder immediately
    if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
      this.stopSnackbarReminder(this.activeSnackbarDevice);
    }

    if (status === 'disconnected' || status === 'completed' || status === 'connected') {
      this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
      // 👉 still continue, because once the sensor turns on, Jetty will connect
    }

    let manual = this.manualEntryParameterBtn.find(res => { return res === key });
    if (manual) {
      console.log("openBloodPressureComponent", manual);
      this.openBloodPressureComponent();
    } else {
      console.log('Opening bp Component Device...');


      // Video consultation - Doctor: send message only, no physical device
      if (!this.isLocalConsultation && this.usertype === 'Doctor') {

        this.sendNullWebSocketMessage('ble_BP_start');
        console.log('📱 [DOCTOR] Video consultation - sending ble_BP_start request to nurse');
        this.nullWebsocketService.messages$.subscribe((message) => {
          console.log('Null WebSocket Message Received: doctor', message);
          if (message?.message === "ble_sensorconnected_BPSensor_30") {
            // console.log('Null WebSocket Message Received: doctor', message);
            this.stopSnackbarReminder(key);
            if (!this.isBpDialogOpen) {
              this.isBpDialogOpen = true;

              const dialogRef = this.dialog.open(BloodPressureJettyPage, {
                data: { api: "withoutApiCalling" },
                width: "1000px",
                height: "450px",
              });

              dialogRef.afterClosed().subscribe(() => {
                this.isBpDialogOpen = false;
              });
            }
          }
        })
        return;
      }

      // Local consultation OR Video consultation Nurse: handle physical device
      console.log('📱 [NURSE/LOCAL] Starting physical bp device for:', this.isLocalConsultation ? 'Local' : 'Video', 'consultation');
      console.log('📱 [NURSE/LOCAL] About to send startScanFromHtml~30');
      this.WebsocketsService.sendBleMessage("startScanFromHtml~30");
      if (this.valSubscription4) {
        this.valSubscription4.unsubscribe();
      }

      this.valSubscription4 = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {
        // try {
        console.log("BLE Message:", data); // useful for debugging

        if (data === "errorLableUpdate~start scan status : Success!") {
          // optional
        } else if (data === "errorLableUpdate~BPSensor connected successfully.") {
          // optional
        } else if (data?.includes("SensorConnected~BPSensor~30")) {
          // 🔹 Update the card state to "connected"
          const device = this.enabledParameterBtn.find(
            d => d.name.toLowerCase() === key.toLowerCase()
          );
          if (device) {
            device.isActive = true;  // mark as active
            device.manual = false;   // ensure it's not treated as manual
          }

          this.stopSnackbarReminder(key);
          this.deviceConnectionState['BloodPressure'] = "connected";
          this.valSubscription4.unsubscribe();

          const dialogRef = this.dialog.open(BloodPressureJettyPage, {
            width: "1000px",
            height: "450px",
            disableClose: true,
          });

          dialogRef.afterClosed().subscribe(() => {
            this.WebsocketsService.sendBleMessage("ble_close");
            // Clean up subscription
            if (this.valSubscription4) {
              this.valSubscription4.unsubscribe();
            }

            if (this.issdkjarReady) {
              // Jetty running → disconnected
              this.deviceConnectionState['BloodPressure'] = 'disconnected';
            } else {
              // Jetty not running → disabled
              this.deviceConnectionState['BloodPressure'] = 'disabled';
            }
          });
        }
        // } catch (error) {
        //   console.error("Error processing WebSocket data:", error);
        // }
      });
    }
  }

  async openIcareSpo2Page() {
    const dialogRef = this.dialog.open(IcareSpo2Page, {
      width: "600px",
      height: "auto",
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      MedicalDeviceCommunicationPlugin.resetPulseOximeterResult()
        .then(() => {
          console.log("PulseOximeter hash reset successfully.");
        })
        .catch((error: any) => {
          console.error("Failed to reset PulseOximeter hash:", error);
        });
    });
  }


  //   async openPulseOximeterManual() {
  //   console.log("Opening SPO2 Component Device...");
  //     const dialogRef = this.dialog.open(PulseOximeterManualComponent, {
  //       panelClass: 'spo2-dialog-panel',
  //       height: "auto",
  //       disableClose: true,
  //     });

  //     dialogRef.afterClosed().subscribe((result) => {
  //       if (result) {
  //         console.log("Manual SpO2 saved:", result);
  //         // 🔹 Handle manual result (save to DB, sync, etc.)
  //       } else {
  //         console.log("Manual SpO2 entry closed without saving");
  //       }
  //     });

  //     return; // stop here, don’t go to device


  // }

  async openIcareThermometerPage() {
    const dialogRef = this.dialog.open(IcareThermometerPage, {
      width: "600px",
      height: "auto",
      disableClose: true,
      // panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result: any) => {

    });
  }


  // async openThermometerPage() {
  //   console.log("Image clicked!");
  //     const dialogRef = this.dialog.open(ThermometerPage, {
  //             panelClass: 'spo2-dialog-panel',
  //             width: '750px',
  //             height: '500px',
  //             disableClose: true,
  //             data: {

  //             }
  //           });

  //           dialogRef.afterClosed().subscribe((result) => {
  //             this.WebsocketsService.sendBleMessage("ble_close");

  //             if (result !== undefined) {
  //               // handle dialog result if needed
  //             }
  //           });
  //   // this.WebsocketsService.sendBleMessage("startScanFromHtml~40");

  //   // try {
  //   //   this.valSubscription = this.WebsocketsService.bleValueObs$.subscribe(async (data) => {
  //   //     if (data === "errorLableUpdate~start scan status : Success!") {
  //   //     } else if (data === "errorLableUpdate~THERMOSensor connected successfully.") {
  //   //     } else if (data === "SensorConnected~THERMOSensor~40") {
  //   //       this.sharedDataService.getData().subscribe(apiResponse => {
  //   //         const dialogRef = this.dialog.open(ThermometerPage, {
  //   //           panelClass: 'spo2-dialog-panel',
  //   //           width: '750px',
  //   //           height: '500px',
  //   //           disableClose: true,
  //   //           data: {
  //   //             apiResponse: apiResponse,  // pass the API response here
  //   //             api: 'withoutApiCalling'
  //   //           }
  //   //         });

  //   //         dialogRef.afterClosed().subscribe((result) => {
  //   //           this.WebsocketsService.sendBleMessage("ble_close");

  //   //           if (result !== undefined) {
  //   //             // handle dialog result if needed
  //   //           }
  //   //         });
  //   //       });
  //   //     }
  //   //   });
  //   // } catch (error) {
  //   //   console.error("Error in openThermometerPage:", error);
  //   // }
  // }

  async openTemperatureManualComponent() {
    const dialogRef = this.dialog.open(TemperatureManualComponent, {
      panelClass: 'spo2-dialog-panel',
      height: "auto",
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
      } else {
      }
    });

    return; // stop here, don’t go to device


  }


  async openThermometerPage(index: number, key: string) {
    // 1️⃣ Stop any previous device reminder
    if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
      this.stopSnackbarReminder(this.activeSnackbarDevice);
    }

    // 2️⃣ Check device status
    const status = this.getCardClass(key);
    if (status === 'disconnected' || status === 'completed') {
      this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
    }

    // 3️⃣ Handle manual entry
    if (this.manualEntryParameterBtn.includes(key)) {
      console.log("openTemperatureManualComponent", key);
      this.openTemperatureManualComponent();
      return;
    }

    // 4️⃣ Prevent multiple dialogs
    if (this.isThermometerDialogOpen) return;
    this.isThermometerDialogOpen = true;

    // 5️⃣ Start scanning BLE
    this.WebsocketsService.sendBleMessage("startScanFromHtml~40");

    try {
      this.valSubscription = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {
        console.log("Local temperature data:", data);

        if (data === "errorLableUpdate~start scan status : Success!") {
          this.errorMsgLocal = true;
        } else if (data === "errorLableUpdate~THERMOSensor connected successfully.") {
          this.errorStart = false;
          this.errorMsgLocal = false;
        } else if (data === "SensorConnected~THERMOSensor~40") {
          this.errorStart = false;
          this.errorMsgLocal = false;

          const device = this.enabledParameterBtn[index];
          device.isActive = true;
          device.isRipple = false;

          // Manual entry check again just in case
          if (this.manualEntryParameterBtn.includes(key)) {
            this.openTemperatureManualComponent();
            return;
          }

          // Open dialog if not already open
          if (!this.isThermometerDialogOpen) {
            this.isThermometerDialogOpen = true;

            const dialogRef = this.dialog.open(ThermometerPage, {
              panelClass: 'spo2-dialog-panel',
              width: '1000px',
              height: '480px',
              disableClose: true,
              data: { api: 'withoutApiCalling' }
            });

            dialogRef.afterClosed().subscribe(result => {
              this.isThermometerDialogOpen = false;
              this.WebsocketsService.sendBleMessage("ble_close");

              if (this.valSubscription) {
                this.valSubscription.unsubscribe();
                this.valSubscription = null;
              }

              this.deviceConnectionState['Temperature'] = result !== undefined
                ? 'completed'
                : (this.issdkjarReady ? 'disconnected' : 'disabled');
            });
          }
        }
      });
    } catch (error) {
      console.error("Local BLE device error", error);
      this.isThermometerDialogOpen = false;
    }
  }


  // async openThermometerPage(key: any) {

  //    // 1️⃣ Check device status first
  // const status = this.getCardClass(key);

  // // Stop any previous device reminder immediately
  // if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
  //   this.stopSnackbarReminder(this.activeSnackbarDevice);
  // }

  // if (status === 'disconnected' || status === 'completed') {
  //   this.startSnackbarReminder(`Please switch on ${key} Sensor`,key);
  //   // 👉 still continue, because once the sensor turns on, Jetty will connect
  // }
  //   let manual = this.manualEntryParameterBtn.find(res => { return res === key });
  //   if (manual) {
  //     console.log("openTemperatureManualComponent", manual);
  //     this.openTemperatureManualComponent();
  //   } else {
  //     this.WebsocketsService.sendBleMessage("startScanFromHtml~40");
  //     try {
  //       this.valSubscription = this.WebsocketsService.bleValueObs$.subscribe(async (data: string) => {
  //         if (data == "errorLableUpdate~start scan status : Success!") {
  //           // handle
  //         } else if (data == "errorLableUpdate~THERMOSensor connected successfully.") {
  //           // handle
  //         } else if (data == "SensorConnected~THERMOSensor~40") {
  //           // 🔹 Update the card state to "connected"
  //            const device = this.enabledParameterBtn.find(
  //             d => d.name.toLowerCase() === key.toLowerCase()
  //            );
  //           if (device) {
  //           device.isActive = true;  // mark as active
  //           device.manual = false;   // ensure it's not treated as manual
  //           }

  //           this.stopSnackbarReminder(key);
  //           this.deviceConnectionState['Temperature'] = "connected";
  //           const dialogRef = this.dialog.open(ThermometerPage, {
  //             panelClass: 'spo2-dialog-panel',
  //             width: '1000px',
  //             height: '480px',
  //             disableClose: true, // optional: disables clicking outside
  //             data: {
  //               api: 'withoutApiCalling'
  //             }
  //           });

  //           dialogRef.afterClosed().subscribe((result: undefined) => {
  //                this.WebsocketsService.sendBleMessage("ble_close");
  //           if (result != undefined) {
  //         // ✅ Measurement taken → completed
  //          this.deviceConnectionState['Temperature'] = 'completed';
  //         } else {
  //         // ❌ No result, check Jetty state
  //         if (this.issdkjarReady) {
  //         // Jetty running → disconnected
  //          this.deviceConnectionState['Temperature'] = 'disconnected';
  //         } else {
  //         // Jetty not running → disabled
  //         this.deviceConnectionState['Temperature'] = 'disabled';
  //         }
  //       }
  //           });
  //         }
  //       });
  //     } catch (error) {
  //       console.error("Error in openSpo2ComponentDevice:", error);
  //     }
  //   }

  //   console.log("Image clicked!");

  // }

  //Icare
  async openBloodPressureIcarePage() {
    const dialogRef = this.dialog.open(BloodPressureIcarePage, {
      width: "600px",
      height: "auto",
      disableClose: true,
      // panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result: any) => {
    });
  }


  async openBloodPressureComponent() {
    const dialogRef = this.dialog.open(BloodPressureComponent, {
      panelClass: 'spo2-dialog-panel',
      height: "auto",
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
      } else {
      }
    });

    return; // stop here, don’t go to device


  }




  async openHemoglobinPage() {
    const dialogRef = this.dialog.open(HemoglobinPage, {
      width: "600px",
      height: "auto",
      disableClose: true,
      // panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result: any) => {

    });
  }

  async openHemoglobinManualComponent() {
    const dialogRef = this.dialog.open(HemoglobinManualComponent, {
      width: "600px",
      height: "auto",
      disableClose: true,
      // panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result: any) => {

    });
  }



  openHemoglobinJettyPage(key: any) {

    // 1️⃣ Check device status first
    const status = this.getCardClass(key);

    // Stop any previous device reminder immediately
    if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
      this.stopSnackbarReminder(this.activeSnackbarDevice);
    }

    if (status === 'disconnected' || status === 'completed') {
      this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
      // 👉 still continue, because once the sensor turns on, Jetty will connect
    }
    let manual = this.manualEntryParameterBtn.find(res => { return res === key });
    if (manual) {
      console.log("openHemoglobinManualComponent", manual);
      this.openHemoglobinManualComponent();
    } else {
      // 🔹 Update the card state to "connected"
      const device = this.enabledParameterBtn.find(
        d => d.name.toLowerCase() === key.toLowerCase()
      );
      if (device) {
        device.isActive = true;  // mark as active
        device.manual = false;   // ensure it's not treated as manual
      }

      this.stopSnackbarReminder(key);
      this.deviceConnectionState['Hemoglobin'] = "connected";
      const dialogRef = this.dialog.open(HemoglobinJettyPage, {
        width: '1000px',
        height: 'auto',
        disableClose: true,
      });

      dialogRef.afterClosed().subscribe((result: undefined) => {
        this.WebsocketsService.sendParamMessage("disableNotificationFromHtml");
        // Handle dialog result if needed
        if (result != undefined) {
          // ✅ Measurement taken → completed
          this.deviceConnectionState['Hemoglobin'] = 'completed';
        } else {
          // ❌ No result, check Jetty state
          if (this.issdkjarReady) {
            // Jetty running → disconnected
            this.deviceConnectionState['Hemoglobin'] = 'disconnected';
          } else {
            // Jetty not running → disabled
            this.deviceConnectionState['Hemoglobin'] = 'disabled';
          }
        }
      });
    }
  }


  async openEcgComponentDevice() {
    // 1️⃣ Check device status first
    const key = "Electrocardiogram";
    const status = this.getCardClass(key);

    // // Stop any previous device reminder immediately
    // if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
    //   this.stopSnackbarReminder(this.activeSnackbarDevice);
    // }
    // if (status === 'disconnected' || status === 'completed') {
    //   this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
    //   // 👉 still continue, because once the sensor turns on, Jetty will connect
    // }

     const config = this.deviceConfig['electrocardiogram'];
    this.openDeviceComponent('Electrocardiogram', config.component, config.dialogConfig);
    // try {
    //   if (this.valSubscription) {
    //     this.valSubscription.unsubscribe();
    //   }

    //   this.valSubscription = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {
    //     if (!data) return;

    //     const parts = data.split('~');
    //     const eventType = parts[0];
    //     const message = parts[1];

    //     if (eventType === 'errorLableUpdate' && message === 'ECGSensor connected successfully.') {
    //       console.log(' ECG Sensor Connected — opening ECG dialog');
    //       // 🔹 Update the card state to "connected"
    //       const device = this.enabledParameterBtn.find(
    //         d => d.name.toLowerCase() === key.toLowerCase()
    //       );
    //       if (device) {
    //         device.isActive = true;  // mark as active
    //         device.manual = false;   // ensure it's not treated as manual
    //       }

    //       this.stopSnackbarReminder(key);
    //       this.deviceConnectionState['Electrocardiogram'] = "connected";
    //       const dialogRef = this.dialog.open(EcgJettyDevicePage, {
    //         panelClass: 'ecg-dialog-panel',
    //         disableClose: true,
    //         data: {
    //           api: 'withoutApiCalling'
    //         }
    //       });

    //       dialogRef.afterClosed().subscribe((result: string) => {
    //         console.log(' ECG Dialog closed:', result);
    //         if (result === 'closedByUser') {
    //           if (this.issdkjarReady) {
    //             this.deviceConnectionState['Electrocardiogram'] = 'disconnected';
    //           } else {
    //             // Jetty not running → disabled
    //             this.deviceConnectionState['Electrocardiogram'] = 'disabled';
    //           }
    //         }

    //       });

    //       if (this.valSubscription) {
    //         this.valSubscription.unsubscribe();
    //         this.valSubscription = null;
    //       }
    //     }
    //   });

    //   this.WebsocketsService.sendBleMessage('startScanFromHtml~10');

    // } catch (error) {
    //   if (this.issdkjarReady) {
    //     // Jetty running → disconnected
    //     this.deviceConnectionState['Electrocardiogram'] = 'disconnected';
    //   } else {
    //     // Jetty not running → disabled
    //     this.deviceConnectionState['Electrocardiogram'] = 'disabled';
    //   }
    //   console.error(' Error in openEcgComponentDevice:', error);
    // }

  }



  async openSpirometerManualComponent() {
    const dialogRef = this.dialog.open(SpirometerManualComponent, {

      height: "auto",
      disableClose: true,
      panelClass: 'spiro-manual-dialog'
    });

    dialogRef.afterClosed().subscribe((result: any) => {

    });
  }
  //Spirometer Device Component//
  spiroSeriesData = [];
  spiroCount = 0;
  spirometerDeviceComponentCount = 0;
  async openJettySpirometerDevice(key: any) {
    const status = this.getCardClass(key);

    // // Stop any previous device reminder immediately
    // if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
    //   this.stopSnackbarReminder(this.activeSnackbarDevice);
    // }

    // if (status === 'disconnected' || status === 'completed') {
    //   this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
    //   // 👉 still continue, because once the sensor turns on, Jetty will connect
    // }
    let manual = this.manualEntryParameterBtn.find(res => { return res === key });
    if (manual) {
        if (!this.isLocalConsultation && this.usertype === 'Doctor') {
        this.nullWebsocketService.sendMessage("open_spiro_manual");
      }
      console.log("openHemoglobinManualComponent", manual);
      this.openSpirometerManualComponent();
    } else {
        const config = this.deviceConfig['spirometer'];
    this.openDeviceComponent('Spirometer', config.component, config.dialogConfig);
      // this.WebsocketsService.sendBleMessage("startScanFromHtml~60");
      // try {
      //   this.valSubscription = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {
      //     // var jsondata = JSON.parse(data);
      //     if (data == "errorLableUpdate~start scan status : Success!") {
      //       this.errorMsgLocal = true;
      //       // this.connectedConsultaionDoctor1();
      //     } else if (
      //       data == "errorLableUpdate~Spiro sensor connected successfully."
      //     ) {
      //       this.errorStart = false;
      //     } else if (data == "SensorConnected~Spiro sensor~60") {
      //       this.errorStart = false;
      //       this.errorMsgLocal = false;
      //       let data: any;
      //       // if (this.spiroCount != 0) {
      //       data = {
      //         api: "withoutApiCalling",
      //         spiroSeriesData: this.spiroSeriesData,
      //         spiroCount: this.spiroCount,
      //       };
      //       // }
      //       // console.log("SpirometerDeviceComponent", jsondata?.message);
      //       if (this.spirometerDeviceComponentCount == 0) {
      //         // 🔹 Update the card state to "connected"
      //         const device = this.enabledParameterBtn.find(
      //           d => d.name.toLowerCase() === key.toLowerCase()
      //         );
      //         if (device) {
      //           device.isActive = true;  // mark as active
      //           device.manual = false;   // ensure it's not treated as manual
      //         }

      //         this.stopSnackbarReminder(key);
      //         this.deviceConnectionState['SpiroMeter'] = "connected";
      //         this.spirometerDeviceComponentCount++;
      //         const dialogRef = this.dialog.open(SpirometerJettyDevicePage, {
      //           data: data,
      //           width: '1000px',
      //           maxWidth: '1000px',
      //           panelClass: 'custom-spiro-dialog',
      //           height: 'auto',
      //           disableClose: true,
      //         });
      //         dialogRef.afterClosed().subscribe((result: { spiroSeriesData: any; spiroCount: number; } | undefined) => {
      //           // this.subscription8.unsubscribe();
      //           console.log(
      //             "this.websocketsService",
      //             this.WebsocketsService,
      //             result
      //           );
      //           // this.websocketsService.send('ble_spiro_start');
      //           this.spirometerDeviceComponentCount = 0;
      //           // this.websocketsService.send("ble_close");
      //           this.WebsocketsService.sendBleMessage(
      //             "disableNotificationFromHtml"
      //           );
      //           // ❌ No result → reset back
      //           if (this.issdkjarReady) {
      //             // Jetty running → disconnected
      //             this.deviceConnectionState['SpiroMeter'] = 'disconnected';
      //           } else {
      //             // Jetty not running → disabled
      //             this.deviceConnectionState['SpiroMeter'] = 'disabled';
      //           }
      //           if (result != undefined) {
      //             // ✅ Mark completed if we got a result
      //             this.deviceConnectionState['SpiroMeter'] = "completed";

      //             setTimeout(() => {
      //               this.WebsocketsService.sendBleMessage("ble_spiro_start");
      //             }, 1500);
      //             this.spiroSeriesData = JSON.parse(
      //               JSON.stringify(result.spiroSeriesData)
      //             );
      //             if (result.spiroCount == 3) {
      //               // ✅ Mark completed if we got a result
      //               this.deviceConnectionState['SpiroMeter'] = "completed";

      //               console.log(
      //                 "this.websocketsService",
      //                 this.WebsocketsService
      //               );
      //               this.subscription5.unsubscribe();
      //             }
      //             // this.spiroCount = result.spiroCount;
      //           } else {
      //             // ❌ No result → reset back
      //             if (this.issdkjarReady) {
      //               // Jetty running → disconnected
      //               this.deviceConnectionState['SpiroMeter'] = 'disconnected';
      //             } else {
      //               // Jetty not running → disabled
      //               this.deviceConnectionState['SpiroMeter'] = 'disabled';
      //             }
      //             this.subscription5.unsubscribe();
      //             this.spirometerDeviceComponentCount = 0;
      //           }
      //         });
      //       }
      //       this.status = false;
      //     }
      //   }
      //   );
      // } catch (e) {
      //   // ❌ No result → reset back
      //   if (this.issdkjarReady) {
      //     // Jetty running → disconnected
      //     this.deviceConnectionState['SpiroMeter'] = 'disconnected';
      //   } else {
      //     // Jetty not running → disabled
      //     this.deviceConnectionState['SpiroMeter'] = 'disabled';
      //   }
      // }
    }
    // }
  }

  async openGlucoseManualEntryComponent() {
    const dialogRef = this.dialog.open(GlucoseManualEntryComponent, {

      height: "auto",
      disableClose: true,
      // panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result: any) => {

    });
  }




  async openGlucoseTestDevice(key: any) {

    // 1️⃣ Check device status first
    const status = this.getCardClass(key);

    // Stop any previous device reminder immediately
    if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
      this.stopSnackbarReminder(this.activeSnackbarDevice);
    }

    if (status === 'disconnected' || status === 'completed') {
      this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
      // 👉 still continue, because once the sensor turns on, Jetty will connect
    }
    let manual = this.manualEntryParameterBtn.find(res => { return res === key });
    if (manual) {
      console.log("openHemoglobinManualComponent", manual);
      this.openGlucoseManualEntryComponent();
    } else {
      console.log("glucose test device clicked!");

      // Check if kit is ready
      if (!this.issdkjarReady) {
        console.log("glucose test kit not ready yet!");
        return;
      }

      // Check if dialog is already open
      if (this.glucosetestdialogopen) {
        console.log("glucose test dialog already open!");
        return;
      }

      try {
        console.log('✅ Kit ready - opening dialog...');

        if (this.paramValueSubscription) {
          console.log(" Unsubscribing paramValueObs$ in ParameterPage");
          this.paramValueSubscription.unsubscribe();
        }

        // Set flag to prevent multiple dialogs
        this.glucosetestdialogopen = true;
        // 🔹 Update the card state to "connected"
        const device = this.enabledParameterBtn.find(
          d => d.name.toLowerCase() === key.toLowerCase()
        );
        if (device) {
          device.isActive = true;  // mark as active
          device.manual = false;   // ensure it's not treated as manual
        }

        this.stopSnackbarReminder(key);
        this.deviceConnectionState['Glucose'] = "connected";
        const dialogRef = this.dialog.open(GlucosePage, {
          panelClass: 'glucose-dialog-panel', // Changed to glucose-specific class
          width: '1289px', // Updated to match Figma design
          height: '535px', // Updated to match Figma design386
          maxWidth: "95vw",
          maxHeight: "90vh",
          disableClose: true,
          data: {
            api: 'withoutApiCalling'
          }
        });

        dialogRef.afterClosed().subscribe((result: undefined) => {
          console.log('📱 Dialog closed glucose');
          this.glucosetestdialogopen = false;

          if (!this.paramValueSubscription) {
            console.log("🔁 Re-subscribing paramValueObs$ after Glucose dialog");
            this.WebsocketsService.sendParamMessage("connectKitFirstTime");
            this.paramValueSubscription = this.WebsocketsService.paramValueObs$.subscribe((data: string | null) => {
              console.log("param data", data);

              if (data == null || data == "null") {
                console.log("usb Test not available - Please start the SDK");
                this.issdkjarReady = false;
              } else if (data === "kitStatusCheck~1001") {
                console.log("usb Test ready!");
                this.issdkjarReady = true;
              } else if (data == "error") {
                console.log("usb Test has error!");
                this.issdkjarReady = false;
              }
            });
          }

          if (result !== undefined) {
            console.log('Dialog result:', result);
            this.deviceConnectionState['Glucose'] = 'completed';
          } else {
            // ❌ No result, check Jetty state
            if (this.issdkjarReady) {
              // Jetty running → disconnected
              this.deviceConnectionState['Glucose'] = 'disconnected';
            } else {
              // Jetty not running → disabled
              this.deviceConnectionState['Glucose'] = 'disabled';
            }
          }
        });

      } catch (error) {
        console.error("Error in openGlucoseTestDevice:", error);
        this.glucosetestdialogopen = false;
      }
    }
  }



  async openGlucoseBleDevicePage() {
    console.log("Glucose BLE device clicked!");
    // 1️⃣ Check device status first
    const key = "GlucoseBLE";
    const status = this.getCardClass(key);

    // Stop any previous device reminder immediately
    if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
      this.stopSnackbarReminder(this.activeSnackbarDevice);
    }

    if (status === 'disconnected' || status === 'completed') {
      this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
      // 👉 still continue, because once the sensor turns on, Jetty will connect
    }
    // Prevent multiple dialogs from opening
    if (this.dialog.openDialogs.length > 0) {
      console.log("Dialog already open, preventing duplicate");
      return;
    }

    try {
      // Clean up any existing subscription before creating new one
      if (this.valSubscription5) {  // Use consistent variable name
        this.valSubscription5.unsubscribe();
      }

      // Initialize BLE connection
      this.WebsocketsService.sendBleMessage("BleAppletInit");  // Use consistent service name

      // Create new subscription for BLE messages
      this.valSubscription5 = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {  // Consistent names
        console.log("BLE Message for Glucose:", data);

        if (!data) return; // Handle null/undefined data

        if (data === "msgFromBLEApplet~false~Dongle not connected.") {
          console.warn("Dongle is not connected.");
          // Optionally show user notification here

        } else if (data === "error") {
          console.error("BLE connection error.");
          // Optionally show error notification here

        } else if (
          data === "msgFromBLEApplet~true~Dongle connected successfully.~1" ||
          data === "msgFromBLEApplet~true~Dongle connected successfully.~2"
        ) {
          console.log("Dongle connected successfully - opening Glucose BLE dialog");

          // Unsubscribe immediately after successful connection to prevent multiple dialogs
          if (this.valSubscription5) {
            this.valSubscription5.unsubscribe();

          }

          // Check again to prevent multiple dialogs
          if (this.dialog.openDialogs.length > 0) {
            console.log("Dialog already exists, skipping creation");
            return;
          }
          // 🔹 Update the card state to "connected"
          const device = this.enabledParameterBtn.find(
            d => d.name.toLowerCase() === key.toLowerCase()
          );
          if (device) {
            device.isActive = true;  // mark as active
            device.manual = false;   // ensure it's not treated as manual
          }

          this.stopSnackbarReminder(key);
          this.deviceConnectionState['GlucoseBLE'] = "connected";
          // Open the glucose BLE dialog directly after dongle connection
          const dialogRef = this.dialog.open(GlucoseBlePage, {
            width: "1289px",
            height: "681px",
            maxWidth: "95vw",
            maxHeight: "90vh",
            disableClose: true,
            panelClass: 'glucose-dialog-panel',
            data: {
              api: "withoutApiCalling",
            },
          });
          dialogRef.afterClosed().subscribe((result: undefined) => {
            console.log("Glucose BLE dialog closed:", result);

            // Clean up BLE notifications
            this.WebsocketsService.sendBleMessage("disableNotificationFromHtml");

            if (result !== undefined) {
              console.log("Dialog result:", result);
              this.deviceConnectionState['GlucoseBLE'] = 'completed';
            } else {
              // ❌ No result, check Jetty state
              if (this.issdkjarReady) {
                // Jetty running → disconnected
                this.deviceConnectionState['GlucoseBLE'] = 'disconnected';
              } else {
                // Jetty not running → disabled
                this.deviceConnectionState['GlucoseBLE'] = 'disabled';
              }
            }
          });
        }
      });

    } catch (error) {
      console.error("Error in openGlucoseBleDevicePage:", error);

      // Clean up subscription on error
      if (this.valSubscription5) {  // Fix: Use correct variable name
        this.valSubscription5.unsubscribe();  // Fix: Use correct variable name
      }
    }
  }


  async openUrineManualComponent() {
    const dialogRef = this.dialog.open(UrineManualComponent, {
      width: "600px",
      height: "auto",
      disableClose: true,
      // panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result: any) => {

    });
  }


  async openUrineTestDevice(key: any) {
    let manual = this.manualEntryParameterBtn.find(res => { return res === key });
    if (manual) {
      console.log("openUrineManualComponent", manual);
      this.openUrineManualComponent();
    } else {
      console.log("urine test device clicked!");

      // Check if kit is ready
      if (!this.issdkjarReady) {
        console.log("Rapid test kit not ready yet!");
        return;
      }

      // Check if dialog is already open
      if (this.urinetestdialogopen) {
        console.log("Urine test dialog already open!");
        return;
      }

      try {
        console.log('✅ Kit ready - opening dialog...');

        // Set flag to prevent multiple dialogs
        this.urinetestdialogopen = true;

        // Open the dialog with normal size for instructions/processing
        // Only resize when results are displayed
        const dialogRef = this.dialog.open(UrineTestPage, {
          panelClass: 'urine-test-dialog-panel',
          width: '700px',  // Normal width for instructions/processing
          height: '550px', // Normal height
          maxWidth: 'none', // Allow expansion when needed
          maxHeight: '95vh',
          disableClose: true,
          data: {
            api: 'withoutApiCalling'
          }
        });

        dialogRef.afterClosed().subscribe((result: undefined) => {
          console.log('📱 Dialog closed');

          // Reset flag when dialog closes
          this.urinetestdialogopen = false;

          if (result != undefined) {
            console.log('Dialog result:', result);
          }
        });

      } catch (error) {
        console.error("Error in openUrineTestDevice:", error);
        // Reset flag on error
        this.urinetestdialogopen = false;
      }
    }
  }



  async openRapidManualComponent() {
    const dialogRef = this.dialog.open(RapidManualComponent, {
      width: "600px",
      height: "auto",
      disableClose: true,
      // panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result: any) => {

    });
  }


  async openRapidTestDevice(key: any) {
    let manual = this.manualEntryParameterBtn.find(res => { return res === key });
    if (manual) {
      console.log("openRapidManualComponent", manual);
      this.openRapidManualComponent();
    } else {
      console.log("Rapid test device clicked!");

      // Check if kit is ready
      if (!this.issdkjarReady) {
        console.log("Rapid test kit not ready yet!");
        return;
      }

      // Check if dialog is already open
      if (this.rapidTestDialogOpen) {
        console.log("Rapid test dialog already open!");
        return;
      }

      try {
        console.log('✅ Kit ready - opening dialog...');

        // Set flag to prevent multiple dialogs
        this.rapidTestDialogOpen = true;

        // Open the dialog immediately - don't wait for WebSocket messages
        const dialogRef = this.dialog.open(RapidTestPage, {
          panelClass: 'rapid-test-dialog-panel',
          width: '840px',
          height: '360px',
          disableClose: true,
          data: {
            api: 'withoutApiCalling'
          }
        });

        dialogRef.afterClosed().subscribe((result: undefined) => {
          console.log('📱 Dialog closed');

          // Reset flag when dialog closes
          this.rapidTestDialogOpen = false;

          if (result != undefined) {
            // Handle result if needed
            console.log('Dialog result:', result);
          }
        });

      } catch (error) {
        console.error("Error in openRapidTestDevice:", error);
        // Reset flag on error
        this.rapidTestDialogOpen = false;
      }
    }
  }
  getEnabledParameterList() {
    let data =
      "?action=enabledParameterList&domain=" +
      this.currDomainId +
      "&consId=" +
      this.consultationId +
      "&token=" +
      this.tokenRequest;

    this.apiSvc
      .postServiceByQueryBasic<EnabledParameterResponse>(
        this.constantSvc.APIConfig.GETCOMMONSERVICES,
        data
      )
      .subscribe({
        next: (res: { Result: string; data: any[]; }) => {
          console.log("enabledParameterBtn", res);

          if (res.Result === "Success") {
            this.enabledParameterBtn = res.data.map((element: string) => {
              return {
                name: element,
                disable: false,
                src: "assets/images/" + element.toLowerCase() + ".png",
                manual: false,
                isRipple: false,
                isActive: false,
              };
            });
          }
          this.getManualEntryParameter();
        },
        error: (err) => {
          console.warn('EnabledParameterList API failed, using offline data:', err);
          this.loadOfflineParameterList();
        }
      });
  }

  private loadOfflineParameterList(): void {
    this.pouchdbService.initDB('consultation_db');
    
    this.pouchdbService.getRecordById(`parameterConf_${this.username}`).subscribe({
      next: (doc: any) => {
        console.log('Using offline ParameterList data');
        const parameterList = doc.data?.ParameterList || [];
        
        this.enabledParameterBtn = parameterList.map((element: string) => {
          return {
            name: element,
            disable: false,
            src: "assets/images/" + element.toLowerCase() + ".png",
            manual: true, // Default to manual in offline mode
            isRipple: false,
            isActive: false,
          };
        });
        
        this.getManualEntryParameter();
      },
      error: (err) => {
        console.error('No offline ParameterList data available:', err);
        // Set empty array as fallback
        this.enabledParameterBtn = [];
        this.getManualEntryParameter();
      }
    });
  }


  isDeviceEnabled(deviceName: string): boolean {
    // Check if device is enabled in parameter list
    const isEnabled = this.enabledParameterBtn.some(
      (item: EnabledParameter) => item.name.toLowerCase() === deviceName.toLowerCase()
    );

    // If video consultation and user is nurse, disable device access
    if (this.isVideoConsultationActive && this.usertype === 'Nurse') {
      return false;
    }

    return isEnabled;
  }

  getManualEntryParameter(): void {
    // Define expected response type

    const data =
      "?action=manualEntryParameter&domain=" +
      this.currDomainId +
      "&consId=" +
      this.consultationId +
      "&token=" +
      this.tokenRequest;

    this.apiSvc
      .postServiceByQueryBasic<ManualEntryResponse>(
        this.constantSvc.APIConfig.GETCOMMONSERVICES,
        data
      )
      .subscribe((res: ManualEntryResponse) => {
        if (res.Result === "OK") {
          this.manualEntryParameterBtn = res.Records;

          console.log(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
          console.log(this.manualEntryParameterBtn);
          sessionStorage.setItem("manualEntryRecords", JSON.stringify(res.Records));
          sessionStorage.setItem("rapid_manual", res.Records.includes("Rapidtest") ? "true" : "false");
          sessionStorage.setItem("urine_manual", res.Records.includes("Urinetest") ? "true" : "false");

          this.manualEntryParameterBtn.forEach((entry: string) => {
            this.enabledParameterBtn.forEach((element: any) => {
              console.log("entry", element.name);
              if (entry === element.name) {
                element.disable = false;
              }
            });
          });

          // If you need this later, uncomment it:
          this.getParameterConf();
        }
      });
  }

  getParameterConf(): void {
    const data =
      "?action=ParameterConf" +
      "&username=" +
      this.username +
      "&consId=" +
      this.consultationId +
      "&token=" +
      this.tokenRequest;

    this.apiSvc
      .postServiceByQueryBasic<ParameterConfResponse>(
        this.constantSvc.APIConfig.GETCOMMONSERVICES,
        data
      )
      .subscribe({
        next: (res: ParameterConfResponse) => {
          if (res.status === "success") {
            // Store in PouchDB for offline use
            this.storeParameterConfInPouchDB(res.data);
            this.applyParameterConfiguration(res.data);
          }
        },
        error: (error) => {
          console.warn('ParameterConf API failed, using offline data:', error);
          this.loadParameterConfFromPouchDB();
        }
      });
  }

  private storeParameterConfInPouchDB(data: any): void {
    // Initialize the consultation_db to store parameter conf
    this.pouchdbService.initDB('consultation_db');

    const parameterConfDoc = {
      _id: `parameterConf_${this.username}`,
      data: data,
      timestamp: new Date().toISOString(),
      username: this.username,
      type: 'parameterConf'
    };

    this.pouchdbService.updateRecord(parameterConfDoc).subscribe({
      next: () => console.log('ParameterConf stored in PouchDB'),
      error: (err) => {
        // If update fails, try adding as new record
        this.pouchdbService.addRecord(parameterConfDoc).subscribe({
          next: () => console.log('ParameterConf added to PouchDB'),
          error: (addErr) => console.error('Error storing ParameterConf:', addErr)
        });
      }
    });
  }

  private loadParameterConfFromPouchDB(): void {
    // Initialize the consultation_db to access stored parameter conf
    this.pouchdbService.initDB('consultation_db');

    this.pouchdbService.getRecordById(`parameterConf_${this.username}`).subscribe({
      next: (doc: any) => {
        console.log('Using offline ParameterConf data:', doc);
        this.applyParameterConfiguration(doc.data);
      },
      error: (err) => {
        console.error('No offline ParameterConf data available:', err);
        this.setDefaultParameterConfiguration();
      }
    });
  }

  private applyParameterConfiguration(data: any): void {
    setTimeout(() => {
      this.enabledParameterBtn.forEach((element: ParameterButton) => {
        const manualParams = data.ParameterListWithManual;
        const paramValue = manualParams[element.name];

        if (paramValue !== undefined) {
          // Special case for specific parameters
          if (
            element.name === "FetalDopler" ||
            element.name === "Electrocardiogram" ||
            element.name === "StethoScope"
          ) {
            if (
              paramValue === 0 &&
              sessionStorage.getItem("dialogRef") !== '"local"'
            ) {
              element.manual = false;
            } else {
              element.manual = true;
            }

            if (sessionStorage.getItem("dialogRef") === "local") {
              element.manual = paramValue === 1;
            }
          } else {
            // For other parameters
            if (sessionStorage.getItem("dialogRef") !== "local") {
              element.manual = paramValue === 1;
            } else {
              element.manual = paramValue === 1;
            }
          }

          console.log(element, "manual entry log", paramValue);
        }
      });
    });

    this.parameterConf = data;
  }

  private setDefaultParameterConfiguration(): void {
    console.log('Setting default parameter configuration for offline mode');
    // Set all enabled parameters to manual mode as fallback
    this.enabledParameterBtn.forEach((element: ParameterButton) => {
      element.manual = true;
    });
    // Set parameterConf to empty object to indicate offline mode
    this.parameterConf = {};
  }

  async openHba1cManualComponent() {
    const dialogRef = this.dialog.open(Hba1cManualComponent, {

      height: "auto",
      disableClose: true,
      // panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result: any) => {

    });
  }

  async openHbA1cJettyPage(key: any) {

    // 1️⃣ Check device status first
    const status = this.getCardClass(key);

    // Stop any previous device reminder immediately
    if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
      this.stopSnackbarReminder(this.activeSnackbarDevice);
    }

    if (status === 'disconnected' || status === 'completed') {
      this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
      // 👉 still continue, because once the sensor turns on, Jetty will connect
    }
    let manual = this.manualEntryParameterBtn.find(res => { return res === key });
    if (manual) {
      console.log("openHba1cManualComponent", manual);
      this.openHba1cManualComponent();
    } else {
      this.WebsocketsService.sendBleMessage("startScanFromHtml~101");

      this.valSubscription1 = this.WebsocketsService.bleValueObs$.subscribe((data: string | string[]) => {
        try {
          console.log("BLE Message (HbA1c):", data);

          if (data === "errorLableUpdate~start scan status : Success!") {

          }
          else if (data === "errorLableUpdate~HbA1c connected successfully.") {

          }
          else if (data?.includes("SensorConnected~HbA1c~101")) {

            this.valSubscription1.unsubscribe();
            // 🔹 Update the card state to "connected"
            const device = this.enabledParameterBtn.find(
              d => d.name.toLowerCase() === key.toLowerCase()
            );
            if (device) {
              device.isActive = true;  // mark as active
              device.manual = false;   // ensure it's not treated as manual
            }

            this.stopSnackbarReminder(key);
            this.deviceConnectionState['HBA1C'] = "connected";
            const dialogRef = this.dialog.open(HbA1cBleDevicePage, {

              disableClose: true,
            });

            dialogRef.afterClosed().subscribe(() => {
              this.WebsocketsService.sendBleMessage("ble_close");
              if (this.issdkjarReady) {
                // Jetty running → disconnected
                this.deviceConnectionState['HBA1C'] = 'disconnected';
              } else {
                // Jetty not running → disabled
                this.deviceConnectionState['HBA1C'] = 'disabled';
              }
            });
          }
        } catch (error) {
          console.error("Error processing WebSocket data (HbA1c):", error);
        }
      });
    }
  }

  async openLipidManualEntryComponent() {
    const dialogRef = this.dialog.open(LipidManualEntryComponent, {

      disableClose: true,
      // panelClass: 'slot-dialog'
    });

    dialogRef.afterClosed().subscribe((result: any) => {

    });
  }
  openLipidProfilePage() {

    const key = "Lipid";
    const status = this.getCardClass(key);
    console.log("I have netered inside the method");

    if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
      this.stopSnackbarReminder(this.activeSnackbarDevice);
    }

    if (status === 'disconnected' || status === 'completed') {
      this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
      // 👉 still continue, because once the sensor turns on, Jetty will connect
      console.log("I have netered inside the method");
    }
    this.stopSnackbarReminder(key);


    this.deviceConnectionState['Lipid'] = "connected";
    let manual = this.manualEntryParameterBtn.find(res => { return res === key });
    if (manual) {
      console.log("openLipidManualEntryComponent", manual);
      this.openLipidManualEntryComponent();
    } else {
      const dialogRef = this.dialog.open(LipidTestSelectionComponent, {
        panelClass: 'test-selection-dialog-panel',
        width: '1289px',
        height: 'auto',
        disableClose: true,
      });

      dialogRef.afterClosed().subscribe((result: any) => {
        // this.WebsocketsService.sendBleMessage("ble_close");
        // this.WebsocketsService.sendParamMessage("ble_close");
        // Handle dialog result if needed
        if (result != undefined) {
          // ✅ Measurement taken → completed
          this.deviceConnectionState['Lipid'] = 'completed';
        } else {
          // ❌ No result, check Jetty state
          if (this.issdkjarReady) {
            // Jetty running → disconnected
            this.deviceConnectionState['Lipid'] = 'disconnected';
          } else {
            // Jetty not running → disabled
            this.deviceConnectionState['Lipid'] = 'disabled';
          }
        }
      });
    }
  }


  // Device configuration mapping
  private deviceConfig: { [key: string]: { component: any; dialogConfig: any; deviceKey: string } } = {
    'stethoscope': {
      component: StethoscopeDevicePage,
      dialogConfig: {
        width: "95vw", height: "95vh", maxWidth: "95vw", maxHeight: "95vh",
        panelClass: 'stethoscope-dialog-panel'
      },
      deviceKey: 'stethoscope'
    },
    'fetaldopler': {
      component: FetalDopplerDevicePage,
      dialogConfig: {
        width: "85%", height: "88%", maxWidth: "1289px", maxHeight: "1000px",
        panelClass: 'fetal-doppler-dialog-panel'
      },
      deviceKey: 'fetaldopler'
    },
    'Temprature': {
      component: ThermometerPage,
      dialogConfig: {
        width: "1000px", height: "480px", maxWidth: "1000px", maxHeight: "480px",
        panelClass: 'spo2-dialog-panel'
      },
      deviceKey: 'temperature'
    }, 
     'electrocardiogram': {
      component: EcgJettyDevicePage,
      dialogConfig: {
        panelClass: 'ecg-dialog-panel'
      },
      deviceKey: 'electrocardiogram'
    },
    'mecginterpretation': {
      component: EcgInterpretationManualJettyComponent,
      dialogConfig: {
        panelClass: this.currentUserType === 'Doctor'
          ? 'ecgi-manual-dialog-panel' : 'ecg-dialog-panel'
      },
      deviceKey: 'mecginterpretation'
    },
    'pecginterpretation': {
      component: EcgInterpretationJettyDeviceComponent,
      dialogConfig: {
        panelClass: 'ecg-dialog-panel'
      },
      deviceKey: 'pecginterpretation'
    },
    'spirometer': {
      component: SpirometerJettyDevicePage,
      dialogConfig: {
        width: '1000px',
        maxWidth: '1000px',
        height: 'auto',
        panelClass: 'custom-spiro-dialog'
      },
      deviceKey: 'spirometer'
    },

  };

  /**
   * 🔧 REUSABLE DEVICE COMPONENT OPENER - Works for all medical devices
   * Opens device-specific dialog and handles doctor control messages
   */
  private openDeviceComponent(deviceName: string, componentClass: any, dialogConfig: any): void {
    const deviceKey = deviceName.toLowerCase();

    // Send doctor control start message
    this.sendDeviceStartMessage(deviceKey);

    const dialogRef = this.dialog.open(componentClass, {
      ...dialogConfig,
      disableClose: true,
      data: { api: 'withoutApiCalling' }
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      // Send doctor control close message
      this.sendDeviceCloseMessage(deviceKey);

      if (result) {
        console.log(`${deviceName} dialog completed with result:`, result);
      }
    });
  }

  openStethoscopeDeviceComponent() {
    const config = this.deviceConfig['stethoscope'];
    this.openDeviceComponent('Stethoscope', config.component, config.dialogConfig);
  }

  openFetalDopplerDeviceComponent() {
    const config = this.deviceConfig['fetaldopler'];
    this.openDeviceComponent('FetalDopler', config.component, config.dialogConfig);
  }

  openTempratureDeviceComponent(key:any) {
    let manual = this.manualEntryParameterBtn.find(res => { return res === key });
    if (manual) {
      // Manual entry flow
      if (!this.isLocalConsultation && this.usertype === 'Doctor') {
        this.nullWebsocketService.sendMessage("open_temp_manual");
      }
      console.log("Opening manual temperature entry", manual);
      this.openTemperatureManualComponent();
    }
    else{
    const config = this.deviceConfig['Temprature'];
    this.openDeviceComponent('Temperature', config.component, config.dialogConfig);
    }
  }
  private opticalReaderDialogOpen = false;
  private fetalDopplerDialogOpen = false;

  // Add this method to your ParametersPage class
  async openOpticalReaderDevice() {
    console.log("Optical Reader device clicked!");

    // if (!this.issdkjarReady) {
    //   console.log("SDK not ready yet!");
    //   return;
    // }

    if (this.opticalReaderDialogOpen) {
      console.log("Optical Reader dialog already open!");
      return;
    }

    try {
      console.log('✅ Kit ready - opening test selection dialog...');
      this.opticalReaderDialogOpen = true;

      const dialogRef = this.dialog.open(TestSelectionDialogPage, {
        panelClass: 'test-selection-dialog-panel',
        width: '1289px',
        height: '800px',
        maxWidth: '95vw',
        maxHeight: '90vh',
        disableClose: true,
        data: {
          api: 'withoutApiCalling'
        },
        // Ensure responsive behavior
        autoFocus: false,
        restoreFocus: false
      });

      dialogRef.afterClosed().subscribe((result: undefined) => {
        console.log('📱 Test selection dialog closed');
        this.opticalReaderDialogOpen = false;

        if (result != undefined) {
          console.log('Dialog result:', result);
        }
      });

    } catch (error) {
      console.error("Error in openOpticalReaderDevice:", error);
      this.opticalReaderDialogOpen = false;
    }
  }
  async openOtoscope()
  {
    const dialogRef = this.dialog.open(OtoscopePage, {
      width: "1289px", 
      height: "auto",
      maxHeight: "90vh", 
      panelClass: 'otoscope-dialog',
      disableClose: true,
      autoFocus: false 
    });
  
    dialogRef.afterClosed();
  }


  private initBleStatusMonitoring() {
    // Set initial state
    this.bleConnectionStatus = 'not-connected';
    this.bleConnectionMessage = 'BLE Dongle Not Connected';

    // Create a separate subscription for BLE status monitoring
    this.bleStatusSubscription = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {
      this.handleBleStatusMessage(data);
    });
  }

  private handleBleStatusMessage(data: string) {
    if (!data) return;

    console.log(`🔧 BLE Status Message (${this.usertype}):`, data);

    // Handle connection success
    if (data === "msgFromBLEApplet~true~Dongle connected successfully.~1" ||
      data === "msgFromBLEApplet~true~Dongle connected successfully.~2") {
      this.bleConnectionStatus = 'connected';
      this.bleConnectionMessage = 'BLE USB Dongle Connected';

      // Clear any reconnection attempts
      this.stopReconnectionAttempts();
      this.isDongleConnected = true;

      // 🔧 Handle dongle connection for both local and video consultation
      this.handleDongleConnection();

      // 🔧 For video consultation nurse side, send dongle status to doctor
      if (this.isVideoConsultationActive && this.usertype === 'Nurse') {
        this.sendNurseBleDongleStatus();
      }

      console.log(`✅ BLE Dongle connected successfully (${this.usertype})`);
    }
    // Handle connection failure or disconnection
    else if (data === "msgFromBLEApplet~false~Dongle not connected." ||
      data.includes("errordongledisconnect~dongle disconnected while taking reading")) {
      this.bleConnectionStatus = 'not-connected';
      this.bleConnectionMessage = 'BLE Dongle Not Connected';
      this.isDongleConnected = false;
      this.dongleMessagesAlreadySent = false;
      this.startReconnectionAttempts();

      console.log("❌ BLE Dongle not connected");
    }
  }

  private startReconnectionAttempts() {
    // Clear any existing interval
    this.stopReconnectionAttempts();

    console.log("🔄 Starting BLE reconnection attempts...");

    // Try to reconnect every 2 seconds
    this.reconnectInterval = setInterval(() => {
      if (this.bleConnectionStatus !== 'connected') {
        console.log("🔄 Attempting BLE reconnection...");
        this.WebsocketsService.sendBleMessage("BleAppletInit");
      }
    }, 2000);
  }

  private stopReconnectionAttempts() {
    if (this.reconnectInterval) {
      clearInterval(this.reconnectInterval);
      this.reconnectInterval = null;
      console.log("⏹️ Stopped BLE reconnection attempts");
    }
  }

  private cleanupBleStatusMonitoring() {
    // Unsubscribe from BLE status monitoring
    if (this.bleStatusSubscription) {
      this.bleStatusSubscription.unsubscribe();
      this.bleStatusSubscription = null;
    }

    // Stop reconnection attempts
    this.stopReconnectionAttempts();
  }

  // Getter for BLE status CSS classes
  getBleStatusClass(): string {
    switch (this.bleConnectionStatus) {
      case 'connected':
        return 'ble-status-connected';
      case 'not-connected':
      default:
        return 'ble-status-not-connected';
    }
  }
  isParameterEnabled(deviceName: string): boolean {
    return this.enabledParameterBtn.some(
      item => item.name.toLowerCase() === deviceName.toLowerCase()
    );
  }

  shouldShowCard(deviceName: string): boolean {
    // Hide card completely if API didn't enable this parameter
    return this.isParameterEnabled(deviceName);
  }
  getCardClass(deviceName: string): string {
    const device = this.enabledParameterBtn.find(
      item => item.name.toLowerCase() === deviceName.toLowerCase()
    ); 

    if (!device) return 'hidden';

    // 🔹 Offline mode: Show devices as manual when ParameterConf API failed
    if (!navigator.onLine || this.parameterConf === null) {
      return 'manual'; // Show all devices as manual in offline mode
    }

    // 🔹 Special handling for ECGInterpretation
  if (deviceName.toLowerCase() === 'ecginterpretation') {
    const isManual = device.manual;
    const isDoctor = this.usertype?.toLowerCase() === 'doctor';
    const isLocal = this.isLocalConsultation;
    const jettyReady = this.issdkjarReady;

    if (isManual) {
      // Manual devices
      if (isDoctor && !isLocal) {
        return 'manual'; // Remote doctor: always manual
      } else {
        return jettyReady ? 'manual' : 'disabled'; // Local doctor/nurse or remote nurse: depends on Jetty
      }
    }else {
  // Non-manual devices
  if (isDoctor && !isLocal) {
    // Remote doctor: Jetty is irrelevant
    return 'disconnected';
  }

  // Local (doctor or nurse) — Jetty matters
  return jettyReady ? 'disconnected' : 'disabled';
}

  
    }
    if (
      device.manual &&
      deviceName.toLowerCase() !== 'stethoscope' &&
      deviceName.toLowerCase() !== 'electrocardiogram' &&
      deviceName.toLowerCase() !== 'fetaldopler' &&
      deviceName.toLowerCase() !== 'glucoseble' &&
      deviceName.toLowerCase() !== 'ecginterpretation'
    ) {
      return 'manual';
    }


    // 🔹 Video consultation mode: BLE devices can work without Jetty if dongle is connected
    if (this.isVideoConsultationActive) {
      const bleDevices = ['stethoscope', 'fetaldopler', 'pulseoximeter', 'temperature', 'bloodpressure', 'glucoseble', 'hba1c', 'electrocardiogram', 'ecginterpretation', 'spirometer', 'hemoglobin'];
      if (bleDevices.includes(deviceName.toLowerCase())) {
        // Runtime state takes priority
        const runtimeState = this.deviceConnectionState[deviceName];
        if (runtimeState) return runtimeState;

        // In video consultation, if dongle is connected, show as disconnected (ready to connect)
        if (this.bleConnectionStatus === 'connected') {
          return 'disconnected';
        }

        // If dongle not connected, show as disabled
        return 'disabled';
      }
    }

    if (!this.issdkjarReady) return 'disabled';

    // 🔹 Runtime state takes priority
    const runtimeState = this.deviceConnectionState[deviceName];
    if (runtimeState) return runtimeState;  // "connected" or "completed"

    // 🔹 Otherwise fall back to API
    if (device.isActive) return 'completed';

    return 'disconnected';
  }



  getCardLabel(deviceName: string): string {
    const status = this.getCardClass(deviceName);

    switch (status) {
      case 'manual':
        return 'Manual Entry';
      case 'disconnected':
        return 'Disconnected';   // 👈 new status
      case 'completed':
        return 'Completed';
      case 'disabled':
        return 'Not Available';
      default:
        return '';
    }
  }
  // Add this property to store the snackbar reference
  private activeSnackBarRef: any = null;

  startSnackbarReminder(message: string, device: string) {
    this.stopSnackbarReminder(this.activeSnackbarDevice); // clear any previous
    this.activeSnackbarDevice = device;

    this.activeSnackBarRef = this.snackBar.openFromComponent(Snackbar, {
      data: {
        title: 'Connection Required!',
        message: message
      },
      duration: 0, // Keep it open indefinitely
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
      panelClass: ['custom-snackbar-panel']
    });

    // Handle dismiss action
    this.activeSnackBarRef.onAction().subscribe(() => {
      this.stopSnackbarReminder(device);
    });
  }

  stopSnackbarReminder(device: string | null) {
    if (this.activeSnackBarRef) {
      this.activeSnackBarRef.dismiss();
      this.activeSnackBarRef = null;
    }
    this.activeSnackbarDevice = null;
  }


  showSnackbar(message: string) {
    this.snackBar.open(message, 'OK', {
      duration: 0,
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
    });
  }

  private deviceConnectionState: { [key: string]: 'connected' | 'completed' | 'disabled' | 'disconnected' | 'manual' | undefined } = {};


  // ==================================================================================
  // DOCTOR CONTROL SYSTEM IMPLEMENTATION - PARAMETERS PAGE
  // ==================================================================================
  // Purpose: Initialize and handle doctor control messages when dongle connects
  // Pattern: Doctor → Dongle connects → Send 2 messages to nurse via nullwebsocket
  // Messages: ble_msgFromBLEApplet_true_Dongle connected successfully + ble_enablestethoble_2
  // ==================================================================================

  // Set video consultation flag based on consultation type
  private initializeVideoConsultationStatus(): void {
    if (!this.isLocalConsultation) {
      this.isVideoConsultationActive = true;
    } else {
      this.isVideoConsultationActive = false;
    }
  }

  // Initialize doctor control system for video consultations only
  private async initializeDoctorControlSystem(): Promise<void> {
    this.initializeUserType();

    if (this.isLocalConsultation) {
      return;
    }

    if (this.currentUserType !== 'Doctor') {
      return;
    }

    try {
      const consultationId = localStorage.getItem('consultationId');
      if (!consultationId) {
        return;
      }

      // Connect using centralized service (will reuse existing connection if available)
      const connected = await this.nullWebsocketService.connect(consultationId);

      if (connected) {
        // Subscribe to video consultation status changes
        this.nullWebsocketService.videoConsultationStatus$.subscribe((isActive: boolean) => {
          this.isVideoConsultationActive = isActive;
        });

        // Subscribe to null websocket messages (including nurse BLE messages)
        this.nullWebsocketService.messages$.subscribe((message: any) => {
          this.handleNullWebsocketMessage(message);
        });
      }

    } catch (error) {
      // Silent fail for optional video consultation feature
    }
  }

  // Extract user type from login response
  private initializeUserType(): void {
    try {
      const loginResponseRaw = localStorage.getItem('LOGIN_RESPONSE');
      if (loginResponseRaw) {
        const loginResponse = JSON.parse(loginResponseRaw);
        this.currentUserType = loginResponse.commondetail?.usertype || '';
      }
    } catch (error) {
      this.currentUserType = '';
    }
  }

  // ==================================================================================
  // NURSE-SIDE STETHOSCOPE READING IMPLEMENTATION
  // ==================================================================================
  // Purpose: Handle doctor's stethoscope reading requests and send data back to doctor
  // Flow: Doctor sends message → Nurse starts reading → Nurse sends data to doctor
  // ==================================================================================

  // Initialize nurse-side handling for video consultations only
  private async initializeNurseSideStethoscopeHandling(): Promise<void> {
    if (this.isLocalConsultation) {
      return;
    }

    if (this.currentUserType !== 'Nurse') {
      return;
    }

    try {
      const consultationId = localStorage.getItem('consultationId');
      if (!consultationId) {
        return;
      }

      // Connect to centralized nullwebsocket service
      const connected = await this.nullWebsocketService.connect(consultationId);

      if (connected) {
        // Subscribe to video consultation status changes for nurse
        this.nullWebsocketService.videoConsultationStatus$.subscribe((isActive: boolean) => {
          this.isVideoConsultationActive = isActive;
        });

        // Subscribe to incoming messages from doctor
        this.nullWebsocketService.messages$.subscribe((message: any) => {
          this.handleDoctorStethoscopeMessage(message);
        });
      }

    } catch (error) {
      // Silent fail for optional video consultation feature
    }
  }

  // Process incoming video consultation messages
  private handleNullWebsocketMessage(message: any): void {
    try {
      const messageText = message?.message || message;

      // Handle nurse BLE status message for video consultation doctor side
      if (messageText === 'ble_msgFromBLEApplet_true_Dongle connected successfully._2' &&
        this.isVideoConsultationActive && this.currentUserType === 'Doctor') {
        this.bleConnectionStatus = 'connected';
        this.bleConnectionMessage = 'BLE USB Dongle Connected (Nurse Side)';
        this.isDongleConnected = true;
      }
      // Handle doctor control messages for nurse side
      else if (this.isVideoConsultationActive && this.currentUserType === 'Nurse') {
        this.handleDoctorControlMessages(messageText);
      }
      // Handle other messages
      else {
        this.handleDoctorStethoscopeMessage(message);
      }

    } catch (error) {
      // Silent error handling for video consultation messages
    }
  }

  // Process doctor control messages on nurse side
  private handleDoctorControlMessages(messageText: string): void {
    // Handle dongle connection message from doctor
    if (messageText === 'ble_msgFromBLEApplet_true_Dongle connected successfully') {
      // Doctor is telling nurse that dongle should be connected;
    }
    // Handle enable stethoscope message
    else if (messageText === 'ble_enablestethoble_1') {
      console.log('🔧 [PARAMETERS] Doctor enabled stethoscope on nurse side');
    }
    // Handle other device control messages
    else {
      this.handleDoctorStethoscopeMessage({ message: messageText });
    }
  }

  /**
   * 📨 HANDLE DOCTOR STETHOSCOPE MESSAGE - Process incoming messages from doctor
   * Listens for: {"message":"stethopos_true_1_1_null"}
   * Action: Start stethoscope reading and send data back to doctor
   */
  private handleDoctorStethoscopeMessage(message: any): void {
    try {
      const messageText = message?.message || message;
      console.log('📨 [PARAMETERS] Processing doctor message:', messageText);

      // Handle stethoscope reading request
      if (messageText === 'stethopos_true_1_1_null') {
        console.log('🩺 [PARAMETERS] Doctor requested stethoscope reading - starting nurse-side reading');
        // this.startStethoscopeReading(); // COMMENTED - Use real stethoscope-device component
      }
      // Handle other doctor messages if needed
      else if (messageText === 'stethopos_stop') {
        console.log('🛑 [PARAMETERS] Doctor requested stop stethoscope reading');
        // this.stopStethoscopeReading(); // COMMENTED - Use real stethoscope-device component
      }
      // Handle SpO2 manual entry request from doctor
      else if (messageText === 'open_spo2_manual') {
        console.log('🩺 [PARAMETERS] Doctor requested SpO2 manual entry - opening nurse-side dialog');
        this.openPulseOximeterManual();
      }    // Handle SPO2 device request from doctor
      else if (messageText === 'ble_spo2_start') {
        console.log('🩺 [PARAMETERS] Doctor requested SPO2 device - starting nurse-side device');
        this.handleVideoConsultationSpo2Device();
      }
        else if (messageText === 'open_Bp_manual') {
        console.log('🩺 [PARAMETERS] Doctor requested BP manual entry - opening nurse-side dialog');
        this.openBloodPressureComponent();
      }
      else if (messageText === 'open_spiro_manual') {
        console.log('🩺 [PARAMETERS] Doctor requested Spiro manual entry - opening nurse-side dialog');
        this.openSpirometerManualComponent();
      }
          else if (messageText === 'open_temp_manual') {
        console.log('🩺 [PARAMETERS] Doctor requested temperature manual entry - opening nurse-side dialog');
        this.openTemperatureManualComponent();
 
      // Handle SPO2 device request from doctor
   
      } else if (messageText === 'ble_BP_start') {
        console.log('🩸 [PARAMETERS] Doctor requested BP device - starting nurse-side device');
        // if (!this.isBpDialogOpen && this.dialog.openDialogs.length === 0) {
        // this.openBloodPressure('BloodPressure'); 
        this.handleVideoConsultationBpDevice();
        // }
      }



    } catch (error) {
      console.error('❌ [PARAMETERS] Error handling doctor stethoscope message:', error);
    }
}


  /**
   *  HANDLE DONGLE CONNECTION - Main method called when dongle connects
   * Handles dongle connection for both local and video consultation modes
   */
  private handleDongleConnection(): void {
    console.log('🔧 [PARAMETERS] Dongle connected - handling for', this.usertype, 'in', this.isVideoConsultationActive ? 'video' : 'local', 'consultation');

    // For video consultation doctor side
    if (this.isVideoConsultationActive && this.currentUserType === 'Doctor') {
      this.handleDoctorDongleConnection();
    }

    // For video consultation nurse side
    if (this.isVideoConsultationActive && this.currentUserType === 'Nurse') {
      console.log('🔧 [PARAMETERS] Nurse dongle connected in video consultation');
      // Nurse side dongle connection is handled in sendNurseBleDongleStatus()
    }

    // For local consultation (both doctor and nurse)
    if (!this.isVideoConsultationActive) {
      console.log('🔧 [PARAMETERS] Local consultation dongle connected');
      // Local consultation handles dongle connection through BLE WebSocket
    }
  }

  /**
   * 🔧 HANDLE DOCTOR DONGLE CONNECTION - Sends messages to nurse in video consultation
   */
  private handleDoctorDongleConnection(): void {
    if (!this.isDongleConnected) {
      console.log('⚠️ [PARAMETERS] Dongle not connected - skipping doctor dongle handling');
      return;
    }

    // Prevent duplicate message sending
    if (this.dongleMessagesAlreadySent) {
      console.log('⚠️ [PARAMETERS] Dongle messages already sent - skipping duplicate');
      return;
    }

    console.log('🔧 [PARAMETERS] Doctor dongle connected - sending control messages to nurse');
    this.dongleMessagesAlreadySent = true;

    try {
      // Send first message: Dongle connection confirmation
      this.sendNullWebSocketMessage('ble_msgFromBLEApplet_true_Dongle connected successfully');
      console.log('📤 [PARAMETERS] Sent message 1: ble_msgFromBLEApplet_true_Dongle connected successfully');

      // Send second message: Enable stethoscope
      setTimeout(() => {
        this.sendNullWebSocketMessage('ble_enablestethoble_1');
        console.log('📤 [PARAMETERS] Sent message 2: ble_enablestethoble_1');
      }, 100); // Small delay between messages

    } catch (error) {
      console.error('❌ [PARAMETERS] Error sending doctor dongle connection messages:', error);
    }
  }

  /**
   * 🔧 SEND NURSE BLE DONGLE STATUS - Sends dongle status from nurse to doctor
   */
  private sendNurseBleDongleStatus(): void {
    if (!this.isVideoConsultationActive) {
      console.log('🔍 [PARAMETERS] Not in video consultation - skipping nurse BLE status');
      return;
    }

    try {
      // Send dongle connected message from nurse to doctor
      this.sendNullWebSocketMessage('ble_msgFromBLEApplet_true_Dongle connected successfully._2');
      console.log('📤 [PARAMETERS] Nurse sent BLE dongle status to doctor');
    } catch (error) {
      console.error('❌ [PARAMETERS] Error sending nurse BLE dongle status:', error);
    }
  }

  // Device message configuration
  private deviceMessages: { [key: string]: { start: string; close?: string; reading?: string } } = {
    'stethoscope': { start: 'ble_stetho_start', close: 'ble_close' },
    'fetaldopler': { start: 'ble_fetalDopler_start', close: 'ble_close' },
    'electrocardiogram': { start: 'ble_ecg_start', close: 'ble_close' },
    'spo2': { start: 'ble_spo2_start', close: 'ble_close' },
    'temperature': { start: 'ble_temp_start', close: 'ble_close' },
    'bloodpressure': { start: 'ble_bp_start', close: 'ble_close' },
    'hemoglobin': { start: 'ble_hb_start', close: 'ble_close' },
    'glucose': { start: 'ble_glucose_start', close: 'ble_close' },
    'spirometer': { start: 'ble_spiro_start', close: 'ble_close' },
    'mecginterpretation': { start: 'ble_mecginterpretation_start', close: 'ble_close' },
    'pecginterpretation': { start: 'ble_pecginterpretation_start', close: 'ble_close' },
  };

  private deviceStartFlags: { [key: string]: boolean } = {};

  /**
   * 🩺 REUSABLE DEVICE START MESSAGE - Works for all devices
   * Sends device-specific start message to nurse
   */
  private sendDeviceStartMessage(deviceKey: string): void {
    if (this.currentUserType !== 'Doctor') return;
    if (!this.isVideoConsultationActive) return;
console.log("DEVICE KEY:", deviceKey);
    const deviceConfig = this.deviceMessages[deviceKey.toLowerCase()];
    if (!deviceConfig) {
      console.warn(`⚠️ [PARAMETERS] No configuration found for device: ${deviceKey}`);
      return;
    }

    // Prevent duplicate messages
    if (this.deviceStartFlags[deviceKey]) {
      console.log(`⚠️ [PARAMETERS] ${deviceKey} start already sent - skipping duplicate`);
      return;
    }

    try {
      // Send start message
      this.sendNullWebSocketMessage(deviceConfig.start);

      this.deviceStartFlags[deviceKey] = true;
      console.log(`🩺 [PARAMETERS] Doctor clicked ${deviceKey} - sent ${deviceConfig.start} to nurse`);
    } catch (error) {
      console.error(`❌ [PARAMETERS] Error sending ${deviceKey} start message:`, error);
    }
  }

  /**
   * 🔒 REUSABLE DEVICE CLOSE MESSAGE - Works for all devices
   * Sends device-specific close message to nurse
   */
  private sendDeviceCloseMessage(deviceKey: string): void {
    if (this.currentUserType !== 'Doctor') return;
    if (!this.isVideoConsultationActive) return;

    const deviceConfig = this.deviceMessages[deviceKey.toLowerCase()];
    if (!deviceConfig?.close) return;

    try {
      // Send stop reading message first (for stethoscope)
      if (deviceKey.toLowerCase() === 'stethoscope') {
        this.sendNullWebSocketMessage('stethopos_stop');
      }

      // Send close message
      setTimeout(() => {
        this.sendNullWebSocketMessage(deviceConfig.close!);
      }, 100);

      this.deviceStartFlags[deviceKey] = false;
      console.log(`🔒 [PARAMETERS] Doctor closed ${deviceKey} - sent close message to nurse`);
    } catch (error) {
      console.error(`❌ [PARAMETERS] Error sending ${deviceKey} close message:`, error);
    }
  }

  private handleVideoConsultationSpo2Device(): void {
      console.error("function called");

    if (!this.isVideoConsultationActive || this.currentUserType !== 'Nurse') return;
    if (this.isSpo2DialogOpen || this.dialog.openDialogs.length > 0) return;
    console.log('🩺 [NURSE] Starting spo2 device for doctor request');

    // try {
      // Start BLE scan for SPO2 device
      this.WebsocketsService.sendBleMessage("startScanFromHtml~50");
let key = "PulseOximeter";
    this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);

      if (this.valSubscription6) {
        this.valSubscription6.unsubscribe();
      }

    //   this.valSubscription6 = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {
    //     if (data === "errorLableUpdate~start scan status : Success!") {
    //       // Scan started successfully
    //     } else if (data === "errorLableUpdate~SPO2Sensor connected successfully.") {
    //       // Device connected
    //     } else if (data === "SensorConnected~SPO2Sensor~50") {
    //       // Open SPO2 dialog for nurse
    //       if (!this.isSpo2DialogOpen) {
    //         this.isSpo2DialogOpen = true;
    //         const dialogRef = this.dialog.open(Spo2DevicePage, {
    //           panelClass: 'spo2-dialog-panel',
    //           width: 'auto',
    //           height: 'auto',
    //           disableClose: true,
    //           data: { api: 'withoutApiCalling' }
    //         });

    //         dialogRef.afterClosed().subscribe((result: any) => {
    //           this.isSpo2DialogOpen = false;
    //           this.WebsocketsService.sendBleMessage("ble_close");

    //           if (this.valSubscription6) {
    //             this.valSubscription6.unsubscribe();
    //             this.valSubscription6 = null;
    //           }

    //           // Send result back to doctor if needed
    //           if (result) {
    //             this.sendNullWebSocketMessage(`spo2_result_${JSON.stringify(result)}`);
    //           }
    //         });
    //       }
    //     }
    //   });
    // // } catch (error) {
    // //   console.error('❌ [PARAMETERS] Error in video consultation SPO2 device:', error);
    // // }

    this.valSubscription6 = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {
      console.log("checking",data);
      
      if (data === "SensorConnected~SPO2Sensor~50" && !this.isSpo2DialogOpen && this.dialog.openDialogs.length === 0) {
        this.stopSnackbarReminder(key);
        this.isSpo2DialogOpen = true;

        const dialogRef = this.dialog.open(Spo2DevicePage, {
          panelClass: 'spo2-dialog-panel',
          width: 'auto',
          height: 'auto',
          disableClose: true,
          data: { api: 'withoutApiCalling' }
        });

        dialogRef.afterClosed().subscribe(() => {
          this.isSpo2DialogOpen = false;
          this.WebsocketsService.sendBleMessage("ble_close");
          if (this.valSubscription6) {
            this.valSubscription6.unsubscribe();
            this.valSubscription6 = null;
          }
        });
      }
    });
  }
  private handleVideoConsultationBpDevice(): void {
    if (!this.isVideoConsultationActive || this.currentUserType !== 'Nurse') return;
    if (this.isBpDialogOpen || this.dialog.openDialogs.length > 0) return;

    console.log('🩺 [NURSE] Starting bp device for doctor request');
    this.WebsocketsService.sendBleMessage("startScanFromHtml~30");
    let key = "BloodPressure";
    this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
    if (this.valSubscription6) {
      this.valSubscription6.unsubscribe();
    }

    this.valSubscription6 = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {
      if (data === "SensorConnected~BPSensor~30" && !this.isBpDialogOpen && this.dialog.openDialogs.length === 0) {
        this.stopSnackbarReminder(key);
        this.isBpDialogOpen = true;

        const dialogRef = this.dialog.open(BloodPressureJettyPage, {
          panelClass: 'spo2-dialog-panel',
          width: "1000px",
          height: "450px",
          disableClose: true,
          data: { api: 'withoutApiCalling' }
        });

        dialogRef.afterClosed().subscribe(() => {
          this.isSpo2DialogOpen = false;
          this.WebsocketsService.sendBleMessage("ble_close");
          if (this.valSubscription6) {
            this.valSubscription6.unsubscribe();
            this.valSubscription6 = null;
          }
        });
      }
    });
  }



  // Legacy methods for backward compatibility
  private sendStethoscopeStartMessage(): void { this.sendDeviceStartMessage('stethoscope'); }
  private sendStethoscopeCloseMessage(): void { this.sendDeviceCloseMessage('stethoscope'); }
  private sendFetalDopplerStartMessage(): void { this.sendDeviceStartMessage('fetaldopler'); }

  /**
   *  SEND NULLWEBSOCKET MESSAGE - Sends message via nullwebsocket
   * Core method for video consultation communication
   */
  private sendNullWebSocketMessage(message: string): void {
    if (!this.isVideoConsultationActive) {
      console.log('🔍 [PARAMETERS] Not in video consultation - skipping nullwebsocket message');
      return;
    }

    const success = this.nullWebsocketService.sendMessage(message);
    if (success) {
      console.log(`📤 [PARAMETERS] Sent nullwebsocket message via centralized service: ${message}`);
    } else {
      console.error('❌ [PARAMETERS] Failed to send nullwebsocket message via centralized service');
    }
  }
// this block added to fix finish status issue 
  private ensureBleConnectionAndInit(): void {
    const checkAndSend = () => {
      const bleSocket = this.WebsocketsService.getBleSocketInstance();
      
      if (bleSocket?.readyState === WebSocket.OPEN) {
        this.WebsocketsService.sendBleMessage("BleAppletInit");
      } else {
        setTimeout(() => {
          this.WebsocketsService.sendBleMessage("BleAppletInit");
        }, 500);
      }
    };
    
    checkAndSend();
  }

  /**
   * 🔌 DISCONNECT DOCTOR WEBSOCKET - Cleans up nullwebsocket connection
   * Called when video consultation ends
   */
  private disconnectDoctorWebSocket(): void {
    try {
      // Note: Don't disconnect the centralized service here as other pages might be using it
      // The service will handle cleanup automatically when all pages are destroyed
      this.isVideoConsultationActive = false;
      console.log('🔌 [PARAMETERS] Parameters page cleanup - video consultation status reset');
    } catch (error) {
      console.error('❌ [PARAMETERS] Error during parameters page cleanup:', error);
    }
  }


  async openEcgInterpetationComponentDevice() {
    // 1️⃣ Check device status first
    const key = "ECGInterpretation";
    const status = this.getCardClass(key);

    // // Stop any previous device reminder immediately
    // if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
    //   this.stopSnackbarReminder(this.activeSnackbarDevice);
    // }
    // if (status === 'disconnected' || status === 'completed'  || status === 'manual') {
    //   this.startSnackbarReminder(`Please switch on ${key} Sensor`, key);
    //   // 👉 still continue, because once the sensor turns on, Jetty will connect
    // }
    let manual = this.manualEntryParameterBtn.find(res => { return res === key });

    if (manual) {

      // 🔹 MANUAL MODE: No BLE scan needed – directly open manual dialog
      console.log("Opening manual ECG Interpretation (no device scan)");

      this.manualEcgInterpretationOpen = true;
      // Update runtime state to 'manual' (but respect issdkjarReady via getCardClass)
      this.deviceConnectionState['ECGInterpretation'] = 'manual';
      this.stopSnackbarReminder(key);
     const dialogConfig = {
  ...this.deviceConfig['mecginterpretation'].dialogConfig,
  panelClass: this.currentUserType === 'Doctor'
    ? 'ecgi-manual-dialog-panel'
    : 'ecg-dialog-panel'
};

this.openDeviceComponent(
  'MECGinterpretation',
  this.deviceConfig['mecginterpretation'].component,
  dialogConfig
);


  //       if (this.valSubscription) {
  //         this.valSubscription.unsubscribe();
  //       }

  //       this.valSubscription = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {
  //         if (!data) return;

  //         const parts = data.split('~');
  //         const eventType = parts[0];
  //         const message = parts[1];

  //         if (eventType === 'errorLableUpdate' && message === 'ECGSensor connected successfully.') {

  //           console.log(' ECG Intepretation Sensor Connected — opening ECG dialog');
  //           // 🔹 Update the card state to "connected"
  //           const device = this.enabledParameterBtn.find(
  //             d => d.name.toLowerCase() === key.toLowerCase()
  //           );
  //           if (device) {
  //             device.isActive = true;  // mark as active
  //             device.manual = false;   // ensure it's not treated as manual
  //           }

  //           this.stopSnackbarReminder(key);
  //           this.deviceConnectionState['ECGInterpretation'] = "connected";
  //           const panelClassName =
  // this.currentUserType === 'Doctor'
  //   ? 'ecgi-manual-dialog-panel'
  //   : 'ecg-dialog-panel';

  //           const dialogRef = this.dialog.open(EcgInterpretationManualJettyComponent, {
  //              panelClass: panelClassName,
  //             disableClose: true,
  //             data: {
  //               api: 'withoutApiCalling'
  //             }
  //           });

  //           dialogRef.afterClosed().subscribe((result: string) => {
  //             console.log(' ECG Dialog closed:', result);
  //             if (result === 'closedByUser') {
  //               this.deviceConnectionState['ECGInterpretation'] = 'disconnected';
  //             } else {
  //               // ❌ No save → reset based on Jetty
  //               if (this.issdkjarReady) {
  //                 this.deviceConnectionState['ECGInterpretation'] = 'manual'; // Still manual if Jetty running
  //               } else {
  //                 this.deviceConnectionState['ECGInterpretation'] = 'disconnected'; // Back to disconnected if Jetty off
  //               }

  //             }

  //           });

  //           // this.valSubscription.unsubscribe();
  //         }
  //       });

  //       this.WebsocketsService.sendBleMessage('startScanFromHtml~102~true');

  //     } catch (error) {
  //       if (this.issdkjarReady) {
  //         // Jetty running → disconnected
  //         this.deviceConnectionState['ECGInterpretation'] = 'disconnected';
  //       } else {
  //         // Jetty not running → disabled
  //         this.deviceConnectionState['ECGInterpretation'] = 'disabled';
  //       }
  //       console.error(' Error in openEcgComponentDevice:', error);
  //     }
    } else {
      console.log("openEcgParameterComponent", manual);
      this.openEcgParameterComponent();
    }


  }
 
async openEcgParameterComponent(){
   const key="ECGInterpretation";
  const status = this.getCardClass(key);

  // // Stop any previous device reminder immediately
  // if (this.activeSnackbarDevice && this.activeSnackbarDevice !== key) {
  //   this.stopSnackbarReminder(this.activeSnackbarDevice);
  // }
  //  if (status === 'disconnected' || status === 'completed') {
  //   this.startSnackbarReminder(`Please switch on ${key} Sensor`,key);
  //   // 👉 still continue, because once the sensor turns on, Jetty will connect
  // }
     const config = this.deviceConfig['pecginterpretation'];
    this.openDeviceComponent('PECGinterpretation', config.component, config.dialogConfig);
  // try {

  //        if (!this.isSubscribedToBle) {
  //     this.isSubscribedToBle = true;

  //     this.valSubscription = this.WebsocketsService.bleValueObs$.subscribe((data: string) => {
  //       if (!data) return;

  //       const [eventType, message] = data.split("~");

  //       if (
  //         eventType === "errorLableUpdate" &&
  //         message === "ECGSensor connected successfully." &&
  //         !this.isEcgDialogOpen
  //       ) {
  //         console.log("ECG Interpretation Sensor Connected — opening ECG dialog");

  //         this.isEcgDialogOpen = true;

  //         const device = this.enabledParameterBtn.find(
  //           (d) => d.name.toLowerCase() === key.toLowerCase()
  //         );
  //         if (device) {
  //           device.isActive = true;
  //           device.manual = false;
  //         }

  //         this.stopSnackbarReminder(key);
  //         this.deviceConnectionState["ECGInterpretation"] = "connected";

  //         const dialogRef = this.dialog.open(EcgInterpretationJettyDeviceComponent, {
  //           panelClass: "ecg-dialog-panel",
  //           disableClose: true,
  //           data: { api: "withoutApiCalling" },
  //         });

  //         dialogRef.afterClosed().subscribe((result: string) => {
  //           console.log("ECG Dialog closed:", result);
  //           this.isEcgDialogOpen = false;

  //           if (result === "closedByUser") {
  //             if (this.issdkjarReady) {
  //               this.deviceConnectionState["ECGInterpretation"] = "manual";
  //             } else {
  //               this.deviceConnectionState["ECGInterpretation"] = "disabled";
  //             }
  //           }
  //         });
  //       }
  //     });
  //   }

  //   // ✅ Only send scan message once
  //   this.WebsocketsService.sendBleMessage("startScanFromHtml~102~true");
  // } catch (error) {
  //   this.deviceConnectionState["ECGInterpretation"] = this.issdkjarReady
  //     ? "manual"
  //     : "disabled";
  //   console.error("Error in openEcgInterpetationComponentDevice:", error);
  // }
  }



}
