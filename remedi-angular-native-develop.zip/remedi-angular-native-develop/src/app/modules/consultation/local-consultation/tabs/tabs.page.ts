import { Component, OnInit, ChangeDetectorRef, NgZone, OnDestroy } from '@angular/core';
import { PatientHistoryPage } from '../patient-history/patient-history.page';
import { DiagnosisPage } from '../diagnosis/diagnosis.page';
import { ComplaintsPage } from '../complaints/complaints.page';
import { MedicinesPage } from '../medicines/medicines.page';
import { InterventionPage } from '../intervention/intervention.page';
import { InvestigationsPage } from '../investigations/investigations.page';
import { CounselingPage } from '../counseling/counseling.page';
import { ReferralsPage } from '../referrals/referrals.page';
import { PastrecordsPage } from '../pastrecords/pastrecords.page';
import { CommonModule } from '@angular/common';
import { ParametersPage } from '../parameters/parameters.page';

import { WebsocketsService } from '../../../../core/services/websocket.service';

import { NullWebsocketService } from '../../../../core/services/null-websocket.service';




@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.page.html',
  styleUrls: ['./tabs.page.scss'],
  standalone: true,
  imports: [PatientHistoryPage, CommonModule,  ComplaintsPage, DiagnosisPage, MedicinesPage, InterventionPage, InvestigationsPage, CounselingPage, ReferralsPage, PastrecordsPage, ParametersPage]
})
export class TabsPage implements OnInit, OnDestroy {


  // ==================================================================================
  // CENTRALIZED DOCTOR CONTROL SYSTEM - TABS PAGE
  // ==================================================================================
  // Purpose: Use centralized nullwebsocket service for tab switching control
  // Benefits: Single connection shared across all pages, no duplicate connections
  // Pattern: Doctor clicks parameters tab → sends Kit_Start → nurse receives response
  // Communication: Uses centralized nullwebsocket service for doctor-nurse messaging
  // ==================================================================================

  currentUserType: string = '';                    // Store user type (Doctor/Nurse)
  usertype: string = '';                           // User type for template access
  private isVideoConsultationActive: boolean = false;     // Flag to enable doctor control
  private isParametersTabActive: boolean = false;         // Flag to track if parameters tab is active
  showOnlyParametersTab: boolean = false;                 // Flag to show only parameters tab for nurse
  isVideoConsultation: boolean = false;                   // Flag to track if in video consultation mode

  // Add missing properties for diagnosis tab
  isProvisional: boolean = false;
  selectedDiagnosis: string = '';
  diagnoses: { code: string; name: string; provisional: boolean }[] = [
    { code: 'A42.1', name: 'Abdominal Actinomycosis', provisional: true },
    { code: 'A19.0', name: 'Acute Miliary Tuberculosis Of A Single Specified Site', provisional: true },
    { code: 'J00', name: 'Acute Nasopharyngitis [Common Cold]', provisional: false },
    { code: 'Y45.5', name: '4-Aminophenol Derivatives', provisional: false }
  ];
  isLocalConsultation: boolean = false;

  addDiagnosis() {
    if (!this.selectedDiagnosis.trim()) {
      return;
    }
    const newDiagnosis = {
      code: this.generateICDCode(),
      name: this.selectedDiagnosis,
      provisional: this.isProvisional
    };
    this.diagnoses.push(newDiagnosis);
    this.selectedDiagnosis = '';
    this.isProvisional = false;
  }

  generateICDCode(): string {
    const code = 'X' + Math.floor(100 + Math.random() * 900);
    return code;
  }


 selectedTab: string = 'patientHistory';
 isMobileFocusMode: boolean = false;


 constructor(
  private ngZone: NgZone,
  private cdRef: ChangeDetectorRef,

  private websocketsService: WebsocketsService,

  private nullWebsocketService: NullWebsocketService

) {}

  ngOnInit() {
    // Optional: Initialization logic here
    const flag = localStorage.getItem('isLocalConsultation') === 'true';
    console.log('Flag from storage:', flag);
    this.isLocalConsultation = flag;

    // Initialize video consultation flag
    this.initializeVideoConsultationFlag();

    // Initialize centralized doctor control functionality
    this.initializeUserType();
    this.initializeCentralizedNullWebSocket();

  }
  ngOnDestroy(): void {
    this.exitMobileFocusMode();

    // Disconnect WebSocket on component destroy
    this.disconnectDoctorWebSocket();

  }

  private isMobileViewport(): boolean {
    try {
      return window.innerWidth <= 500 || window.matchMedia('(max-width: 500px)').matches;
    } catch {
      return false;
    }
  }

  private enterMobileFocusMode(): void {
    if (this.isMobileFocusMode) return;
    this.isMobileFocusMode = true;
    document.body.classList.add('mobile-focus-mode');
  }

  private exitMobileFocusMode(): void {
    if (!this.isMobileFocusMode) return;
    this.isMobileFocusMode = false;
    document.body.classList.remove('mobile-focus-mode');
  }

  onExitMobileFocus(): void {
    this.exitMobileFocusMode();
  }

  getTabDisplayName(tabKey: string): string {
    const tabNames: { [key: string]: string } = {
      'patientHistory': 'Patient History',
      'complaints': 'Complaints',
      'pastRecords': 'Past Records',
      'parameters': 'Parameters',
      'diagnosis': 'Diagnosis',
      'medicines': 'Medicines',
      'intervention': 'Intervention',
      'investigations': 'Investigations',
      'counseling': 'Counseling',
      'referrals': 'Referrals'
    };

    return tabNames[tabKey] || 'Back to Tabs';
  }





  switchTab(tab: string) {
  this.ngZone.run(() => {

    // ==================================================================================
    // NURSE TAB CONTROL - Prevent tab switching when only parameters tab should show
    // ==================================================================================
    if (this.currentUserType === 'Nurse' && this.isVideoConsultation && this.isVideoConsultationActive && this.showOnlyParametersTab && tab !== 'parameters') {
      console.log('⚠️ [TABS] Only parameters tab available for nurse during kit session');
      return;
    }

    // ==================================================================================
    // DOCTOR CONTROL LOGIC - TAB SWITCHING
    // ==================================================================================
    // Purpose: Handle doctor control messages when switching tabs
    // Kit_Start: When doctor clicks parameters tab → send Kit_Start to nurse
    // Kit_Stop: When doctor switches from parameters to other tab → send Kit_Stop to nurse
    // Safety: Only works when user is Doctor and video consultation is active
    // ==================================================================================

    // Only send doctor control messages in video consultation mode
    if (this.currentUserType === 'Doctor' && this.isVideoConsultation) {
      // Send Kit_Stop when switching away from parameters tab
      if (this.selectedTab === 'parameters' && tab !== 'parameters') {
        this.sendKitStopMessage();
      }

      // Send Kit_Start when switching to parameters tab
      if (tab === 'parameters') {
        this.sendKitStartMessage();
      }
    }

    this.selectedTab = tab;
    this.cdRef.detectChanges();

    // If on mobile, enter focus mode where only tab-content is visible
    if (this.isMobileViewport()) {
      this.enterMobileFocusMode();
    }

    // Update active class on buttons
    setTimeout(() => {
      const buttons = document.querySelectorAll('.button-native');
      buttons.forEach(btn => btn.classList.remove('active'));

      const activeButton = document.querySelector(`[onclick*="${tab}"]`) ||
                          Array.from(buttons).find(btn =>
                            btn.textContent?.toLowerCase().replace(/\s+/g, '') ===
                            tab.toLowerCase().replace(/([A-Z])/g, ' $1').trim().replace(/\s+/g, '')
                          );

      if (activeButton) {
        activeButton.classList.add('active');
      }
    }, 10);
  });
}




  // --------------------------







  // ==================================================================================
  // DOCTOR CONTROL IMPLEMENTATION METHODS
  // ==================================================================================
  // Purpose: Handle doctor-nurse communication via nullwebsocket for parameters tab
  // Pattern: Matches doctor-dashboard.page.ts implementation for consistency
  // ==================================================================================

  /**
   * Initialize user type detection from session storage
   */
  private initializeUserType(): void {
    try {
      const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
      this.currentUserType = loginResponse.commondetail?.usertype || '';
      this.usertype = this.currentUserType; // For template access
      console.log('🔍 [TABS] Current user type:', this.currentUserType);
    } catch (error) {
      console.error('❌ [TABS] Error parsing LOGIN_RESPONSE:', error);
      this.currentUserType = '';
      this.usertype = '';
    }
  }

  /**
   * Initialize video consultation flag from localStorage
   */
  private initializeVideoConsultationFlag(): void {
    // Check if we're in video consultation mode
    const consultationId = localStorage.getItem('consultationId');
    const isLocalConsultation = localStorage.getItem('isLocalConsultation') === 'true';
    
    // If we have consultationId and NOT in local consultation, we're in video consultation
    this.isVideoConsultation = !!(consultationId && !isLocalConsultation);
    
    console.log('🔍 [TABS] Video consultation flag initialized:', this.isVideoConsultation);
    console.log('🔍 [TABS] ConsultationId:', consultationId, 'IsLocal:', isLocalConsultation);
  }

  /**
   * Determine if parameters tab should be visible based on user type and consultation mode
   */
  shouldShowParametersTab(): boolean {
    // Doctor: Always show parameters tab (both local and video consultation)
    if (this.currentUserType === 'Doctor') {
      return true;
    }
    
    // Nurse: Show parameters tab in different scenarios
    if (this.currentUserType === 'Nurse') {
      // Local consultation: Always show
      if (this.isLocalConsultation) {
        return true;
      }
      
      // Video consultation: Show based on doctor control
      if (this.isVideoConsultation) {
        // Before connecting with doctor OR when doctor sends Kit_Start
        return !this.isVideoConsultationActive || this.isParametersTabActive;
      }
    }
    
    return false;
  }

  /**
   * Show all tabs for nurse when parameters session ends
   */
  enableTabs(): void {
    this.ngZone.run(() => {
      this.showOnlyParametersTab = false;
      this.isParametersTabActive = false;
      console.log(' [TABS] All tabs shown for nurse');
    });
  }

  /**
   * Show only parameters tab for nurse when Kit_Start is received
   */
  disableTabs(): void {
    this.ngZone.run(() => {
      this.showOnlyParametersTab = true;
      this.isParametersTabActive = true;
      this.selectedTab = 'parameters';
      console.log('🔒 [TABS] Only parameters tab shown for nurse');
    });
  }

  /**
   * Initialize centralized nullwebsocket connection for doctor control
   * ONLY for video consultations - local consultations use BLE WebSocket
   */
  private async initializeCentralizedNullWebSocket(): Promise<void> {
    // Only initialize for video consultations
    if (this.isLocalConsultation || !this.isVideoConsultation) {
      console.log('🔍 [TABS] Local consultation detected - skipping nullwebsocket initialization (using BLE WebSocket)');
      return;
    }

    // Initialize for both Doctor and Nurse in video consultation
    if (this.currentUserType !== 'Doctor' && this.currentUserType !== 'Nurse') {
      console.log('🔍 [TABS] User is neither Doctor nor Nurse, skipping nullwebsocket initialization');
      return;
    }

    try {
      const consultationId = localStorage.getItem('consultationId');
      if (!consultationId) {
        console.log('🔍 [TABS] No consultation ID found, skipping centralized nullwebsocket initialization');
        return;
      }

      console.log('🔌 [TABS] Video consultation - connecting to centralized nullwebsocket service');

      // Connect using centralized service (will reuse existing connection if available)
      const connected = await this.nullWebsocketService.connect(consultationId);

      if (connected) {
        // Subscribe to video consultation status changes
        this.nullWebsocketService.videoConsultationStatus$.subscribe((isActive: boolean) => {
          this.isVideoConsultationActive = isActive;
          console.log('🔄 [TABS] Video consultation status changed:', isActive);
          
          // Update video consultation flag when status changes
          if (isActive) {
            this.isVideoConsultation = true;
          }
        });

        // Subscribe to incoming messages
        this.nullWebsocketService.messages$.subscribe((message: any) => {
          if (message && this.isVideoConsultationActive) {
            if (this.currentUserType === 'Doctor') {
              this.handleNurseResponseMessage(message);
            } else if (this.currentUserType === 'Nurse') {
              this.handleDoctorMessage(message);
            }
          }
        });

        console.log('✅ [TABS] Connected to centralized nullwebsocket service successfully');
      } else {
        console.warn('⚠️ [TABS] Failed to connect to centralized nullwebsocket service');
      }

    } catch (error) {
      console.warn('⚠️ [TABS] Centralized nullwebsocket connection failed (non-blocking):', error);
    }
  }

  /**
   * Send message via centralized nullwebsocket service
   */
  private sendNullWebSocketMessage(message: string): void {
    const success = this.nullWebsocketService.sendMessage(message);
    if (success) {
      console.log(`📤 [TABS] Sent nullwebsocket message via centralized service: ${message}`);
    } else {
      console.error('❌ [TABS] Failed to send nullwebsocket message via centralized service');
    }
  }


  /**
   * Handle nurse response messages during video consultation
   */
  private handleNurseResponseMessage(message: any): void {
    const messageText = message?.message || message;
    console.log(`📨 [TABS] Nurse response: ${messageText}`);

    switch (messageText) {
      case 'ble_msgFromBLEApplet_true_Dongle connected successfully._2':
        console.log('✅ [TABS] Nurse confirmed kit connection - parameters tab activated successfully');
        break;

      case 'connectedBle':
        console.log('✅ [TABS] Nurse confirmed BLE connection');
        break;

      case 'kitstatus_1001':
        console.log('✅ [TABS] Nurse confirmed kit status');
        break;

      case 'error_stop scan status':
        console.log('✅ [TABS] Nurse confirmed kit stop - parameters tab deactivated successfully');
        break;

      case 'ble_enablestethoble_2':
        console.log('✅ [TABS] Nurse confirmed stethoscope enabled');
        break;

      default:
        console.log(`📨 [TABS] Unhandled nurse response: ${messageText}`);
        break;
    }
  }

  /**
   * Handle doctor messages for nurse side
   */
  private handleDoctorMessage(message: any): void {
    const messageText = message?.message || message;
    console.log(`📨 [TABS] Doctor message: ${messageText}`);

    switch (messageText) {
      case 'Kit_Start':
        console.log('🔧 [TABS] Received Kit_Start - activating parameters tab');
        this.disableTabs();
        break;

      case 'Kit_Stop':
        console.log('🛑 [TABS] Received Kit_Stop - deactivating parameters tab');
        this.enableTabs();
        break;

      default:
        console.log(`📨 [TABS] Unhandled doctor message: ${messageText}`);
        break;
    }
  }

  /**
   * 🔧 SEND KIT_START MESSAGE - Main method called when doctor clicks parameters tab
   * Sends: "Kit_Start" → Nurse shows parameters tab and switches to it
   * Expected Response: ble_msgFromBLEApplet_true_Dongle connected successfully._2
   */
  private sendKitStartMessage(): void {
    if (this.currentUserType !== 'Doctor') {
      console.warn('⚠️ [TABS] Cannot send Kit_Start - user is not Doctor');
      return;
    }

    if (!this.isVideoConsultation) {
      console.warn('⚠️ [TABS] Cannot send Kit_Start - not in video consultation mode');
      return;
    }

    try {
      this.sendNullWebSocketMessage('Kit_Start');
      console.log('🔧 [TABS] Doctor clicked parameters tab - sent Kit_Start to nurse');
      console.log('⏳ [TABS] Waiting for nurse response: ble_msgFromBLEApplet_true_Dongle connected successfully._2');
    } catch (error) {
      console.error('❌ [TABS] Error sending Kit_Start message:', error);
    }
  }

  /**
   * 🛑 SEND KIT_STOP MESSAGE - Called when doctor switches away from parameters tab
   * Sends: "Kit_Stop" → Nurse hides parameters tab and switches to consultation tab
   * Expected Response: error_stop scan status
   */
  private sendKitStopMessage(): void {
    if (this.currentUserType !== 'Doctor') {
      console.warn('⚠️ [TABS] Cannot send Kit_Stop - user is not Doctor');
      return;
    }

    if (!this.isVideoConsultation) {
      console.warn('⚠️ [TABS] Cannot send Kit_Stop - not in video consultation mode');
      return;
    }

    try {
      this.sendNullWebSocketMessage('Kit_Stop');
      console.log('🛑 [TABS] Doctor switched away from parameters tab - sent Kit_Stop to nurse');
      console.log('⏳ [TABS] Waiting for nurse response: error_stop scan status');
    } catch (error) {
      console.error('❌ [TABS] Error sending Kit_Stop message:', error);
    }
  }

  /**
   * Disconnect centralized nullwebsocket connection on component destroy
   */
  private disconnectDoctorWebSocket(): void {
    try {
      // Note: Don't disconnect the centralized service here as other pages might be using it
      // The service will handle cleanup automatically when all pages are destroyed
      this.isVideoConsultationActive = false;
      console.log('🔌 [TABS] Tabs page cleanup - video consultation status reset');
    } catch (error) {
      console.error('❌ [TABS] Error during tabs page cleanup:', error);
    }
  }


}
