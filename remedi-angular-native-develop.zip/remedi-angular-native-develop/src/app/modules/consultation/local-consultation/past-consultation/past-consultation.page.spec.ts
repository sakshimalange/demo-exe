import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PastConsultationPage } from './past-consultation.page';

describe('PastConsultationPage', () => {
  let component: PastConsultationPage;
  let fixture: ComponentFixture<PastConsultationPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PastConsultationPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
