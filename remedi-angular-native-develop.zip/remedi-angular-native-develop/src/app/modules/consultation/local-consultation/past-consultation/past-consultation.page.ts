import { Component, OnInit, Optional, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { WebsocketsService } from 'src/app/core/services/websocket.service';
import { PouchdbService } from 'src/app/core/services/pouchdb.service';
import { ApiService } from 'src/app/core/services/api.service';
import { ConstantService } from 'src/app/core/services/constant.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { NetworkService } from 'src/app/core/services/network.service';
import { NavController } from '@ionic/angular';
import { Spo2DevicePage } from 'src/app/modules/prms/ble-device/spo2-device/spo2-device.page';
import Highcharts from 'highcharts';
import Accessibility from 'highcharts/modules/accessibility';
import { EcgJettyDevicePage } from 'src/app/modules/prms/ble-device/ecg-jetty-device/ecg-jetty-device.page';
import { SpirometerJettyDevicePage } from 'src/app/modules/prms/ble-device/spirometer-jetty-device/spirometer-jetty-device.page';
import { PastpopfordisplayingImagesComponent } from '../pastpopfordisplaying-images/pastpopfordisplaying-images.component';
import { ViewreportPage } from '../viewreport/viewreport.page';
import { EcgInterpretationJettyDeviceComponent } from 'src/app/modules/prms/ble-device/ecg-interpretation-jetty-device/ecg-interpretation-jetty-device.component';
import { EcgInterpretationManualJettyComponent } from 'src/app/modules/prms/manual_entry/ecg-interpretation-manual-jetty/ecg-interpretation-manual-jetty.component';
import { ViewconsultationPage } from '../viewconsultation/viewconsultation.page';
import { PastImagesPreviewPage } from '../past-images-preview/past-images-preview.page';
import { FetalDopplerDevicePage } from 'src/app/modules/prms/ble-device/fetal-doppler-device/fetal-doppler-device.page';
import { StethoscopeDevicePage } from 'src/app/modules/prms/ble-device/stethoscope-device/stethoscope-device.page';

@Component({
  selector: 'app-past-consultation',
  templateUrl: './past-consultation.page.html',
  styleUrls: ['./past-consultation.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
})
export class PastConsultationPage implements OnInit {
  spo2Readings: { percentage: number; pulse: number; filename?: string; percentageData?: number }[] = [];
  spo2PercentageArray: number[] = [];
  temperatureReadings: { f: number; c: number }[] = [];



   glucoseReadings: {
    value: string;
    type: string;
    readingNumber: number;
    sequenceIndex: number;
    category: string;
  }[] = [];
  showGlucoseCard: boolean = false;

  // Rapid Test readings
  rapidTestReadings: {
    testName: string;
    testResult: string;
    testImage: string | null;
    patientId?: number;
    consultationId?: number;
  }[] = [];
  showRapidTestCard: boolean = false;

  // Urine Test readings
  urineTestReadings: {
    BLO: string[];
    GLU: string[];
    PRO: string[];
    URO: string[];
    SG: string[];
    pH: string[];
    BIL: string[];
    NIT: string[];
    KET: string[];
    LEU: string[];
    testimage: string[];
    stripType: string;
    patientId?: number;
    consultationId?: number;
  }[] = [];
  showUrineTestCard: boolean = false;

  patientInfo: any;
  consultationDetails: any;
  consultationImages: any;
  consultationData: any;
  isUrineTestTaken: string = '';
  noDataMessage: string = '';

  showSpo2Card: boolean = false;
  showTemperatureCard: boolean = false;
// ECG readings
ecgReadings: { reportName: string; pulseRate?: number; extra?: string;
   s3Url: string; consultationId: string; patientId: string;
 }[] = [];
showEcgCard: boolean = false;

// Spirometer readings
spiroReadings: {
  reportName: string;
  values: {
    fvc?: number;
    fev1?: number;
    fev1_fvc?: number;
    tv?: number;
    pef?: number;
    fet?: number;
    tlc?: number;
    fivc?: number;
    fef25?: number;
    fef50?: number;
    fef75?: number;
    fef25_75?: number;
    pif?: number;
    fev1percent?: number;
  };
  filePath?: string;
  s3FilePath?: string;
}[] = [];

showSpiroCard: boolean = false;

// Stethoscope readings
stethoReadings: {
  reportName: string;
  filePath?: string;
  s3FilePath?: string;
}[] = [];
showStethoCard: boolean = false;

// Fetal Doppler readings
fetalReadings: {
  reportName: string;
  filePath?: string;
  s3FilePath?: string;
  heartRate?: number;
  fullFileName?: string;
}[] = [];
showFetalCard: boolean = false;

hemoglobinReadings: { value: string; readingNumber: number }[] = [];
showHemoglobinCard: boolean = false;
hemoglobinNormalRange: string = '';

  spo2Index: number = 0;
bpReadings: { systolic: number; diastolic: number; pulse: number }[] = [];
showBPCard: boolean = false;
bpIndex: number = 0;
lipidReadings: {
  totalCholesterol: number;
  triglycerides: number;
  ldlFriedewald: number;
  ldlIranian?: number; // optional, as your API may not have it
  hdl: number;
  readingNumber: string;
}[] = [];

showLipidCard: boolean = false;
hba1cReadings: {
  HbA1c_eAG: number;
  HbA1c_per: number;
  HbA1c_mmol: number;
  readingNumber: string;
}[] = [];
showHba1cCard: boolean = false;

  consultationId: any;
  patientId: any;
  tokenRequest: any;
currentTab: string = 'readings'; // Default to 'readings' tab
  uploadedDocuments: any[] = []; 

 consultationIdv: string = '';
  patientIdv: string = '';
// ECG Interpretation Combined
allEcgReadings: {
  reportName: string;
  pulseRate?: number;
  s3Url: string;
  consultationId: string;
  patientId: string;
  isManual: boolean;
   showTooltip?: boolean;
hasAIReport?:boolean;
}[] = [];

showEcgiCard = false;
  sendataforpreview: any[] = [];

  constructor(
    private formBuilder: FormBuilder,
    private websocketsService: WebsocketsService,
    private pouchdbService: PouchdbService,
    private constantSvc: ConstantService,
    private dialog: MatDialog,
    private apiSvc: ApiService,
    private authService: AuthService,
    private networkService: NetworkService,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any,
    @Optional() private dialogRef: MatDialogRef<PastConsultationPage>,
    private navCtrl: NavController
  ) {}
// Lipid readings


ngOnInit() {
  const apiResponse = this.data.apiResponse;

  
    if (!apiResponse) {
      this.noDataMessage = 'No consultation data available';
      return;
    }
    this.consultationIdv = this.data?.consultationId || '';
    this.patientIdv = this.data?.patientId || apiResponse.patientInfo?.patientId || '';

    this.patientInfo = apiResponse.patientInfo;
    this.consultationDetails = apiResponse.consultationDetails;
    this.consultationImages = apiResponse.consultationImages;
    this.consultationData = apiResponse.data;
    this.isUrineTestTaken = apiResponse.isUrineTestTaken;
this.patientId = this.patientInfo?.patientId || 0;
  this.consultationId = this.consultationData?.consultationid || 0;
    this.tokenRequest = this.authService.getToken() || '';
  console.log('Patient ID:', this.patientId, 'Consultation ID:', this.consultationId);
    this.parseTemperature();
    this.parseSpo2();
    this.parseEcg();
    this.parseSpirometer();
    this.parseStethoscope();
    this.parseFetalDoppler();
      this.parseBP(); // Add this
   this.parseGlucose();
    this.parseRapidTest();
    this.parseUrineTest();
      this.parseLipid();
  this.parseHba1c();
    this.parseEcgInterpretations();
      this.parseUploadedDocuments();
  }

  /** ================== PARSING FUNCTIONS ================== **/

  private parseTemperature() {
    if (this.consultationData?.temperature?.length) {
      this.temperatureReadings = this.consultationData.temperature.map((val: string) => {
        const [tempF, tempC] = val.split(',').map((v) => v.trim());
        return { f: parseFloat(tempF), c: parseFloat(tempC) };
      });
    }
    console.log('Temperature Readings:', this.temperatureReadings);
  }
private parseLipid() {
  if (this.consultationData?.lipid?.length) {
    this.lipidReadings = this.consultationData.lipid.map((item: any) => ({
      totalCholesterol: parseFloat(item.total_cholesterol),
      triglycerides: parseFloat(item.triglycerides),
      ldlFriedewald: parseFloat(item.ldl_friedewald),
      ldlIranian: item.ldl_iranian ? parseFloat(item.ldl_iranian) : undefined,
      hdl: parseFloat(item.hdl_cholesterol),
      readingNumber: item.reading_number,
    }));
    console.log('Lipid Readings:', this.lipidReadings);
  }
}

private parseHba1c() {
  if (this.consultationData?.hbA1cBean?.length) {
    this.hba1cReadings = this.consultationData.hbA1cBean.map((item: any) => ({
      HbA1c_eAG: parseFloat(item.HbA1c_eAG),
      HbA1c_per: parseFloat(item.HbA1c_per),
      HbA1c_mmol: parseFloat(item.HbA1c_mmol),
      readingNumber: item.reading_number,
    }));
    console.log('✅ Parsed HBA1C Readings:', this.hba1cReadings);
  }
}


  private parseSpo2() {
    if (this.consultationData?.spo2?.length) {
      this.spo2Readings = this.consultationData.spo2.map((val: any) => ({
        percentage: parseFloat(val.percentage),
        pulse: parseFloat(val.pulse),
      }));
    }

    if (this.consultationData?.spo2_OxygenSaturation_Percentage) {
      this.spo2PercentageArray = Object.values(this.consultationData.spo2_OxygenSaturation_Percentage).map(val =>
        parseFloat(val as string)
      );

      this.spo2Readings = this.spo2Readings.map((r, i) => ({
        ...r,
        percentageData: this.spo2PercentageArray[i] ?? r.percentage,
        spo2_OxygenSaturation_Percentage: this.consultationData.spo2_OxygenSaturation_Percentage,
      }));
    }

    console.log('SpO2 Readings:', this.spo2Readings);
    console.log('SpO2 Percentage Array:', this.spo2PercentageArray);
  }

 private parseEcg() {
  const data = this.consultationData;
  if (!data?.ecg_filepath || !data?.s3_ecg_filepath) {
    console.log('No ECG data found');
    return;
  }

  const ecgFilepath = data.ecg_filepath || {};
  const s3EcgFilepath = data.s3_ecg_filepath || {};
// Sort filenames numerically by the sequence number (e.g., 1, 2, 3 from "ble_ecg_97776_X.txt")
            const sortedEcgFilenames = Object.keys(ecgFilepath).sort((a, b) => {
            // Extract the number before ".txt" (e.g., "1" from "ble_ecg_97776_1.txt")
            const numA = parseInt(a.match(/ble_ecg_\d+_(\d+)\.txt/)?.[1] || '0', 10);
            const numB = parseInt(b.match(/ble_ecg_\d+_(\d+)\.txt/)?.[1] || '0', 10);
            return numA - numB;  // Ascending order
            });
  // Map and filter valid ECG readings
  this.ecgReadings =  sortedEcgFilenames.map(filename => {
      const pulseRate = parseFloat(ecgFilepath[filename]);
      const s3Url = s3EcgFilepath
        ? Object.keys(s3EcgFilepath).find((url) => url.includes(filename))
        : null;

      return {
        reportName: filename || 'ECG Report',
        pulseRate: pulseRate || 0,
        s3Url: s3Url || '',
        consultationId: this.consultationId,
        patientId: this.patientId,
      };
    })
    .filter((r) => r.reportName && r.reportName.trim() !== '');

  console.log('✅ ECG Readings (Parsed):', this.ecgReadings);

  // If you need to auto-download ECG files (like in your list logic)
  if (this.ecgReadings.length > 0) {
    const globalEcgList = this.ecgReadings
      .map((r) => r.reportName)
      .filter((n) => n)
      .join(',');

    if (globalEcgList) {
      this.downloadFileFroms3(globalEcgList, 'ecg');
    }
  }
}

  private parseSpirometer() {
    if (this.consultationData?.spiro_filepath?.length) {
      this.spiroReadings = this.consultationData.spiro_filepath.map((file: string, index: number) => ({
        values: {
          fvc: parseFloat(this.consultationData.fvc?.[index]),
          fev1: parseFloat(this.consultationData.fev1?.[index]),
          fev1_fvc: parseFloat(this.consultationData.fev1_fvc?.[index]),
          tv: parseFloat(this.consultationData.tv?.[index]),
          pef: parseFloat(this.consultationData.pef?.[index]),
          fet: parseFloat(this.consultationData.fet?.[index]),
          tlc: parseFloat(this.consultationData.tlc?.[index]),
          fivc: parseFloat(this.consultationData.fivc?.[index]),
          fef25: parseFloat(this.consultationData.fef25?.[index]),
          fef50: parseFloat(this.consultationData.fef50?.[index]),
          fef75: parseFloat(this.consultationData.fef75?.[index]),
          fef25_75: parseFloat(this.consultationData.fef25_75?.[index]),
          pif: parseFloat(this.consultationData.pif?.[index]),
          fev1percent: parseFloat(this.consultationData.fev1percent?.[index]),
        },
        s3Url: this.consultationData.s3_spiro_filepath?.[index],
      }));
    }
    console.log('Spiro Readings:', this.spiroReadings);
  }

  private parseStethoscope() {
    if (this.consultationData?.stetho_filepath?.length) {
      this.stethoReadings = this.consultationData.stetho_filepath.map((file: string, index: number) => ({
        reportName: file || 'Stethoscope Report',
        filePath: file,
        s3FilePath: this.consultationData.s3_stetho_filepath?.[index],
      }));

      // Download files if available
      const globalStethoList: string[] = [];
      this.stethoReadings.forEach((reading) => {
        if (reading.reportName && reading.reportName.trim() !== '') {
          globalStethoList.push(reading.reportName);
        }
      });

      if (globalStethoList.length > 0) {
        this.downloadFileFroms3stetho(globalStethoList, 'stetho_filepath');
      }
    }
    console.log('Stethoscope Readings:', this.stethoReadings);
  }

  private parseFetalDoppler() {
    if (this.consultationData?.fetal_filepath?.length) {
      this.fetalReadings = this.consultationData.fetal_filepath.map((file: string, index: number) => {
        // Extract heart rate from filename if available (format: filename~heartrate)
        let reportName = file || 'Fetal Doppler Report';
        let heartRate = null;
        
        if (file && file.includes('~')) {
          const parts = file.split('~');
          reportName = parts[0];
          heartRate = parts[1] ? Number(parts[1]) : null;
        }
        
        return {
          reportName: reportName,
          filePath: file,
          s3FilePath: this.consultationData.s3_fetal_filepath?.[index],
          heartRate: heartRate,
          fullFileName: file // Keep original filename with heart rate
        };
      });

      // Download files if available
      const globalFetalList: string[] = [];
      this.fetalReadings.forEach((reading) => {
        if (reading.reportName && reading.reportName.trim() !== '') {
          globalFetalList.push(reading.fullFileName || reading.reportName);
        }
      });

      if (globalFetalList.length > 0) {
        this.downloadFileFroms3fetal(globalFetalList, 'fetal_filepath');
      }
    }
    console.log('Fetal Doppler Readings:', this.fetalReadings);
  }

  private parseBP() {
  const data = this.consultationData;
  if (!data) return;

  if (data.bpSystolic?.length && data.bpDiastolic?.length && data.pulse?.length) {
    this.bpReadings = data.bpSystolic.map((systolicVal: string, i: number) => ({
      systolic: parseFloat(systolicVal),
      diastolic: parseFloat(data.bpDiastolic[i]),
      pulse: parseFloat(data.pulse[i]),
    }));
  }

  console.log('BP Readings:', this.bpReadings);
   console.log('ECG Readings:', this.ecgReadings);

  // ✅ Parse spirometer readings
  if (this.consultationData?.spiro_filepath?.length) {
    this.spiroReadings = this.consultationData.spiro_filepath.map(
      (file: string, index: number) => {
        return {
          reportName: file || 'Spirometer Report',
          values: {
            fvc: parseFloat(this.consultationData.fvc?.[index]),
            fev1: parseFloat(this.consultationData.fev1?.[index]),
            fev1_fvc: parseFloat(this.consultationData.fev1_fvc?.[index]),
            tv: parseFloat(this.consultationData.tv?.[index]),
            pef: parseFloat(this.consultationData.pef?.[index]),
            fet: parseFloat(this.consultationData.fet?.[index]),
            tlc: parseFloat(this.consultationData.tlc?.[index]),
            fivc: parseFloat(this.consultationData.fivc?.[index]),
            fef25: parseFloat(this.consultationData.fef25?.[index]),
            fef50: parseFloat(this.consultationData.fef50?.[index]),
            fef75: parseFloat(this.consultationData.fef75?.[index]),
            fef25_75: parseFloat(this.consultationData.fef25_75?.[index]),
            pif: parseFloat(this.consultationData.pif?.[index]),
            fev1percent: parseFloat(this.consultationData.fev1percent?.[index]),
          },
          s3Url: this.consultationData.s3_spiro_filepath?.[index],
        };
      }
    );
  }
// Prepare list of report names for download
const globalSpiroList: string[] = [];
const deviceName = 'spiro_filepath';

this.spiroReadings.forEach((reading) => {
  if (reading.reportName && reading.reportName.trim() !== '') {
    globalSpiroList.push(reading.reportName);
  }
});

// Call the download method if files exist
if (globalSpiroList.length > 0) {
  this.downloadFileFroms3spirofilepath(globalSpiroList, deviceName);
}

  console.log('Spiro Readings:', this.spiroReadings);

    if (this.consultationData) {
    const len = Math.max(
      this.consultationData.glucoseRandom?.length || 0,
      this.consultationData.glucoseFasting?.length || 0,
      this.consultationData.glucosePostprandial?.length || 0
    );

    
  }
 

  if (this.consultationData?.hemoglobin?.length) {
  this.hemoglobinReadings = this.consultationData.hemoglobin.map(
    (val: string, index: number) => ({
      value: val,
      readingNumber: index + 1
    })
  );
}

this.hemoglobinNormalRange = this.consultationData?.hemoglobinNormalRange || '';
console.log('Hemoglobin Readings:', this.hemoglobinReadings);

}

  private parseGlucose() {
    const glucoseFastingArr = this.consultationData?.glucoseFasting || [];
    const glucoseRandomArr = this.consultationData?.glucoseRandom || [];
    const glucosePostprandialArr = this.consultationData?.glucosePostprandial || [];

    const maxLength = Math.max(
      glucoseFastingArr.length,
      glucoseRandomArr.length,
      glucosePostprandialArr.length
    );

    for (let i = 0; i < maxLength; i++) {
      if (i < glucoseFastingArr.length && glucoseFastingArr[i]?.trim() !== '') {
        this.glucoseReadings.push({
          value: glucoseFastingArr[i].trim(),
          type: 'Fasting',
          readingNumber: i + 1,
          sequenceIndex: i,
          category: 'fasting'
        });
      }
      if (i < glucoseRandomArr.length && glucoseRandomArr[i]?.trim() !== '') {
        this.glucoseReadings.push({
          value: glucoseRandomArr[i].trim(),
          type: 'Random',
          readingNumber: i + 1,
          sequenceIndex: i,
          category: 'random'
        });
      }
      if (i < glucosePostprandialArr.length && glucosePostprandialArr[i]?.trim() !== '') {
        this.glucoseReadings.push({
          value: glucosePostprandialArr[i].trim(),
          type: 'Post-Prandial',
          readingNumber: i + 1,
          sequenceIndex: i,
          category: 'postprandial'
        });
      }
    }

    console.log('Glucose Readings:', this.glucoseReadings);
  }



  private parseRapidTest() {
    const rapidReaderArr = this.consultationData?.rapidreader || [];
    if (Array.isArray(rapidReaderArr) && rapidReaderArr.length > 0) {
      this.rapidTestReadings = rapidReaderArr.map((test: any) => ({
        testName: test.testName || 'Rapid Test',
        testResult: test.testResult || 'N/A',
        testImage: test.testImage || null,
        patientId: test.patientid || this.patientInfo?.patientId,
        consultationId: test.consultationid || this.consultationDetails?.consultationId,
      }));
    }

    console.log('Rapid Test Readings:', this.rapidTestReadings);
  }

   private parseUrineTest() {
    const urineTestData = this.consultationData;
    const hasUrineTestData = urineTestData && (
      urineTestData.BLO || urineTestData.GLU || urineTestData.PRO ||
      urineTestData.URO || urineTestData.SG || urineTestData.pH ||
      urineTestData.BIL || urineTestData.NIT || urineTestData.KET || urineTestData.LEU
    );

    if (hasUrineTestData) {
      const maxUrineReadings = Math.max(
        (urineTestData.BLO || []).length,
        (urineTestData.GLU || []).length,
        (urineTestData.PRO || []).length,
        (urineTestData.URO || []).length,
        (urineTestData.SG || []).length,
        (urineTestData.pH || []).length,
        (urineTestData.BIL || []).length,
        (urineTestData.NIT || []).length,
        (urineTestData.KET || []).length,
        (urineTestData.LEU || []).length
      );

      for (let i = 0; i < maxUrineReadings; i++) {
        this.urineTestReadings.push({
          BLO: urineTestData.BLO?.[i] ? [urineTestData.BLO[i]] : [],
          GLU: urineTestData.GLU?.[i] ? [urineTestData.GLU[i]] : [],
          PRO: urineTestData.PRO?.[i] ? [urineTestData.PRO[i]] : [],
          URO: urineTestData.URO?.[i] ? [urineTestData.URO[i]] : [],
          SG: urineTestData.SG?.[i] ? [urineTestData.SG[i]] : [],
          pH: urineTestData.pH?.[i] ? [urineTestData.pH[i]] : [],
          BIL: urineTestData.BIL?.[i] ? [urineTestData.BIL[i]] : [],
          NIT: urineTestData.NIT?.[i] ? [urineTestData.NIT[i]] : [],
          KET: urineTestData.KET?.[i] ? [urineTestData.KET[i]] : [],
          LEU: urineTestData.LEU?.[i] ? [urineTestData.LEU[i]] : [],
          testimage: urineTestData.testimage?.[i] ? [urineTestData.testimage[i]] : [],
          stripType: urineTestData.urineTestStripType?.[0] || '1',
          patientId: this.patientInfo?.patientId,
          consultationId: this.consultationDetails?.consultationId,
        });
      }
    }

    console.log('Urine Test Readings:', this.urineTestReadings);
  }



private parseEcgInterpretations() {
  const data = this.consultationData;
  if (!data?.ecgi_filepath || !data?.s3_ecgi_filepath) {
    console.log('No ECG interpretation data found');
    return;
  }

  const ecgiFilepath = data.ecgi_filepath || {};
  const s3EcgiFilepath = data.s3_ecgi_filepath || {};

  const allReadings: any[] = [];
// Sort filenames numerically by the sequence number (e.g., 1, 2, 3 from "ble_ecgi_97776_X.txt")
const sortedFilenames = Object.keys(ecgiFilepath).sort((a, b) => {
  // Extract the number before ".txt" (e.g., "1" from "ble_ecgi_97776_1.txt")
  const numA = parseInt(a.match(/ble_ecgi_\d+_(\d+)\.txt/)?.[1] || '0', 10);
  const numB = parseInt(b.match(/ble_ecgi_\d+_(\d+)\.txt/)?.[1] || '0', 10);
  return numA - numB;  // Ascending order
});
 sortedFilenames.forEach((filename) => {
    const details = ecgiFilepath[filename]; // Example: "79,1,0"
    const parts = details ? details.split(',') : [];
    const pulseRate = parts[0] ? parseFloat(parts[0]) : undefined;
    const isManual = parts[1] === '1'; // second value = 1 => manual
 const hasAIReport = parts.length > 2 && parts[parts.length - 1] === '1'; 
    const reading = {
      reportName: filename || 'ECG Interpretation Report',
      pulseRate,
      s3Url: s3EcgiFilepath
        ? Object.keys(s3EcgiFilepath).find((url) => url.includes(filename))
        : null,
      consultationId: this.consultationId,
      patientId: this.patientId,
      isManual,
       hasAIReport,
       showTooltip: false,
    };

    allReadings.push(reading);
  });

  console.log('Combined ECG Readings:', allReadings);
  this.allEcgReadings = allReadings;

  // Download files from S3
  const fileList = allReadings.map((r) => r.reportName).filter((n) => n).join(',');
  if (fileList) this.downloadFileFroms3(fileList, 'ecgi_filepath');
}

getLatestEcgi() {
  return this.allEcgReadings.length
    ? this.allEcgReadings[this.allEcgReadings.length - 1]
    : null;
}

toggleEcgiCard() {
  this.showEcgiCard = !this.showEcgiCard;
}
  /** ================== UTILITIES ================== **/

  getLatestTemperature(): { f: number; c: number } | null {
    return this.temperatureReadings.length ? this.temperatureReadings[this.temperatureReadings.length - 1] : null;
  }

  getLatestSpo2(): { percentage: number; pulse: number } | null {
    return this.spo2Readings.length ? this.spo2Readings[this.spo2Readings.length - 1] : null;
  }


  toggleBPCard() {
  this.showBPCard = !this.showBPCard;
}

// Get latest BP
getLatestBP() {
  return this.bpReadings.length ? this.bpReadings[this.bpReadings.length - 1] : null;
}
  toggleTemperatureCard() {
    this.showTemperatureCard = !this.showTemperatureCard;
  }

  toggleSpo2Card() {
    this.showSpo2Card = !this.showSpo2Card;
  }



  onDialogClose() {
    this.dialogRef?.close(false);
  }

 getLatestGlucose() {
    if (!this.glucoseReadings.length) return null;
    return this.glucoseReadings.reduce((latest, current) =>
      current.sequenceIndex > latest.sequenceIndex ? current : latest
    );
  }

   toggleGlucoseCard() {
    this.showGlucoseCard = !this.showGlucoseCard;
  }

    hasMultipleGlucoseReadings(): boolean {
    return this.glucoseReadings.length > 1;
  }

  toggleRapidTestCard() {
    this.showRapidTestCard = !this.showRapidTestCard;
  }

  toggleUrineTestCard() {
    this.showUrineTestCard = !this.showUrineTestCard;
  }

 

  hasMultipleRapidTests(): boolean {
    return this.rapidTestReadings.length > 1;
  }

  hasMultipleUrineTests(): boolean {
    return this.urineTestReadings.length > 1;
  }
  getPastRecordLipid(reading: any) {
  // Your logic to view lipid profile details
  console.log('View lipid reading:', reading);
}
  /** ================== SPO2 DIALOG ================== **/
  openSpo2Dialog(allReadings: any[], index: number = 0) {
    if (!allReadings?.length) {
      console.warn('No SPO2 readings available to open dialog.');
      return;
    }

    if (index < 0 || index >= allReadings.length) index = 0;
    this.spo2Index = index;

    const spo2Data = this.consultationData;
    const dialogData = {
      api: 'apiCalling',
      parameter: 'spo2',
      data: {
        readings: allReadings,
        percentageData: spo2Data?.spo2_OxygenSaturation_Percentage
          ? Object.values(spo2Data.spo2_OxygenSaturation_Percentage).map(val => parseFloat(val as string))
          : [],
        percentageNormalRange: spo2Data?.spo2_OxygenSaturation_PercentageNormalRange || '',
        pulseNormalRange: spo2Data?.spo2_PulseRateNormalRange || '',
        s3FilePaths: spo2Data?.s3_spo2_filepath || {},
        consultationId: spo2Data?.consultationid || 0,
        patientId: spo2Data?.patientid || 0,
        isXrayTaken: spo2Data?.isXrayTaken || false
      },
      index: this.spo2Index
    };

    this.dialog.open(Spo2DevicePage, {
      data: dialogData,
      width: '1000px',
      height: '400px',
      disableClose: true,
    });
   console.log('SPO2 Dialog opened with full data:', dialogData);
  }

getLatestEcg(): { reportName: string; pulseRate?: number; extra?: string } | null {
  if (!this.ecgReadings.length) return null;
  return this.ecgReadings[this.ecgReadings.length - 1];
}

toggleEcgCard() {
  this.showEcgCard = !this.showEcgCard;
}
toggleEcgInterpretationCard(){
  this.showEcgiCard = !this.showEcgiCard;
}

// Utility to prepare payload for ECG detailed view
prepareEcgPayload(reading: any) {
  return {
    reportName: reading.reportName,
    pulseRate: reading.pulseRate,
    extra: reading.extra,
     consultationId: reading.consultationId,
    patientId: reading.patientId,
    s3Url:reading.s3Url
  };
}


getLatestSpiro() {
   if (!this.spiroReadings.length) return null;
   return this.spiroReadings[this.spiroReadings.length - 1];
 }

 toggleSpiroCard() {
   this.showSpiroCard = !this.showSpiroCard;
 }

getLatestStetho() {
  if (!this.stethoReadings.length) return null;
  return this.stethoReadings[this.stethoReadings.length - 1];
}

toggleStethoCard() {
  this.showStethoCard = !this.showStethoCard;
}

getLatestFetal() {
  if (!this.fetalReadings.length) return null;
  const latest = this.fetalReadings[this.fetalReadings.length - 1];
  return {
    ...latest,
    displayName: latest.heartRate ? `${latest.reportName} (${latest.heartRate} BPM)` : latest.reportName
  };
}

toggleFetalCard() {
  this.showFetalCard = !this.showFetalCard;
}

getLatestHemoglobin() {
  return this.hemoglobinReadings.length
    ? this.hemoglobinReadings[this.hemoglobinReadings.length - 1]
    : null;
}

toggleHemoglobinCard() {
  this.showHemoglobinCard = !this.showHemoglobinCard;
}
// Add these methods in your component class (after the other toggle methods)

// ---------------- HbA1C Methods ----------------
getLatestHba1c() {
  if (this.hba1cReadings && this.hba1cReadings.length > 0) {
    return this.hba1cReadings[this.hba1cReadings.length - 1];
  }
  return null;
}

toggleHba1cCard() {
  this.showHba1cCard = !this.showHba1cCard;
}

// ---------------- Lipid Profile Methods ----------------
getLatestLipid() {
  if (this.lipidReadings && this.lipidReadings.length > 0) {
    return this.lipidReadings[this.lipidReadings.length - 1];
  }
  return null;
}

toggleLipidCard() {
  this.showLipidCard = !this.showLipidCard;
}

getPastRecordEcg(reading: any) {
  console.log("INSIDE getPastRecordEcg:", reading);

  const dialogRef = this.dialog.open(EcgJettyDevicePage, {
    data: {
      api: "apiCalling",
      data: { readings: reading },
      index: '1',
    },
    width: "1000px",
    height: "auto",
    disableClose: true,
    panelClass: 'slot-dialog'
  });

  dialogRef.afterClosed().subscribe((result) => {
    if (result !== undefined) {
      console.log("Dialog closed with:", result);
    }
  });
}
downloadFileFroms3spirofilepath(spiro_filepaths: string[], deviceNamefetal: string) {
  
    this.tokenRequest = this.authService.getToken() || '';
  spiro_filepaths.forEach(file => {
    const data = `?action=downloadfilefroms3&downloadfilelist=${file}`
      + `&devicename=${deviceNamefetal}`
      + `&conId=${this.consultationId}`
      + `&patientId=${this.patientId}`
      + `&token=${this.tokenRequest}`;

    this.apiSvc.postServiceByQueryBasicText(
      this.constantSvc.APIConfig.GETCOMMONSERVICES,
      data
    ).subscribe((res: any) => {
      console.log("Downloaded file:", res);
    });
  });
}

downloadFileFroms3stetho(stetho_filepaths: string[], deviceName: string) {
  this.tokenRequest = this.authService.getToken() || '';
  stetho_filepaths.forEach(file => {
    const data = `?action=downloadfilefroms3&downloadfilelist=${file}`
      + `&devicename=${deviceName}`
      + `&conId=${this.consultationId}`
      + `&patientId=${this.patientId}`
      + `&token=${this.tokenRequest}`;

    this.apiSvc.postServiceByQueryBasicText(
      this.constantSvc.APIConfig.GETCOMMONSERVICES,
      data
    ).subscribe((res: any) => {
      console.log("Downloaded stethoscope file:", res);
    });
  });
}

downloadFileFroms3fetal(fetal_filepaths: string[], deviceName: string) {
  this.tokenRequest = this.authService.getToken() || '';
  fetal_filepaths.forEach(file => {
    const data = `?action=downloadfilefroms3&downloadfilelist=${file}`
      + `&devicename=${deviceName}`
      + `&conId=${this.consultationId}`
      + `&patientId=${this.patientId}`
      + `&token=${this.tokenRequest}`;

    this.apiSvc.postServiceByQueryBasicText(
      this.constantSvc.APIConfig.GETCOMMONSERVICES,
      data
    ).subscribe((res: any) => {
      console.log("Downloaded fetal doppler file:", res);
    });
  });
}


spiroSeriesData = [];
  spiroCount = 0;
getPastRecordSpiroDevice(allReadings: any[], index: number) {
const selectedReading = {
  ...allReadings[index],           // existing reading values
  consultationId: this.consultationId,  // add consultationId
  patientId: this.patientId,           // add patientId
};
  const dialogRef = this.dialog.open(SpirometerJettyDevicePage, {
    data: {
      api: "apiCalling",
      data: selectedReading, 
      
    },
    disableClose: true,
    width: '1000px',
    maxWidth: '1000px',
    panelClass: 'custom-spiro-dialog',
  });

  dialogRef.afterClosed().subscribe((result) => {
    if (result != undefined) { }
  });
}

 private parseUploadedDocuments() {
  this.uploadedDocuments = [];
  if (this.consultationImages?.imageGroups && this.consultationImages.imageGroups.length > 0) {
    this.consultationImages.imageGroups.forEach((group: any) => {
      if (group.images && group.images.length > 0) {
        group.images.forEach((image: any) => {
          const { date, time } = this.getFormattedDate(image.addedAt);
            // Pluralization: "image" if count === 1, "images" otherwise
          const imagePlural = group.imageCount === 1 ? 'image' : 'images';
          const documentType = `${group.imageType} (${group.imageCount} ${imagePlural})`;

          this.uploadedDocuments.push({
            date: date, 
            time: time, 
            documentType: documentType, 
            uploadedBy: this.consultationDetails?.attendedBy || 'Unknown', 
             S3URL:image.S3URL,
            addedAt:image.addedAt,
            addedBy:image.addedBy,
            category:image.category,
            imagePath:image.imagePath,
            imageType:image.imageType,
            imageTypeId:image.imageTypeId,
          });
        });
      }
    });
  }
  console.log('✅ Uploaded Documents Parsed:', this.uploadedDocuments);
}

  // NEW: Method to switch tabs
  switchTab(tabName: string) {
    this.currentTab = tabName;
  }
  // NEW: Method to view document (e.g., open image in new tab)
  viewDocument(s3Url: string) {
    // if (s3Url) {
    //   window.open(s3Url, '_blank'); // Opens in new tab; customize as needed (e.g., modal)
    // }
  }

  private getFormattedDate(addedAtStr: string): { date: string; time: string } {
  const monthMap: { [key: string]: number } = {
    'Jan': 0, 'Feb': 1, 'Mar': 2, 'Apr': 3, 'May': 4, 'Jun': 5,
    'Jul': 6, 'Aug': 7, 'Sep': 8, 'Oct': 9, 'Nov': 10, 'Dec': 11
  };
  // Parse the string (split into date and time parts)
  const [datePart, timePart] = addedAtStr.split(' ');
  const [dayStr, monthStr, yearStr] = datePart.split('-');
  const day = parseInt(dayStr, 10);
  const month = monthMap[monthStr];
  const year = parseInt(yearStr, 10);
  if (isNaN(day) || month === undefined || isNaN(year)) {
    // Fallback if parsing fails
    return { date: 'Invalid Date', time: 'Invalid Time' };
  }
  const date = new Date(year, month, day);
  // Ordinal suffix for day (e.g., 1st, 2nd, 3rd, 4th, ..., 11th, 12th, 13th, 21st, etc.)
  const getOrdinalSuffix = (d: number): string => {
    const j = d % 10;
    const k = d % 100;
    if (j === 1 && k !== 11) return 'st';
    if (j === 2 && k !== 12) return 'nd';
    if (j === 3 && k !== 13) return 'rd';
    return 'th';
  };
  const ordinalDay = day + getOrdinalSuffix(day);
  const monthName = date.toLocaleDateString('en-US', { month: 'short' }); // e.g., "October"
  const formattedDate = `${ordinalDay} ${monthName}, ${year}`; // e.g., "06th October, 2025"
 // Time formatting (e.g., "4:27 PM")
  const [timeStr] = timePart.split(' '); // Ignore AM/PM for now, use toLocaleTimeString
  const [hourStr, minuteStr] = timeStr.split(':');
  const hour = parseInt(hourStr, 10);
  const minute = parseInt(minuteStr, 10);
  const ampm = timePart.includes('PM') && hour < 12 ? hour + 12 : (timePart.includes('AM') && hour === 12 ? 0 : hour);
  const fullDate = new Date(year, month, day, ampm, minute);
  const formattedTime = fullDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
  return { date: formattedDate, time: formattedTime };
}

 setRowHover(index: number, isHovered: boolean) {
       // Example: Log or update a style array; customize as needed
       console.log(`Row ${index} hovered: ${isHovered}`);
       // If you want dynamic background, add a property like hoveredRows: boolean[] = []; and update it here
     }
   



   openRapidTestPopup(reading: any) {
    console.log('Opening Rapid Test popup:', reading);

    const dialogRef = this.dialog.open(PastpopfordisplayingImagesComponent, {
      data: {
        reading: {
          testName: reading.testName || 'Rapid Test',
          testResult: reading.testResult || 'N/A',
          testImage: reading.testImage || null,
          gender: this.patientInfo?.gender || 'N/A',
          dateOfBirth: this.patientInfo?.dateOfBirth || 'N/A'
        },
        record: {
          patientName: `${this.patientInfo?.firstName} ${this.patientInfo?.lastName}` || 'N/A',
          age: this.patientInfo?.age || 'N/A'
        }
      },
      width: '1289px',
      maxWidth: '90vw',
      height: 'auto',
      maxHeight: '90vh',
      disableClose: true,
      panelClass: 'rapid-test-dialog'
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result !== undefined) {
        console.log("Rapid Test Dialog closed with:", result);
      }
    });
  }

  openUrineTestPopup(reading: any) {
    console.log('Opening Urine Test popup:', reading);

    const dialogRef = this.dialog.open(PastpopfordisplayingImagesComponent, {
      data: {
        testType: 'urine',
        reading: {
          BLO: reading.BLO || [],
          GLU: reading.GLU || [],
          PRO: reading.PRO || [],
          URO: reading.URO || [],
          SG: reading.SG || [],
          pH: reading.pH || [],
          BIL: reading.BIL || [],
          NIT: reading.NIT || [],
          KET: reading.KET || [],
          LEU: reading.LEU || [],
          testimage: reading.testimage || [],
          stripType: reading.stripType || '1',
          patientId: reading.patientId || this.patientInfo?.patientId,
          consultationId: reading.consultationId || this.consultationDetails?.consultationId
        },
        record: {
          patientName: `${this.patientInfo?.firstName} ${this.patientInfo?.lastName}` || 'N/A',
          age: this.patientInfo?.age || 'N/A',
          appointmentDate: this.consultationDetails?.appointmentDate || 'N/A'
        }
      },
      width: '1289px',
      maxWidth: '95vw',
      height: 'auto',
      maxHeight: '90vh',
      disableClose: true,
      panelClass: ['urine-test-dialog', 'full-width-dialog'],
      hasBackdrop: true,
      backdropClass: 'urine-transparent-backdrop',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result !== undefined) {
        console.log("Urine Test Dialog closed with:", result);
      }
    });
  }





  viewReport() {
  console.log(' consultation report clicked');
  console.log('Using consultationId:', this.consultationIdv);
  console.log('Using patientId:', this.patientIdv);

  if (!this.consultationIdv) {
    console.error('No consultation ID available');
    return;
  }

  if (!this.patientIdv) {
    console.error('No patient ID available');
    return;
  }

  //ViewreportPage
  const dialogRef = this.dialog.open(ViewreportPage, {
    width: '95vw',
    height: '95vh',
    maxWidth: '95vw',
    maxHeight: '95vh',
    data: {
      id: this.consultationIdv,
      ptId: this.patientIdv,
      dt: new Date().toISOString()
    },
    panelClass: 'consultation-report-dialog',
    disableClose: true
  });

  dialogRef.afterClosed().subscribe(result => {
    console.log('Consultation report dialog closed');
  });
}


openEcgInterpretation(reading: any): void {
  console.log('Opening ECG Interpretation:', reading);

  const isManual = reading.isManual === true;
if (isManual) {
  const dialogRef = this.dialog.open(EcgInterpretationManualJettyComponent, {
    data: {
      api: 'apiCalling',
      data: { readings: reading },
      index: '1',
    },
    width: '1000px',
    height: 'auto',
    disableClose: true,
    panelClass: 'ecgi-manual-dialog-panel',
  });

  dialogRef.afterClosed().subscribe((result) => {
    if (result !== undefined) {
      console.log('Manual ECG Dialog closed with:', result);
    }
  });
} else {
  const dialogRef = this.dialog.open(EcgInterpretationJettyDeviceComponent, {
    data: {
      api: 'apiCalling',
      data: { readings: reading },
      index: '1',
    },
    width: '1000px',
    height: 'auto',
    disableClose: true,
    panelClass: 'slot-dialog',
  });

  dialogRef.afterClosed().subscribe((result) => {
    if (result !== undefined) {
      console.log('AI ECG Dialog closed with:', result);
    }
  });
}

}

  downloadFileFroms3(downloadfilelist: string, devicename: string) {
    let data =
      "?action=downloadfilefroms3&downloadfilelist=" +
      downloadfilelist +
      "&devicename=" +
      devicename +
      "&conId=" +
      this.consultationId +
      "&patientId=" +
      this.patientId +
      "&token=" +
      this.tokenRequest;

    this.apiSvc
      .postServiceByQueryBasic(
        this.constantSvc.APIConfig.GETCOMMONSERVICES,
        data
      )
      .subscribe((res) => {
        console.log("downloadFileFroms3", res);
      });
  }


  // Add this method to the PastConsultationPage component
downloadReport(reading: any) {
  const params = {
    action: 'downloadInterpretationReport',
    username: this.authService.getCurrentSession()?.username || '',
    conId: this.consultationId,
    domain: this.authService.getCurrentSession()?.domainId || '',
    filepath: reading.reportName,  // Assuming reportName is the filepath, e.g., 'ble_ecgi_96314_1.txt'
    patientId: this.patientId,
    token: this.tokenRequest
  };

  const queryString = new URLSearchParams(params).toString();

  this.apiSvc.postServiceByQueryBasic(this.constantSvc.APIConfig.GETCOMMONSERVICES, `?${queryString}`)
    .subscribe({
      next: (res: any) => {
        if (res.status === 'ok' && res.S3FileName_URL) {
          // Extract the URL and trigger download
          const downloadUrl = res.S3FileName_URL;
          window.open(downloadUrl, '_blank');  // Opens the PDF in a new tab/window for download
        } else {
          console.error('Failed to download report:', res.message);
          // Optionally show a user-friendly error message
        }
      },
      error: (err) => {
        console.error('Error downloading report:', err);
        // Optionally show a user-friendly error message
      }
    });
}

viewImages(images: any[]) {
  event?.stopPropagation(); // Prevent row click duplication

  console.log('Viewing images:', images);
  const patientId = this.patientInfo?.patientId || null;
  const consultationId = this.consultationIdv || null;
  console.log('Patient ID:', patientId);
  console.log('Consultation ID:', consultationId);

  // Close the current PastConsultationPage dialog to "hide" it
  this.dialogRef.close();

  // Open the PastImagesPreviewPage dialog
  const dialogRefPreview = this.dialog.open(PastImagesPreviewPage, {
    data: { 
      images, 
      patientId,
      consultationId 
    }, 
    width: '1000px',
    height: '600px',
    disableClose: true,
    panelClass: 'past-image-viewer-dialog' 
  });

  // After the preview dialog closes, reopen the PastConsultationPage dialog
  dialogRefPreview.afterClosed().subscribe((result) => {
    if (result) {
      console.log('Image action:', result);
    }
    // Reopen PastConsultationPage with the original data
    this.dialog.open(PastConsultationPage, {
      data: this.data, // Use the injected data to restore the state
      width: '1000px',
      height: '720px',
      disableClose: true
    });
  });
}

getPastRecordStetho(allReadings: any[], index: number) {
  console.log("INSIDE getPastRecordStetho:", allReadings, index);

  const dialogRef = this.dialog.open(StethoscopeDevicePage, {
    data: {
      api: "apiCalling",
      data: { readings: allReadings },
      index: index,
    },
    width: "800px",
    height: "auto",
    disableClose: true,
    panelClass: 'slot-dialog'
  });

  dialogRef.afterClosed().subscribe((result) => {
    if (result !== undefined) {
      console.log("Stethoscope Dialog closed with:", result);
    }
  });
}

getPastRecordFetal(allReadings: any[], index: number) {
  console.log("INSIDE getPastRecordFetal:", allReadings, index);

  // Enhanced data structure for fetal doppler past records with file reading support
  const selectedReading = allReadings[index];
  const dialogRef = this.dialog.open(FetalDopplerDevicePage, {
    data: {
      api: "apiCalling",
      parameter: "fetal",
      data: { 
        readings: allReadings,
        consultationId: this.consultationId,
        patientId: this.patientId,
        // Pass additional data for enhanced functionality
        fetal_filepath: this.consultationData?.fetal_filepath || {},
        selectedFileName: selectedReading?.fullFileName || selectedReading?.reportName
      },
      index: index,
      // Flags to enable enhanced past record functionality
      enableFileReading: true,
      enableGraphPlotting: true,
      enableAudioPlayback: true
    },
    width: "1000px",
    height: "650px", // Slightly taller for audio controls
    disableClose: true,
    panelClass: 'fetal-doppler-enhanced-dialog'
  });

  dialogRef.afterClosed().subscribe((result) => {
    if (result !== undefined) {
      console.log("Enhanced Fetal Doppler Dialog closed with:", result);
    }
  });
}

}
