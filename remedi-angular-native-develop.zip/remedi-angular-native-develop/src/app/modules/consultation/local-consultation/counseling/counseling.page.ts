import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { PouchdbService } from '../../../../core/services/pouchdb.service';
import { Counseling } from '../../../../core/interfaces/localconsultation.model';
import { ApiService } from '../../../../core/services/api.service';
import { ConstantService } from '../../../../core/services/constant.service';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { ToastService } from 'src/app/core/services/toast.service';
import { DialogService } from 'src/app/core/services/dialog.service';

interface MasterData {
  [key: string]: any;
}

interface Speciality {
  speciality: string;
  Id: string;
}

@Component({
  selector: 'app-counseling',
  templateUrl: './counseling.page.html',
  styleUrls: [
    './counseling.page.scss',
    '../tabs/tabs.page.scss',
    '../medicines/medicines.page.scss',
    '../investigations/investigations.page.scss',
  ],

  standalone: true,
  imports: [IonicModule, CommonModule, ReactiveFormsModule, MatSnackBarModule],
})

export class CounselingPage implements OnInit {
  counseling: Counseling[] = [];
  specialityList: Speciality[] = [];
  categoryList: string[] = [
    '-620', 'ABC', 'Acute gastroenteritis', 'Anemia', 'Antenatal advice', 'Asd',
    'Bronchitis and Asthma', 'Cervical spondylitis', 'Cervicitis/Vaginitis', 'Constipation',
    'Deetal', 'Dental', 'Diabetes', 'do not smoke', 'dshj j', 'Gastritis', 'General',
    'Gout', 'Hypertension', 'Isaphgol Preparation', 'JKL', 'Lower back pain/strain',
    'Maven', 'Mental Health', 'Mental Health issue', 'Mental helath couselling',
    'naicine', 'not to drink alchol', 'not to eat fastfood', 'nurveweekness', 'OB/GYN',
    'obesity', 'Oral Rehydration Salt (ORS) Recipe', 'Protein Energy Malnutrition (PEM)',
    'Respiratory infections in children:', 'sdfsd', 'Talking therapy', 'Vaginal candidiasis',
    'Volini spray', 'zasd'
  ];
  filteredCategoryList: string[] = [];
  counselingForm: FormGroup;
  loading = false;
  error = '';
  message = '';
  counselingList: Counseling[] = [];
  saving = false;
  editingCounseling: Counseling | null = null;
    isMobile = false;
  isModalOpen = false;
  showCategoryDropdown = false;

  constructor(
    private http: HttpClient,
    private pouchdbService: PouchdbService,
    private pouch: PouchdbService,
    private formBuilder: FormBuilder,
    private apiService: ApiService,
    private constantService: ConstantService,
    private toastService: ToastService,
    private dialog: MatDialog,
    private dialogService: DialogService,
    private snackBar: MatSnackBar
  ) {

    this.counselingForm = this.formBuilder.group({
      selectedSpeciality: ['', Validators.required],
      counselingText: ['', Validators.required],
    });
  }
  async ngOnInit() {
    this.pouch.initDB('prms_instruction');

       this.checkScreenSize();
    window.addEventListener('resize', () => this.checkScreenSize());

    this.loadSavedCounseling();
    this.checkNetworkAndSync();

    this.specialityList = await this.pouchdbService.getTable('tblspeciality_list');
    console.log('Patient specialityList:', this.specialityList);

    // Initialize filtered category list with ascending order sorting
    this.filteredCategoryList = [...this.categoryList].sort((a, b) => a.localeCompare(b));


  }
  checkScreenSize() {
    this.isMobile = window.innerWidth <= 500;
  }
  openModal() {
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
    this.editingCounseling = null;
    this.counselingForm.reset({ days: 0 });
  }


  private checkNetworkAndSync() {
    if (navigator.onLine) {
      console.log('Device is online - Starting auto-sync...');
      this.syncAllUnsyncedCounseling();
    } else {
      console.log('Device is offline - Sync will retry when online');
    }

    window.addEventListener('online', () => {
      console.log('Network restored - Starting auto-sync...');
      this.syncAllUnsyncedCounseling();
    });

    window.addEventListener('offline', () => {
      console.log('Network lost - Data will be saved locally');
    });
  }




  loadSavedCounseling(): void {
   const consultationId = localStorage.getItem('consultationId') || '';
    console.log('consultationId', consultationId);
    this.pouch.getRecordsByType<Counseling>('counseling').subscribe({
      next: (docs) => {
        this.counseling = docs.filter(counseling => counseling.consultationId === consultationId);
        this.counselingList = docs; // Keep for sync purposes
        console.log('✅ Counseling Records Loaded:', this.counseling);
        this.syncAllUnsyncedCounseling();
      },
      error: (err) => {
        console.error('Error loading counseling records:', err);
        this.error = 'Failed to load counseling records.';
      },
    });
  }

  saveCounseling() {
    const formValue = this.counselingForm.value;

    // Validation with warning dialog
    if (!formValue.selectedSpeciality?.trim()) {
      this.dialogService.warning('Please select a category.');
      return;
    }
    if (!formValue.counselingText?.trim()) {
      this.dialogService.warning('Please enter counseling text.');
      return;
    }

    this.saving = true;
    this.error = '';
    this.message = '';

    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const consultationId = localStorage.getItem('consultationId') || '1';
    const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
    const domain = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
    const username = loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? '';
    const patientId = patientDetails.patientid || '';
    const counselingData: Counseling = {
      instructionCategory: formValue.selectedSpeciality,
      instruction: formValue.counselingText,
      createdAt: new Date().toISOString(),
      type: 'counseling',
      synced: false,
      domain: domain,
      action: 'savetoserver',
      patientId: patientId,
      consultationId,
      username: username,
      paramName: 'complaint',
      tblname: 'prms_instruction',
      token: token,
      forwardto: 'AndroidRemoteConsultaionSevices.do',

    };


    if (this.editingCounseling && this.editingCounseling._id && this.editingCounseling._rev) {
      const updatedDoc = { ...this.editingCounseling, ...counselingData };
      this.pouch.updateRecord(updatedDoc).subscribe({
        next: () => {
          this.finishAction('Counseling updated!');
          this.snackBar.open('Counseling updated successfully.', 'Close', { duration: 3000 });
        },
        error: () => this.finishAction('Failed to update counseling', true),
      });
    } else {
      this.pouch.addRecord(counselingData).subscribe({
        next: () => {
          this.finishAction('Counseling saved!');
          this.snackBar.open('Counseling saved successfully.', 'Close', { duration: 3000 });
        },
        error: () => this.finishAction('Failed to save counseling', true),
      });
    }

    if (this.isMobile) this.closeModal();
  }

  editCounseling(item: Counseling) {
    this.editingCounseling = { ...item };
    this.counselingForm.patchValue({
      selectedSpeciality: item.instructionCategory,
      counselingText: item.instruction,
    });
  }

  async deleteCounseling(item: Counseling) {
    if (!item._id) return;

    // Optimistically remove item from counseling list
    const index = this.counseling.findIndex(c => c._id === item._id);
    if (index > -1) {
      this.counseling.splice(index, 1);
    }

    try {
      // ✅ Fetch the latest document to get the current _rev before deleting
      const latestItem = await firstValueFrom(this.pouchdbService.getRecordById<Counseling>(item._id));
      this.pouch.deleteRecord(latestItem).subscribe({
        next: () => {
          this.finishAction('Counseling deleted!');
          this.snackBar.open('Counseling deleted successfully.', 'Close', { duration: 3000 });
        },
        error: () => {
          // Revert removal on error
          if (index > -1) {
            this.counseling.splice(index, 0, item);
          }
          this.finishAction('Failed to delete counseling', true);
        },
      });
    } catch (err) {
      // Revert removal on error
      if (index > -1) {
        this.counseling.splice(index, 0, item);
      }
      this.finishAction('Failed to delete counseling', true);
    }
  }

  private async syncAllUnsyncedCounseling() {
    this.pouch.initDB('prms_instruction');
    const unsyncedCounseling = this.counselingList.filter((c) => !c.synced);
    for (const counseling of unsyncedCounseling) {
      await this.syncWithBackend(counseling);
    }
  }

  private async syncWithBackend(counseling: Counseling) {
    this.pouch.getAllRecords<Counseling>().subscribe((records) => {
      const unsynced = records.filter((r) => !r.synced && r.consultationId === localStorage.getItem('consultationId'));
      console.log('unsynced', unsynced);

      unsynced.forEach((record) => {

        const token = localStorage.getItem('token') || '';
        const query =
          `?forwardto=${counseling.forwardto}` +
          `&action=${counseling.action}` +
          `&domain=${counseling.domain}` +
          `&username=${counseling.username}` +
          `&patientId=${counseling.patientId}` +
          `&consultationId=${counseling.consultationId}` +
          `&tblname=${counseling.tblname}` +
          `&instructionCategory=${encodeURIComponent(counseling.instructionCategory)}` +
          `&instruction=${encodeURIComponent(counseling.instruction)}` +
          `&token=${encodeURIComponent(token)}`;

        this.apiService.postServiceByQueryBasic(this.constantService.APIConfig.GETCOMMONSERVICES, query)
          .subscribe({
            next: (res: any) => {
              if (res.status === 'success') {
                console.log('Synced Counseling record:', record);
                record.synced = true;
                this.pouch.updateRecord(record).subscribe();
              } else {
                console.warn('Sync failed:', res);
              }
            },
            error: (err) => {
              console.error('Error syncing Counseling record:', err);
            },
          });
      });
   });
  }

  private finishAction(msg: string, isError = false) {
    this.saving = false;

    if (isError) this.error = msg;
    else this.message = msg;
    this.resetForm();
    this.loadSavedCounseling();

  }

  private resetForm() {
    this.counselingForm.reset();
    this.editingCounseling = null;
  }

  // Filter and Search Methods
  filterCategoryList() {
    const input = this.counselingForm.get('selectedSpeciality')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredCategoryList = [...this.categoryList].sort((a, b) => a.localeCompare(b));
      return;
    }
    this.filteredCategoryList = this.categoryList.filter(category =>
      category.toLowerCase().includes(input)
    ).sort((a, b) => a.localeCompare(b));
  }

  selectCategory(category: string) {
    this.counselingForm.get('selectedSpeciality')?.setValue(category);
    this.showCategoryDropdown = false;
  }

  hideCategoryDropdown() {
    setTimeout(() => this.showCategoryDropdown = false, 200);
  }

}
