import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CounselingPage } from './counseling.page';

describe('CounselingPage', () => {
  let component: CounselingPage;
  let fixture: ComponentFixture<CounselingPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CounselingPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
