import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { firstValueFrom, lastValueFrom, catchError, of } from 'rxjs';
import { Referral } from '../../../../core/interfaces/localconsultation.model';
import { PouchdbService } from '../../../../core/services/pouchdb.service';
import { ApiService } from '../../../../core/services/api.service';
import { ConstantService } from '../../../../core/services/constant.service';

import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { DialogService } from 'src/app/core/services/dialog.service';

interface MasterData {
  [key: string]: any;
}

interface Speciality {
  speciality: string;
  Id: string;
}

@Component({
  selector: 'app-referrals',
  templateUrl: './referrals.page.html',
  styleUrls: [
    './referrals.page.scss',
    '../tabs/tabs.page.scss',
    '../medicines/medicines.page.scss',
    '../investigations/investigations.page.scss'
  ],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, IonicModule, HttpClientModule, MatSnackBarModule]
})
export class ReferralsPage implements OnInit {
  specialityList: Speciality[] = [];
  filteredSpecialityList: Speciality[] = [];
  referralForm: FormGroup;
  loading = false;
  saving = false;
  message = '';
  error = '';
  referrals: Referral[] = []; //  bound to table

  editingReferral: Referral | null = null;
   isMobile = false;
  isModalOpen = false;
  showSpecialityDropdown = false;

  constructor(
    private pouchdbService: PouchdbService,
    private pouch: PouchdbService,
    private pouchdb: PouchdbService,
    private http: HttpClient,
    private formBuilder: FormBuilder,
    private apiService: ApiService,
    private constantService: ConstantService,
      private dialogService: DialogService,
      private snackBar: MatSnackBar
  ) {
    this.referralForm = this.formBuilder.group({
      selectedSpeciality: ['', Validators.required],
      referralNote: ['', Validators.required]
    });
  }

  async ngOnInit() {
    this.pouch.initDB('prms_referrals');


    this.checkScreenSize();
    window.addEventListener('resize', () => this.checkScreenSize());


    this.loadSavedReferrals();
    this.checkNetworkAndSync();

    this.specialityList = await this.pouchdbService.getTable('tblspeciality_list');
    console.log('Patient specialityList:', this.specialityList);

    // Initialize filtered list with ascending order sorting
    this.filteredSpecialityList = [...this.specialityList].sort((a, b) => (a.speciality || '').localeCompare(b.speciality || ''));

    this.loadSavedReferrals();
  }

  checkScreenSize() {
    this.isMobile = window.innerWidth <= 500;
  }

  openModal() {
    this.isModalOpen = true;
  }
  closeModal() {
    this.isModalOpen = false;
    this. editingReferral = null;
    this.referralForm.reset({ days: 0 });
  }

  private async checkNetworkAndSync() {
    if (navigator.onLine) {
      await this.syncAllUnsyncedReferrals();
      this.loadSavedReferrals();
    }
    window.addEventListener('online', async () => {
      await this.syncAllUnsyncedReferrals();
      this.loadSavedReferrals();
    });
  }

  ionViewWillEnter() {
    this.loadSavedReferrals();
  }

  private extractTable(master: any, tableName: string): any[] {
    if (!master) return [];
    if (Array.isArray(master.data)) {
      for (const item of master.data) if (item[tableName]) return item[tableName];
    }
    return master[tableName] || [];
  }




  /**  Sync all unsynced referrals */
  private async syncAllUnsyncedReferrals() {
     this.pouch.initDB('prms_referrals');

    const unsynced = this.referrals.filter(r => !r.synced);
    for (const referral of unsynced) {
      await this.syncWithBackend(referral);
    }
  }

  /**  API sync */
  private async syncWithBackend(referral: Referral) {
    const records = await lastValueFrom(this.pouchdbService.getAllRecords<Referral>());
    const unsynced = records.filter((r) => r.synced == false && r.consultationId === localStorage.getItem('consultationId'));
    console.log('unsynced', unsynced);

    for (const record of unsynced) {
      const token = localStorage.getItem('token') || '';

      const query =
        `?forwardto=${record.forwardto}` +
        `&action=${record.action}` +
        `&tblname=${record.tblname}` +
        `&domain=${record.domain}` +
        `&username=${record.username}` +
        `&patientId=${record.patientId}` +
        `&consultationId=${record.consultationId}` +
        `&referralId=0` +
        `&referralName=${encodeURIComponent(record.referralName)}` +
        `&referralNote=${encodeURIComponent(record.referralNote)}` +
        `&token=${encodeURIComponent(token)}`;

      try {
        const res: any = await lastValueFrom(this.apiService.postServiceByQueryBasic(this.constantService.APIConfig.GETCOMMONSERVICES, query));
        if (res.status === 'success') {
          console.log('Synced referral record:', record);
          record.synced = true;
          await lastValueFrom(this.pouchdbService.updateRecord(record));
        } else {
          console.warn('Sync failed:', res);
        }
      } catch (err) {
        console.error('Error syncing referral record:', err);
      }
    }
  }

  /**  Add or update referral */
  addReferral() {
    const formValue = this.referralForm.value;

    // Validation with warning dialog
    if (!formValue.selectedSpeciality?.trim()) {
      this.dialogService.warning('Please select a speciality.');
      return;
    }
    if (!formValue.referralNote?.trim()) {
      this.dialogService.warning('Please enter referral note.');
      return;
    }

    if (this.saving) return;

    this.saving = true;
    this.error = '';

   const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const consultationId = localStorage.getItem('consultationId') || '1';
    const loginResponse = JSON.parse( localStorage.getItem('LOGIN_RESPONSE') || '{}' );
    const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
    const domain = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
    const username = loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? '';
    const patientId = patientDetails.patientid || '';

    const referral: Referral = {
      referralName: formValue.selectedSpeciality,
      referralNote: formValue.referralNote,
      createdAt: new Date().toISOString(),
      type: 'referral',
      synced: false,
      domain: domain,
      action: 'savetoserver',
      patientId: patientId,
      consultationId: consultationId,
      username:username,
      paramName: 'referral',
      tblname: 'prms_referrals',
      token:token,
      forwardto: 'AndroidRemoteConsultaionSevices.do',

    };

    if (this.editingReferral) {
      referral._id = this.editingReferral._id;
    }

    const save$ = this.editingReferral
      ? this.pouchdb.updateRecord(referral)
      : this.pouchdb.addRecord(referral);

    save$.subscribe({
      next: () => {
        this.saving = false;
        this.message = this.editingReferral ? 'Referral updated!' : 'Referral saved!';
        this.resetForm();
        this.loadSavedReferrals();
        this.snackBar.open('Referral data saved successfully.', 'Close', { duration: 3000 });
      },
      error: err => {
        this.saving = false;
        this.error = `Error saving referral: ${err.message || err}`;
      }

    });
if (this.isMobile) this.closeModal();
  }

  /** ✅ Edit referral */
  editReferral(item: Referral) {
    this.editingReferral = item;
    this.referralForm.patchValue({
      selectedSpeciality: item.referralName,
      referralNote: item.referralNote
    });
  }


  /** ✅ Delete referral */
  deleteReferral(item: Referral) {
    if (!item._id) return;
    this.pouchdb.getRecordById<Referral>(item._id).subscribe({
      next: current => {
        this.pouchdb.deleteRecord(current).subscribe({
          next: () => {
            this.message = `Deleted "${item.referralName}" successfully!`;
            this.loadSavedReferrals();
            this.snackBar.open('Referral data deleted successfully.', 'Close', { duration: 3000 });
          },
          error: err => (this.error = `Error deleting referral: ${err.message || err}`)
        });
      },
      error: err => (this.error = `Error fetching referral for delete: ${err.message || err}`)
    });
  }

  private resetForm() {
    this.referralForm.reset();
    this.editingReferral = null;
  }

  loadSavedReferrals() {
       const consultationId = localStorage.getItem('consultationId') || '';
    console.log('consultationId', consultationId);
    this.pouchdb.getRecordsByType<Referral>('referral').subscribe({
      next: docs => {
    this.referrals = docs.filter(referrals => referrals.consultationId === consultationId);
      },
      error: err => (this.error = `Failed to load referrals: ${err.message || err}`)
    });
  }

  // Filter and Search Methods
  filterSpecialityList() {
    const input = this.referralForm.get('selectedSpeciality')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredSpecialityList = [...this.specialityList].sort((a, b) => (a.speciality || '').localeCompare(b.speciality || ''));
      return;
    }
    this.filteredSpecialityList = this.specialityList.filter(speciality =>
      speciality.speciality?.toLowerCase().includes(input)
    ).sort((a, b) => (a.speciality || '').localeCompare(b.speciality || ''));
  }

  selectSpeciality(speciality: Speciality) {
    this.referralForm.get('selectedSpeciality')?.setValue(speciality.speciality);
    this.showSpecialityDropdown = false;
  }

  hideSpecialityDropdown() {
    setTimeout(() => this.showSpecialityDropdown = false, 200);
  }
}
