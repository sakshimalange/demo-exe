import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { lastValueFrom } from 'rxjs';
import { PouchdbService } from '../../../../core/services/pouchdb.service';
import { PatientHistory } from '../../../../core/interfaces/localconsultation.model';
import { ApiService } from 'src/app/core/services/api.service';
import { ConstantService } from '../../../../core/services/constant.service';
import {DialogService } from 'src/app/core/services/dialog.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-patient-history',
  templateUrl: './patient-history.page.html',
  styleUrls: ['./patient-history.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, ReactiveFormsModule]
})
export class PatientHistoryPage implements OnInit {
  patientHistoryForm: FormGroup;
  saving = false;
  snackbarInterval: any;
  private activeSnackBarRef: any = null;

  constructor(
    private pouchdbService: PouchdbService,
    private formBuilder: FormBuilder,
    private apiService: ApiService,
    private constantService: ConstantService,
    private dialogService: DialogService
  ) {
    // Initialize the form group with all form controls.
    this.patientHistoryForm = this.formBuilder.group({
      historyOfPresentIllness: [''],
      personalHistory: [''],
      pastMedicalOrSurgicalHistory: [''],
      familyHistory: [''],
      currentAndRecentMedications: [''],
      medicalAllergies: [''],
      otherAllergiesOrSensitivities: [''],
      additionalNotes: [''],
      physicalExamination: [''],
      reviewNote: ['']
    });
  }

  async ngOnInit(): Promise<void> {
    // Initialize the PouchDB database for storing patient history records.
    this.pouchdbService.initDB('prms_patienthistory');

    // Load patient history data on component initialization, attempting API first.
    await this.loadPatientHistory();

    // Set up a listener to sync unsynced data when the device comes back online.
    window.addEventListener('online', () => this.syncUnsyncedHistories());
  }

  /**
   * Main method to load patient history, with API as the primary source
   * and PouchDB as a fallback.
   */
  async loadPatientHistory(): Promise<void> {
    const consultationId = localStorage.getItem('consultationId') || '';

    if (!consultationId) {
      console.error('Consultation ID not found in localStorage.');
      return;
    }

    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
    const domain = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
    const username = loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? '';
    const patientId = patientDetails.patientid || '';

    // Construct the API query string.
    const queryParams = `?&action=patienthistory` +
      `&domain=${domain}` +
      `&username=${username}` +
      `&patientId=${patientId}` +
      `&consultationId=${consultationId}` +
      `&token=${encodeURIComponent(token)}`;

    try {
      // 1. Attempt to fetch data from the API.
      const response: any = await lastValueFrom(
        this.apiService.get(this.constantService.APIConfig.GETCOMMONSERVICES, queryParams)
      );

      // Check for a successful response with data.
      if (response && response.status === 'success') {
        // Log the API response to help with debugging the data structure.
        console.log('API Response:', response);

        // Check if the 'data' key exists and is a valid object.
        if (response.data) {
          this.patchFormWithData(response.data);
          console.log('Successfully loaded patient history from API.');


          // Save the API response to PouchDB.
          await this.saveApiDataToPouchDB(response.data);
        } else {
          // The API call was successful, but there's no data.
          console.warn('API call succeeded, but no patient history data was returned. Falling back to local database.');

          await this.loadFromPouchDB();
        }
      } else {
        // If the API call itself reports a failure status.
        throw new Error('API status was not successful.');
      }
    } catch (error) {
      // 2. Fallback to PouchDB if the API call fails or has no data.
      console.error('API call failed, falling back to PouchDB...', error);

      await this.loadFromPouchDB();
    }
  }


  private async saveApiDataToPouchDB(apiData: any): Promise<void> {
    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const patientId = patientDetails.patientid || '';
    const consultationId = localStorage.getItem('consultationId') || '';

    if (!patientId || !consultationId) {
      console.error('Cannot save API data to PouchDB: Patient ID or Consultation ID is missing.');
      return;
    }

    // Create a PatientHistory object from the API data, setting synced to true.
    const newRecord: PatientHistory = {
      _id: `patient-history:${patientId}:${new Date().toISOString()}`,
      History_Of_Present_Illness: apiData.History_Of_Present_Illness,
      Personal_History: apiData.Personal_History,
      Past_Medical_Surgical_History: apiData.Past_Medical_Surgical_History,
      Family_History: apiData.Family_History,
      Current_And_Recent_Medications: apiData.Current_And_Recent_Medications,
      Medical_Allergies: apiData.Medical_Allergies,
      Other_Allergies_Or_Sensitivities: apiData.Other_Allergies_Or_Sensitivities,
      Additional_Notes: apiData.Additional_Notes,
      Physical_Examination: apiData.Physical_Examination,
      Review_Note: apiData.Review_Note,
      type: 'patient-history',
      createdAt: new Date().toISOString(),
      synced: true, // This record came from the server, so it's synced.
      domain: apiData.domain,
      action: apiData.action,
      patientId: apiData.patientId,
      consultationId: apiData.consultationId,
      username: apiData.username,
      paramName: apiData.paramName,
      token: apiData.token,
      forwardto: apiData.forwardto,
    };

    try {
      const existingRecord = await lastValueFrom(
        this.pouchdbService.getRecordsByType<PatientHistory>('patient-history')
      ).then(records => records.find(record => record.patientId === patientId));

      if (existingRecord) {
        // Update the existing record.
        newRecord._id = existingRecord._id;
        newRecord._rev = existingRecord._rev;
        await lastValueFrom(this.pouchdbService.updateRecord(newRecord));
        console.log('API data successfully updated in PouchDB.');
      } else {
        // Create a new record.
        await lastValueFrom(this.pouchdbService.addRecord(newRecord));
        console.log('API data successfully saved as a new record in PouchDB.');
      }
    } catch (error) {
      console.error('Error saving API data to PouchDB:', error);
    }
  }

  /**
   * Retrieves the most recent patient history from PouchDB for the given patient ID.
   */
  private async loadFromPouchDB(): Promise<void> {
    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const patientId = patientDetails.patientid || '';

    if (!patientId) {
      console.error('Patient ID not found in localStorage. Cannot load history from PouchDB.');
      return;
    }

    try {
      const allRecords = await lastValueFrom(
        this.pouchdbService.getRecordsByType<PatientHistory>('patient-history')
      );

      // Filter records by patient ID and sort by creation date to get the latest one.
      const lastRecord = allRecords
        .filter(record => record.patientId === patientId)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];

      if (lastRecord) {
        this.patchFormWithData(lastRecord);
        console.log('Successfully loaded patient history from PouchDB.');

      } else {
        console.log('No history found in PouchDB for this patient.');

      }
    } catch (error) {
      console.error('Error loading history from PouchDB:', error);

    }
  }


  private patchFormWithData(data: any): void {
    if (data) {
      this.patientHistoryForm.patchValue({
        historyOfPresentIllness: data.History_Of_Present_Illness || '',
        personalHistory: data.Personal_History || '',
        pastMedicalOrSurgicalHistory: data.Past_Medical_Surgical_History || '',
        familyHistory: data.Family_History || '',
        currentAndRecentMedications: data.Current_And_Recent_Medications || '',
        medicalAllergies: data.Medical_Allergies || '',
        otherAllergiesOrSensitivities: data.Other_Allergies_Or_Sensitivities || '',
        additionalNotes: data.Additional_Notes || '',
        physicalExamination: data.Physical_Examination || '',
        reviewNote: data.Review_Note || ''
      });
    } else {
      console.error('Data object is null or undefined, cannot patch form.');
    }
  }

  /**
   * Saves the current form data. It first saves to PouchDB, then attempts to sync to the API.
   */
  async onSave(): Promise<void> {
    if (this.saving) return;
    this.saving = true;

    const formValue = this.patientHistoryForm.value;
    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const consultationId = localStorage.getItem('consultationId') || '1';
    const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
    const domain = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
    const username = loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? '';
    const patientId = patientDetails.patientid || '';

    // Create a new history record object.
    const record: PatientHistory = {
      _id: `patient-history:${patientId}:${new Date().toISOString()}`,
      History_Of_Present_Illness: formValue.historyOfPresentIllness,
      Personal_History: formValue.personalHistory,
      Past_Medical_Surgical_History: formValue.pastMedicalOrSurgicalHistory,
      Family_History: formValue.familyHistory,
      Current_And_Recent_Medications: formValue.currentAndRecentMedications,
      Medical_Allergies: formValue.medicalAllergies,
      Other_Allergies_Or_Sensitivities: formValue.otherAllergiesOrSensitivities,
      Additional_Notes: formValue.additionalNotes,
      Physical_Examination: formValue.physicalExamination,
      Review_Note: formValue.reviewNote,
      type: 'patient-history',
      createdAt: new Date().toISOString(),
      synced: false,
      domain: domain,
      action: 'savepatienthistory',
      patientId: patientId,
      consultationId: consultationId,
      username: username,
      paramName: 'patient-history',
      token: token,
      forwardto: 'AndroidCommonWPServices.do',
    };

    try {
      // 1. Save the record to PouchDB first.
      await lastValueFrom(this.pouchdbService.addRecord(record));
      console.log('Patient history saved to PouchDB successfully.');
      this.dialogService.success('Patient history saved successfully.');

      // 2. Immediately attempt to sync this record if online.
      if (navigator.onLine) {
        await this.syncUnsyncedHistories();
        // After syncing, reload data to show the latest state.
        await this.loadPatientHistory();
      } else {

      }
    } catch (err) {
      console.error('Error saving record:', err);
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      this.dialogService.error(`Error saving record: ${errorMessage}`);
    } finally {
      this.saving = false;
    }
  }

  /**
   * Syncs all unsynced records from PouchDB to the server.
   */
  async syncUnsyncedHistories(): Promise<void> {
    if (!navigator.onLine) {
      console.log('Device is offline. Skipping API sync.');
      return;
    }
    console.log('Starting sync for unsynced records...');
    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const patientId = patientDetails.patientid || '';
    if (!patientId) {
      console.error('Patient ID not found in localStorage. Cannot sync.');
      return;
    }

    try {
      // Get all unsynced records from PouchDB for the current patient.
      const records = await lastValueFrom(this.pouchdbService.getRecordsByType<PatientHistory>('patient-history'));
      const unsyncedRecords = records.filter(record => !record.synced && record.patientId === patientId);

      if (unsyncedRecords.length === 0) {
        console.log('No unsynced records to sync.');
        return;
      }

      for (const record of unsyncedRecords) {
        await this.syncWithBackend(record);
      }

    } catch (error) {
      console.error('Error fetching unsynced records for sync:', error);

    }
  }

  private async syncWithBackend(history: PatientHistory): Promise<void> {
    const token = localStorage.getItem('token') || '';

    // Build the query string with all necessary parameters.
    const query =
      `?forwardto=${history.forwardto}` +
      `&action=${history.action}` +
      `&domain=${history.domain}` +
      `&username=${history.username}` +
      `&patientId=${history.patientId}` +
      `&consultationId=${history.consultationId}` +
      `&language=English` +
      `&History_Of_Present_Illness=${encodeURIComponent(history.History_Of_Present_Illness || '')}` +
      `&Personal_History=${encodeURIComponent(history.Personal_History || '')}` +
      `&Past_Medical_Surgical_History=${encodeURIComponent(history.Past_Medical_Surgical_History || '')}` +
      `&Family_History=${encodeURIComponent(history.Family_History || '')}` +
      `&Current_And_Recent_Medications=${encodeURIComponent(history.Current_And_Recent_Medications || '')}` +
      `&Medical_Allergies=${encodeURIComponent(history.Medical_Allergies || '')}` +
      `&Other_Allergies_Or_Sensitivities=${encodeURIComponent(history.Other_Allergies_Or_Sensitivities || '')}` +
      `&Additional_Notes=${encodeURIComponent(history.Additional_Notes || '')}` +
      `&Physical_Examination=${encodeURIComponent(history.Physical_Examination || '')}` +
      `&Review_Note=${encodeURIComponent(history.Review_Note || '')}` +
      `&token=${encodeURIComponent(token)}`;

    try {
      // Use the API service to post the data to the server.
      const response: any = await lastValueFrom(
        this.apiService.postServiceByQueryBasic(this.constantService.APIConfig.GETCOMMONSERVICES, query)
      );

      // Check for a successful sync response.
      if (response.status === 'success') {
        console.log('Successfully synced record to server:', history._id);
        history.synced = true;
        history._rev = response.rev || history._rev; // Update the revision number.
        await lastValueFrom(this.pouchdbService.updateRecord(history));
        console.log('Record updated in PouchDB as synced:', history._id);
        this.dialogService.success('Patient history synced successfully.');
      } else {
        console.warn('Server reported sync failure for record:', history._id, response);
        this.dialogService.error('Failed to sync patient history to server.');
      }
    } catch (error) {
      console.error('Error syncing record to server:', history._id, error);
      this.dialogService.error('Error syncing patient history to server.');
    }
  }

  async findDoctors(): Promise<void> {
    const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
    const domain = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '';

    const data = {
      forwardto: 'AndroidNurseWPServices.do',
      action: 'finddoctors',
      domain: domain,
      offset: '5:30',
      speciality: '',
      availdate: '9/04/2025',
      minfee: '',
      maxfee: '54000',
      minhrs: '9',
      maxhrs: '24',
      token: token
    };

    try {
      console.log('findDoctors API Params:', data);

      const response: any = await lastValueFrom(
        this.apiService.post('AndroidNurseWPServices.do', data, true, true)
      );

      console.log('API Response for findDoctors:', response);

      // You can add logic here to handle the response, e.g., display the doctors in a dialog.

    } catch (error) {
      console.error('Error fetching doctors:', error);
    }
  }


}
