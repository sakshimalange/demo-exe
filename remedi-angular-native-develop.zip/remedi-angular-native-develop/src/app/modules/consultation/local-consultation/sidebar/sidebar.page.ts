import { Component, Input } from '@angular/core';
import { IonicModule, IonIcon, IonContent } from '@ionic/angular';

import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [IonicModule, CommonModule],
  templateUrl: './sidebar.page.html',
  styleUrls: ['./sidebar.page.scss'],
})
export class SidebarPage {
selectedItem: string = 'dashboard'; // default selected
@Input() showSideBar = true;

  selectItem(item: string) {
    this.selectedItem = item;
  }

}
