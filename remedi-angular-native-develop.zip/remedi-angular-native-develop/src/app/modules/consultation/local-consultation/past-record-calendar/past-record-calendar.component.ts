import { Component, EventEmitter, Output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

interface CalendarDay {
  date: Date;
  day: number;
  isOtherMonth: boolean;
}

@Component({
  selector: 'app-past-record-calendar',
  templateUrl: './past-record-calendar.component.html',
  styleUrls: ['./past-record-calendar.component.scss'],
  standalone: true,
  imports: [CommonModule],
  
})
export class PastRecordCalendarComponent implements OnInit {
  @Output() dateRangeSelected = new EventEmitter<{start: Date, end: Date}>();
  @Output() calendarClosed = new EventEmitter<void>();

  currentDate = new Date();
  startDate: Date | null = null;
  endDate: Date | null = null;
  calendarDays: CalendarDay[] = [];
  private prevValue = { start: '', end: '' };
  
  weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  ngOnInit() {
    this.startDate = null;
    this.endDate = null;
    this.currentDate = new Date(); // Display the current month by default
    this.generateCalendarDays();
  }

  get currentMonthYear(): string {
    return this.currentDate.toLocaleString('default', { month: 'long', year: 'numeric' });
  }
  

  generateCalendarDays(): void {
    const year = this.currentDate.getFullYear();
    const month = this.currentDate.getMonth();
    
    // First day of the month
    const firstDay = new Date(year, month, 1);
    // Last day of the month
    const lastDay = new Date(year, month + 1, 0);
    
    // Start from the first day of the week containing the first day of the month
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - startDate.getDay());
    
    // End at the last day of the week containing the last day of the month
    const endDate = new Date(lastDay);
    endDate.setDate(endDate.getDate() + (6 - endDate.getDay()));
    
    this.calendarDays = [];
    const currentDate = new Date(startDate);
    
    while (currentDate <= endDate) {
      this.calendarDays.push({
        date: new Date(currentDate),
        day: currentDate.getDate(),
        isOtherMonth: currentDate.getMonth() !== month
      });
      currentDate.setDate(currentDate.getDate() + 1);
    }
  }

  previousMonth(): void {
    this.currentDate.setMonth(this.currentDate.getMonth() - 1);
    this.generateCalendarDays();
  }

  nextMonth(): void {
    this.currentDate.setMonth(this.currentDate.getMonth() + 1);
    this.generateCalendarDays();
  }

  selectDate(date: Date): void {
    // Past dates check can be improved to ignore time
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    

    if (!this.startDate || (this.startDate && this.endDate)) {
      this.startDate = date;
      this.endDate = null;
    } else if (date < this.startDate) {
      this.startDate = date; // Allow changing start date to an earlier one
    } else {
      this.endDate = date;
    }
  }

  isStartDate(date: Date): boolean {
    return this.startDate ? this.isSameDate(date, this.startDate) : false;
  }

  isEndDate(date: Date): boolean {
    return this.endDate ? this.isSameDate(date, this.endDate) : false;
  }

  isInRange(date: Date): boolean {
    if (!this.startDate || !this.endDate) {
      return false;
    }
    return date >= this.startDate && date <= this.endDate;
  }

  isToday(date: Date): boolean {
    const today = new Date();
    return this.isSameDate(date, today);
  }

  private isSameDate(date1: Date, date2: Date): boolean {
    return date1.getDate() === date2.getDate() &&
           date1.getMonth() === date2.getMonth() &&
           date1.getFullYear() === date2.getFullYear();
  }

  formatDisplayDate(date: Date | null): string {
    if (!date) {
      return ''; // Return an empty string for the input value
    }
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear().toString().slice(-2);
    return `${day}/${month}/${year}`;
  }

  confirmSelection(): void {
    if (this.startDate && this.endDate) {
      this.dateRangeSelected.emit({
        start: this.startDate,
        end: this.endDate
      });
      this.closeCalendar();
    }
  }
  handleDateInputChange(event: Event, type: 'start' | 'end'): void {
    const inputElement = event.target as HTMLInputElement;
    const value = inputElement.value;
    
    const parts = value.split('/');
    if (parts.length !== 3) return; // Invalid format

    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1; // JS month is 0-indexed
    const year = 2000 + parseInt(parts[2], 10); // Assuming year is 'YY'

    if (isNaN(day) || isNaN(month) || isNaN(year)) return;
    
    const newDate = new Date(year, month, day);

    // Validate the parsed date
    if (newDate.getFullYear() !== year || newDate.getMonth() !== month || newDate.getDate() !== day) {
      return;
    }

    if (type === 'start') {
      this.startDate = newDate;
      if (this.endDate && newDate > this.endDate) {
        this.endDate = null; // Clear end date if it's before the new start date
      }
    } else { // type === 'end'
      if (this.startDate && newDate < this.startDate) {
        // If end date is before start date, revert the input to its previous valid state
        inputElement.value = this.formatDisplayDate(this.endDate);
        return;
      }
      this.endDate = newDate;
    }
    
    // Navigate the calendar to show the month of the newly entered date
    this.currentDate = new Date(newDate.getFullYear(), newDate.getMonth(), 1);
    this.generateCalendarDays();
  }

  handleDateInput(event: Event, type: 'start' | 'end'): void {
    const inputElement = event.target as HTMLInputElement;
    const previousValue = this.prevValue[type];
    let value = inputElement.value;
  
    // 1. Sanitize: Remove any character that is not a number
    let sanitized = value.replace(/[^0-9]/g, '');
  
    // 2. Format: Automatically add slashes for DD/MM/YY format
    if (sanitized.length > 2) {
      sanitized = sanitized.slice(0, 2) + '/' + sanitized.slice(2);
    }
    if (sanitized.length > 5) {
      sanitized = sanitized.slice(0, 5) + '/' + sanitized.slice(5);
    }
    
    // 3. Update the input field value with the formatted string
    inputElement.value = sanitized;
    this.prevValue[type] = sanitized;
  
    // 4. Parse and update calendar state if the date is complete (DD/MM/YY)
    if (sanitized.length === 8) {
      const parts = sanitized.split('/');
      const day = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const year = 2000 + parseInt(parts[2], 10);
      const newDate = new Date(year, month, day);
  
      // Basic validation
      if (newDate.getFullYear() === year && newDate.getMonth() === month && newDate.getDate() === day) {
        if (type === 'start') {
          this.startDate = newDate;
          if (this.endDate && newDate > this.endDate) this.endDate = null;
        } else { // type === 'end'
          if (this.startDate && newDate >= this.startDate) {
            this.endDate = newDate;
          }
        }
        // Navigate calendar to the new date's month
        this.currentDate = new Date(newDate.getFullYear(), newDate.getMonth(), 1);
        this.generateCalendarDays();
      }
    }
  }
  closeCalendar(): void {
    this.calendarClosed.emit();
  }
}
