import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { lastValueFrom } from 'rxjs';
import { PouchdbService } from '../../../../core/services/pouchdb.service';
import { Medicine } from '../../../../core/interfaces/localconsultation.model';
import { ApiService } from '../../../../core/services/api.service';
import { ConstantService } from '../../../../core/services/constant.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { DialogService } from 'src/app/core/services/dialog.service';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';


@Component({
  selector: 'app-medicines',
  templateUrl: './medicines.page.html',
  styleUrls: ['./medicines.page.scss', '../diagnosis/diagnosis.page.scss', '../tabs/tabs.page.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule, MatSnackBarModule],
})
export class MedicinesPage implements OnInit {
  masterData: any = {};
  medicineList: any[] = [];
  drugFormList: any[] = [];
  medicinesList: any[] = [];
  instructionList: string[] = [
    'a minimum', 'a sparay', 'a sufficient quantity', 'after meals', 'apply',
    'arround the clock', 'as a large single dose', 'as directed', 'as needed',
    'as bedtime', 'at night', 'before meals', 'both ears', 'both eyes'
  ];
  dosageList: string[] = [
    '1 Tab', 'half Tab', 'quarter Tab', '2 Tab', '3 Tab', 'Tab 5', '0.5 ml', '0.1 ml'
  ];
  frequencyList: string[] = [
    '1-0-0', '0-1-0', '0-0-1', '1-1-0', '1-0-1', '0-1-1', '1-1-1',
    'daily one', 'twice a day', 'every after 4 hour', 'trice a day',
    'twice in a day', 'per day', '1'
  ];

  // Filtered arrays for search
  filteredDrugFormList: any[] = [];
  filteredMedicinesList: any[] = [];
  filteredInstructionsList: string[] = [];
  filteredDosageList: string[] = [];
  filteredFrequencyList: string[] = [];

  // Dropdown visibility flags
  showDrugFormDropdown = false;
  showMedicinesDropdown = false;
  showInstructionsDropdown = false;
  showDosageDropdown = false;
  showFrequencyDropdown = false;

  medicines: Medicine[] = [];
  medicineForm: FormGroup;

  saving = false;
  message = '';
  error = '';
  editingMedicine: Medicine | null = null;
  isMobile = false;
  isModalOpen = false;

  constructor(
    private http: HttpClient,
    private pouch: PouchdbService,
    private pouchdbService: PouchdbService,
    private formBuilder: FormBuilder,
    private apiService: ApiService,
    private constantService: ConstantService,
    private dialogService: DialogService,
    private snackBar: MatSnackBar,
  ) {
    this.medicineForm = this.formBuilder.group({
      drugForm: ['', Validators.required],
      name: ['', Validators.required],
      instructions: ['', Validators.required],
      dosage: ['', Validators.required],
      frequency: ['', Validators.required],
      days: [0, [Validators.required, Validators.min(1)]]
    });
  }

  async ngOnInit() {
    this.pouch.initDB('prms_medication');

    this.checkScreenSize();
    window.addEventListener('resize', () => this.checkScreenSize());

    this.loadSavedMedicines();
    this.checkNetworkAndSync();

 this.drugFormList = await this.pouchdbService.getTable('tbldrug_form');
    this.medicinesList = await this.pouchdbService.getTable('tblmedicinemaster');
    console.log('Patient drugFormList:', this.drugFormList);

    // Initialize filtered lists with ascending order sorting
    this.filteredDrugFormList = [...this.drugFormList].sort((a, b) => (a.Drug_Form || '').localeCompare(b.Drug_Form || ''));
    this.filteredMedicinesList = [...this.medicinesList].sort((a, b) => (a['Medicine(generic_Name)'] || '').localeCompare(b['Medicine(generic_Name)'] || ''));
    this.filteredInstructionsList = [...this.instructionList].sort((a, b) => a.localeCompare(b));
    this.filteredDosageList = [...this.dosageList].sort((a, b) => a.localeCompare(b));
    this.filteredFrequencyList = [...this.frequencyList].sort((a, b) => a.localeCompare(b));

  }

  checkScreenSize() {
    this.isMobile = window.innerWidth <= 500;
  }

  openModal() {
    this.isModalOpen = true;
  }
  closeModal() {
    this.isModalOpen = false;
    this.editingMedicine = null;
    this.medicineForm.reset({ days: 0 });
  }

  private checkNetworkAndSync() {
    if (navigator.onLine) {
      console.log('Device is online - Starting auto-sync for medicines...');
      this.syncAllUnsyncedMedicines();
    } else {
      console.log('Device is offline - Medicine sync will retry when online');
    }

    window.addEventListener('online', () => {
      console.log('Network restored - Starting auto-sync for medicines...');
      this.syncAllUnsyncedMedicines();
    });

    window.addEventListener('offline', () => {
      console.log('Network lost - Medicine data will be saved locally');
    });
  }


  /**  Add or  Update Medicine */
  saveMedicine() {
    const formValue = this.medicineForm.value;

    // Validation with snack bar
    if (!formValue.name?.trim()) {
      this.snackBar.open('Please enter medicine name.', 'Close', { duration: 3000 });
      return;
    }
    if (!formValue.instructions?.trim()) {
      this.snackBar.open('Please enter instructions.', 'Close', { duration: 3000 });
      return;
    }
    if (!formValue.dosage?.trim()) {
      this.snackBar.open('Please enter dosage.', 'Close', { duration: 3000 });
      return;
    }
    if (!formValue.frequency?.trim()) {
      this.snackBar.open('Please enter frequency.', 'Close', { duration: 3000 });
      return;
    }
    if (!formValue.days || formValue.days <= 0) {
      this.snackBar.open('Please enter number of days (must be greater than 0).', 'Close', { duration: 3000 });
      return;
    }

    if (this.saving) return;
    this.saving = true;
    this.error = '';
    this.message = '';

    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const consultationId = localStorage.getItem('consultationId') || '1';
    const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
    const domain = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
    const username = loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? '';
    const patientId = patientDetails.patientid || '';
    const data: Medicine = {
      Drug_Form: formValue.drugForm,
      freetext: formValue.name,
      specialInstruction: formValue.instructions,
      dose: formValue.dosage,
      frequency: formValue.frequency,
      numberOfDays: formValue.days,
      createdAt: new Date().toISOString(),
      type: 'medicine',
      synced: false,
      domain: domain,
      action: 'savetoserver',
      patientId: patientId,
      consultationId,
      username: username,
      usertype: 'Doctor',
      tblname: 'prms_medication',
      token: token,
      forwardto: 'AndroidRemoteConsultaionSevices.do',
    };

    if (this.editingMedicine && this.editingMedicine._id && this.editingMedicine._rev) {
      const updatedDoc = { ...this.editingMedicine, ...data };

      this.pouchdbService.updateRecord(updatedDoc).subscribe({
        next: () => this.finishAction(' Medicine updated!'),
        error: (err) => this.finishAction(' Failed to update medicine: ' + err.message, true),
      });
    } else {
      this.pouchdbService.addRecord(data).subscribe({
        next: () => this.finishAction(' Medicine added!'),
        error: (err) => this.finishAction(' Failed to add medicine: ' + err.message, true),
      });
    }
    if (this.isMobile) this.closeModal();
  }

  /**  Load all saved medicines */
  loadSavedMedicines() {
   const consultationId = localStorage.getItem('consultationId') || '';
    console.log('consultationId', consultationId);

    this.pouchdbService.getRecordsByType<Medicine>('medicine').subscribe({
      next: async (docs) => {
        this.medicines = docs.filter(medicine => medicine.consultationId === consultationId);
        console.log('Medicines Loaded for consultation ' + consultationId + ':', this.medicines);
        await this.syncAllUnsyncedMedicines();
      },
      error: (err) => {
        console.error(' Error loading medicines:', err);
        this.error = 'Failed to load medicines.';
      },
    });
  }

  /**  Edit medicine */
  editMedicine(item: Medicine) {
    this.editingMedicine = { ...item };
    this.medicineForm.patchValue({
      drugForm: item.Drug_Form,
      name: item.freetext,
      instructions: item.specialInstruction,
      dosage: item.dose,
      frequency: item.frequency,
      days: item.numberOfDays
    });
  }

  /**  Delete medicine */
  async deleteMedicine(item: Medicine) {
    if (!item._id) return;

    try {
      //  Fetch the latest document to get the current _rev before deleting
      const latestItem = await lastValueFrom(this.pouchdbService.getRecordById<Medicine>(item._id));
      this.pouchdbService.deleteRecord(latestItem).subscribe({
        next: () => {
          this.finishAction(' Medicine deleted!');
          this.snackBar.open('Medicine Data Deleted successfully.', 'Close', { duration: 3000 });
        },
        error: (err) => this.finishAction(' Failed to delete medicine: ' + err.message, true),
      });
    } catch (err) {
      this.finishAction(' Failed to delete medicine: ' + (err instanceof Error ? err.message : String(err)), true);
    }
  }

  /** Reset after save/update/delete */
  private finishAction(msg: string, isError = false) {
    this.saving = false;
    if (isError) {
      this.error = msg;

    } else {
      this.message = msg;

    }

    this.resetForm();
    this.loadSavedMedicines();
  }

  private resetForm() {
    this.medicineForm.reset();
    this.editingMedicine = null;
  }

  // --- Sync Code Added Below ---

  private async syncAllUnsyncedMedicines() {
    this.pouch.initDB('prms_medication');
    for (const medicine of this.medicines) {
      if (!medicine.synced) {
        await this.syncWithBackend(medicine);
      }
    }
  }

  private async syncWithBackend(medicine: Medicine) {


    this.pouch.getAllRecords<Medicine>().subscribe((records) => {
      const unsynced = records.filter((r) => !r.synced && r.consultationId === localStorage.getItem('consultationId'));
      console.log('unsynced', unsynced);

      unsynced.forEach((record) => {
        // Get auth + context values
        const token = localStorage.getItem('token') || '';


        const query =
          `?action=${medicine.action}` +
          `&domain=${medicine.domain}` +
          `&username=${medicine.username}` +
          `&usertype=${medicine.usertype}` +
          `&tblname=${medicine.tblname}` +

          `&frequency=${medicine.frequency}` +
          `&specialInstruction=${encodeURIComponent(medicine.specialInstruction || '')}` +
          `&dose=${encodeURIComponent(medicine.dose || '')}` +
          `&numberOfDays=${medicine.numberOfDays}` +
          `&medicine_Id=${medicine.freetext}` +

          `&patientId=${medicine.patientId}` +
          `&consultationId=${medicine.consultationId}` +
          `&token=${token}`;

        this.apiService.postServiceByQueryBasic(this.constantService.APIConfig.GETCOMMONSERVICES, query)
          .subscribe({
            next: (res: any) => {
              if (res.status === 'success') {
                console.log('Synced Counseling record:', record);
                record.synced = true;
                this.pouch.updateRecord(record).subscribe();
              } else {
                console.warn('Sync failed:', res);
              }
            },
            error: (err) => {
              console.error('Error syncing Counseling record:', err);
            },
          });
      });
    });
  }

  // Filter and Search Methods

  // Drug Form dropdown
  filterDrugFormList() {
    const input = this.medicineForm.get('drugForm')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredDrugFormList = [...this.drugFormList].sort((a, b) => (a.Drug_Form || '').localeCompare(b.Drug_Form || ''));
      return;
    }
    this.filteredDrugFormList = this.drugFormList.filter(form =>
      form.Drug_Form?.toLowerCase().includes(input)
    ).sort((a, b) => (a.Drug_Form || '').localeCompare(b.Drug_Form || ''));
  }

  selectDrugForm(form: any) {
    this.medicineForm.get('drugForm')?.setValue(form.Drug_Form);
    this.showDrugFormDropdown = false;
  }

  hideDrugFormDropdown() {
    setTimeout(() => this.showDrugFormDropdown = false, 200);
  }

  // Medicines dropdown
  filterMedicinesList() {
    const input = this.medicineForm.get('name')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredMedicinesList = [...this.medicinesList].sort((a, b) => (a['Medicine(generic_Name)'] || '').localeCompare(b['Medicine(generic_Name)'] || ''));
      return;
    }
    this.filteredMedicinesList = this.medicinesList.filter(medicine =>
      medicine['Medicine(generic_Name)']?.toLowerCase().includes(input)
    ).sort((a, b) => (a['Medicine(generic_Name)'] || '').localeCompare(b['Medicine(generic_Name)'] || ''));
  }

  selectMedicine(medicine: any) {
    this.medicineForm.get('name')?.setValue(medicine['Medicine(generic_Name)']);
    this.showMedicinesDropdown = false;
  }

  hideMedicinesDropdown() {
    setTimeout(() => this.showMedicinesDropdown = false, 200);
  }

  // Instructions dropdown
  filterInstructionsList() {
    const input = this.medicineForm.get('instructions')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredInstructionsList = [...this.instructionList].sort((a, b) => a.localeCompare(b));
      return;
    }
    this.filteredInstructionsList = this.instructionList.filter(instruction =>
      instruction.toLowerCase().includes(input)
    ).sort((a, b) => a.localeCompare(b));
  }

  selectInstruction(instruction: string) {
    this.medicineForm.get('instructions')?.setValue(instruction);
    this.showInstructionsDropdown = false;
  }

  hideInstructionsDropdown() {
    setTimeout(() => this.showInstructionsDropdown = false, 200);
  }

  // Dosage dropdown
  filterDosageList() {
    const input = this.medicineForm.get('dosage')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredDosageList = [...this.dosageList].sort((a, b) => a.localeCompare(b));
      return;
    }
    this.filteredDosageList = this.dosageList.filter(dosage =>
      dosage.toLowerCase().includes(input)
    ).sort((a, b) => a.localeCompare(b));
  }

  selectDosage(dosage: string) {
    this.medicineForm.get('dosage')?.setValue(dosage);
    this.showDosageDropdown = false;
  }

  hideDosageDropdown() {
    setTimeout(() => this.showDosageDropdown = false, 200);
  }

  // Frequency dropdown
  filterFrequencyList() {
    const input = this.medicineForm.get('frequency')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredFrequencyList = [...this.frequencyList].sort((a, b) => a.localeCompare(b));
      return;
    }
    this.filteredFrequencyList = this.frequencyList.filter(frequency =>
      frequency.toLowerCase().includes(input)
    ).sort((a, b) => a.localeCompare(b));
  }

  selectFrequency(frequency: string) {
    this.medicineForm.get('frequency')?.setValue(frequency);
    this.showFrequencyDropdown = false;
  }

  hideFrequencyDropdown() {
    setTimeout(() => this.showFrequencyDropdown = false, 200);
  }

}




