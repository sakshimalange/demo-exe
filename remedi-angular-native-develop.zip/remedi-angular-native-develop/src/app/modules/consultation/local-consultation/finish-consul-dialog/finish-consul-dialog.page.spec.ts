import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FinishConsulDialogPage } from './finish-consul-dialog.page';

describe('FinishConsulDialogPage', () => {
  let component: FinishConsulDialogPage;
  let fixture: ComponentFixture<FinishConsulDialogPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(FinishConsulDialogPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
