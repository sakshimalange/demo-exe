import { CommonModule } from '@angular/common';
import { FormGroup, FormsModule, Validators, FormBuilder,ReactiveFormsModule } from '@angular/forms';
import { IonicModule, ModalController } from '@ionic/angular';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { environment } from 'src/environments/environment';
import { DialogService } from 'src/app/core/services/dialog.service';
import { PouchdbService } from 'src/app/core/services/pouchdb.service';
import { ApiService } from 'src/app/core/services/api.service';
import { ConstantService } from 'src/app/core/services/constant.service';
import { NetworkService } from 'src/app/core/services/network.service';
import { AuthService } from 'src/app/core/services/auth.service';



@Component({
  selector: 'app-finish-consul-dialog',
  templateUrl: './finish-consul-dialog.page.html',
  styleUrls: ['./finish-consul-dialog.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, TranslateModule,ReactiveFormsModule],
})
export class FinishConsulDialogPage implements OnInit {
  print: boolean = true;
  mailReport: boolean = false;
  username: any;
  currDomainId: any;
  mailList: any;
  mailForm!: FormGroup;
  submitted: boolean = false;
  isMailChecked: boolean = false;
  consulID: any;
  patientID: any;
  tokenRequest: any;

  constructor(
    private modalCtrl: ModalController,
    private pouchdbService: PouchdbService,
    private authService: AuthService,
    private constantSvc: ConstantService,
    private apiSvc: ApiService,
    private networkService: NetworkService,
    private router: Router,
    private fb: FormBuilder,
    private dialog: MatDialog,
    private dialogService: DialogService,
    private dialogRef: MatDialogRef<FinishConsulDialogPage>
  ) {}

  ngOnInit(): void {
    this.createForm();
  }

  /** ✅ FIX: renamed to match template */
  confirmFinishDialog() {
    this.submitted = true;

    if (this.isMailChecked && this.mailForm.invalid) {
      return;
    }

    if (this.isMailChecked) {
      this.sendMail();
    } else {
      this.dialogRef.close({ val: 'finish', print: this.print });
    }
  }

  mailReportFunc(isChecked: boolean) {
    this.isMailChecked = isChecked;
    if (isChecked) {
      this.getMailList();
    }
  }

  getMailList() {
    const data =
      '?action=mailreporttopharmacy&domainId=' +
      this.currDomainId +
      '&username=' +
      this.username +
      '&token=' +
      this.tokenRequest;

    this.apiSvc.postServiceByQueryBasic(this.constantSvc.APIConfig.GETCOMMONSERVICES, data).subscribe((res: any) => {
      if (res.Result === 'OK') {
        this.mailList = res.Records;
      }
    });
  }

  get fc() {
    return this.mailForm.controls;
  }

  createForm() {
    this.mailForm = this.fb.group({
      pharmacyName: ['', Validators.required],
      phoneNumber: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      address: [''],
    });
  }

  sendMail() {
    const data =
      '?action=sendconsultationmail&pharmacymail=' +
      this.mailForm.value.pharmacyName +
      '&consultationId=' +
      this.consulID +
      '&patientId=' +
      this.patientID +
      '&patientphnentered=' +
      this.mailForm.value.phoneNumber +
      '&patientaddrentered=' +
      this.mailForm.value.address +
      '&domainId=' +
      this.currDomainId +
      '&offset=' +
      environment.getTimeOffSet() +
      '&token=' +
      this.tokenRequest;

    this.apiSvc.postServiceByQueryBasic(this.constantSvc.APIConfig.GETCOMMONSERVICES, data).subscribe(
      (res: any) => {
        if (res.status === 'success') {
          this.dialogRef.close({ val: 'finish', print: this.print });
        }
      },
      (err: any) => {
        console.error(err);
      }
    );
  }

  /** ✅ Close the modal manually */
  onDialogClose() {
    this.dialogRef.close();
  }
}
