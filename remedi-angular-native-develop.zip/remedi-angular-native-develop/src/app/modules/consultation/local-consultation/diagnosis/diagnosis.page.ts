import { Component, OnInit, Optional, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { IonicModule, LoadingController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, of, lastValueFrom } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { PouchdbService } from '../../../../core/services/pouchdb.service';
import { Diagnosis } from '../../../../core/interfaces/localconsultation.model';
import { ApiService } from '../../../../core/services/api.service';
import { ConstantService } from '../../../../core/services/constant.service';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { DialogService } from 'src/app/core/services/dialog.service';

interface MasterData {
  [key: string]: any;
}

@Component({
  selector: 'app-diagnosis',
  templateUrl: './diagnosis.page.html',
  styleUrls: ['./diagnosis.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, ReactiveFormsModule, MatSnackBarModule],
})
export class DiagnosisPage implements OnInit {
  masterData: any = {};
  diagnosisList: any[] = [];     // (your diagnosis items; you already populate it)
  chapterList: any[] = [];       // full chapters
  diagnosisForm: FormGroup;

  // All data from DB
  allSubChapters: any[] = [];    // full subchapter table
  categoryList: any[] = [];      // full category table

  // Filtered arrays used by template
  subChapterList: any[] = [];    // filtered subchapters (for the subchapter dropdown)
  subCategoryList: any[] = [];   // filtered categories (for the category dropdown)
  filteredDiagnosisList: any[] = [];

  // Filter/Search properties
  showDiagnosisDropdown = false;
  showChapterDropdown = false;
  showSubChapterDropdown = false;
  showCategoryDropdown = false;
  showChapterDiagnosisDropdown = false;

  // Filtered lists for search
  filteredDiagnosisListForSelect: any[] = [];
  filteredChapterList: any[] = [];
  filteredSubChapterList: any[] = [];
  filteredCategoryList: any[] = [];

  // extra (existing)
  diagnoses: Diagnosis[] = [];
  saving = false;
  message = '';
  error = '';
  editingDiagnosis: Diagnosis | null = null;
  isLocalConsultation: boolean = false;
  showForm: boolean = false; // Control form visibility
  showMobileCards: boolean = true; // Control mobile cards visibility
  isDialog: boolean = false;
  isMobile = false;
  isModalOpen = false;

  // Selected IDs (not strictly necessary but helpful)
  selectedChapterId: string = '';
  selectedSubChapterId: string = '';
  selectedCategoryId: string = '';
  selectedDiagnosisObject: any = null; // Store selected diagnosis object with ICD code

  constructor(
    private pouchdbService: PouchdbService,
    private http: HttpClient,
    private pouchdb: PouchdbService,
    private formBuilder: FormBuilder,
    private apiService: ApiService,
    private constantService: ConstantService,
    private dialog: MatDialog,
    private dialogService: DialogService,
    private snackBar: MatSnackBar,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any,
    @Optional() private dialogRef: MatDialogRef<DiagnosisPage>
  ) {
    this.isDialog = !!data;
    this.diagnosisForm = this.formBuilder.group({
      diagnosisMode: ['select'],
      selectedDiagnosis: [''],
      selectedChapter: [''],
      selectedSubChapter: [''],
      selectedSubCategory: [''],
      manualIcdCode: [''],
      isProvisional: [false],
    });
  }

  async ngOnInit() {
    this.pouchdbService.initDB('prms_diagnosis');

    this.checkScreenSize();
    window.addEventListener('resize', () => this.checkScreenSize());

    this.loadSavedDiagnoses();
    this.checkNetworkAndSync();

    // --- Load tables (full lists) ---
    this.diagnosisList = await this.pouchdbService.getTable('tbldiagnosismaster');
    console.log('Patient diagnosisList:', this.diagnosisList);

    this.chapterList = await this.pouchdbService.getTable('tbldiagnosischapter');
    console.log('Patient chapterList:', this.chapterList);

    this.allSubChapters = await this.pouchdbService.getTable('tbldiagnosissubchapter');
    console.log('Patient allSubChapters:', this.allSubChapters);


    this.categoryList = await this.pouchdbService.getTable('tbldiagnosiscategory');
    console.log('Patient categoryList (full):', this.categoryList);

    // initialize filtered arrays (the ones used in template)
    this.subChapterList = [];   // filtered subchapters
    this.subCategoryList = [];  // filtered categories

    // Initialize filtered lists for search with ascending order sorting
    this.filteredDiagnosisListForSelect = [...this.diagnosisList].sort((a, b) => (a.Name || '').localeCompare(b.Name || ''));
    this.filteredChapterList = [...this.chapterList].sort((a, b) => (a.chapter || '').localeCompare(b.chapter || ''));
    this.filteredSubChapterList = [...this.subChapterList];
    this.filteredCategoryList = [...this.subCategoryList];

    const flag = localStorage.getItem('isLocalConsultation') === 'true';
    this.isLocalConsultation = flag;

    // --- Subscribe to form control changes (reactive form) ---
    this.diagnosisForm.get('selectedChapter')?.valueChanges.subscribe((val) => {
      this.onChapterChange(val);
    });

    this.diagnosisForm.get('selectedSubChapter')?.valueChanges.subscribe((val) => {
      this.onSubChapterChange(val);
    });

    this.diagnosisForm.get('selectedSubCategory')?.valueChanges.subscribe(val => this.onCategoryChange(val));

    // Clear form data when diagnosis mode changes
    this.diagnosisForm.get('diagnosisMode')?.valueChanges.subscribe(() => {
      this.clearFormData();
    });
  }

  private clearFormData(): void {
    this.diagnosisForm.patchValue({
      selectedDiagnosis: '',
      selectedChapter: '',
      selectedSubChapter: '',
      selectedSubCategory: '',
      manualIcdCode: ''
    }, { emitEvent: false });

    // Reset filtered lists and selected diagnosis
    this.subChapterList = [];
    this.subCategoryList = [];
    this.filteredDiagnosisList = [];
    this.selectedDiagnosisObject = null;
  }

  labelMap: any = {
    select: 'Diagnosis',
    chapter: 'Chapter',
    manual: 'Manual Entry'
  };

  // Utility: robust comparison of ids (strings/numbers)
  private idEq(a: any, b: any): boolean {
    return String(a ?? '').trim() === String(b ?? '').trim();
  }

  // Called whenever chapter changes
  onChapterChange(eventOrValue: any) {
    // support both (change) event objects and direct values from valueChanges
    const chapterId = eventOrValue && eventOrValue.target ? eventOrValue.target.value : eventOrValue;

    this.selectedChapterId = chapterId ?? '';
    //  this.selectedChapterId = event.target.value;

    if (!chapterId) {
      // clear filtered lists and form controls for lower levels
      this.subChapterList = [];
      this.subCategoryList = [];
      this.diagnosisForm.patchValue({ selectedSubChapter: '', selectedSubCategory: '' }, { emitEvent: false });
      return;
    }

    // Filter subchapters for selected chapter using the full allSubChapters array
    this.subChapterList = this.allSubChapters.filter(sc =>
      this.idEq(sc.chapterid ?? sc.chapterId ?? sc.id, chapterId)
    ).sort((a, b) => (a.subchapter || '').localeCompare(b.subchapter || ''));

    // reset dependent selections
    this.subCategoryList = [];
    this.diagnosisForm.patchValue({ selectedSubChapter: '', selectedSubCategory: '' }, { emitEvent: false });
  }

  // Called when subchapter changes -> filter categories
  onSubChapterChange(eventOrValue: any) {
    const subChapterId = eventOrValue && eventOrValue.target ? eventOrValue.target.value : eventOrValue;
    this.selectedSubChapterId = subChapterId ?? '';

    if (!subChapterId) {
      this.subCategoryList = [];
      this.diagnosisForm.patchValue({ selectedSubCategory: '' }, { emitEvent: false });
      return;
    }

    // Filter categories using categoryList (full)
    this.subCategoryList = this.categoryList.filter(cat =>
      this.idEq(cat.subchapterid ?? cat.SubChapterId ?? cat.subChapter ?? cat.subchapter, subChapterId)
    ).sort((a, b) => (a.Category || '').localeCompare(b.Category || ''));

    // reset selected category
    this.diagnosisForm.patchValue({ selectedSubCategory: '' }, { emitEvent: false });
  }

    onCategoryChange(categoryId: any) {
    this.selectedCategoryId = categoryId ?? '';
    if (!categoryId) {
      this.filteredDiagnosisList = [];
      return;
    }

    this.filteredDiagnosisList = this.diagnosisList.filter(d =>
      this.idEq(d.Category_Id, categoryId) && d.IsDeleted === "0"
    ).sort((a, b) => (a.Name || '').localeCompare(b.Name || ''));

    console.log("Filtered Diagnosis List:", this.filteredDiagnosisList);
  }
  // ================= remaining methods unchanged =================

  checkScreenSize() {
    this.isMobile = window.innerWidth <= 500;
  }

  openModal() {
    this.isModalOpen = true;
  }
  closeModal() {
    this.isModalOpen = false;
    this.editingDiagnosis = null;
    this.diagnosisForm.reset({ days: 0 });
  }

  closeDialog() {
    if (this.isDialog) {
      this.dialogRef.close();
    }
  }
  private checkNetworkAndSync() {
    if (navigator.onLine) {
      console.log('Device is online - Starting auto-sync...');
      this.syncAllUnsyncedDiagnoses();
    } else {
      console.log('Device is offline - Sync will retry when online');
    }

    window.addEventListener('online', () => {
      console.log('Network restored - Starting auto-sync...');
      this.syncAllUnsyncedDiagnoses();
    });

    window.addEventListener('offline', () => {
      console.log('Network lost - Data will be saved locally');
    });
  }

  addDiagnosis() {
    const formValue = this.diagnosisForm.value;

    // Validation with warning dialog
    if (!formValue.selectedDiagnosis?.trim()) {
      this.dialogService.warning('Please enter a diagnosis before saving.');
      return;
    }

    if (formValue.diagnosisMode === 'chapter') {
      if (!formValue.selectedChapter?.trim() || !formValue.selectedSubChapter?.trim() || !formValue.selectedSubCategory?.trim()) {
        this.dialogService.warning('Please fill all required fields: Chapter, Sub Chapter, Category, and Diagnosis.');
        return;
      }
    }

    this.saving = true;
    this.error = '';
    this.message = '';

    const patientDetails = JSON.parse(
      localStorage.getItem('patientDetails') || '{}'
    );
    const consultationId = localStorage.getItem('consultationId') || '1';

    const loginResponse = JSON.parse(
      localStorage.getItem('LOGIN_RESPONSE') || '{}'
    );

    const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
    const domain =
      loginResponse.profiledetail?.domainId ??
      localStorage.getItem('domainId') ?? '0';
    const username =
      loginResponse.profiledetail?.userName ??
      localStorage.getItem('userName') ??
      '';

    const patientId = patientDetails.patientid || '';

    // Get ICD code from selected diagnosis or manual input
    let icdCode = '';
    if (formValue.diagnosisMode === 'manual' && formValue.manualIcdCode) {
      icdCode = formValue.manualIcdCode;
    } else if (this.selectedDiagnosisObject && this.selectedDiagnosisObject.ICD_CODE) {
      icdCode = this.selectedDiagnosisObject.ICD_CODE;
    } else {
      // Fallback: try to find diagnosis in list by name
      const foundDiagnosis = this.diagnosisList.find(d => d.Name === formValue.selectedDiagnosis);
      icdCode = foundDiagnosis ? foundDiagnosis.ICD_CODE : '';
    }

    const diagnosisData: Diagnosis = {
      icdCode: icdCode,
      freetext: formValue.selectedDiagnosis,
      isProvisional: formValue.isProvisional || false,
      createdAt: new Date().toISOString(),
      type: 'diagnosis',
      synced: false,
      domain: domain,
      action: 'savetoserver',
      patientId: patientId,
      consultationId: consultationId,
      username: username,
      paramName: 'diagnosis',
      tblname: 'prms_diagnosis',
      token: token,
      forwardto: 'AndroidRemoteConsultaionSevices.do',
    };

    if (
      this.editingDiagnosis &&
      this.editingDiagnosis._id &&
      this.editingDiagnosis._rev
    ) {
      const updatedDoc = { ...this.editingDiagnosis, ...diagnosisData };
      this.pouchdb.updateRecord(updatedDoc).subscribe({
        next: () => this.finishAction('Diagnosis updated!'),
        error: () => this.finishAction('Failed to update diagnosis', true),
      });
      this.snackBar.open('Diagnosis update successfully.', 'Close', { duration: 3000 });
    } else {
      this.pouchdb.addRecord(diagnosisData).subscribe({
        next: () => this.finishAction('Diagnosis saved!'),
        error: () => this.finishAction('Failed to save diagnosis', true),
      });
      this.snackBar.open('Diagnosis saved successfully.', 'Close', { duration: 3000 });
    }
  }

  editDiagnosis(item: Diagnosis) {
    this.editingDiagnosis = { ...item };
    this.diagnosisForm.patchValue({
      selectedDiagnosis: item.freetext,
      isProvisional: item.isProvisional,
      diagnosisMode: 'select',
    });
  }

  async deleteDiagnosis(item: Diagnosis) {
    if (!item._id) return;

    try {
      // ✅ Fetch the latest document to get the current _rev before deleting
      const latestItem = await lastValueFrom(this.pouchdbService.getRecordById<Diagnosis>(item._id));
      this.pouchdbService.deleteRecord(latestItem).subscribe({
        next: () => {
          this.finishAction('Diagnosis deleted!');
          this.dialogService.success('Diagnosis Data Deleted successfully.');
        },
        error: () => this.finishAction('Failed to delete diagnosis', true),
      });
    } catch (err) {
      this.finishAction('Failed to delete diagnosis', true);
    }
  }

  loadSavedDiagnoses() {
  const consultationId = localStorage.getItem('consultationId') || '';
    console.log('consultationId', consultationId);
    this.pouchdb.getRecordsByType<Diagnosis>('diagnosis').subscribe({
      next: async (docs) => {
        this.diagnoses = docs.filter(diagnosis => diagnosis.consultationId === consultationId);
        console.log('Diagnoses Loaded for patient ' + consultationId + ':', this.diagnoses);
        await this.syncAllUnsyncedDiagnoses();
      },
      error: (err) => {
        console.error('Error loading diagnoses:', err);
        this.error = 'Failed to load diagnoses.';
      },
    });
    if (this.isMobile) this.closeModal();
  }

  private async syncAllUnsyncedDiagnoses() {
    this.pouchdbService.initDB('prms_diagnosis');

    for (const diagnosis of this.diagnoses) {
      if (!diagnosis.synced) {
        await this.syncWithBackend(diagnosis);
      }
    }
  }

  private async syncWithBackend(diagnosis: Diagnosis) {
    // Get auth + context values
    const token = localStorage.getItem('token') || '';

    this.pouchdbService.getAllRecords<Diagnosis>().subscribe((records) => {
      const unsynced = records.filter(
        (r) =>
          r.synced == false &&
          r.consultationId === localStorage.getItem('consultationId')
      );
      console.log('unsynced', unsynced);

      unsynced.forEach((record) => {
        // Convert boolean 'isProvisional' to '1' or '0'
        const isProvisionalValue = diagnosis.isProvisional ? '1' : '0';

        const query =
          `?forwardto=${diagnosis.forwardto}` +
          `&action=${diagnosis.action}` +
          `&domain=${diagnosis.domain}` +
          `&username=${diagnosis.username}` +
          `&patientId=${diagnosis.patientId}` +
          `&consultationId=${diagnosis.consultationId}` +
          `&tblname=${diagnosis.tblname}` +
          `&icdCode=${encodeURIComponent(diagnosis.icdCode || '')}` +
          `&isProvisional=${isProvisionalValue}` +
          `&freetext=${encodeURIComponent(diagnosis.freetext || '')}` +
          `&token=${token}`;

        this.apiService
          .postServiceByQueryBasic(
            this.constantService.APIConfig.GETCOMMONSERVICES,
            query
          )
          .subscribe({
            next: (res: any) => {
              if (res.status === 'success') {
                console.log('Synced Diagnosis record:', record);
                record.synced = true;
                this.pouchdbService.updateRecord(record).subscribe();
              } else {
                console.warn('Sync failed:', res);
              }
            },
            error: (err) => {
              console.error(' Error syncing Diagnosis record:', err);
            },
          });
      });
    });
  }

  private finishAction(msg: string, isError = false): void {
    this.saving = false;
    if (isError) {
      this.error = msg;
    } else {
      this.message = msg;
    }

    this.resetForm();
    this.loadSavedDiagnoses();

    // Show mobile cards again after form submission
    this.showMobileCards = true;
    if (this.isDialog) {
      this.dialogRef.close();
    }
  }

  private resetForm(): void {
    this.diagnosisForm.reset({
      diagnosisMode: 'select',
      selectedDiagnosis: '',
      selectedChapter: '',
      selectedSubChapter: '',
      selectedSubCategory: '',
      manualIcdCode: '',
      isProvisional: false,
    });
    this.editingDiagnosis = null;
    this.selectedDiagnosisObject = null;
  }



  // Filter and Search Methods

  // Diagnosis dropdown (select mode)
  filterDiagnosisList() {
    const input = this.diagnosisForm.get('selectedDiagnosis')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredDiagnosisListForSelect = [...this.diagnosisList].sort((a, b) => (a.Name || '').localeCompare(b.Name || ''));
      return;
    }
    this.filteredDiagnosisListForSelect = this.diagnosisList.filter(d =>
      d.Name?.toLowerCase().includes(input)
    ).sort((a, b) => (a.Name || '').localeCompare(b.Name || ''));
  }

  selectDiagnosis(diagnosis: any) {
    this.diagnosisForm.get('selectedDiagnosis')?.setValue(diagnosis.Name);
    this.selectedDiagnosisObject = diagnosis; // Store the selected diagnosis object
    this.showDiagnosisDropdown = false;
  }

  hideDiagnosisDropdown() {
    setTimeout(() => this.showDiagnosisDropdown = false, 200);
  }

  // Chapter dropdown
  filterChapterList() {
    const input = this.diagnosisForm.get('selectedChapter')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredChapterList = [...this.chapterList].sort((a, b) => (a.chapter || '').localeCompare(b.chapter || ''));
      return;
    }
    this.filteredChapterList = this.chapterList.filter(c =>
      c.chapter?.toLowerCase().includes(input)
    ).sort((a, b) => (a.chapter || '').localeCompare(b.chapter || ''));
  }

  selectChapter(chapter: any) {
    this.diagnosisForm.get('selectedChapter')?.setValue(chapter.chapter);
    this.showChapterDropdown = false;
    this.onChapterChange(chapter.id);
  }

  hideChapterDropdown() {
    setTimeout(() => this.showChapterDropdown = false, 200);
  }

  // Sub Chapter dropdown
  filterSubChapterList() {
    const input = this.diagnosisForm.get('selectedSubChapter')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredSubChapterList = [...this.subChapterList].sort((a, b) => (a.subchapter || '').localeCompare(b.subchapter || ''));
      return;
    }
    this.filteredSubChapterList = this.subChapterList.filter(sc =>
      sc.subchapter?.toLowerCase().includes(input)
    ).sort((a, b) => (a.subchapter || '').localeCompare(b.subchapter || ''));
  }

  selectSubChapter(subChapter: any) {
    this.diagnosisForm.get('selectedSubChapter')?.setValue(subChapter.subchapter);
    this.showSubChapterDropdown = false;
    this.onSubChapterChange(subChapter.id);
  }

  hideSubChapterDropdown() {
    setTimeout(() => this.showSubChapterDropdown = false, 200);
  }

  // Category dropdown
  filterCategoryList() {
    const input = this.diagnosisForm.get('selectedSubCategory')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredCategoryList = [...this.subCategoryList].sort((a, b) => (a.Category || '').localeCompare(b.Category || ''));
      return;
    }
    this.filteredCategoryList = this.subCategoryList.filter(cat =>
      cat.Category?.toLowerCase().includes(input)
    ).sort((a, b) => (a.Category || '').localeCompare(b.Category || ''));
  }

  selectCategory(category: any) {
    this.diagnosisForm.get('selectedSubCategory')?.setValue(category.Category);
    this.showCategoryDropdown = false;
    this.onCategoryChange(category.Category_Id);
  }

  hideCategoryDropdown() {
    setTimeout(() => this.showCategoryDropdown = false, 200);
  }

  // Chapter diagnosis dropdown
  filterChapterDiagnosisList() {
    const input = this.diagnosisForm.get('selectedDiagnosis')?.value?.toLowerCase() || '';
    if (!input) {
      this.filteredDiagnosisList = [...this.diagnosisList].sort((a, b) => (a.Name || '').localeCompare(b.Name || ''));
      return;
    }
    this.filteredDiagnosisList = this.diagnosisList.filter(d =>
      d.Name?.toLowerCase().includes(input) && d.IsDeleted === "0"
    ).sort((a, b) => (a.Name || '').localeCompare(b.Name || ''));
  }

  selectChapterDiagnosis(diagnosis: any) {
    this.diagnosisForm.get('selectedDiagnosis')?.setValue(diagnosis.Name);
    this.selectedDiagnosisObject = diagnosis; // Store the selected diagnosis object
    this.showChapterDiagnosisDropdown = false;
  }

  hideChapterDiagnosisDropdown() {
    setTimeout(() => this.showChapterDiagnosisDropdown = false, 200);
  }

  // Initialize methods for focus handlers
  initializeSubChapterList() {
    this.filteredSubChapterList = [...this.subChapterList].sort((a, b) => (a.subchapter || '').localeCompare(b.subchapter || ''));
  }

  initializeCategoryList() {
    this.filteredCategoryList = [...this.subCategoryList].sort((a, b) => (a.Category || '').localeCompare(b.Category || ''));
  }

  initializeChapterDiagnosisList() {
    this.filteredDiagnosisList = this.diagnosisList.filter(d =>
      this.selectedCategoryId && this.idEq(d.Category_Id, this.selectedCategoryId) && d.IsDeleted === "0"
    ).sort((a, b) => (a.Name || '').localeCompare(b.Name || ''));
  }
}
