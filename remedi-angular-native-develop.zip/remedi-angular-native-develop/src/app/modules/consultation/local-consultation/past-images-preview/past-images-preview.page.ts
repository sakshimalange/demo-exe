import { Component, Inject, OnInit, Optional } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ConstantService } from 'src/app/core/services/constant.service';
import { ApiService } from 'src/app/core/services/api.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-past-images-preview',
  templateUrl: './past-images-preview.page.html',
  styleUrls: ['./past-images-preview.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class PastImagesPreviewPage implements OnInit {
  images: any[] = [];
  fetchedImages: any[] = [];
  comments: any[] = [];
  loading = false;
  tokenRequest: any;
  currentIndex = 0;
  zoomLevel = 1;
  newComment: string = '';
currentUser: string = '';
isTextareaFocused = false;
  usertype: any;
  constructor(
    @Optional() private dialogRef: MatDialogRef<PastImagesPreviewPage>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private constantSvc: ConstantService,
      private apiSvc: ApiService, 
       private authService: AuthService, 
  ) {}

  ngOnInit() {
    if (this.data?.images) {
      this.images = this.data.images;
      console.log('Received images in dialog:', this.images);
    }
 // ✅ Call API using passed data
    this.fetchMedicalImages();
     this.fetchComments();
    const loginResponse = JSON.parse(localStorage.getItem('USER') || '{}');
    this.currentUser = loginResponse?.name || '';
     this.usertype = loginResponse.commondetail?.usertype ?? localStorage.getItem('usertype') ?? '';
    console.log('Current user:', this.currentUser);
    
  }
 
  fetchMedicalImages() {
  const patientId = this.data?.patientId;
  const consultationId = this.data?.consultationId;
  console.log("🔍 Images before fetch:", this.images);

  const firstImage = Array.isArray(this.images) ? this.images[0] : this.images;
const imageTypeId = firstImage?.imageTypeId;
  const category = this.images?.[0]?.category || 'PAST_RECORD';
  
  this.tokenRequest = this.authService.getToken() || '';
  this.loading = true;

  console.log('Fetching images for:', { patientId, consultationId, imageTypeId, category });

  this.apiSvc.postServiceByQueryBasic(
    this.constantSvc.APIConfig.GETCOMMONSERVICES,
    `?action=medicalimagesbypatient&patientId=${patientId}&consultationId=${consultationId}&imageTypeId=${imageTypeId}&category=${category}&token=${this.tokenRequest}`
  ).subscribe({
   next: (response: any) => {
  const apiImages = response?.data || [];
  
  // Use the original image metadata if available
  const originalImages = Array.isArray(this.data.images) ? this.data.images : [this.data.images];
  
  // Merge API and original images intelligently
  this.fetchedImages = apiImages.length > 0 ? apiImages : originalImages;

  console.log("Original Image Metadata:", originalImages);
  console.log("Fetched Medical Images:", this.fetchedImages);
},

    error: (err) => console.error('Error fetching images:', err),
    complete: () => (this.loading = false)
  });
}


formatDateDisplay(dateString: string): string {
  if (!dateString) return '-';

  // Convert "27-Oct-2025 2:05 PM" to valid Date object
  const date = new Date(dateString.replace(/-/g, ' '));

  if (isNaN(date.getTime())) return dateString; // fallback

  const day = date.getDate();
  const month = date.toLocaleString('default', { month: 'long' }); // e.g. October
  const year = date.getFullYear();
  const time = date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

  // Get ordinal suffix (st, nd, rd, th)
  const getOrdinal = (n: number): string => {
    if (n > 3 && n < 21) return 'th';
    switch (n % 10) {
      case 1: return 'st';
      case 2: return 'nd';
      case 3: return 'rd';
      default: return 'th';
    }
  };

  const suffix = getOrdinal(day);

  return `${day}${suffix} ${month}, ${year} | ${time}`;
}


get firstImage() {
  return Array.isArray(this.data?.images) ? this.data.images[0] : this.data?.images;
}


fetchComments() {
  const patientId = this.data?.patientId;
  const consultationId = this.data?.consultationId;
  const currentSession = this.authService.getCurrentSession();
  const domain = currentSession?.domainId || '';
  const offset = environment.getTimeOffSet();
  const token = this.authService.getToken() || '';
const firstImage = Array.isArray(this.images) ? this.images[0] : this.images;
const imgName = firstImage?.imagePath || '';
const username = firstImage?.addedBy || '';
  const query = `?action=displayComment&consultationId=${consultationId}&userName=${username}&patientId=${patientId}&domain=${domain}&tblname=upload_media_comment&imgName=${imgName}&timeOffset=${offset}&paramName=displayComment&token=${token}`;

  console.log('Fetching comments with:', query);

  this.apiSvc.postServiceByQueryBasicSafe(this.constantSvc.APIConfig.GETCOMMONSERVICES, query)
    .subscribe({
      next: (res: any) => {
        console.log('✅ Comments response:', res);

        let parsedData: any[] = [];

        // 🧠 1️⃣ Handle no data case
        if (res.status === 'failure' || res.data === 'No data found!') {
          console.warn('⚠️ No comments found (failure status).');
          this.comments = [];
          return;
        }

        try {
          let messageText = res.message?.trim() || '';

          // 🧠 2️⃣ If message contains two JSONs like {...}{...}, take only the FIRST one
          if (messageText.includes('}{')) {
            const firstJson = messageText.substring(0, messageText.indexOf('}{') + 1);
            const obj = JSON.parse(firstJson);
            if (Array.isArray(obj.data)) {
              parsedData = obj.data;
            }
          } 
          // 🧠 3️⃣ Else, normal single JSON
          else if (messageText) {
            const obj = JSON.parse(messageText);
            if (Array.isArray(obj.data)) {
              parsedData = obj.data;
            }
          } 
          // 🧠 4️⃣ Fallback: maybe res.data already has array
          else if (Array.isArray(res.data)) {
            parsedData = res.data;
          }

        } catch (err) {
          console.error('❌ Failed to parse comment response:', err);
        }

        // 🧠 5️⃣ If still no data, show empty state
        if (!parsedData.length) {
          console.warn('⚠️ No valid comment data found after parsing.');
          this.comments = [];
          return;
        }

        // ✅ 6️⃣ Map data to UI model
        this.comments = parsedData.map((c: any) => ({
          author: c.doctorName || c.name || 'Unknown',
          timestamp: this.formatDateDisplay(c.commentdate || c.comment_date),
          text: c.comment
        }));

        console.log('🟩 Final Comments (first JSON only):', this.comments);
      },
      error: (err) => {
        console.error('Error fetching comments:', err);
        this.comments = [];
      }
    });
}


zoomIn() {
  // Cap the zoom so it doesn’t get too large
  if (this.zoomLevel < 2.5) {
    this.zoomLevel += 0.2;
  }
}

zoomOut() {
  // Keep a minimum zoom level so it doesn’t shrink too small
  if (this.zoomLevel > 0.5) {
    this.zoomLevel -= 0.2;
  }
}
imageWidth: number = 0;
imageHeight: number = 0;

onImageLoad(event: Event) {
  const img = event.target as HTMLImageElement;
this.imageWidth = Math.min(img.naturalWidth, 600);
this.imageHeight = Math.min(img.naturalHeight, 400);


  console.log('📏 Image natural size:', this.imageWidth, this.imageHeight);
}

onSubmitComment() {
  if (!this.newComment.trim()) return;

  const patientId = this.data?.patientId;
  const consultationId = this.data?.consultationId;
  const username = this.images?.[0]?.addedBy || '';
  const currentSession = this.authService.getCurrentSession();
  const domain = currentSession?.domainId || '';
  const offset = environment.getTimeOffSet();
  const imgName = this.images?.[0]?.imagePath || '';
  const token = this.authService.getToken() || '';

  const comment = encodeURIComponent(this.newComment.trim());
  const query = `?action=addComment&consultationId=${consultationId}&userName=${username}&patientId=${patientId}&domain=${domain}&tblname=upload_media_comment&imgName=${imgName}&timeOffset=${offset}&comment=${comment}&paranName=addComment&token=${token}`;

  console.log('🟢 Sending add comment request:', query);

  this.apiSvc.postServiceByQueryBasicSafe(this.constantSvc.APIConfig.GETCOMMONSERVICES, query)
    .subscribe({
      next: (res: any) => {
        console.log('✅ Comment added response:', res);

        // 🧠 If the API confirms the comment was saved, refresh comments
        if (res?.status === 'success') {
          this.newComment = ''; 
           this.isTextareaFocused = false;
          this.fetchComments(); // 🔁 fetch latest comments from backend
        } else {
          console.warn('⚠️ Comment API did not return success, keeping local add fallback.');
          // Optional fallback if API response format uncertain
          this.comments.unshift({
            author: username || 'You',
            timestamp: this.formatDateDisplay(new Date().toString()),
            text: this.newComment.trim()
          });
          this.newComment = '';
        }
      },
      error: (err) => {
        console.error('❌ Failed to add comment:', err);
      }
    });
}
 isUserComment(author: string): boolean {
    const normalizedAuthor = author.replace(/^(Dr\.?\s*|Doctor\s*)/i, '').toLowerCase();
    return normalizedAuthor === this.currentUser.toLowerCase();
  }

  onTextareaFocus() {
  this.isTextareaFocused = true;
}

onTextareaBlur() {
  // Only return to grey if comment box is empty
  if (!this.newComment?.trim()) {
    this.isTextareaFocused = false;
  }
}

  onDialogClose() {
    this.dialogRef?.close(false);
  }
}