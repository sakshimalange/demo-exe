import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { lastValueFrom } from 'rxjs';
import { PouchdbService } from '../../../../core/services/pouchdb.service';
import { Intervention } from '../../../../core/interfaces/localconsultation.model';
import { ApiService } from '../../../../core/services/api.service';
import { ConstantService } from '../../../../core/services/constant.service';
import { DialogService } from 'src/app/core/services/dialog.service';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerInputEvent, MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, provideNativeDateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';

export const MY_DATE_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};


@Component({
  selector: 'app-intervention',
  templateUrl: './intervention.page.html',
  styleUrls: ['./intervention.page.scss', '../tabs/tabs.page.scss', '../investigations/investigations.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    IonicModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatSnackBarModule
  ],
  providers: [
    provideNativeDateAdapter(),
    { provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS },
  ],
})
export class InterventionPage implements OnInit {
  interventions: Intervention[] = [];
  interventionForm: FormGroup;

  // editingIntervention: Intervention | null = null;
  saving = false;
  message = '';
  error = '';

  // isMobile = false;
  // isModalOpen = false;

  constructor(
    private pouchdb: PouchdbService,
    private formBuilder: FormBuilder,
    private apiService: ApiService,
    private constantService: ConstantService,
    private pouch: PouchdbService,
    private dialogService: DialogService,
    private snackBar: MatSnackBar
  ) {
    this.interventionForm = this.formBuilder.group({
      treatmentPlan: ['', Validators.required],
      clinicalObservations: ['', Validators.required],
      followUpDate: [''],
    });
  }

  async ngOnInit() {
    this.pouch.initDB('consultation_intervention');
    await this.loadInterventionData();
    this.checkNetworkAndSync();
  }

  // Method to get tomorrow's date for Material datepicker min attribute
  get minDate(): Date {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0); // Reset time to start of day
    return tomorrow;
  }

  onFollowUpDateChange(event: MatDatepickerInputEvent<Date>): void {
    const selectedDate = event.value;
    if (selectedDate) {
      this.interventionForm.patchValue({
        followUpDate: selectedDate
      });
    }
  }



  private checkNetworkAndSync() {
    if (navigator.onLine) {
      console.log(' Online - Starting intervention sync...');
      this.syncAllUnsyncedIntervention();
    }
    window.addEventListener('online', () => {
      console.log(' Back online - Syncing interventions...');
      this.syncAllUnsyncedIntervention();
    });
  }

  saveIntervention(): void {
    if (this.saving || this.interventionForm.invalid) return;
    this.saving = true;
    this.message = '';
    this.error = '';

    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const consultationId = localStorage.getItem('consultationId') || '1';
    const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
    const domain = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
    const username = loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? '';
    const patientId = patientDetails.patientid || '';

    const formValue = this.interventionForm.value;
    const data: Intervention = {
      Treatment_Plan: formValue.treatmentPlan,
      Clinical_Observations: formValue.clinicalObservations,
      Follow_Up_Schedule: formValue.followUpDate || null,
      createdAt: new Date().toISOString(),
      type: 'intervention',
      synced: false,
      domain: domain,
      action: 'savePRMSIntervention',
      patientId: patientId,
      consultationId: consultationId,
      username: username,
      paramName: 'intervention',
      tblname: 'prms_intervention',
      token: token,
      forwardto: 'AndroidRemoteConsultaionSevices.do', // Android-specific endpoint preserved
    };

    this.pouchdb.addRecord(data).subscribe({
      next: () => {
        this.finishAction(' Intervention saved!');
        this.snackBar.open('Intervention saved successfully.', 'Close', { duration: 3000 });
      },
      error: (err) => this.finishAction(' Failed to save intervention: ' + err.message, true),
    });
  }

  addIntervention() {
    this.saveIntervention();
  }

  // loadSavedInterventions() {
  //   const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
  //   const patientId = patientDetails.patientid || '';
  //   this.pouchdb.getRecordsByType<Intervention>('intervention').subscribe({
  //     next: (docs) => {
  //       this.interventions = docs.filter(intervention => intervention.patientId === patientId);
  //       console.log(' Interventions Loaded:', this.interventions);
  //       this.syncAllUnsyncedIntervention();
  //     },
  //     error: (err) => {
  //       console.error(' Error loading interventions:', err);
  //       this.error = 'Failed to load interventions.';
  //     },
  //   });
  // }




  private async syncAllUnsyncedIntervention() {
    this.pouch.initDB('consultation_intervention');
    const records = await lastValueFrom(this.pouchdb.getAllRecords<Intervention>());
    const unsyncedInterventions = records.filter((inv) => !inv.synced && inv.consultationId === localStorage.getItem('consultationId'));
    for (const intervention of unsyncedInterventions) {
      await this.syncWithBackend(intervention);
    }
  }

  private async syncWithBackend(intervention: Intervention) {
    const records = await lastValueFrom(this.pouchdb.getAllRecords<Intervention>());
    const unsynced = records.filter((r) => !r.synced && r.consultationId === localStorage.getItem('consultationId'));
    console.log('unsynced interventions', unsynced);

    for (const record of unsynced) {
      const token = localStorage.getItem('token') || '';

      const query =
        `?&action=${record.action}` +
        `&domain=${record.domain}` +
        `&username=${record.username}` +
        `&patientId=${record.patientId}` +
        `&consultationId=${record.consultationId}` +
        `&Treatment_Plan=${encodeURIComponent(record.Treatment_Plan)}` +
        `&Clinical_Observations=${encodeURIComponent(record.Clinical_Observations)}` +
        `&Follow_Up_Schedule=${encodeURIComponent(record.Follow_Up_Schedule || '')}`+
        `&token=${token}`+
        `&langObj=English`  ;

      try {
        const res: any = await lastValueFrom(this.apiService.postServiceByQueryBasic(this.constantService.APIConfig.GETCOMMONSERVICES, query));

        if (res.status === 'success') {
          console.log('Synced intervention record:', record);
          record.synced = true;
          await lastValueFrom(this.pouchdb.updateRecord(record));
        } else {
          console.warn('Intervention sync failed:', res);
        }
      } catch (err) {
        console.error('Error syncing intervention record:', err);
      }
    }
  }

  private async finishAction(msg: string, isError = false) {
    this.saving = false;
    if (isError) {
      this.error = msg;
      this.snackBar.open(msg, 'Close', { duration: 3000 });
    } else {
      this.message = msg;
    }

    this.resetForm();
    if (navigator.onLine) {
      await this.syncAllUnsyncedIntervention();
      await this.loadInterventionData();
    }
  }

  private resetForm() {
    this.interventionForm.reset();
  }

  async loadInterventionData(): Promise<void> {
    const consultationId = localStorage.getItem('consultationId') || '';
    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    const token = loginResponse.token ?? localStorage.getItem('token') ?? '';
    const domain = loginResponse.profiledetail?.domainId ?? localStorage.getItem('domainId') ?? '0';
    const username = loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? '';
    const patientId = patientDetails.patientid || '';

    const query = `?&action=getPRMSIntervention&username=${username}&domain=${domain}&patientId=${patientId}&consultationId=${consultationId}&language=English&token=${encodeURIComponent(token)}`;

    try {
      const response: any = await lastValueFrom(
        this.apiService.get(this.constantService.APIConfig.GETCOMMONSERVICES, query)
      );

      if (response && response.status === 'success') {
        if (response.data && Array.isArray(response.data) && response.data.length > 0) {
          // Merge all data objects into one
          const mergedData = response.data.reduce((acc: any, curr: any) => ({ ...acc, ...curr }), {});
          this.patchFormWithData(mergedData);
          await this.saveApiDataToPouchDB(mergedData);
        } else {
          await this.loadFromPouchDB();
        }
      } else {
        await this.loadFromPouchDB();
      }
    } catch (error) {
      console.error('API call failed, loading from PouchDB:', error);
      await this.loadFromPouchDB();
    }
  }

  private async saveApiDataToPouchDB(apiData: any): Promise<void> {
    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const consultationId = localStorage.getItem('consultationId') || '';
    const patientId = patientDetails.patientid || '';

    const record: Intervention = {
      _id: `intervention:${patientId}:${consultationId}`,
      Treatment_Plan: apiData.Treatment_Plan || '',
      Clinical_Observations: apiData.Clinical_Observations || '',
      Follow_Up_Schedule: apiData.Follow_Up_Schedule || null,
      type: 'intervention',
      createdAt: new Date().toISOString(),
      synced: true,
      domain: apiData.domain,
      action: 'getPRMSIntervention',
      patientId: patientId,
      consultationId: consultationId,
      username: apiData.username,
      paramName: 'intervention',
      tblname: 'prms_intervention',
      token: apiData.token,
      forwardto: 'AndroidRemoteConsultaionSevices.do'
    };

    try {
      const existingRecord = await lastValueFrom(
        this.pouchdb.getRecordsByType<Intervention>('intervention')
      ).then(records => records.find(r => r.patientId === patientId && r.consultationId === consultationId));

      if (existingRecord) {
        record._id = existingRecord._id;
        record._rev = existingRecord._rev;
        await lastValueFrom(this.pouchdb.updateRecord(record));
      } else {
        await lastValueFrom(this.pouchdb.addRecord(record));
      }
    } catch (error) {
      console.error('Error saving API data to PouchDB:', error);
    }
  }

  private async loadFromPouchDB(): Promise<void> {
    const patientDetails = JSON.parse(localStorage.getItem('patientDetails') || '{}');
    const consultationId = localStorage.getItem('consultationId') || '';
    const patientId = patientDetails.patientid || '';

    try {
      const records = await lastValueFrom(
        this.pouchdb.getRecordsByType<Intervention>('intervention')
      );

      const lastRecord = records
        .filter(r => r.patientId === patientId && r.consultationId === consultationId)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];

      if (lastRecord) {
        this.patchFormWithData(lastRecord);
      }
    } catch (error) {
      console.error('Error loading from PouchDB:', error);
    }
  }

  private patchFormWithData(data: any): void {
    if (data) {
      this.interventionForm.patchValue({
        treatmentPlan: data.Treatment_Plan || '',
        clinicalObservations: data.Clinical_Observations || '',
        followUpDate: data.Follow_Up_Schedule ? new Date(data.Follow_Up_Schedule) : null
      });
    }
  }
}
