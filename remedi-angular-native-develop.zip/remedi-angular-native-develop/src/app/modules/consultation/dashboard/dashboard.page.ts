import { Component, OnInit, OnDestroy } from '@angular/core';
import { IonicModule, AlertController } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { PatientinfoPage } from '../local-consultation/patientinfo/patientinfo.page';
import { NavbarPage } from '../navbar/navbar.page';
import { SessionDebugComponent } from '../../common/session-debug/session-debug.component';
import { AuthService } from 'src/app/core/services/auth.service';
import { Subscription, firstValueFrom } from 'rxjs';
import { DialogService } from 'src/app/core/services/dialog.service';
import { Router } from '@angular/router';
import { TokboxService, VideoCallState, TokboxRole } from 'src/app/core/services/tokbox.service';
import { DoctorConsultationApiService } from 'src/app/core/services/doctor-consultation-api.service';
import { ConstantService } from 'src/app/core/services/constant.service';
import { ApiService } from 'src/app/core/services/api.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonicModule,
    NavbarPage,
    PatientinfoPage,
    SessionDebugComponent
  ],
})
export class DashboardPage implements OnInit, OnDestroy {
  showDebugInfo = false;
  private dialogSub!: Subscription;

  // Video consultation properties
  showVideoConsultation: boolean = false;
  currentConsultation: any = null;
  isVideoCallActive: boolean = false;
  isAudioEnabled: boolean = true;
  isVideoEnabled: boolean = true;
  isLocalConsultation: boolean = false;
  videoState: VideoCallState = {
    isConnected: false,
    isPublishing: false,
    isSubscribing: false,
    connectionCount: 0
  };
  private stateSubscription: any;
  private heartbeatInterval: any;

  // ✅ New properties for device activation signaling
  private signalingSubscription: Subscription | null = null;
  kitActivated = false; // Tracks if the medical device kit has been activated
  activeDevices: Set<string> = new Set(); // Tracks which specific devices are currently active

  constructor(
    private authService: AuthService,
    private dialogService: DialogService,
    private alertController: AlertController,
    private router: Router,
    private tokboxService: TokboxService,
    private docApi: DoctorConsultationApiService,
    private constantSvc: ConstantService,
    private apiSvc: ApiService,
 
  ) {
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras.state as { appointment: any, consultationId: string };
    if (state && state.appointment) {
      this.currentConsultation = state.appointment;
    }
  }

  ngOnInit() {
    console.log('📊 Dashboard loaded');
    this.stateSubscription = this.tokboxService.videoCallState$.subscribe(
      (state: VideoCallState) => this.videoState = state
    );

    if (this.currentConsultation) {
      const consultationId = this.currentConsultation.consultationId || this.currentConsultation.consultation_id || this.currentConsultation.consId;
      if (consultationId) {
        this.joinConsultation(consultationId, this.currentConsultation);
      }
    }
    // this.apiSvc.patientData.subscribe((patientData) => {
    //   console.log("patientData", patientData);
    // })

    // Add listener for Parameters tab click from local consultation parameters page
    // This assumes an event or shared service triggers this method
    // For example, you can use a shared service or router event to detect tab clicks
  }

  ngOnDestroy() {
    // this.apiSvc.setPatientData(null);
    // this.apiSvc.patientData.unsubscribe();
    this.stateSubscription?.unsubscribe();
    if (this.isVideoCallActive) {
      this.tokboxService.disconnect();
    }
    // this.stopHeartbeat();
  }

  /** Orchestrated flow for “Join Consultation” button */
  async joinConsultation(consultationId: string | number, appointment: any) {
    // Switch to remote consultation mode to show video containers
      this.isLocalConsultation = false;
      localStorage.setItem('isLocalConsultation', 'false');
      sessionStorage.setItem('isLocalConsultation', 'false');
    try {
      this.showVideoConsultation = true;
      this.currentConsultation = {
        consultationId: consultationId,
        patientId: appointment.patientId || appointment.domainwiseid || appointment.patient_id,
        appointmentId: appointment.id || appointment.appointmentId,
        patientName: appointment.patientName || appointment.patient_name || 'Unknown Patient',
        appointment: appointment
      };

      // ✅ Store consultationId in localStorage for access by child components
      localStorage.setItem('consultationId', consultationId.toString());

      await this.connectToConsultation(consultationId);
      const wss = await this.getSignalingUrl(consultationId);
      console.log('Signaling WSS:', wss);

      await this.initWebRtc(consultationId);

      this.isVideoCallActive = true;
      // this.startHeartbeat(String(consultationId));

    
    } catch (error: any) {
      console.error('❌ Error joining consultation:', error);
      this.showVideoConsultation = false;
      this.currentConsultation = null;
      const alert = await this.alertController.create({
        header: 'Error',
        message: `Failed to join consultation: ${error.message}`,
        buttons: ['OK']
      });
      await alert.present();
    }
  }

  // All device activation and control now handled via nullwebsocket messages

  private getAuth() {
    const loginResponse = JSON.parse(localStorage.getItem('LOGIN_RESPONSE') || '{}');
    return {
      domainId: loginResponse.profiledetail?.domainId ?? localStorage.getItem('s3test2') ?? 's3test2',
      username: loginResponse.profiledetail?.userName ?? localStorage.getItem('userName') ?? 'rushikesh',
      token: loginResponse.token ?? localStorage.getItem('token') ?? '',
    };
  }

  async connectToConsultation(consultationId: string | number) {
    const { domainId, username, token } = this.getAuth();
    const res = await firstValueFrom(
      this.docApi.connectedConsultation({
        domain: domainId,
        consultationId,
        username,
        token
      })
    );
    if ((res?.status ?? res?.STATUS) !== 'success') {
      throw new Error(res?.message || res?.msg || 'Failed to connect consultation');
    }
    return res;
  }

  async getSignalingUrl(consultationId: string | number) {
    const { username, token } = this.getAuth();
    const res = await firstValueFrom(
      this.docApi.getWssUrl({ username, consultationId, token })
    );
    if ((res?.status ?? res?.STATUS) !== 'success') {
      throw new Error(res?.message || res?.msg || 'Failed to fetch WSS URL');
    }
    return res?.data?.['wssUrl'] || res?.['wssUrl'] || '';
  }

  async initWebRtc(consultationId: string | number) {
    const { token } = this.getAuth();
    const res = await firstValueFrom(
      this.docApi.getWebRtcCredentials({ consId: consultationId, token })
    );

    const status = res?.status ?? res?.STATUS;
    if (status !== 'success') {
      throw new Error(res?.message || res?.msg || 'Failed to get WebRTC credentials');
    }

    const creds = {
      API_KEY: res['API_KEY'] ?? res?.data?.['API_KEY'],
      SESSION_ID: res['SESSION_ID'] ?? res?.data?.['SESSION_ID'],
      TOKEN: res['TOKEN'] ?? res?.data?.['TOKEN'],
    };

    if (!creds.API_KEY || !creds.SESSION_ID || !creds.TOKEN) {
      throw new Error('Incomplete WebRTC credentials');
    }

    const role: TokboxRole = 'doctor'; // ✅ Set role as 'doctor' here for this page

    await this.tokboxService.initializeSession({
      API_KEY: creds.API_KEY,
      SESSION_ID: creds.SESSION_ID,
      TOKEN: creds.TOKEN,
      STATUS: status || ''
    }, role);

    await this.tokboxService.startPublishing(role, 'publisher-container');
  }

  endVideoCall() {
    this.tokboxService.disconnect();
    this.isVideoCallActive = false;
    this.showVideoConsultation = false;
    this.currentConsultation = null;
    // this.stopHeartbeat();
    this.router.navigate(['/doctor-dashboard']);
  }

  toggleAudio() {
    this.isAudioEnabled = this.tokboxService.toggleAudio();
  }

  toggleVideo() {
    this.isVideoEnabled = this.tokboxService.toggleVideo();
  }

  closeVideoConsultation() {
    if (this.isVideoCallActive) {
      this.endVideoCall();
    } else {
      this.showVideoConsultation = false;
      this.currentConsultation = null;
    }
  }

  // private startHeartbeat(consultationId: string) {
  //   this.stopHeartbeat();
  //   this.heartbeatInterval = setInterval(() => {
  //     const data = `action=18&consultationId=${consultationId}`;
  //     const url = this.constantSvc.APIConfig.GETCOMMONSERVICES.replace('RemediNovaDoctorAPI.do', 'pages/ConsultationServlet');
  //     firstValueFrom(this.apiSvc.postServiceByQuery(url, data));
  //   }, 4000);
  // }

  // private stopHeartbeat() {
  //   if (this.heartbeatInterval) {
  //     clearInterval(this.heartbeatInterval);
  //     this.heartbeatInterval = null;
  //   }
  // }

  toggleDebugInfo(): void {
    this.showDebugInfo = !this.showDebugInfo;
    console.log(' Debug info toggled:', this.showDebugInfo);
  }

  quickLogout(): void {
    console.log('🚪 Quick logout triggered');
    this.authService.logout().subscribe({
      next: () => console.log('✅ Quick logout successful'),
      error: (err) => console.error('❌ Quick logout error:', err)
    });
  }

 
  /**
   * Checks if a specific device is currently active
   *
   * @param deviceType - The device type to check
   * @returns boolean indicating if the device is active
   */
  isDeviceActive(deviceType: string): boolean {
    return this.activeDevices.has(deviceType);
  }
}
