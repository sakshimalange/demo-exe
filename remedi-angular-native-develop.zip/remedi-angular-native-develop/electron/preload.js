const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('electronAPI', {
  isElectron: true,
  platform: process.platform,
  version: process.versions.electron,
  writeFile: (fileName, base64Data) => ipcRenderer.invoke('write-file', fileName, base64Data),
  readFile: (fileName) => ipcRenderer.invoke('read-file', fileName),
  getStoragePath: () => ipcRenderer.invoke('get-storage-path'), // ✅ New
  openStorageFolder: () => ipcRenderer.invoke('open-storage-folder'), // ✅ New
  listFiles: () => ipcRenderer.invoke('list-files') // ✅ New

  // Add any additional IPC methods here if needed
  // For example:
  // sendMessage: (channel, data) => ipcRenderer.invoke(channel, data),
  // onMessage: (channel, func) => ipcRenderer.on(channel, func)
});