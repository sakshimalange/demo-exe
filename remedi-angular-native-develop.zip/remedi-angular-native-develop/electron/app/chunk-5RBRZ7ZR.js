import{a}from"./chunk-T72FF35D.js";import"./chunk-I3OTLJ7N.js";import"./chunk-PGTUUCJB.js";export{a as MedicalDeviceCommunicationPlugin};
