import{c as p}from"./chunk-I3OTLJ7N.js";var o=p("App",{web:()=>import("./chunk-D2OSFLAI.js").then(e=>new e.AppWeb)});export{o as a};
