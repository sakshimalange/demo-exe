import{b as a,c as b}from"./chunk-36VF6GFX.js";import"./chunk-PGTUUCJB.js";export{a as GESTURE_CONTROLLER,b as createGesture};
