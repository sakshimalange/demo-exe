import{aa as d}from"./chunk-5Y3XZB57.js";import{h as r}from"./chunk-PGTUUCJB.js";var u=(()=>{let n=class n{constructor(){this.symbols={success:"",error:"",warning:"",info:"\u2139"},this.activeDialogs=new Set,this.addModalStyles()}success(t,o="Success"){return r(this,null,function*(){yield this.showAlert({type:"success",message:t,title:o})})}error(t,o="Error"){return r(this,null,function*(){yield this.showAlert({type:"error",message:t,title:o})})}warning(t,o="Warning"){return r(this,null,function*(){yield this.showAlert({type:"warning",message:t,title:o})})}info(t,o="Information"){return r(this,null,function*(){yield this.showAlert({type:"info",message:t,title:o})})}confirm(t,o="Confirm"){return r(this,null,function*(){let a=`confirm-${t}`;return this.activeDialogs.has(a)?(console.log(`Confirm dialog already active for: ${a}`),!1):(this.activeDialogs.add(a),new Promise(i=>r(this,null,function*(){let e=this.createModal({type:"confirm",message:t,title:o}),l=e.querySelector(".modal-ok-btn"),p=e.querySelector(".modal-cancel-btn"),c=m=>{this.activeDialogs.delete(a),e.remove(),i(m)};l?.addEventListener("click",()=>c(!0)),p?.addEventListener("click",()=>c(!1)),document.body.appendChild(e)})))})}showAlert(t){return r(this,null,function*(){let o=`${t.type}-${t.message}`;if(this.activeDialogs.has(o)){console.log(`Dialog already active for: ${o}`);return}this.activeDialogs.add(o);let a=this.createModal(t),i=a.querySelector(".modal-close-btn"),e=()=>{this.activeDialogs.delete(o),a.remove()};i?.addEventListener("click",e),a.addEventListener("click",l=>{l.target===a&&e()}),document.body.appendChild(a)})}createModal(t){let o=t.type==="confirm",a=t.type!=="confirm"?this.symbols[t.type]:"\u2753",i=document.createElement("div");i.className="modal-overlay";let e="alert-wrapper";switch(t.type){case"success":e+=" success-dialog";break;case"error":e+=" error-dialog";break;case"warning":e+=" warning-dialog";break;case"info":e+=" info-dialog";break}return i.innerHTML=`
      <div class="${e}">
        <div class="alert-message">
          <p>${a} ${t.message}</p>
        </div>
        <div class="alert-button-group">
          ${o?`
            <button class="modal-button modal-cancel-btn alert-button" role="cancel">Cancel</button>
            <button class="modal-button modal-ok-btn alert-button">OK</button>
          `:`
            <button class="modal-button modal-close-btn alert-button">OK</button>
          `}
        </div>
      </div>
    `,i}addModalStyles(){let t="modal-styles";if(!document.getElementById(t)){let o=document.createElement("style");o.id=t,o.textContent=`
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          background-color: rgba(0, 0, 0, 0.5);
          z-index: 9999;
          animation: dialogFadeIn 0.3s ease-out;
        }
        .success-dialog,
        .error-dialog,
        .warning-dialog,
        .info-dialog {
          --background: #ffffff;
          --border-radius: 12px;
          --box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
          --backdrop-opacity: 0.6;
          --backdrop-color: rgba(0, 0, 0, 0.5);
        }

        .alert-wrapper {
          width: 398px !important;
          border-radius: 5px; /* \u2705 Changed from 12px to 5px as requested */
          overflow: hidden;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
          border: 1px solid rgba(0, 0, 0, 0.1);
          background: var(--background);
          border-color: var(--border-color);
          animation: dialogFadeIn 0.3s ease-out;
        }
        .alert-head {
          display: none !important;
        }
        .alert-message {
          padding: 20px 24px 16px;
          font-size: 16px;
          line-height: 1.5;
          color: #555;

        }
        .alert-button-group {
          padding: 0 24px 24px;
          display: flex;
          justify-content: flex-end;

          gap: 12px;
        }
        .alert-button {
          min-width: 78px !important;
          padding: 8px 26px !important;
          border-radius: 8px !important;
          font-size: 16px !important;
          font-weight: 500 !important;
          border: none !important;
          cursor: pointer !important;
          transition: all 0.3s ease !important;
        }
        .alert-button.activated {
          transform: scale(0.95) !important;
        }
        .alert-button[role="cancel"] {
          background-color: #f5f5f5 !important;
          color: #666 !important;
          border: 1px solid #ddd !important;
        }
        .alert-button[role="cancel"]:hover {
          background-color: #e0e0e0 !important;
        }
        .alert-button:not([role="cancel"]) {
          background-color: #007bff !important;
          color: white !important;
          border: 1px solid #007bff !important;
        }
        .alert-button:not([role="cancel"]):hover {
          background-color: #0056b3 ;
          border-color: #0056b3 !important;
        }
        @media (max-width: 480px) {
          .alert-wrapper {
            margin: 16px;
            max-width: calc(100vw - 32px);
          }
          .alert-title {
            font-size: 18px;
          }
          .alert-message {
            font-size: 14px;
          }
          .alert-button {
            min-width: 80px;
            padding: 10px 20px;
            font-size: 14px;
          }
        }
        @keyframes dialogFadeIn {
          from {
            opacity: 0;
            transform: scale(0.9);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
      `,document.head.appendChild(o)}}};n.\u0275fac=function(o){return new(o||n)},n.\u0275prov=d({token:n,factory:n.\u0275fac,providedIn:"root"});let s=n;return s})();export{u as a};
