import{a}from"./chunk-6SYM2GBX.js";import"./chunk-PGTUUCJB.js";export{a as startFocusVisible};
