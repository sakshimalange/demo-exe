import{a}from"./chunk-YFLYM54X.js";import"./chunk-I3OTLJ7N.js";import"./chunk-PGTUUCJB.js";export{a as NovaIcareLauncher};
