import{a as r}from"./chunk-MPTSO4CB.js";var n=()=>{if(r!==void 0)return r.Capacitor};export{n as a};
