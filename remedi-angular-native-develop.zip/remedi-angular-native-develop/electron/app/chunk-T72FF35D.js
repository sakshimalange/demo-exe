import{c as i}from"./chunk-I3OTLJ7N.js";var n=i("MedicalDeviceCommunicationPlugin");export{n as a};
