import{c as r}from"./chunk-I3OTLJ7N.js";var a=r("NovaIcareLauncherPlugin");export{a};
