// const { app, BrowserWindow, globalShortcut, session } = require('electron');
// const path = require('path');
// const fs = require('fs');

// function createWindow() {
//   const win = new BrowserWindow({
//     width: 1200,
//     height: 800,
//     webPreferences: {
//       contextIsolation: true,
//       nodeIntegration: false,
//       enableRemoteModule: false,
//       sandbox: false,
//       webSecurity: true,
//       allowRunningInsecureContent: false,
//       experimentalFeatures: false,
//       preload: path.join(__dirname, 'preload.js'), // Required for secure IPC
//       // Allow camera and microphone access for video calls
//       permissions: {
//         media: true
//       }
//    }
//   });


//   session.defaultSession.webRequest.onBeforeSendHeaders((details, callback) => {
//     details.requestHeaders['User-Agent'] = 'RemediElectronApp';
//     callback({ requestHeaders: details.requestHeaders });
//   });

//   session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
//     callback({
//       responseHeaders: {
//         ...details.responseHeaders
//       }
//     });
//   });

//   const indexPath = app.isPackaged
//     ? path.join(__dirname, '../www/index.html')
//     : 'http://localhost:4200';

//   console.log('Running in packaged mode:', app.isPackaged);
//   console.log('Index path:', indexPath);

//   if (app.isPackaged) {
//     if (fs.existsSync(indexPath)) {
//       console.log('index.html found at:', indexPath);
//       win.loadFile(indexPath).catch(err => console.error('Load error:', err));
//     } else {
//       console.error('index.html NOT FOUND at:', indexPath);
//     }
//   } else {
//     win.loadURL(indexPath).catch(err => console.error('Dev server load error:', err));
//   }

//   if (process.env.NODE_ENV === 'development') {
//     win.webContents.openDevTools();
//   }

//   win.webContents.session.setPermissionRequestHandler((webContents, permission, callback) => {
//     if (permission === 'media') {
//       callback(true);
//     } else {
//       callback(false);
//     }
//   });

//   win.webContents.on('did-finish-load', () => {
//     globalShortcut.register('Alt+Left', () => {
//       if (win.webContents.canGoBack()) win.webContents.goBack();
//     });

//     win.webContents.executeJavaScript(`
//       window.electronAPI = {
//         isElectron: true,
//         platform: '${process.platform}',
//         version: '${process.versions.electron}'
//       };
//     `);
//   });
// }

// app.whenReady().then(() => {
//   createWindow();

//   app.on('activate', () => {
//     if (BrowserWindow.getAllWindows().length === 0) createWindow();
//   });
// });

// app.on('window-all-closed', () => {
//   if (process.platform !== 'darwin') app.quit();
// });

// app.on('will-quit', () => {
//   globalShortcut.unregisterAll();
// });




const { ipcMain, app, BrowserWindow, globalShortcut, session } = require('electron');
const path = require('path');
const fs = require('fs');

// ✅ Get paths early
const userDataPath = app.getPath('userData');
const reportsDir = path.join(userDataPath, 'medical-reports');

// ✅ Create directory early
if (!fs.existsSync(reportsDir)) {
  fs.mkdirSync(reportsDir, { recursive: true });
  console.log('✅ Created reports directory');
}

// ✅ Register IPC handlers BEFORE app.whenReady()
ipcMain.handle('write-file', async (event, fileName, base64Data) => {
  try {
    const filePath = path.join(reportsDir, fileName);
    const buffer = Buffer.from(base64Data, 'base64');
    fs.writeFileSync(filePath, buffer);
    console.log('✅ File written successfully:', fileName);
    console.log('   Full path:', filePath);
    console.log('   Size:', buffer.length, 'bytes');
    return { success: true, path: filePath };
  } catch (error) {
    console.error('❌ Error writing file:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('read-file', async (event, fileName) => {
  try {
    const filePath = path.join(reportsDir, fileName);
    console.log('📖 Reading file from:', filePath);
    
    if (!fs.existsSync(filePath)) {
      throw new Error(`File not found: ${fileName}`);
    }
    
    const buffer = fs.readFileSync(filePath);
    console.log('✅ File read successfully, size:', buffer.length, 'bytes');
    return { success: true, data: buffer.toString('base64') };
  } catch (error) {
    console.error('❌ Error reading file:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-storage-path', async () => {
  return reportsDir;
});

ipcMain.handle('open-storage-folder', async () => {
  const { shell } = require('electron');
  shell.openPath(reportsDir);
  return { success: true };
});

ipcMain.handle('list-files', async () => {
  try {
    const files = fs.readdirSync(reportsDir);
    const fileDetails = files.map(file => {
      const filePath = path.join(reportsDir, file);
      const stats = fs.statSync(filePath);
      return {
        name: file,
        size: stats.size,
        created: stats.birthtime,
        modified: stats.mtime
      };
    });
    return { success: true, files: fileDetails };
  } catch (error) {
    return { success: false, error: error.message };
  }
});
function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    title: 'ReMeDi',
    icon: path.join(__dirname, '../src/assets/icon/Remedi-logo.png'),
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      enableRemoteModule: false,
      sandbox: false, // Disabled sandbox to allow camera/microphone access
      webSecurity: true,
      allowRunningInsecureContent: false,
      experimentalFeatures: false,
      preload: path.join(__dirname, 'preload.js'), // Required for secure IPC
      // Allow camera and microphone access for video calls
      permissions: {
        media: true
      }
    }
  });

  // Modify request headers (optional)
  session.defaultSession.webRequest.onBeforeSendHeaders((details, callback) => {
    details.requestHeaders['User-Agent'] = 'RemediElectronApp';
    callback({ requestHeaders: details.requestHeaders });
  });

  // Set a stricter Content Security Policy
  session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        // 'Content-Security-Policy': [
        //   "default-src 'self'; " +
        //   "script-src 'self'; " +
        //   "style-src 'self' 'unsafe-inline'; " +
        //   "img-src 'self' data:; " +
        //   "connect-src 'self'; " +
        //   "font-src 'self';"
        // ]
      }
    });
  });

  // Determine path to Angular index.html
  const indexPath = path.join(__dirname, '../www/index.html');

  // Check if index.html exists before loading
  if (fs.existsSync(indexPath)) {
    console.log('index.html found at:', indexPath);
    win.loadFile(indexPath).catch(err => console.error('Load error:', err));
  } else {
    console.error('index.html NOT FOUND at:', indexPath);
    // Fallback to Angular dev server in development
    if (!app.isPackaged) {
      win.loadURL('http://localhost:4200').catch(err => console.error('Dev server load error:', err));
    }
  }

  // Open DevTools only in development
  if (process.env.NODE_ENV === 'development') {
    win.webContents.openDevTools();
  }

  // Handle media permission requests for camera and microphone access
  win.webContents.session.setPermissionRequestHandler((webContents, permission, callback) => {
    if (permission === 'media') {
      // Grant permission for media access (camera and microphone)
      callback(true);
    } else {
      callback(false);
    }
  });

  // Navigation shortcut and electronAPI injection
  win.webContents.on('did-finish-load', () => {
    globalShortcut.register('Alt+Left', () => {
      if (win.webContents.canGoBack()) win.webContents.goBack();
    });

    win.webContents.executeJavaScript(`
      window.electronAPI = {
        isElectron: true,
        platform: '${process.platform}',
        version: '${process.versions.electron}'
      };
    `);
  });
}

app.whenReady().then(() => {
  // Get user data directory
const userDataPath = app.getPath('userData');
const reportsDir = path.join(userDataPath, 'medical-reports');
// Log on app start
console.log('==========================================');
console.log('📂 App User Data Path:', userDataPath);
console.log('📂 Medical Reports Directory:', reportsDir);
console.log('==========================================');


  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});