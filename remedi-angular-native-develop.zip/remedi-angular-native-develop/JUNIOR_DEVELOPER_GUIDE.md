# Medical Device Communication Solution - Junior Developer Guide

## 🎯 What This Solution Does

Imagine you have an Ionic app that needs to talk to medical devices like pulse oximeters, thermometers, and stethoscopes. But here's the challenge:

- **On Android**: We use a special app called "NovaICare" that connects to these devices
- **On Web/Desktop**: We use a server called "Jetty" that connects to these devices

This solution creates **ONE unified way** to talk to medical devices regardless of which platform you're on!

## 🏗️ The Big Picture Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Your Ionic App                           │
├─────────────────────────────────────────────────────────────┤
│  📱 Device Page (icare-device.page.ts)                     │
│  └── Calls: launchPulseOximeter()                          │
├─────────────────────────────────────────────────────────────┤
│  🎯 Master Service (medical-device-communication.service)   │
│  └── Decides: Android or Web?                              │
├─────────────────────────────────────────────────────────────┤
│  🤖 Android Path        │  🌐 Web Path                      │
│  AndroidIntentService   │  WebSocketDeviceService          │
│  └── Talks to NovaICare │  └── Talks to Jetty Server       │
├─────────────────────────────────────────────────────────────┤
│  📱 NovaICare App       │  🖥️ Jetty Server                  │
│  └── Connects to       │  └── Connects to                 │
│      Medical Device     │      Medical Device               │
└─────────────────────────────────────────────────────────────┘
```

## 📁 File Structure Explained

### 🎯 Core Files (The Brain)

```
src/app/core/
├── interfaces/
│   └── medical-device.interface.ts     ← Defines what data looks like
├── services/
│   ├── medical-device-communication.service.ts  ← The MASTER service
│   ├── platform-detector.service.ts             ← Detects Android/Web
│   ├── android-intent.service.ts                ← Handles Android
│   └── websocket-device.service.ts              ← Handles Web
├── config/
│   └── medical-device.config.ts                 ← All settings
└── plugins/
    └── medical-device-communication.plugin.ts   ← Bridge to Android
```

### 🤖 Android Files (Native Code)

```
android/app/src/main/java/io/ionic/starter/
├── services/
│   └── NovaICareIntentService.java      ← Smart Android service
├── plugins/
│   └── MedicalDeviceCommunicationPlugin.java  ← Capacitor plugin
└── MainActivity.java                    ← Updated main activity
```

## 🔍 Step-by-Step: How It Works

### Step 1: User Clicks "Launch Pulse Oximeter"

**File**: `src/app/modules/prms/ble-device/icare-device/icare-device.page.ts`

```typescript
async launchPulseOximeter(): Promise<void> {
  // This calls the master service
  await this.launchDevice(DeviceType.PULSE_OXIMETER, 'Pulse Oximeter');
}
```

**What happens**: User clicks a button, and this function runs.

### Step 2: Master Service Takes Control

**File**: `src/app/core/services/medical-device-communication.service.ts`

```typescript
async launchDevice(options: DeviceLaunchOptions): Promise<DeviceCommunicationResult> {
  // 1. Check what platform we're on
  if (!this.currentProvider) {
    throw new Error('No communication provider available');
  }
  
  // 2. Use the right provider (Android or Web)
  const result = await this.currentProvider.launchDevice(options);
  
  return result;
}
```

**What happens**: The master service decides whether to use Android intents or WebSocket.

### Step 3A: Android Path (If on Android)

**File**: `src/app/core/services/android-intent.service.ts`

```typescript
async launchDevice(options: DeviceLaunchOptions): Promise<DeviceCommunicationResult> {
  // 1. Create an Android Intent (like a message to another app)
  const intentConfig = MedicalDeviceConfig.getAndroidIntentConfig(options.deviceType);
  
  // 2. Launch NovaICare app
  const result = await this.executeAndroidIntent(intentParams);
  
  return result;
}
```

**What happens**: Creates an Android "Intent" (a message) to launch NovaICare app.

### Step 3B: Web Path (If on Web/Desktop)

**File**: `src/app/core/services/websocket-device.service.ts`

```typescript
async launchDevice(options: DeviceLaunchOptions): Promise<DeviceCommunicationResult> {
  // 1. Connect to Jetty server via WebSocket
  const connection = await this.getOrCreateConnection(options.deviceType);
  
  // 2. Send command to server
  const launchCommand = this.createLaunchCommand(options);
  connection.socket$.next(launchCommand);
  
  return result;
}
```

**What happens**: Connects to Jetty server using WebSocket and sends a command.

### Step 4: Getting Data Back

#### Android: NovaICare Returns Data

**File**: `android/app/src/main/java/io/ionic/starter/MainActivity.java`

```java
private void handleIncomingIntent(Intent intent) {
  // NovaICare sends data back via Intent
  if (intent.hasExtra("spo2") && intent.hasExtra("pulse_rate")) {
    String spo2 = intent.getStringExtra("spo2");
    String pulseRate = intent.getStringExtra("pulse_rate");
    
    // Send to our plugin
    MedicalDeviceCommunicationPlugin.instance.sendDeviceResult("PULSE_OXIMETER", data);
  }
}
```

**What happens**: NovaICare app finishes and sends data back to our app.

#### Web: Jetty Server Sends Data

**File**: `src/app/core/services/websocket-device.service.ts`

```typescript
private handleMessage(deviceType: DeviceType, message: any): void {
  // Server sends data via WebSocket
  const processedData = this.processDeviceData(deviceType, message.data);
  
  // Notify everyone who's listening
  this.deviceData$.next({
    success: true,
    data: processedData,
    deviceType,
    timestamp: Date.now()
  });
}
```

**What happens**: Jetty server sends data through WebSocket connection.

### Step 5: Display Data to User

**File**: `src/app/modules/prms/ble-device/icare-device/icare-device.page.ts`

```typescript
private handleDeviceData(data: DeviceCommunicationResult): void {
  if (data.success) {
    // Show the data to user
    this.showDeviceDataAlert(data);
  }
}

private showDeviceDataAlert(data: DeviceCommunicationResult): void {
  let message = `Device: ${data.deviceType}\n`;
  
  if (data.deviceType === DeviceType.PULSE_OXIMETER) {
    message += `SPO2: ${data.data.spo2}%\nPulse Rate: ${data.data.pulseRate} BPM`;
  }
  
  alert(message); // Show to user
}
```

**What happens**: Data is displayed to the user in a nice format.

## 🧩 Key Concepts Explained

### 1. What is an "Interface" in TypeScript?

**File**: `src/app/core/interfaces/medical-device.interface.ts`

```typescript
export interface PulseOximeterData {
  spo2: number;           // Oxygen saturation percentage
  pulseRate: number;      // Heart rate
  timestamp: number;      // When was this measured
  batteryLevel?: number;  // Optional: device battery level
}
```

**Think of it as**: A contract that says "any pulse oximeter data MUST have these fields."

### 2. What is a "Service" in Angular?

```typescript
@Injectable({
  providedIn: 'root'  // This means: create ONE instance for the whole app
})
export class MedicalDeviceCommunicationService {
  // This service can be used anywhere in the app
}
```

**Think of it as**: A helper that can be used by any component in your app.

### 3. What is an "Observable"?

```typescript
// This is like a TV channel - components can "subscribe" to watch for data
public deviceData$ = new BehaviorSubject<DeviceCommunicationResult | null>(null);

// Components subscribe like this:
this.medicalDeviceService.getDeviceDataObservable().subscribe(data => {
  console.log('New data arrived!', data);
});
```

**Think of it as**: A TV channel that broadcasts data. Components can "tune in" to receive updates.

### 4. What is an Android "Intent"?

```java
Intent intent = new Intent();
intent.setComponent(new ComponentName("com.neurosynaptic.nova_icare", "PulseOxiMeterSensor1"));
intent.putExtra("patient_id", "12345");
startActivityForResult(intent, REQUEST_CODE);
```

**Think of it as**: A message you send to another app saying "Hey, please do this task and send me the result back."

### 5. What is a "WebSocket"?

```typescript
const socket$ = webSocket({
  url: 'ws://localhost:8444/bleWS/',
  // This creates a real-time connection to the server
});

socket$.subscribe(message => {
  console.log('Server sent:', message);
});
```

**Think of it as**: A phone call between your app and the server - both can talk anytime.

## 🎯 How Each File Contributes

### 1. Platform Detection (`platform-detector.service.ts`)

**Purpose**: Figure out if we're on Android, Web, or Desktop

```typescript
get isAndroid(): boolean {
  return this.platform.is('android');
}

get isWeb(): boolean {
  return !this.isAndroid && !this.isElectron;
}
```

**Why we need it**: Different platforms need different approaches.

### 2. Configuration (`medical-device.config.ts`)

**Purpose**: Store all settings in one place

```typescript
static readonly NOVA_ICARE_ANDROID = {
  packageName: 'com.neurosynaptic.nova_icare',
  activityName: 'com.neurosynaptic.ble.sensors.PulseOxiMeterSensor1'
};
```

**Why we need it**: Easy to change settings without hunting through code.

### 3. Android Intent Service (`android-intent.service.ts`)

**Purpose**: Handle Android-specific communication

```typescript
async launchDevice(options: DeviceLaunchOptions) {
  // 1. Create Android intent
  // 2. Launch NovaICare app
  // 3. Wait for result
  // 4. Process and return data
}
```

**Why we need it**: Android has its own way of talking to other apps.

### 4. WebSocket Service (`websocket-device.service.ts`)

**Purpose**: Handle Web/Desktop communication

```typescript
async launchDevice(options: DeviceLaunchOptions) {
  // 1. Connect to Jetty server
  // 2. Send command
  // 3. Listen for data
  // 4. Process and return data
}
```

**Why we need it**: Web browsers can't launch other apps, so we use servers.

### 5. Master Service (`medical-device-communication.service.ts`)

**Purpose**: Provide ONE simple interface for everything

```typescript
async launchDevice(options: DeviceLaunchOptions) {
  // Automatically choose Android or Web approach
  return await this.currentProvider.launchDevice(options);
}
```

**Why we need it**: Components don't need to know about Android vs Web complexity.

## 🔧 How to Add a New Device Type

Let's say you want to add a "Blood Glucose Monitor":

### Step 1: Add to Interface

**File**: `src/app/core/interfaces/medical-device.interface.ts`

```typescript
export enum DeviceType {
  PULSE_OXIMETER = 'pulse_oximeter',
  BLOOD_GLUCOSE = 'blood_glucose',  // ← Add this
  // ... other devices
}

export interface BloodGlucoseData {  // ← Add this
  glucoseLevel: number;
  unit: 'mg/dL' | 'mmol/L';
  timestamp: number;
}
```

### Step 2: Add to Configuration

**File**: `src/app/core/config/medical-device.config.ts`

```typescript
static readonly ANDROID_DEVICE_INTENTS = {
  [DeviceType.BLOOD_GLUCOSE]: {  // ← Add this
    activityName: 'com.neurosynaptic.ble.sensors.BloodGlucoseSensor',
    extras: {
      DEVICE_TYPE: 'BLOOD_GLUCOSE',
      SENSOR_MODE: 'GLUCOSE_MEASUREMENT'
    }
  },
  // ... other devices
};
```

### Step 3: Add Processing Logic

**File**: `src/app/core/services/android-intent.service.ts`

```typescript
private processDeviceResult(deviceType: DeviceType, rawData: any): any {
  switch (deviceType) {
    case DeviceType.BLOOD_GLUCOSE:  // ← Add this
      return this.processBloodGlucoseData(rawData);
    // ... other cases
  }
}

private processBloodGlucoseData(data: any): BloodGlucoseData {  // ← Add this
  return {
    glucoseLevel: parseFloat(data.glucose_level) || 0,
    unit: data.unit || 'mg/dL',
    timestamp: Date.now()
  };
}
```

### Step 4: Add to UI

**File**: `src/app/modules/prms/ble-device/icare-device/icare-device.page.ts`

```typescript
async launchBloodGlucose(): Promise<void> {  // ← Add this
  await this.launchDevice(DeviceType.BLOOD_GLUCOSE, 'Blood Glucose Monitor');
}
```

**That's it!** The new device will work on both Android and Web automatically.

## 🐛 Common Issues and Solutions

### Issue 1: "No communication provider available"

**Cause**: Platform detection failed
**Solution**: Check if `PlatformDetectorService` is working

```typescript
// Debug in browser console:
console.log('Current platform:', this.medicalDeviceService.getCurrentPlatform());
```

### Issue 2: "NovaICare app is not installed"

**Cause**: NovaICare app missing on Android device
**Solution**: Install NovaICare app or add fallback

```typescript
// Check before launching:
const isAvailable = await MedicalDeviceCommunicationPlugin.isDeviceAvailable({
  deviceType: DeviceType.PULSE_OXIMETER
});
```

### Issue 3: "WebSocket connection failed"

**Cause**: Jetty server not running or wrong URL
**Solution**: Check server status and configuration

```typescript
// Check WebSocket URL in config:
console.log('WebSocket URL:', MedicalDeviceConfig.getWebSocketUrl(deviceType));
```

### Issue 4: "Data not received"

**Cause**: Not subscribed to data observable
**Solution**: Make sure you're listening for data

```typescript
// Always subscribe to data:
this.medicalDeviceService.getDeviceDataObservable().subscribe(data => {
  console.log('Data received:', data);
});
```

## 🧪 Testing Your Changes

### Test on Web Browser

1. Start the app: `npm start`
2. Go to: `http://localhost:4200/icare-device`
3. Click device buttons
4. Check browser console for logs

### Test on Android

1. Build the app: `ionic capacitor build android`
2. Install NovaICare app on device
3. Run your app on device
4. Test device launching

### Debug Logs

Add these to see what's happening:

```typescript
// In any service:
console.log('🔍 Debug:', { variable1, variable2 });

// In Android (Java):
Log.d("MyTag", "🔍 Debug: " + variable);
```

## 📚 Key Learning Points

### 1. **Separation of Concerns**
- Each service has ONE job
- Platform detection is separate from communication
- Configuration is separate from logic

### 2. **Abstraction**
- Components don't know about Android vs Web
- Master service hides complexity
- Interfaces define contracts

### 3. **Error Handling**
- Every async operation has try/catch
- User-friendly error messages
- Graceful degradation

### 4. **Observables Pattern**
- Data flows through observables
- Components subscribe to get updates
- Automatic cleanup prevents memory leaks

### 5. **Cross-Platform Strategy**
- One codebase, multiple platforms
- Platform-specific implementations
- Unified API for components

## 🎓 Next Steps for Learning

1. **Study RxJS Observables**: Learn about `subscribe`, `map`, `filter`
2. **Understand Android Intents**: Read Android documentation
3. **Learn WebSocket Protocol**: Understand real-time communication
4. **Practice TypeScript**: Master interfaces and types
5. **Explore Ionic/Capacitor**: Understand hybrid app development

## 💡 Pro Tips

### 1. Always Use TypeScript Types
```typescript
// ❌ Bad
function processData(data: any) { }

// ✅ Good
function processData(data: PulseOximeterData) { }
```

### 2. Handle Errors Gracefully
```typescript
// ❌ Bad
const result = await service.launchDevice(options);

// ✅ Good
try {
  const result = await service.launchDevice(options);
  if (!result.success) {
    this.showError(result.error);
  }
} catch (error) {
  this.showError('Unexpected error occurred');
}
```

### 3. Use Meaningful Names
```typescript
// ❌ Bad
const d = new Date();
const r = await svc.launch(opts);

// ✅ Good
const currentTimestamp = new Date();
const deviceResult = await medicalDeviceService.launchDevice(launchOptions);
```

### 4. Keep Functions Small
```typescript
// ❌ Bad: One giant function doing everything

// ✅ Good: Small functions with single responsibility
async launchDevice() {
  const options = this.prepareLaunchOptions();
  const result = await this.executeDeviceLaunch(options);
  this.handleDeviceResult(result);
}
```

This solution is like building a universal translator that speaks both "Android" and "Web" languages, so your medical device communication works everywhere! 🌟
